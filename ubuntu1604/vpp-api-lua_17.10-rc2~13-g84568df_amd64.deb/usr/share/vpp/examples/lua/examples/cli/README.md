This is a small experiment to have a wrapper CLI which can call both API functions as well as debug CLI.

To facilitate tab completion and help, the API call names are broken up with spaces replacing the underscores.


