#ifndef __included_acl_api_json
#define __included_acl_api_json

#include <stdlib.h>
#include <stddef.h>
#include <arpa/inet.h>
#include <vapi/vapi_internal.h>
#include <vapi/vapi.h>
#include <vapi/vapi_dbg.h>

#ifdef __cplusplus
extern "C" {
#endif
#include <vapi/vpe.api.vapi.h>

extern vapi_msg_id_t vapi_msg_id_acl_interface_add_del;
extern vapi_msg_id_t vapi_msg_id_acl_del;
extern vapi_msg_id_t vapi_msg_id_acl_interface_list_details;
extern vapi_msg_id_t vapi_msg_id_macip_acl_del_reply;
extern vapi_msg_id_t vapi_msg_id_macip_acl_del;
extern vapi_msg_id_t vapi_msg_id_macip_acl_interface_add_del_reply;
extern vapi_msg_id_t vapi_msg_id_acl_plugin_get_version;
extern vapi_msg_id_t vapi_msg_id_acl_add_replace_reply;
extern vapi_msg_id_t vapi_msg_id_macip_acl_details;
extern vapi_msg_id_t vapi_msg_id_macip_acl_interface_add_del;
extern vapi_msg_id_t vapi_msg_id_acl_plugin_control_ping_reply;
extern vapi_msg_id_t vapi_msg_id_acl_interface_set_acl_list;
extern vapi_msg_id_t vapi_msg_id_macip_acl_add_reply;
extern vapi_msg_id_t vapi_msg_id_macip_acl_add_replace_reply;
extern vapi_msg_id_t vapi_msg_id_acl_dump;
extern vapi_msg_id_t vapi_msg_id_acl_interface_list_dump;
extern vapi_msg_id_t vapi_msg_id_macip_acl_interface_list_dump;
extern vapi_msg_id_t vapi_msg_id_acl_del_reply;
extern vapi_msg_id_t vapi_msg_id_acl_add_replace;
extern vapi_msg_id_t vapi_msg_id_acl_interface_add_del_reply;
extern vapi_msg_id_t vapi_msg_id_acl_plugin_control_ping;
extern vapi_msg_id_t vapi_msg_id_macip_acl_interface_get;
extern vapi_msg_id_t vapi_msg_id_macip_acl_interface_list_details;
extern vapi_msg_id_t vapi_msg_id_macip_acl_add;
extern vapi_msg_id_t vapi_msg_id_macip_acl_add_replace;
extern vapi_msg_id_t vapi_msg_id_acl_interface_set_acl_list_reply;
extern vapi_msg_id_t vapi_msg_id_acl_plugin_get_version_reply;
extern vapi_msg_id_t vapi_msg_id_acl_details;
extern vapi_msg_id_t vapi_msg_id_macip_acl_dump;
extern vapi_msg_id_t vapi_msg_id_macip_acl_interface_get_reply;

#define DEFINE_VAPI_MSG_IDS_ACL_API_JSON\
  vapi_msg_id_t vapi_msg_id_acl_interface_add_del;\
  vapi_msg_id_t vapi_msg_id_acl_del;\
  vapi_msg_id_t vapi_msg_id_acl_interface_list_details;\
  vapi_msg_id_t vapi_msg_id_macip_acl_del_reply;\
  vapi_msg_id_t vapi_msg_id_macip_acl_del;\
  vapi_msg_id_t vapi_msg_id_macip_acl_interface_add_del_reply;\
  vapi_msg_id_t vapi_msg_id_acl_plugin_get_version;\
  vapi_msg_id_t vapi_msg_id_acl_add_replace_reply;\
  vapi_msg_id_t vapi_msg_id_macip_acl_details;\
  vapi_msg_id_t vapi_msg_id_macip_acl_interface_add_del;\
  vapi_msg_id_t vapi_msg_id_acl_plugin_control_ping_reply;\
  vapi_msg_id_t vapi_msg_id_acl_interface_set_acl_list;\
  vapi_msg_id_t vapi_msg_id_macip_acl_add_reply;\
  vapi_msg_id_t vapi_msg_id_macip_acl_add_replace_reply;\
  vapi_msg_id_t vapi_msg_id_acl_dump;\
  vapi_msg_id_t vapi_msg_id_acl_interface_list_dump;\
  vapi_msg_id_t vapi_msg_id_macip_acl_interface_list_dump;\
  vapi_msg_id_t vapi_msg_id_acl_del_reply;\
  vapi_msg_id_t vapi_msg_id_acl_add_replace;\
  vapi_msg_id_t vapi_msg_id_acl_interface_add_del_reply;\
  vapi_msg_id_t vapi_msg_id_acl_plugin_control_ping;\
  vapi_msg_id_t vapi_msg_id_macip_acl_interface_get;\
  vapi_msg_id_t vapi_msg_id_macip_acl_interface_list_details;\
  vapi_msg_id_t vapi_msg_id_macip_acl_add;\
  vapi_msg_id_t vapi_msg_id_macip_acl_add_replace;\
  vapi_msg_id_t vapi_msg_id_acl_interface_set_acl_list_reply;\
  vapi_msg_id_t vapi_msg_id_acl_plugin_get_version_reply;\
  vapi_msg_id_t vapi_msg_id_acl_details;\
  vapi_msg_id_t vapi_msg_id_macip_acl_dump;\
  vapi_msg_id_t vapi_msg_id_macip_acl_interface_get_reply;


typedef struct __attribute__((__packed__)) {
  u8 is_permit;
  u8 is_ipv6;
  u8 src_ip_addr[16];
  u8 src_ip_prefix_len;
  u8 dst_ip_addr[16];
  u8 dst_ip_prefix_len;
  u8 proto;
  u16 srcport_or_icmptype_first;
  u16 srcport_or_icmptype_last;
  u16 dstport_or_icmpcode_first;
  u16 dstport_or_icmpcode_last;
  u8 tcp_flags_mask;
  u8 tcp_flags_value;
} vapi_type_acl_rule;

typedef struct __attribute__((__packed__)) {
  u8 is_permit;
  u8 is_ipv6;
  u8 src_mac[6];
  u8 src_mac_mask[6];
  u8 src_ip_addr[16];
  u8 src_ip_prefix_len;
} vapi_type_macip_acl_rule;

typedef struct __attribute__ ((__packed__)) {
  u8 is_add;
  u8 is_input;
  u32 sw_if_index;
  u32 acl_index; 
} vapi_payload_acl_interface_add_del;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_acl_interface_add_del payload;
} vapi_msg_acl_interface_add_del;

typedef struct __attribute__ ((__packed__)) {
  u32 acl_index; 
} vapi_payload_acl_del;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_acl_del payload;
} vapi_msg_acl_del;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u8 count;
  u8 n_input;
  u32 acls[0]; 
} vapi_payload_acl_interface_list_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_acl_interface_list_details payload;
} vapi_msg_acl_interface_list_details;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_macip_acl_del_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_macip_acl_del_reply payload;
} vapi_msg_macip_acl_del_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 acl_index; 
} vapi_payload_macip_acl_del;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_macip_acl_del payload;
} vapi_msg_macip_acl_del;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_macip_acl_interface_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_macip_acl_interface_add_del_reply payload;
} vapi_msg_macip_acl_interface_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_acl_plugin_get_version;

typedef struct __attribute__ ((__packed__)) {
  u32 acl_index;
  i32 retval; 
} vapi_payload_acl_add_replace_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_acl_add_replace_reply payload;
} vapi_msg_acl_add_replace_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 acl_index;
  u8 tag[64];
  u32 count;
  vapi_type_macip_acl_rule r[0]; 
} vapi_payload_macip_acl_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_macip_acl_details payload;
} vapi_msg_macip_acl_details;

typedef struct __attribute__ ((__packed__)) {
  u8 is_add;
  u32 sw_if_index;
  u32 acl_index; 
} vapi_payload_macip_acl_interface_add_del;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_macip_acl_interface_add_del payload;
} vapi_msg_macip_acl_interface_add_del;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u32 client_index;
  u32 vpe_pid; 
} vapi_payload_acl_plugin_control_ping_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_acl_plugin_control_ping_reply payload;
} vapi_msg_acl_plugin_control_ping_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u8 count;
  u8 n_input;
  u32 acls[0]; 
} vapi_payload_acl_interface_set_acl_list;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_acl_interface_set_acl_list payload;
} vapi_msg_acl_interface_set_acl_list;

typedef struct __attribute__ ((__packed__)) {
  u32 acl_index;
  i32 retval; 
} vapi_payload_macip_acl_add_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_macip_acl_add_reply payload;
} vapi_msg_macip_acl_add_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 acl_index;
  i32 retval; 
} vapi_payload_macip_acl_add_replace_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_macip_acl_add_replace_reply payload;
} vapi_msg_macip_acl_add_replace_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 acl_index; 
} vapi_payload_acl_dump;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_acl_dump payload;
} vapi_msg_acl_dump;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index; 
} vapi_payload_acl_interface_list_dump;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_acl_interface_list_dump payload;
} vapi_msg_acl_interface_list_dump;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index; 
} vapi_payload_macip_acl_interface_list_dump;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_macip_acl_interface_list_dump payload;
} vapi_msg_macip_acl_interface_list_dump;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_acl_del_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_acl_del_reply payload;
} vapi_msg_acl_del_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 acl_index;
  u8 tag[64];
  u32 count;
  vapi_type_acl_rule r[0]; 
} vapi_payload_acl_add_replace;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_acl_add_replace payload;
} vapi_msg_acl_add_replace;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_acl_interface_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_acl_interface_add_del_reply payload;
} vapi_msg_acl_interface_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_acl_plugin_control_ping;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_macip_acl_interface_get;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u8 count;
  u32 acls[0]; 
} vapi_payload_macip_acl_interface_list_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_macip_acl_interface_list_details payload;
} vapi_msg_macip_acl_interface_list_details;

typedef struct __attribute__ ((__packed__)) {
  u8 tag[64];
  u32 count;
  vapi_type_macip_acl_rule r[0]; 
} vapi_payload_macip_acl_add;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_macip_acl_add payload;
} vapi_msg_macip_acl_add;

typedef struct __attribute__ ((__packed__)) {
  u32 acl_index;
  u8 tag[64];
  u32 count;
  vapi_type_macip_acl_rule r[0]; 
} vapi_payload_macip_acl_add_replace;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_macip_acl_add_replace payload;
} vapi_msg_macip_acl_add_replace;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_acl_interface_set_acl_list_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_acl_interface_set_acl_list_reply payload;
} vapi_msg_acl_interface_set_acl_list_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 major;
  u32 minor; 
} vapi_payload_acl_plugin_get_version_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_acl_plugin_get_version_reply payload;
} vapi_msg_acl_plugin_get_version_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 acl_index;
  u8 tag[64];
  u32 count;
  vapi_type_acl_rule r[0]; 
} vapi_payload_acl_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_acl_details payload;
} vapi_msg_acl_details;

typedef struct __attribute__ ((__packed__)) {
  u32 acl_index; 
} vapi_payload_macip_acl_dump;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_macip_acl_dump payload;
} vapi_msg_macip_acl_dump;

typedef struct __attribute__ ((__packed__)) {
  u32 count;
  u32 acls[0]; 
} vapi_payload_macip_acl_interface_get_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_macip_acl_interface_get_reply payload;
} vapi_msg_macip_acl_interface_get_reply;


static inline void vapi_type_acl_rule_hton(vapi_type_acl_rule *msg)
{
  msg->srcport_or_icmptype_first = htobe16(msg->srcport_or_icmptype_first);
  msg->srcport_or_icmptype_last = htobe16(msg->srcport_or_icmptype_last);
  msg->dstport_or_icmpcode_first = htobe16(msg->dstport_or_icmpcode_first);
  msg->dstport_or_icmpcode_last = htobe16(msg->dstport_or_icmpcode_last);
}

static inline void vapi_type_acl_rule_ntoh(vapi_type_acl_rule *msg)
{
  msg->srcport_or_icmptype_first = be16toh(msg->srcport_or_icmptype_first);
  msg->srcport_or_icmptype_last = be16toh(msg->srcport_or_icmptype_last);
  msg->dstport_or_icmpcode_first = be16toh(msg->dstport_or_icmpcode_first);
  msg->dstport_or_icmpcode_last = be16toh(msg->dstport_or_icmpcode_last);
}

static inline void vapi_type_macip_acl_rule_hton(vapi_type_macip_acl_rule *msg)
{

}

static inline void vapi_type_macip_acl_rule_ntoh(vapi_type_macip_acl_rule *msg)
{

}

static inline void vapi_msg_acl_interface_add_del_payload_hton(vapi_payload_acl_interface_add_del *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
  payload->acl_index = htobe32(payload->acl_index);
}

static inline void vapi_msg_acl_interface_add_del_payload_ntoh(vapi_payload_acl_interface_add_del *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
  payload->acl_index = be32toh(payload->acl_index);
}

static inline uword vapi_calc_acl_interface_add_del_msg_size(vapi_msg_acl_interface_add_del *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_acl_interface_add_del_hton(vapi_msg_acl_interface_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_acl_interface_add_del'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_acl_interface_add_del_payload_hton(&msg->payload);
}

static inline void vapi_msg_acl_interface_add_del_ntoh(vapi_msg_acl_interface_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_acl_interface_add_del'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_acl_interface_add_del_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_acl_del_payload_hton(vapi_payload_acl_del *payload)
{
  payload->acl_index = htobe32(payload->acl_index);
}

static inline void vapi_msg_acl_del_payload_ntoh(vapi_payload_acl_del *payload)
{
  payload->acl_index = be32toh(payload->acl_index);
}

static inline uword vapi_calc_acl_del_msg_size(vapi_msg_acl_del *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_acl_del_hton(vapi_msg_acl_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_acl_del'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_acl_del_payload_hton(&msg->payload);
}

static inline void vapi_msg_acl_del_ntoh(vapi_msg_acl_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_acl_del'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_acl_del_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_acl_interface_list_details_payload_hton(vapi_payload_acl_interface_list_details *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
  do { unsigned i; for (i = 0; i < payload->count; ++i) { payload->acls[i] = htobe32(payload->acls[i]); } } while(0);
}

static inline void vapi_msg_acl_interface_list_details_payload_ntoh(vapi_payload_acl_interface_list_details *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
  do { unsigned i; for (i = 0; i < payload->count; ++i) { payload->acls[i] = be32toh(payload->acls[i]); } } while(0);
}

static inline uword vapi_calc_acl_interface_list_details_msg_size(vapi_msg_acl_interface_list_details *msg)
{
  return sizeof(*msg)+ msg->payload.count * sizeof(msg->payload.acls[0]);
}

static inline void vapi_msg_acl_interface_list_details_hton(vapi_msg_acl_interface_list_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_acl_interface_list_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_acl_interface_list_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_acl_interface_list_details_ntoh(vapi_msg_acl_interface_list_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_acl_interface_list_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_acl_interface_list_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_macip_acl_del_reply_payload_hton(vapi_payload_macip_acl_del_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_macip_acl_del_reply_payload_ntoh(vapi_payload_macip_acl_del_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_macip_acl_del_reply_msg_size(vapi_msg_macip_acl_del_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_macip_acl_del_reply_hton(vapi_msg_macip_acl_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_macip_acl_del_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_macip_acl_del_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_macip_acl_del_reply_ntoh(vapi_msg_macip_acl_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_macip_acl_del_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_macip_acl_del_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_macip_acl_del_payload_hton(vapi_payload_macip_acl_del *payload)
{
  payload->acl_index = htobe32(payload->acl_index);
}

static inline void vapi_msg_macip_acl_del_payload_ntoh(vapi_payload_macip_acl_del *payload)
{
  payload->acl_index = be32toh(payload->acl_index);
}

static inline uword vapi_calc_macip_acl_del_msg_size(vapi_msg_macip_acl_del *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_macip_acl_del_hton(vapi_msg_macip_acl_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_macip_acl_del'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_macip_acl_del_payload_hton(&msg->payload);
}

static inline void vapi_msg_macip_acl_del_ntoh(vapi_msg_macip_acl_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_macip_acl_del'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_macip_acl_del_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_macip_acl_interface_add_del_reply_payload_hton(vapi_payload_macip_acl_interface_add_del_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_macip_acl_interface_add_del_reply_payload_ntoh(vapi_payload_macip_acl_interface_add_del_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_macip_acl_interface_add_del_reply_msg_size(vapi_msg_macip_acl_interface_add_del_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_macip_acl_interface_add_del_reply_hton(vapi_msg_macip_acl_interface_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_macip_acl_interface_add_del_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_macip_acl_interface_add_del_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_macip_acl_interface_add_del_reply_ntoh(vapi_msg_macip_acl_interface_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_macip_acl_interface_add_del_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_macip_acl_interface_add_del_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_acl_plugin_get_version_msg_size(vapi_msg_acl_plugin_get_version *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_acl_plugin_get_version_hton(vapi_msg_acl_plugin_get_version *msg)
{
  VAPI_DBG("Swapping `vapi_msg_acl_plugin_get_version'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_acl_plugin_get_version_ntoh(vapi_msg_acl_plugin_get_version *msg)
{
  VAPI_DBG("Swapping `vapi_msg_acl_plugin_get_version'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_acl_add_replace_reply_payload_hton(vapi_payload_acl_add_replace_reply *payload)
{
  payload->acl_index = htobe32(payload->acl_index);
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_acl_add_replace_reply_payload_ntoh(vapi_payload_acl_add_replace_reply *payload)
{
  payload->acl_index = be32toh(payload->acl_index);
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_acl_add_replace_reply_msg_size(vapi_msg_acl_add_replace_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_acl_add_replace_reply_hton(vapi_msg_acl_add_replace_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_acl_add_replace_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_acl_add_replace_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_acl_add_replace_reply_ntoh(vapi_msg_acl_add_replace_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_acl_add_replace_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_acl_add_replace_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_macip_acl_details_payload_hton(vapi_payload_macip_acl_details *payload)
{
  payload->acl_index = htobe32(payload->acl_index);
  payload->count = htobe32(payload->count);
}

static inline void vapi_msg_macip_acl_details_payload_ntoh(vapi_payload_macip_acl_details *payload)
{
  payload->acl_index = be32toh(payload->acl_index);
  payload->count = be32toh(payload->count);
}

static inline uword vapi_calc_macip_acl_details_msg_size(vapi_msg_macip_acl_details *msg)
{
  return sizeof(*msg)+ msg->payload.count * sizeof(msg->payload.r[0]);
}

static inline void vapi_msg_macip_acl_details_hton(vapi_msg_macip_acl_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_macip_acl_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_macip_acl_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_macip_acl_details_ntoh(vapi_msg_macip_acl_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_macip_acl_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_macip_acl_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_macip_acl_interface_add_del_payload_hton(vapi_payload_macip_acl_interface_add_del *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
  payload->acl_index = htobe32(payload->acl_index);
}

static inline void vapi_msg_macip_acl_interface_add_del_payload_ntoh(vapi_payload_macip_acl_interface_add_del *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
  payload->acl_index = be32toh(payload->acl_index);
}

static inline uword vapi_calc_macip_acl_interface_add_del_msg_size(vapi_msg_macip_acl_interface_add_del *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_macip_acl_interface_add_del_hton(vapi_msg_macip_acl_interface_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_macip_acl_interface_add_del'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_macip_acl_interface_add_del_payload_hton(&msg->payload);
}

static inline void vapi_msg_macip_acl_interface_add_del_ntoh(vapi_msg_macip_acl_interface_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_macip_acl_interface_add_del'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_macip_acl_interface_add_del_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_acl_plugin_control_ping_reply_payload_hton(vapi_payload_acl_plugin_control_ping_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->client_index = htobe32(payload->client_index);
  payload->vpe_pid = htobe32(payload->vpe_pid);
}

static inline void vapi_msg_acl_plugin_control_ping_reply_payload_ntoh(vapi_payload_acl_plugin_control_ping_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->client_index = be32toh(payload->client_index);
  payload->vpe_pid = be32toh(payload->vpe_pid);
}

static inline uword vapi_calc_acl_plugin_control_ping_reply_msg_size(vapi_msg_acl_plugin_control_ping_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_acl_plugin_control_ping_reply_hton(vapi_msg_acl_plugin_control_ping_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_acl_plugin_control_ping_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_acl_plugin_control_ping_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_acl_plugin_control_ping_reply_ntoh(vapi_msg_acl_plugin_control_ping_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_acl_plugin_control_ping_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_acl_plugin_control_ping_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_acl_interface_set_acl_list_payload_hton(vapi_payload_acl_interface_set_acl_list *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
  do { unsigned i; for (i = 0; i < payload->count; ++i) { payload->acls[i] = htobe32(payload->acls[i]); } } while(0);
}

static inline void vapi_msg_acl_interface_set_acl_list_payload_ntoh(vapi_payload_acl_interface_set_acl_list *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
  do { unsigned i; for (i = 0; i < payload->count; ++i) { payload->acls[i] = be32toh(payload->acls[i]); } } while(0);
}

static inline uword vapi_calc_acl_interface_set_acl_list_msg_size(vapi_msg_acl_interface_set_acl_list *msg)
{
  return sizeof(*msg)+ msg->payload.count * sizeof(msg->payload.acls[0]);
}

static inline void vapi_msg_acl_interface_set_acl_list_hton(vapi_msg_acl_interface_set_acl_list *msg)
{
  VAPI_DBG("Swapping `vapi_msg_acl_interface_set_acl_list'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_acl_interface_set_acl_list_payload_hton(&msg->payload);
}

static inline void vapi_msg_acl_interface_set_acl_list_ntoh(vapi_msg_acl_interface_set_acl_list *msg)
{
  VAPI_DBG("Swapping `vapi_msg_acl_interface_set_acl_list'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_acl_interface_set_acl_list_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_macip_acl_add_reply_payload_hton(vapi_payload_macip_acl_add_reply *payload)
{
  payload->acl_index = htobe32(payload->acl_index);
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_macip_acl_add_reply_payload_ntoh(vapi_payload_macip_acl_add_reply *payload)
{
  payload->acl_index = be32toh(payload->acl_index);
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_macip_acl_add_reply_msg_size(vapi_msg_macip_acl_add_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_macip_acl_add_reply_hton(vapi_msg_macip_acl_add_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_macip_acl_add_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_macip_acl_add_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_macip_acl_add_reply_ntoh(vapi_msg_macip_acl_add_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_macip_acl_add_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_macip_acl_add_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_macip_acl_add_replace_reply_payload_hton(vapi_payload_macip_acl_add_replace_reply *payload)
{
  payload->acl_index = htobe32(payload->acl_index);
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_macip_acl_add_replace_reply_payload_ntoh(vapi_payload_macip_acl_add_replace_reply *payload)
{
  payload->acl_index = be32toh(payload->acl_index);
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_macip_acl_add_replace_reply_msg_size(vapi_msg_macip_acl_add_replace_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_macip_acl_add_replace_reply_hton(vapi_msg_macip_acl_add_replace_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_macip_acl_add_replace_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_macip_acl_add_replace_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_macip_acl_add_replace_reply_ntoh(vapi_msg_macip_acl_add_replace_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_macip_acl_add_replace_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_macip_acl_add_replace_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_acl_dump_payload_hton(vapi_payload_acl_dump *payload)
{
  payload->acl_index = htobe32(payload->acl_index);
}

static inline void vapi_msg_acl_dump_payload_ntoh(vapi_payload_acl_dump *payload)
{
  payload->acl_index = be32toh(payload->acl_index);
}

static inline uword vapi_calc_acl_dump_msg_size(vapi_msg_acl_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_acl_dump_hton(vapi_msg_acl_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_acl_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_acl_dump_payload_hton(&msg->payload);
}

static inline void vapi_msg_acl_dump_ntoh(vapi_msg_acl_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_acl_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_acl_dump_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_acl_interface_list_dump_payload_hton(vapi_payload_acl_interface_list_dump *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_acl_interface_list_dump_payload_ntoh(vapi_payload_acl_interface_list_dump *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_acl_interface_list_dump_msg_size(vapi_msg_acl_interface_list_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_acl_interface_list_dump_hton(vapi_msg_acl_interface_list_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_acl_interface_list_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_acl_interface_list_dump_payload_hton(&msg->payload);
}

static inline void vapi_msg_acl_interface_list_dump_ntoh(vapi_msg_acl_interface_list_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_acl_interface_list_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_acl_interface_list_dump_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_macip_acl_interface_list_dump_payload_hton(vapi_payload_macip_acl_interface_list_dump *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_macip_acl_interface_list_dump_payload_ntoh(vapi_payload_macip_acl_interface_list_dump *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_macip_acl_interface_list_dump_msg_size(vapi_msg_macip_acl_interface_list_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_macip_acl_interface_list_dump_hton(vapi_msg_macip_acl_interface_list_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_macip_acl_interface_list_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_macip_acl_interface_list_dump_payload_hton(&msg->payload);
}

static inline void vapi_msg_macip_acl_interface_list_dump_ntoh(vapi_msg_macip_acl_interface_list_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_macip_acl_interface_list_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_macip_acl_interface_list_dump_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_acl_del_reply_payload_hton(vapi_payload_acl_del_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_acl_del_reply_payload_ntoh(vapi_payload_acl_del_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_acl_del_reply_msg_size(vapi_msg_acl_del_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_acl_del_reply_hton(vapi_msg_acl_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_acl_del_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_acl_del_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_acl_del_reply_ntoh(vapi_msg_acl_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_acl_del_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_acl_del_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_acl_add_replace_payload_hton(vapi_payload_acl_add_replace *payload)
{
  payload->acl_index = htobe32(payload->acl_index);
  payload->count = htobe32(payload->count);
  do { unsigned i; for (i = 0; i < be32toh(payload->count); ++i) { vapi_type_acl_rule_hton(&payload->r[i]); } } while(0);
}

static inline void vapi_msg_acl_add_replace_payload_ntoh(vapi_payload_acl_add_replace *payload)
{
  payload->acl_index = be32toh(payload->acl_index);
  payload->count = be32toh(payload->count);
  do { unsigned i; for (i = 0; i < payload->count; ++i) { vapi_type_acl_rule_ntoh(&payload->r[i]); } } while(0);
}

static inline uword vapi_calc_acl_add_replace_msg_size(vapi_msg_acl_add_replace *msg)
{
  return sizeof(*msg)+ msg->payload.count * sizeof(msg->payload.r[0]);
}

static inline void vapi_msg_acl_add_replace_hton(vapi_msg_acl_add_replace *msg)
{
  VAPI_DBG("Swapping `vapi_msg_acl_add_replace'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_acl_add_replace_payload_hton(&msg->payload);
}

static inline void vapi_msg_acl_add_replace_ntoh(vapi_msg_acl_add_replace *msg)
{
  VAPI_DBG("Swapping `vapi_msg_acl_add_replace'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_acl_add_replace_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_acl_interface_add_del_reply_payload_hton(vapi_payload_acl_interface_add_del_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_acl_interface_add_del_reply_payload_ntoh(vapi_payload_acl_interface_add_del_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_acl_interface_add_del_reply_msg_size(vapi_msg_acl_interface_add_del_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_acl_interface_add_del_reply_hton(vapi_msg_acl_interface_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_acl_interface_add_del_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_acl_interface_add_del_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_acl_interface_add_del_reply_ntoh(vapi_msg_acl_interface_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_acl_interface_add_del_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_acl_interface_add_del_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_acl_plugin_control_ping_msg_size(vapi_msg_acl_plugin_control_ping *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_acl_plugin_control_ping_hton(vapi_msg_acl_plugin_control_ping *msg)
{
  VAPI_DBG("Swapping `vapi_msg_acl_plugin_control_ping'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_acl_plugin_control_ping_ntoh(vapi_msg_acl_plugin_control_ping *msg)
{
  VAPI_DBG("Swapping `vapi_msg_acl_plugin_control_ping'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline uword vapi_calc_macip_acl_interface_get_msg_size(vapi_msg_macip_acl_interface_get *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_macip_acl_interface_get_hton(vapi_msg_macip_acl_interface_get *msg)
{
  VAPI_DBG("Swapping `vapi_msg_macip_acl_interface_get'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_macip_acl_interface_get_ntoh(vapi_msg_macip_acl_interface_get *msg)
{
  VAPI_DBG("Swapping `vapi_msg_macip_acl_interface_get'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_macip_acl_interface_list_details_payload_hton(vapi_payload_macip_acl_interface_list_details *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
  do { unsigned i; for (i = 0; i < payload->count; ++i) { payload->acls[i] = htobe32(payload->acls[i]); } } while(0);
}

static inline void vapi_msg_macip_acl_interface_list_details_payload_ntoh(vapi_payload_macip_acl_interface_list_details *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
  do { unsigned i; for (i = 0; i < payload->count; ++i) { payload->acls[i] = be32toh(payload->acls[i]); } } while(0);
}

static inline uword vapi_calc_macip_acl_interface_list_details_msg_size(vapi_msg_macip_acl_interface_list_details *msg)
{
  return sizeof(*msg)+ msg->payload.count * sizeof(msg->payload.acls[0]);
}

static inline void vapi_msg_macip_acl_interface_list_details_hton(vapi_msg_macip_acl_interface_list_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_macip_acl_interface_list_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_macip_acl_interface_list_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_macip_acl_interface_list_details_ntoh(vapi_msg_macip_acl_interface_list_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_macip_acl_interface_list_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_macip_acl_interface_list_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_macip_acl_add_payload_hton(vapi_payload_macip_acl_add *payload)
{
  payload->count = htobe32(payload->count);
}

static inline void vapi_msg_macip_acl_add_payload_ntoh(vapi_payload_macip_acl_add *payload)
{
  payload->count = be32toh(payload->count);
}

static inline uword vapi_calc_macip_acl_add_msg_size(vapi_msg_macip_acl_add *msg)
{
  return sizeof(*msg)+ msg->payload.count * sizeof(msg->payload.r[0]);
}

static inline void vapi_msg_macip_acl_add_hton(vapi_msg_macip_acl_add *msg)
{
  VAPI_DBG("Swapping `vapi_msg_macip_acl_add'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_macip_acl_add_payload_hton(&msg->payload);
}

static inline void vapi_msg_macip_acl_add_ntoh(vapi_msg_macip_acl_add *msg)
{
  VAPI_DBG("Swapping `vapi_msg_macip_acl_add'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_macip_acl_add_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_macip_acl_add_replace_payload_hton(vapi_payload_macip_acl_add_replace *payload)
{
  payload->acl_index = htobe32(payload->acl_index);
  payload->count = htobe32(payload->count);
}

static inline void vapi_msg_macip_acl_add_replace_payload_ntoh(vapi_payload_macip_acl_add_replace *payload)
{
  payload->acl_index = be32toh(payload->acl_index);
  payload->count = be32toh(payload->count);
}

static inline uword vapi_calc_macip_acl_add_replace_msg_size(vapi_msg_macip_acl_add_replace *msg)
{
  return sizeof(*msg)+ msg->payload.count * sizeof(msg->payload.r[0]);
}

static inline void vapi_msg_macip_acl_add_replace_hton(vapi_msg_macip_acl_add_replace *msg)
{
  VAPI_DBG("Swapping `vapi_msg_macip_acl_add_replace'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_macip_acl_add_replace_payload_hton(&msg->payload);
}

static inline void vapi_msg_macip_acl_add_replace_ntoh(vapi_msg_macip_acl_add_replace *msg)
{
  VAPI_DBG("Swapping `vapi_msg_macip_acl_add_replace'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_macip_acl_add_replace_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_acl_interface_set_acl_list_reply_payload_hton(vapi_payload_acl_interface_set_acl_list_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_acl_interface_set_acl_list_reply_payload_ntoh(vapi_payload_acl_interface_set_acl_list_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_acl_interface_set_acl_list_reply_msg_size(vapi_msg_acl_interface_set_acl_list_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_acl_interface_set_acl_list_reply_hton(vapi_msg_acl_interface_set_acl_list_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_acl_interface_set_acl_list_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_acl_interface_set_acl_list_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_acl_interface_set_acl_list_reply_ntoh(vapi_msg_acl_interface_set_acl_list_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_acl_interface_set_acl_list_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_acl_interface_set_acl_list_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_acl_plugin_get_version_reply_payload_hton(vapi_payload_acl_plugin_get_version_reply *payload)
{
  payload->major = htobe32(payload->major);
  payload->minor = htobe32(payload->minor);
}

static inline void vapi_msg_acl_plugin_get_version_reply_payload_ntoh(vapi_payload_acl_plugin_get_version_reply *payload)
{
  payload->major = be32toh(payload->major);
  payload->minor = be32toh(payload->minor);
}

static inline uword vapi_calc_acl_plugin_get_version_reply_msg_size(vapi_msg_acl_plugin_get_version_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_acl_plugin_get_version_reply_hton(vapi_msg_acl_plugin_get_version_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_acl_plugin_get_version_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_acl_plugin_get_version_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_acl_plugin_get_version_reply_ntoh(vapi_msg_acl_plugin_get_version_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_acl_plugin_get_version_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_acl_plugin_get_version_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_acl_details_payload_hton(vapi_payload_acl_details *payload)
{
  payload->acl_index = htobe32(payload->acl_index);
  payload->count = htobe32(payload->count);
  do { unsigned i; for (i = 0; i < be32toh(payload->count); ++i) { vapi_type_acl_rule_hton(&payload->r[i]); } } while(0);
}

static inline void vapi_msg_acl_details_payload_ntoh(vapi_payload_acl_details *payload)
{
  payload->acl_index = be32toh(payload->acl_index);
  payload->count = be32toh(payload->count);
  do { unsigned i; for (i = 0; i < payload->count; ++i) { vapi_type_acl_rule_ntoh(&payload->r[i]); } } while(0);
}

static inline uword vapi_calc_acl_details_msg_size(vapi_msg_acl_details *msg)
{
  return sizeof(*msg)+ msg->payload.count * sizeof(msg->payload.r[0]);
}

static inline void vapi_msg_acl_details_hton(vapi_msg_acl_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_acl_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_acl_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_acl_details_ntoh(vapi_msg_acl_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_acl_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_acl_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_macip_acl_dump_payload_hton(vapi_payload_macip_acl_dump *payload)
{
  payload->acl_index = htobe32(payload->acl_index);
}

static inline void vapi_msg_macip_acl_dump_payload_ntoh(vapi_payload_macip_acl_dump *payload)
{
  payload->acl_index = be32toh(payload->acl_index);
}

static inline uword vapi_calc_macip_acl_dump_msg_size(vapi_msg_macip_acl_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_macip_acl_dump_hton(vapi_msg_macip_acl_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_macip_acl_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_macip_acl_dump_payload_hton(&msg->payload);
}

static inline void vapi_msg_macip_acl_dump_ntoh(vapi_msg_macip_acl_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_macip_acl_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_macip_acl_dump_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_macip_acl_interface_get_reply_payload_hton(vapi_payload_macip_acl_interface_get_reply *payload)
{
  payload->count = htobe32(payload->count);
  do { unsigned i; for (i = 0; i < be32toh(payload->count); ++i) { payload->acls[i] = htobe32(payload->acls[i]); } } while(0);
}

static inline void vapi_msg_macip_acl_interface_get_reply_payload_ntoh(vapi_payload_macip_acl_interface_get_reply *payload)
{
  payload->count = be32toh(payload->count);
  do { unsigned i; for (i = 0; i < payload->count; ++i) { payload->acls[i] = be32toh(payload->acls[i]); } } while(0);
}

static inline uword vapi_calc_macip_acl_interface_get_reply_msg_size(vapi_msg_macip_acl_interface_get_reply *msg)
{
  return sizeof(*msg)+ msg->payload.count * sizeof(msg->payload.acls[0]);
}

static inline void vapi_msg_macip_acl_interface_get_reply_hton(vapi_msg_macip_acl_interface_get_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_macip_acl_interface_get_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_macip_acl_interface_get_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_macip_acl_interface_get_reply_ntoh(vapi_msg_macip_acl_interface_get_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_macip_acl_interface_get_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_macip_acl_interface_get_reply_payload_ntoh(&msg->payload);
}

static inline vapi_msg_acl_interface_add_del* vapi_alloc_acl_interface_add_del(struct vapi_ctx_s *ctx)
{
  vapi_msg_acl_interface_add_del *msg = NULL;
  const size_t size = sizeof(vapi_msg_acl_interface_add_del);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_acl_interface_add_del*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_acl_interface_add_del);

  return msg;
}

static inline vapi_error_e vapi_acl_interface_add_del(struct vapi_ctx_s *ctx,
  vapi_msg_acl_interface_add_del *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_acl_interface_add_del_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_acl_interface_add_del_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_acl_interface_add_del_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_acl_del* vapi_alloc_acl_del(struct vapi_ctx_s *ctx)
{
  vapi_msg_acl_del *msg = NULL;
  const size_t size = sizeof(vapi_msg_acl_del);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_acl_del*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_acl_del);

  return msg;
}

static inline vapi_error_e vapi_acl_del(struct vapi_ctx_s *ctx,
  vapi_msg_acl_del *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_acl_del_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_acl_del_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_acl_del_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_macip_acl_del* vapi_alloc_macip_acl_del(struct vapi_ctx_s *ctx)
{
  vapi_msg_macip_acl_del *msg = NULL;
  const size_t size = sizeof(vapi_msg_macip_acl_del);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_macip_acl_del*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_macip_acl_del);

  return msg;
}

static inline vapi_error_e vapi_macip_acl_del(struct vapi_ctx_s *ctx,
  vapi_msg_macip_acl_del *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_macip_acl_del_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_macip_acl_del_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_macip_acl_del_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_acl_plugin_get_version* vapi_alloc_acl_plugin_get_version(struct vapi_ctx_s *ctx)
{
  vapi_msg_acl_plugin_get_version *msg = NULL;
  const size_t size = sizeof(vapi_msg_acl_plugin_get_version);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_acl_plugin_get_version*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_acl_plugin_get_version);

  return msg;
}

static inline vapi_error_e vapi_acl_plugin_get_version(struct vapi_ctx_s *ctx,
  vapi_msg_acl_plugin_get_version *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_acl_plugin_get_version_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_acl_plugin_get_version_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_acl_plugin_get_version_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_macip_acl_interface_add_del* vapi_alloc_macip_acl_interface_add_del(struct vapi_ctx_s *ctx)
{
  vapi_msg_macip_acl_interface_add_del *msg = NULL;
  const size_t size = sizeof(vapi_msg_macip_acl_interface_add_del);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_macip_acl_interface_add_del*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_macip_acl_interface_add_del);

  return msg;
}

static inline vapi_error_e vapi_macip_acl_interface_add_del(struct vapi_ctx_s *ctx,
  vapi_msg_macip_acl_interface_add_del *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_macip_acl_interface_add_del_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_macip_acl_interface_add_del_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_macip_acl_interface_add_del_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_acl_interface_set_acl_list* vapi_alloc_acl_interface_set_acl_list(struct vapi_ctx_s *ctx, size_t acls_array_size)
{
  vapi_msg_acl_interface_set_acl_list *msg = NULL;
  const size_t size = sizeof(vapi_msg_acl_interface_set_acl_list) + sizeof(msg->payload.acls[0]) * acls_array_size;
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_acl_interface_set_acl_list*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_acl_interface_set_acl_list);
  msg->payload.count = acls_array_size;
  return msg;
}

static inline vapi_error_e vapi_acl_interface_set_acl_list(struct vapi_ctx_s *ctx,
  vapi_msg_acl_interface_set_acl_list *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_acl_interface_set_acl_list_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_acl_interface_set_acl_list_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_acl_interface_set_acl_list_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_acl_dump* vapi_alloc_acl_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_acl_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_acl_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_acl_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_acl_dump);

  return msg;
}

static inline vapi_error_e vapi_acl_dump(struct vapi_ctx_s *ctx,
  vapi_msg_acl_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_acl_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_acl_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_acl_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_acl_interface_list_dump* vapi_alloc_acl_interface_list_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_acl_interface_list_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_acl_interface_list_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_acl_interface_list_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_acl_interface_list_dump);

  return msg;
}

static inline vapi_error_e vapi_acl_interface_list_dump(struct vapi_ctx_s *ctx,
  vapi_msg_acl_interface_list_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_acl_interface_list_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_acl_interface_list_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_acl_interface_list_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_macip_acl_interface_list_dump* vapi_alloc_macip_acl_interface_list_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_macip_acl_interface_list_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_macip_acl_interface_list_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_macip_acl_interface_list_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_macip_acl_interface_list_dump);

  return msg;
}

static inline vapi_error_e vapi_macip_acl_interface_list_dump(struct vapi_ctx_s *ctx,
  vapi_msg_macip_acl_interface_list_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_macip_acl_interface_list_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_macip_acl_interface_list_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_macip_acl_interface_list_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_acl_add_replace* vapi_alloc_acl_add_replace(struct vapi_ctx_s *ctx, size_t r_array_size)
{
  vapi_msg_acl_add_replace *msg = NULL;
  const size_t size = sizeof(vapi_msg_acl_add_replace) + sizeof(msg->payload.r[0]) * r_array_size;
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_acl_add_replace*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_acl_add_replace);
  msg->payload.count = r_array_size;
  return msg;
}

static inline vapi_error_e vapi_acl_add_replace(struct vapi_ctx_s *ctx,
  vapi_msg_acl_add_replace *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_acl_add_replace_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_acl_add_replace_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_acl_add_replace_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_acl_plugin_control_ping* vapi_alloc_acl_plugin_control_ping(struct vapi_ctx_s *ctx)
{
  vapi_msg_acl_plugin_control_ping *msg = NULL;
  const size_t size = sizeof(vapi_msg_acl_plugin_control_ping);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_acl_plugin_control_ping*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_acl_plugin_control_ping);

  return msg;
}

static inline vapi_error_e vapi_acl_plugin_control_ping(struct vapi_ctx_s *ctx,
  vapi_msg_acl_plugin_control_ping *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_acl_plugin_control_ping_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_acl_plugin_control_ping_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_acl_plugin_control_ping_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_macip_acl_interface_get* vapi_alloc_macip_acl_interface_get(struct vapi_ctx_s *ctx)
{
  vapi_msg_macip_acl_interface_get *msg = NULL;
  const size_t size = sizeof(vapi_msg_macip_acl_interface_get);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_macip_acl_interface_get*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_macip_acl_interface_get);

  return msg;
}

static inline vapi_error_e vapi_macip_acl_interface_get(struct vapi_ctx_s *ctx,
  vapi_msg_macip_acl_interface_get *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_macip_acl_interface_get_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_macip_acl_interface_get_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_macip_acl_interface_get_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_macip_acl_add* vapi_alloc_macip_acl_add(struct vapi_ctx_s *ctx, size_t r_array_size)
{
  vapi_msg_macip_acl_add *msg = NULL;
  const size_t size = sizeof(vapi_msg_macip_acl_add) + sizeof(msg->payload.r[0]) * r_array_size;
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_macip_acl_add*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_macip_acl_add);
  msg->payload.count = r_array_size;
  return msg;
}

static inline vapi_error_e vapi_macip_acl_add(struct vapi_ctx_s *ctx,
  vapi_msg_macip_acl_add *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_macip_acl_add_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_macip_acl_add_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_macip_acl_add_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_macip_acl_add_replace* vapi_alloc_macip_acl_add_replace(struct vapi_ctx_s *ctx, size_t r_array_size)
{
  vapi_msg_macip_acl_add_replace *msg = NULL;
  const size_t size = sizeof(vapi_msg_macip_acl_add_replace) + sizeof(msg->payload.r[0]) * r_array_size;
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_macip_acl_add_replace*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_macip_acl_add_replace);
  msg->payload.count = r_array_size;
  return msg;
}

static inline vapi_error_e vapi_macip_acl_add_replace(struct vapi_ctx_s *ctx,
  vapi_msg_macip_acl_add_replace *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_macip_acl_add_replace_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_macip_acl_add_replace_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_macip_acl_add_replace_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_macip_acl_dump* vapi_alloc_macip_acl_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_macip_acl_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_macip_acl_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_macip_acl_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_macip_acl_dump);

  return msg;
}

static inline vapi_error_e vapi_macip_acl_dump(struct vapi_ctx_s *ctx,
  vapi_msg_macip_acl_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_macip_acl_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_macip_acl_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_macip_acl_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}



static void __attribute__((constructor)) __vapi_constructor_acl_interface_add_del()
{
  static const char name[] = "acl_interface_add_del";
  static const char name_with_crc[] = "acl_interface_add_del_98b53725";
  static vapi_message_desc_t __vapi_metadata_acl_interface_add_del = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_acl_interface_add_del, payload),
    sizeof(vapi_msg_acl_interface_add_del),
    (generic_swap_fn_t)vapi_msg_acl_interface_add_del_hton,
    (generic_swap_fn_t)vapi_msg_acl_interface_add_del_ntoh,
    ~0,
  };

  vapi_msg_id_acl_interface_add_del = vapi_register_msg(&__vapi_metadata_acl_interface_add_del);
  VAPI_DBG("Assigned msg id %d to acl_interface_add_del", vapi_msg_id_acl_interface_add_del);
}

static void __attribute__((constructor)) __vapi_constructor_acl_del()
{
  static const char name[] = "acl_del";
  static const char name_with_crc[] = "acl_del_82cc30ed";
  static vapi_message_desc_t __vapi_metadata_acl_del = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_acl_del, payload),
    sizeof(vapi_msg_acl_del),
    (generic_swap_fn_t)vapi_msg_acl_del_hton,
    (generic_swap_fn_t)vapi_msg_acl_del_ntoh,
    ~0,
  };

  vapi_msg_id_acl_del = vapi_register_msg(&__vapi_metadata_acl_del);
  VAPI_DBG("Assigned msg id %d to acl_del", vapi_msg_id_acl_del);
}

static void __attribute__((constructor)) __vapi_constructor_acl_interface_list_details()
{
  static const char name[] = "acl_interface_list_details";
  static const char name_with_crc[] = "acl_interface_list_details_c8150656";
  static vapi_message_desc_t __vapi_metadata_acl_interface_list_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_acl_interface_list_details, payload),
    sizeof(vapi_msg_acl_interface_list_details),
    (generic_swap_fn_t)vapi_msg_acl_interface_list_details_hton,
    (generic_swap_fn_t)vapi_msg_acl_interface_list_details_ntoh,
    ~0,
  };

  vapi_msg_id_acl_interface_list_details = vapi_register_msg(&__vapi_metadata_acl_interface_list_details);
  VAPI_DBG("Assigned msg id %d to acl_interface_list_details", vapi_msg_id_acl_interface_list_details);
}

static void __attribute__((constructor)) __vapi_constructor_macip_acl_del_reply()
{
  static const char name[] = "macip_acl_del_reply";
  static const char name_with_crc[] = "macip_acl_del_reply_eeb60e0f";
  static vapi_message_desc_t __vapi_metadata_macip_acl_del_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_macip_acl_del_reply, payload),
    sizeof(vapi_msg_macip_acl_del_reply),
    (generic_swap_fn_t)vapi_msg_macip_acl_del_reply_hton,
    (generic_swap_fn_t)vapi_msg_macip_acl_del_reply_ntoh,
    ~0,
  };

  vapi_msg_id_macip_acl_del_reply = vapi_register_msg(&__vapi_metadata_macip_acl_del_reply);
  VAPI_DBG("Assigned msg id %d to macip_acl_del_reply", vapi_msg_id_macip_acl_del_reply);
}

static void __attribute__((constructor)) __vapi_constructor_macip_acl_del()
{
  static const char name[] = "macip_acl_del";
  static const char name_with_crc[] = "macip_acl_del_dde1141f";
  static vapi_message_desc_t __vapi_metadata_macip_acl_del = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_macip_acl_del, payload),
    sizeof(vapi_msg_macip_acl_del),
    (generic_swap_fn_t)vapi_msg_macip_acl_del_hton,
    (generic_swap_fn_t)vapi_msg_macip_acl_del_ntoh,
    ~0,
  };

  vapi_msg_id_macip_acl_del = vapi_register_msg(&__vapi_metadata_macip_acl_del);
  VAPI_DBG("Assigned msg id %d to macip_acl_del", vapi_msg_id_macip_acl_del);
}

static void __attribute__((constructor)) __vapi_constructor_macip_acl_interface_add_del_reply()
{
  static const char name[] = "macip_acl_interface_add_del_reply";
  static const char name_with_crc[] = "macip_acl_interface_add_del_reply_9e9ee485";
  static vapi_message_desc_t __vapi_metadata_macip_acl_interface_add_del_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_macip_acl_interface_add_del_reply, payload),
    sizeof(vapi_msg_macip_acl_interface_add_del_reply),
    (generic_swap_fn_t)vapi_msg_macip_acl_interface_add_del_reply_hton,
    (generic_swap_fn_t)vapi_msg_macip_acl_interface_add_del_reply_ntoh,
    ~0,
  };

  vapi_msg_id_macip_acl_interface_add_del_reply = vapi_register_msg(&__vapi_metadata_macip_acl_interface_add_del_reply);
  VAPI_DBG("Assigned msg id %d to macip_acl_interface_add_del_reply", vapi_msg_id_macip_acl_interface_add_del_reply);
}

static void __attribute__((constructor)) __vapi_constructor_acl_plugin_get_version()
{
  static const char name[] = "acl_plugin_get_version";
  static const char name_with_crc[] = "acl_plugin_get_version_d7c07748";
  static vapi_message_desc_t __vapi_metadata_acl_plugin_get_version = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_acl_plugin_get_version),
    (generic_swap_fn_t)vapi_msg_acl_plugin_get_version_hton,
    (generic_swap_fn_t)vapi_msg_acl_plugin_get_version_ntoh,
    ~0,
  };

  vapi_msg_id_acl_plugin_get_version = vapi_register_msg(&__vapi_metadata_acl_plugin_get_version);
  VAPI_DBG("Assigned msg id %d to acl_plugin_get_version", vapi_msg_id_acl_plugin_get_version);
}

static void __attribute__((constructor)) __vapi_constructor_acl_add_replace_reply()
{
  static const char name[] = "acl_add_replace_reply";
  static const char name_with_crc[] = "acl_add_replace_reply_a5e6d0cf";
  static vapi_message_desc_t __vapi_metadata_acl_add_replace_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_acl_add_replace_reply, payload),
    sizeof(vapi_msg_acl_add_replace_reply),
    (generic_swap_fn_t)vapi_msg_acl_add_replace_reply_hton,
    (generic_swap_fn_t)vapi_msg_acl_add_replace_reply_ntoh,
    ~0,
  };

  vapi_msg_id_acl_add_replace_reply = vapi_register_msg(&__vapi_metadata_acl_add_replace_reply);
  VAPI_DBG("Assigned msg id %d to acl_add_replace_reply", vapi_msg_id_acl_add_replace_reply);
}

static void __attribute__((constructor)) __vapi_constructor_macip_acl_details()
{
  static const char name[] = "macip_acl_details";
  static const char name_with_crc[] = "macip_acl_details_ee1c50db";
  static vapi_message_desc_t __vapi_metadata_macip_acl_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_macip_acl_details, payload),
    sizeof(vapi_msg_macip_acl_details),
    (generic_swap_fn_t)vapi_msg_macip_acl_details_hton,
    (generic_swap_fn_t)vapi_msg_macip_acl_details_ntoh,
    ~0,
  };

  vapi_msg_id_macip_acl_details = vapi_register_msg(&__vapi_metadata_macip_acl_details);
  VAPI_DBG("Assigned msg id %d to macip_acl_details", vapi_msg_id_macip_acl_details);
}

static void __attribute__((constructor)) __vapi_constructor_macip_acl_interface_add_del()
{
  static const char name[] = "macip_acl_interface_add_del";
  static const char name_with_crc[] = "macip_acl_interface_add_del_03a4fab2";
  static vapi_message_desc_t __vapi_metadata_macip_acl_interface_add_del = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_macip_acl_interface_add_del, payload),
    sizeof(vapi_msg_macip_acl_interface_add_del),
    (generic_swap_fn_t)vapi_msg_macip_acl_interface_add_del_hton,
    (generic_swap_fn_t)vapi_msg_macip_acl_interface_add_del_ntoh,
    ~0,
  };

  vapi_msg_id_macip_acl_interface_add_del = vapi_register_msg(&__vapi_metadata_macip_acl_interface_add_del);
  VAPI_DBG("Assigned msg id %d to macip_acl_interface_add_del", vapi_msg_id_macip_acl_interface_add_del);
}

static void __attribute__((constructor)) __vapi_constructor_acl_plugin_control_ping_reply()
{
  static const char name[] = "acl_plugin_control_ping_reply";
  static const char name_with_crc[] = "acl_plugin_control_ping_reply_e07e9231";
  static vapi_message_desc_t __vapi_metadata_acl_plugin_control_ping_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_acl_plugin_control_ping_reply, payload),
    sizeof(vapi_msg_acl_plugin_control_ping_reply),
    (generic_swap_fn_t)vapi_msg_acl_plugin_control_ping_reply_hton,
    (generic_swap_fn_t)vapi_msg_acl_plugin_control_ping_reply_ntoh,
    ~0,
  };

  vapi_msg_id_acl_plugin_control_ping_reply = vapi_register_msg(&__vapi_metadata_acl_plugin_control_ping_reply);
  VAPI_DBG("Assigned msg id %d to acl_plugin_control_ping_reply", vapi_msg_id_acl_plugin_control_ping_reply);
}

static void __attribute__((constructor)) __vapi_constructor_acl_interface_set_acl_list()
{
  static const char name[] = "acl_interface_set_acl_list";
  static const char name_with_crc[] = "acl_interface_set_acl_list_7562419c";
  static vapi_message_desc_t __vapi_metadata_acl_interface_set_acl_list = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_acl_interface_set_acl_list, payload),
    sizeof(vapi_msg_acl_interface_set_acl_list),
    (generic_swap_fn_t)vapi_msg_acl_interface_set_acl_list_hton,
    (generic_swap_fn_t)vapi_msg_acl_interface_set_acl_list_ntoh,
    ~0,
  };

  vapi_msg_id_acl_interface_set_acl_list = vapi_register_msg(&__vapi_metadata_acl_interface_set_acl_list);
  VAPI_DBG("Assigned msg id %d to acl_interface_set_acl_list", vapi_msg_id_acl_interface_set_acl_list);
}

static void __attribute__((constructor)) __vapi_constructor_macip_acl_add_reply()
{
  static const char name[] = "macip_acl_add_reply";
  static const char name_with_crc[] = "macip_acl_add_reply_472edb4c";
  static vapi_message_desc_t __vapi_metadata_macip_acl_add_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_macip_acl_add_reply, payload),
    sizeof(vapi_msg_macip_acl_add_reply),
    (generic_swap_fn_t)vapi_msg_macip_acl_add_reply_hton,
    (generic_swap_fn_t)vapi_msg_macip_acl_add_reply_ntoh,
    ~0,
  };

  vapi_msg_id_macip_acl_add_reply = vapi_register_msg(&__vapi_metadata_macip_acl_add_reply);
  VAPI_DBG("Assigned msg id %d to macip_acl_add_reply", vapi_msg_id_macip_acl_add_reply);
}

static void __attribute__((constructor)) __vapi_constructor_macip_acl_add_replace_reply()
{
  static const char name[] = "macip_acl_add_replace_reply";
  static const char name_with_crc[] = "macip_acl_add_replace_reply_650701c2";
  static vapi_message_desc_t __vapi_metadata_macip_acl_add_replace_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_macip_acl_add_replace_reply, payload),
    sizeof(vapi_msg_macip_acl_add_replace_reply),
    (generic_swap_fn_t)vapi_msg_macip_acl_add_replace_reply_hton,
    (generic_swap_fn_t)vapi_msg_macip_acl_add_replace_reply_ntoh,
    ~0,
  };

  vapi_msg_id_macip_acl_add_replace_reply = vapi_register_msg(&__vapi_metadata_macip_acl_add_replace_reply);
  VAPI_DBG("Assigned msg id %d to macip_acl_add_replace_reply", vapi_msg_id_macip_acl_add_replace_reply);
}

static void __attribute__((constructor)) __vapi_constructor_acl_dump()
{
  static const char name[] = "acl_dump";
  static const char name_with_crc[] = "acl_dump_c188156d";
  static vapi_message_desc_t __vapi_metadata_acl_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_acl_dump, payload),
    sizeof(vapi_msg_acl_dump),
    (generic_swap_fn_t)vapi_msg_acl_dump_hton,
    (generic_swap_fn_t)vapi_msg_acl_dump_ntoh,
    ~0,
  };

  vapi_msg_id_acl_dump = vapi_register_msg(&__vapi_metadata_acl_dump);
  VAPI_DBG("Assigned msg id %d to acl_dump", vapi_msg_id_acl_dump);
}

static void __attribute__((constructor)) __vapi_constructor_acl_interface_list_dump()
{
  static const char name[] = "acl_interface_list_dump";
  static const char name_with_crc[] = "acl_interface_list_dump_adfe84b8";
  static vapi_message_desc_t __vapi_metadata_acl_interface_list_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_acl_interface_list_dump, payload),
    sizeof(vapi_msg_acl_interface_list_dump),
    (generic_swap_fn_t)vapi_msg_acl_interface_list_dump_hton,
    (generic_swap_fn_t)vapi_msg_acl_interface_list_dump_ntoh,
    ~0,
  };

  vapi_msg_id_acl_interface_list_dump = vapi_register_msg(&__vapi_metadata_acl_interface_list_dump);
  VAPI_DBG("Assigned msg id %d to acl_interface_list_dump", vapi_msg_id_acl_interface_list_dump);
}

static void __attribute__((constructor)) __vapi_constructor_macip_acl_interface_list_dump()
{
  static const char name[] = "macip_acl_interface_list_dump";
  static const char name_with_crc[] = "macip_acl_interface_list_dump_10645403";
  static vapi_message_desc_t __vapi_metadata_macip_acl_interface_list_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_macip_acl_interface_list_dump, payload),
    sizeof(vapi_msg_macip_acl_interface_list_dump),
    (generic_swap_fn_t)vapi_msg_macip_acl_interface_list_dump_hton,
    (generic_swap_fn_t)vapi_msg_macip_acl_interface_list_dump_ntoh,
    ~0,
  };

  vapi_msg_id_macip_acl_interface_list_dump = vapi_register_msg(&__vapi_metadata_macip_acl_interface_list_dump);
  VAPI_DBG("Assigned msg id %d to macip_acl_interface_list_dump", vapi_msg_id_macip_acl_interface_list_dump);
}

static void __attribute__((constructor)) __vapi_constructor_acl_del_reply()
{
  static const char name[] = "acl_del_reply";
  static const char name_with_crc[] = "acl_del_reply_bbb83d84";
  static vapi_message_desc_t __vapi_metadata_acl_del_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_acl_del_reply, payload),
    sizeof(vapi_msg_acl_del_reply),
    (generic_swap_fn_t)vapi_msg_acl_del_reply_hton,
    (generic_swap_fn_t)vapi_msg_acl_del_reply_ntoh,
    ~0,
  };

  vapi_msg_id_acl_del_reply = vapi_register_msg(&__vapi_metadata_acl_del_reply);
  VAPI_DBG("Assigned msg id %d to acl_del_reply", vapi_msg_id_acl_del_reply);
}

static void __attribute__((constructor)) __vapi_constructor_acl_add_replace()
{
  static const char name[] = "acl_add_replace";
  static const char name_with_crc[] = "acl_add_replace_3c317936";
  static vapi_message_desc_t __vapi_metadata_acl_add_replace = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_acl_add_replace, payload),
    sizeof(vapi_msg_acl_add_replace),
    (generic_swap_fn_t)vapi_msg_acl_add_replace_hton,
    (generic_swap_fn_t)vapi_msg_acl_add_replace_ntoh,
    ~0,
  };

  vapi_msg_id_acl_add_replace = vapi_register_msg(&__vapi_metadata_acl_add_replace);
  VAPI_DBG("Assigned msg id %d to acl_add_replace", vapi_msg_id_acl_add_replace);
}

static void __attribute__((constructor)) __vapi_constructor_acl_interface_add_del_reply()
{
  static const char name[] = "acl_interface_add_del_reply";
  static const char name_with_crc[] = "acl_interface_add_del_reply_c1b3c077";
  static vapi_message_desc_t __vapi_metadata_acl_interface_add_del_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_acl_interface_add_del_reply, payload),
    sizeof(vapi_msg_acl_interface_add_del_reply),
    (generic_swap_fn_t)vapi_msg_acl_interface_add_del_reply_hton,
    (generic_swap_fn_t)vapi_msg_acl_interface_add_del_reply_ntoh,
    ~0,
  };

  vapi_msg_id_acl_interface_add_del_reply = vapi_register_msg(&__vapi_metadata_acl_interface_add_del_reply);
  VAPI_DBG("Assigned msg id %d to acl_interface_add_del_reply", vapi_msg_id_acl_interface_add_del_reply);
}

static void __attribute__((constructor)) __vapi_constructor_acl_plugin_control_ping()
{
  static const char name[] = "acl_plugin_control_ping";
  static const char name_with_crc[] = "acl_plugin_control_ping_fc22c86e";
  static vapi_message_desc_t __vapi_metadata_acl_plugin_control_ping = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_acl_plugin_control_ping),
    (generic_swap_fn_t)vapi_msg_acl_plugin_control_ping_hton,
    (generic_swap_fn_t)vapi_msg_acl_plugin_control_ping_ntoh,
    ~0,
  };

  vapi_msg_id_acl_plugin_control_ping = vapi_register_msg(&__vapi_metadata_acl_plugin_control_ping);
  VAPI_DBG("Assigned msg id %d to acl_plugin_control_ping", vapi_msg_id_acl_plugin_control_ping);
}

static void __attribute__((constructor)) __vapi_constructor_macip_acl_interface_get()
{
  static const char name[] = "macip_acl_interface_get";
  static const char name_with_crc[] = "macip_acl_interface_get_317ce31c";
  static vapi_message_desc_t __vapi_metadata_macip_acl_interface_get = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_macip_acl_interface_get),
    (generic_swap_fn_t)vapi_msg_macip_acl_interface_get_hton,
    (generic_swap_fn_t)vapi_msg_macip_acl_interface_get_ntoh,
    ~0,
  };

  vapi_msg_id_macip_acl_interface_get = vapi_register_msg(&__vapi_metadata_macip_acl_interface_get);
  VAPI_DBG("Assigned msg id %d to macip_acl_interface_get", vapi_msg_id_macip_acl_interface_get);
}

static void __attribute__((constructor)) __vapi_constructor_macip_acl_interface_list_details()
{
  static const char name[] = "macip_acl_interface_list_details";
  static const char name_with_crc[] = "macip_acl_interface_list_details_d38dc074";
  static vapi_message_desc_t __vapi_metadata_macip_acl_interface_list_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_macip_acl_interface_list_details, payload),
    sizeof(vapi_msg_macip_acl_interface_list_details),
    (generic_swap_fn_t)vapi_msg_macip_acl_interface_list_details_hton,
    (generic_swap_fn_t)vapi_msg_macip_acl_interface_list_details_ntoh,
    ~0,
  };

  vapi_msg_id_macip_acl_interface_list_details = vapi_register_msg(&__vapi_metadata_macip_acl_interface_list_details);
  VAPI_DBG("Assigned msg id %d to macip_acl_interface_list_details", vapi_msg_id_macip_acl_interface_list_details);
}

static void __attribute__((constructor)) __vapi_constructor_macip_acl_add()
{
  static const char name[] = "macip_acl_add";
  static const char name_with_crc[] = "macip_acl_add_33356284";
  static vapi_message_desc_t __vapi_metadata_macip_acl_add = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_macip_acl_add, payload),
    sizeof(vapi_msg_macip_acl_add),
    (generic_swap_fn_t)vapi_msg_macip_acl_add_hton,
    (generic_swap_fn_t)vapi_msg_macip_acl_add_ntoh,
    ~0,
  };

  vapi_msg_id_macip_acl_add = vapi_register_msg(&__vapi_metadata_macip_acl_add);
  VAPI_DBG("Assigned msg id %d to macip_acl_add", vapi_msg_id_macip_acl_add);
}

static void __attribute__((constructor)) __vapi_constructor_macip_acl_add_replace()
{
  static const char name[] = "macip_acl_add_replace";
  static const char name_with_crc[] = "macip_acl_add_replace_d6f92681";
  static vapi_message_desc_t __vapi_metadata_macip_acl_add_replace = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_macip_acl_add_replace, payload),
    sizeof(vapi_msg_macip_acl_add_replace),
    (generic_swap_fn_t)vapi_msg_macip_acl_add_replace_hton,
    (generic_swap_fn_t)vapi_msg_macip_acl_add_replace_ntoh,
    ~0,
  };

  vapi_msg_id_macip_acl_add_replace = vapi_register_msg(&__vapi_metadata_macip_acl_add_replace);
  VAPI_DBG("Assigned msg id %d to macip_acl_add_replace", vapi_msg_id_macip_acl_add_replace);
}

static void __attribute__((constructor)) __vapi_constructor_acl_interface_set_acl_list_reply()
{
  static const char name[] = "acl_interface_set_acl_list_reply";
  static const char name_with_crc[] = "acl_interface_set_acl_list_reply_435ddc2b";
  static vapi_message_desc_t __vapi_metadata_acl_interface_set_acl_list_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_acl_interface_set_acl_list_reply, payload),
    sizeof(vapi_msg_acl_interface_set_acl_list_reply),
    (generic_swap_fn_t)vapi_msg_acl_interface_set_acl_list_reply_hton,
    (generic_swap_fn_t)vapi_msg_acl_interface_set_acl_list_reply_ntoh,
    ~0,
  };

  vapi_msg_id_acl_interface_set_acl_list_reply = vapi_register_msg(&__vapi_metadata_acl_interface_set_acl_list_reply);
  VAPI_DBG("Assigned msg id %d to acl_interface_set_acl_list_reply", vapi_msg_id_acl_interface_set_acl_list_reply);
}

static void __attribute__((constructor)) __vapi_constructor_acl_plugin_get_version_reply()
{
  static const char name[] = "acl_plugin_get_version_reply";
  static const char name_with_crc[] = "acl_plugin_get_version_reply_43eb59a5";
  static vapi_message_desc_t __vapi_metadata_acl_plugin_get_version_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_acl_plugin_get_version_reply, payload),
    sizeof(vapi_msg_acl_plugin_get_version_reply),
    (generic_swap_fn_t)vapi_msg_acl_plugin_get_version_reply_hton,
    (generic_swap_fn_t)vapi_msg_acl_plugin_get_version_reply_ntoh,
    ~0,
  };

  vapi_msg_id_acl_plugin_get_version_reply = vapi_register_msg(&__vapi_metadata_acl_plugin_get_version_reply);
  VAPI_DBG("Assigned msg id %d to acl_plugin_get_version_reply", vapi_msg_id_acl_plugin_get_version_reply);
}

static void __attribute__((constructor)) __vapi_constructor_acl_details()
{
  static const char name[] = "acl_details";
  static const char name_with_crc[] = "acl_details_1c8916b7";
  static vapi_message_desc_t __vapi_metadata_acl_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_acl_details, payload),
    sizeof(vapi_msg_acl_details),
    (generic_swap_fn_t)vapi_msg_acl_details_hton,
    (generic_swap_fn_t)vapi_msg_acl_details_ntoh,
    ~0,
  };

  vapi_msg_id_acl_details = vapi_register_msg(&__vapi_metadata_acl_details);
  VAPI_DBG("Assigned msg id %d to acl_details", vapi_msg_id_acl_details);
}

static void __attribute__((constructor)) __vapi_constructor_macip_acl_dump()
{
  static const char name[] = "macip_acl_dump";
  static const char name_with_crc[] = "macip_acl_dump_d38227cb";
  static vapi_message_desc_t __vapi_metadata_macip_acl_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_macip_acl_dump, payload),
    sizeof(vapi_msg_macip_acl_dump),
    (generic_swap_fn_t)vapi_msg_macip_acl_dump_hton,
    (generic_swap_fn_t)vapi_msg_macip_acl_dump_ntoh,
    ~0,
  };

  vapi_msg_id_macip_acl_dump = vapi_register_msg(&__vapi_metadata_macip_acl_dump);
  VAPI_DBG("Assigned msg id %d to macip_acl_dump", vapi_msg_id_macip_acl_dump);
}

static void __attribute__((constructor)) __vapi_constructor_macip_acl_interface_get_reply()
{
  static const char name[] = "macip_acl_interface_get_reply";
  static const char name_with_crc[] = "macip_acl_interface_get_reply_6c86a56c";
  static vapi_message_desc_t __vapi_metadata_macip_acl_interface_get_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_macip_acl_interface_get_reply, payload),
    sizeof(vapi_msg_macip_acl_interface_get_reply),
    (generic_swap_fn_t)vapi_msg_macip_acl_interface_get_reply_hton,
    (generic_swap_fn_t)vapi_msg_macip_acl_interface_get_reply_ntoh,
    ~0,
  };

  vapi_msg_id_macip_acl_interface_get_reply = vapi_register_msg(&__vapi_metadata_macip_acl_interface_get_reply);
  VAPI_DBG("Assigned msg id %d to macip_acl_interface_get_reply", vapi_msg_id_macip_acl_interface_get_reply);
}


static inline void vapi_set_vapi_msg_acl_interface_list_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_acl_interface_list_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_acl_interface_list_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_macip_acl_del_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_macip_acl_del_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_macip_acl_del_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_macip_acl_interface_add_del_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_macip_acl_interface_add_del_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_macip_acl_interface_add_del_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_acl_add_replace_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_acl_add_replace_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_acl_add_replace_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_macip_acl_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_macip_acl_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_macip_acl_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_acl_plugin_control_ping_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_acl_plugin_control_ping_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_acl_plugin_control_ping_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_macip_acl_add_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_macip_acl_add_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_macip_acl_add_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_macip_acl_add_replace_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_macip_acl_add_replace_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_macip_acl_add_replace_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_acl_del_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_acl_del_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_acl_del_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_acl_interface_add_del_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_acl_interface_add_del_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_acl_interface_add_del_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_macip_acl_interface_list_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_macip_acl_interface_list_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_macip_acl_interface_list_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_acl_interface_set_acl_list_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_acl_interface_set_acl_list_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_acl_interface_set_acl_list_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_acl_plugin_get_version_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_acl_plugin_get_version_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_acl_plugin_get_version_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_acl_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_acl_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_acl_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_macip_acl_interface_get_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_macip_acl_interface_get_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_macip_acl_interface_get_reply, (vapi_event_cb)callback, callback_ctx);
};


#ifdef __cplusplus
}
#endif

#endif
