#ifndef __included_ip_api_json
#define __included_ip_api_json

#include <stdlib.h>
#include <stddef.h>
#include <arpa/inet.h>
#include <vapi/vapi_internal.h>
#include <vapi/vapi.h>
#include <vapi/vapi_dbg.h>

#ifdef __cplusplus
extern "C" {
#endif
#include <vapi/vpe.api.vapi.h>

extern vapi_msg_id_t vapi_msg_id_set_ip_flow_hash_reply;
extern vapi_msg_id_t vapi_msg_id_ip_address_dump;
extern vapi_msg_id_t vapi_msg_id_ip_mroute_add_del_reply;
extern vapi_msg_id_t vapi_msg_id_ip6_fib_details;
extern vapi_msg_id_t vapi_msg_id_ip6_fib_dump;
extern vapi_msg_id_t vapi_msg_id_sw_interface_ip6nd_ra_prefix_reply;
extern vapi_msg_id_t vapi_msg_id_ip_details;
extern vapi_msg_id_t vapi_msg_id_ip6nd_proxy_add_del;
extern vapi_msg_id_t vapi_msg_id_ip_add_del_route_reply;
extern vapi_msg_id_t vapi_msg_id_ip_table_add_del;
extern vapi_msg_id_t vapi_msg_id_sw_interface_ip6_set_link_local_address;
extern vapi_msg_id_t vapi_msg_id_ip_fib_details;
extern vapi_msg_id_t vapi_msg_id_ip6nd_proxy_details;
extern vapi_msg_id_t vapi_msg_id_sw_interface_ip6_set_link_local_address_reply;
extern vapi_msg_id_t vapi_msg_id_ip_neighbor_add_del_reply;
extern vapi_msg_id_t vapi_msg_id_ip_table_add_del_reply;
extern vapi_msg_id_t vapi_msg_id_sw_interface_ip6nd_ra_prefix;
extern vapi_msg_id_t vapi_msg_id_ip6_mfib_dump;
extern vapi_msg_id_t vapi_msg_id_sw_interface_ip6nd_ra_config;
extern vapi_msg_id_t vapi_msg_id_sw_interface_ip6_enable_disable;
extern vapi_msg_id_t vapi_msg_id_ip_mfib_details;
extern vapi_msg_id_t vapi_msg_id_sw_interface_ip6_enable_disable_reply;
extern vapi_msg_id_t vapi_msg_id_ip_address_details;
extern vapi_msg_id_t vapi_msg_id_mfib_signal_dump;
extern vapi_msg_id_t vapi_msg_id_ip_mfib_dump;
extern vapi_msg_id_t vapi_msg_id_ip_dump;
extern vapi_msg_id_t vapi_msg_id_sw_interface_ip6nd_ra_config_reply;
extern vapi_msg_id_t vapi_msg_id_ip_neighbor_add_del;
extern vapi_msg_id_t vapi_msg_id_ip_neighbor_dump;
extern vapi_msg_id_t vapi_msg_id_ip_add_del_route;
extern vapi_msg_id_t vapi_msg_id_ip6nd_proxy_dump;
extern vapi_msg_id_t vapi_msg_id_ip_fib_dump;
extern vapi_msg_id_t vapi_msg_id_ip_neighbor_details;
extern vapi_msg_id_t vapi_msg_id_ip6nd_proxy_add_del_reply;
extern vapi_msg_id_t vapi_msg_id_ip_mroute_add_del;
extern vapi_msg_id_t vapi_msg_id_mfib_signal_details;
extern vapi_msg_id_t vapi_msg_id_set_ip_flow_hash;
extern vapi_msg_id_t vapi_msg_id_ip6_mfib_details;

#define DEFINE_VAPI_MSG_IDS_IP_API_JSON\
  vapi_msg_id_t vapi_msg_id_set_ip_flow_hash_reply;\
  vapi_msg_id_t vapi_msg_id_ip_address_dump;\
  vapi_msg_id_t vapi_msg_id_ip_mroute_add_del_reply;\
  vapi_msg_id_t vapi_msg_id_ip6_fib_details;\
  vapi_msg_id_t vapi_msg_id_ip6_fib_dump;\
  vapi_msg_id_t vapi_msg_id_sw_interface_ip6nd_ra_prefix_reply;\
  vapi_msg_id_t vapi_msg_id_ip_details;\
  vapi_msg_id_t vapi_msg_id_ip6nd_proxy_add_del;\
  vapi_msg_id_t vapi_msg_id_ip_add_del_route_reply;\
  vapi_msg_id_t vapi_msg_id_ip_table_add_del;\
  vapi_msg_id_t vapi_msg_id_sw_interface_ip6_set_link_local_address;\
  vapi_msg_id_t vapi_msg_id_ip_fib_details;\
  vapi_msg_id_t vapi_msg_id_ip6nd_proxy_details;\
  vapi_msg_id_t vapi_msg_id_sw_interface_ip6_set_link_local_address_reply;\
  vapi_msg_id_t vapi_msg_id_ip_neighbor_add_del_reply;\
  vapi_msg_id_t vapi_msg_id_ip_table_add_del_reply;\
  vapi_msg_id_t vapi_msg_id_sw_interface_ip6nd_ra_prefix;\
  vapi_msg_id_t vapi_msg_id_ip6_mfib_dump;\
  vapi_msg_id_t vapi_msg_id_sw_interface_ip6nd_ra_config;\
  vapi_msg_id_t vapi_msg_id_sw_interface_ip6_enable_disable;\
  vapi_msg_id_t vapi_msg_id_ip_mfib_details;\
  vapi_msg_id_t vapi_msg_id_sw_interface_ip6_enable_disable_reply;\
  vapi_msg_id_t vapi_msg_id_ip_address_details;\
  vapi_msg_id_t vapi_msg_id_mfib_signal_dump;\
  vapi_msg_id_t vapi_msg_id_ip_mfib_dump;\
  vapi_msg_id_t vapi_msg_id_ip_dump;\
  vapi_msg_id_t vapi_msg_id_sw_interface_ip6nd_ra_config_reply;\
  vapi_msg_id_t vapi_msg_id_ip_neighbor_add_del;\
  vapi_msg_id_t vapi_msg_id_ip_neighbor_dump;\
  vapi_msg_id_t vapi_msg_id_ip_add_del_route;\
  vapi_msg_id_t vapi_msg_id_ip6nd_proxy_dump;\
  vapi_msg_id_t vapi_msg_id_ip_fib_dump;\
  vapi_msg_id_t vapi_msg_id_ip_neighbor_details;\
  vapi_msg_id_t vapi_msg_id_ip6nd_proxy_add_del_reply;\
  vapi_msg_id_t vapi_msg_id_ip_mroute_add_del;\
  vapi_msg_id_t vapi_msg_id_mfib_signal_details;\
  vapi_msg_id_t vapi_msg_id_set_ip_flow_hash;\
  vapi_msg_id_t vapi_msg_id_ip6_mfib_details;


typedef struct __attribute__((__packed__)) {
  u32 sw_if_index;
  u8 weight;
  u8 preference;
  u8 is_local;
  u8 is_drop;
  u8 is_unreach;
  u8 is_prohibit;
  u8 afi;
  u8 next_hop[16];
} vapi_type_fib_path;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_set_ip_flow_hash_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_set_ip_flow_hash_reply payload;
} vapi_msg_set_ip_flow_hash_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u8 is_ipv6; 
} vapi_payload_ip_address_dump;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_ip_address_dump payload;
} vapi_msg_ip_address_dump;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_ip_mroute_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_ip_mroute_add_del_reply payload;
} vapi_msg_ip_mroute_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 table_id;
  u8 table_name[64];
  u8 address_length;
  u8 address[16];
  u32 count;
  vapi_type_fib_path path[0]; 
} vapi_payload_ip6_fib_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_ip6_fib_details payload;
} vapi_msg_ip6_fib_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_ip6_fib_dump;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_sw_interface_ip6nd_ra_prefix_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_sw_interface_ip6nd_ra_prefix_reply payload;
} vapi_msg_sw_interface_ip6nd_ra_prefix_reply;

typedef struct __attribute__ ((__packed__)) {
  u16 _vl_msg_id;
  u32 sw_if_index;
  u32 context;
  u8 is_ipv6; 
} vapi_payload_ip_details;

typedef struct __attribute__ ((__packed__)) {

  vapi_payload_ip_details payload;
} vapi_msg_ip_details;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u8 is_del;
  u8 address[16]; 
} vapi_payload_ip6nd_proxy_add_del;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_ip6nd_proxy_add_del payload;
} vapi_msg_ip6nd_proxy_add_del;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_ip_add_del_route_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_ip_add_del_route_reply payload;
} vapi_msg_ip_add_del_route_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 table_id;
  u8 is_ipv6;
  u8 is_add;
  u8 name[64]; 
} vapi_payload_ip_table_add_del;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_ip_table_add_del payload;
} vapi_msg_ip_table_add_del;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u8 address[16]; 
} vapi_payload_sw_interface_ip6_set_link_local_address;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_sw_interface_ip6_set_link_local_address payload;
} vapi_msg_sw_interface_ip6_set_link_local_address;

typedef struct __attribute__ ((__packed__)) {
  u32 table_id;
  u8 table_name[64];
  u8 address_length;
  u8 address[4];
  u32 count;
  vapi_type_fib_path path[0]; 
} vapi_payload_ip_fib_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_ip_fib_details payload;
} vapi_msg_ip_fib_details;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u8 address[16]; 
} vapi_payload_ip6nd_proxy_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_ip6nd_proxy_details payload;
} vapi_msg_ip6nd_proxy_details;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_sw_interface_ip6_set_link_local_address_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_sw_interface_ip6_set_link_local_address_reply payload;
} vapi_msg_sw_interface_ip6_set_link_local_address_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_ip_neighbor_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_ip_neighbor_add_del_reply payload;
} vapi_msg_ip_neighbor_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_ip_table_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_ip_table_add_del_reply payload;
} vapi_msg_ip_table_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u8 address[16];
  u8 address_length;
  u8 use_default;
  u8 no_advertise;
  u8 off_link;
  u8 no_autoconfig;
  u8 no_onlink;
  u8 is_no;
  u32 val_lifetime;
  u32 pref_lifetime; 
} vapi_payload_sw_interface_ip6nd_ra_prefix;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_sw_interface_ip6nd_ra_prefix payload;
} vapi_msg_sw_interface_ip6nd_ra_prefix;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_ip6_mfib_dump;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u8 suppress;
  u8 managed;
  u8 other;
  u8 ll_option;
  u8 send_unicast;
  u8 cease;
  u8 is_no;
  u8 default_router;
  u32 max_interval;
  u32 min_interval;
  u32 lifetime;
  u32 initial_count;
  u32 initial_interval; 
} vapi_payload_sw_interface_ip6nd_ra_config;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_sw_interface_ip6nd_ra_config payload;
} vapi_msg_sw_interface_ip6nd_ra_config;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u8 enable; 
} vapi_payload_sw_interface_ip6_enable_disable;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_sw_interface_ip6_enable_disable payload;
} vapi_msg_sw_interface_ip6_enable_disable;

typedef struct __attribute__ ((__packed__)) {
  u32 table_id;
  u32 entry_flags;
  u32 rpf_id;
  u8 address_length;
  u8 grp_address[4];
  u8 src_address[4];
  u32 count;
  vapi_type_fib_path path[0]; 
} vapi_payload_ip_mfib_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_ip_mfib_details payload;
} vapi_msg_ip_mfib_details;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_sw_interface_ip6_enable_disable_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_sw_interface_ip6_enable_disable_reply payload;
} vapi_msg_sw_interface_ip6_enable_disable_reply;

typedef struct __attribute__ ((__packed__)) {
  u8 ip[16];
  u8 prefix_length;
  u32 sw_if_index;
  u8 is_ipv6; 
} vapi_payload_ip_address_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_ip_address_details payload;
} vapi_msg_ip_address_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_mfib_signal_dump;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_ip_mfib_dump;

typedef struct __attribute__ ((__packed__)) {
  u8 is_ipv6; 
} vapi_payload_ip_dump;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_ip_dump payload;
} vapi_msg_ip_dump;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_sw_interface_ip6nd_ra_config_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_sw_interface_ip6nd_ra_config_reply payload;
} vapi_msg_sw_interface_ip6nd_ra_config_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u8 is_add;
  u8 is_ipv6;
  u8 is_static;
  u8 is_no_adj_fib;
  u8 mac_address[6];
  u8 dst_address[16]; 
} vapi_payload_ip_neighbor_add_del;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_ip_neighbor_add_del payload;
} vapi_msg_ip_neighbor_add_del;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u8 is_ipv6; 
} vapi_payload_ip_neighbor_dump;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_ip_neighbor_dump payload;
} vapi_msg_ip_neighbor_dump;

typedef struct __attribute__ ((__packed__)) {
  u32 next_hop_sw_if_index;
  u32 table_id;
  u32 classify_table_index;
  u32 next_hop_table_id;
  u8 create_vrf_if_needed;
  u8 is_add;
  u8 is_drop;
  u8 is_unreach;
  u8 is_prohibit;
  u8 is_ipv6;
  u8 is_local;
  u8 is_classify;
  u8 is_multipath;
  u8 is_resolve_host;
  u8 is_resolve_attached;
  u8 not_last;
  u8 next_hop_weight;
  u8 next_hop_preference;
  u8 dst_address_length;
  u8 dst_address[16];
  u8 next_hop_address[16];
  u8 next_hop_n_out_labels;
  u32 next_hop_via_label;
  u32 next_hop_out_label_stack[0]; 
} vapi_payload_ip_add_del_route;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_ip_add_del_route payload;
} vapi_msg_ip_add_del_route;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_ip6nd_proxy_dump;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_ip_fib_dump;

typedef struct __attribute__ ((__packed__)) {
  u8 is_static;
  u8 is_ipv6;
  u8 mac_address[6];
  u8 ip_address[16]; 
} vapi_payload_ip_neighbor_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_ip_neighbor_details payload;
} vapi_msg_ip_neighbor_details;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_ip6nd_proxy_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_ip6nd_proxy_add_del_reply payload;
} vapi_msg_ip6nd_proxy_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 next_hop_sw_if_index;
  u32 table_id;
  u32 entry_flags;
  u32 itf_flags;
  u32 rpf_id;
  u16 grp_address_length;
  u8 create_vrf_if_needed;
  u8 is_add;
  u8 is_ipv6;
  u8 is_local;
  u8 grp_address[16];
  u8 src_address[16]; 
} vapi_payload_ip_mroute_add_del;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_ip_mroute_add_del payload;
} vapi_msg_ip_mroute_add_del;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u32 table_id;
  u16 grp_address_len;
  u8 grp_address[16];
  u8 src_address[16];
  u16 ip_packet_len;
  u8 ip_packet_data[256]; 
} vapi_payload_mfib_signal_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_mfib_signal_details payload;
} vapi_msg_mfib_signal_details;

typedef struct __attribute__ ((__packed__)) {
  u32 vrf_id;
  u8 is_ipv6;
  u8 src;
  u8 dst;
  u8 sport;
  u8 dport;
  u8 proto;
  u8 reverse; 
} vapi_payload_set_ip_flow_hash;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_set_ip_flow_hash payload;
} vapi_msg_set_ip_flow_hash;

typedef struct __attribute__ ((__packed__)) {
  u32 table_id;
  u8 address_length;
  u8 grp_address[16];
  u8 src_address[16];
  u32 count;
  vapi_type_fib_path path[0]; 
} vapi_payload_ip6_mfib_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_ip6_mfib_details payload;
} vapi_msg_ip6_mfib_details;


static inline void vapi_type_fib_path_hton(vapi_type_fib_path *msg)
{
  msg->sw_if_index = htobe32(msg->sw_if_index);
}

static inline void vapi_type_fib_path_ntoh(vapi_type_fib_path *msg)
{
  msg->sw_if_index = be32toh(msg->sw_if_index);
}

static inline void vapi_msg_set_ip_flow_hash_reply_payload_hton(vapi_payload_set_ip_flow_hash_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_set_ip_flow_hash_reply_payload_ntoh(vapi_payload_set_ip_flow_hash_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_set_ip_flow_hash_reply_msg_size(vapi_msg_set_ip_flow_hash_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_set_ip_flow_hash_reply_hton(vapi_msg_set_ip_flow_hash_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_set_ip_flow_hash_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_set_ip_flow_hash_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_set_ip_flow_hash_reply_ntoh(vapi_msg_set_ip_flow_hash_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_set_ip_flow_hash_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_set_ip_flow_hash_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ip_address_dump_payload_hton(vapi_payload_ip_address_dump *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_ip_address_dump_payload_ntoh(vapi_payload_ip_address_dump *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_ip_address_dump_msg_size(vapi_msg_ip_address_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ip_address_dump_hton(vapi_msg_ip_address_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_address_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_ip_address_dump_payload_hton(&msg->payload);
}

static inline void vapi_msg_ip_address_dump_ntoh(vapi_msg_ip_address_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_address_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_ip_address_dump_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ip_mroute_add_del_reply_payload_hton(vapi_payload_ip_mroute_add_del_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_ip_mroute_add_del_reply_payload_ntoh(vapi_payload_ip_mroute_add_del_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_ip_mroute_add_del_reply_msg_size(vapi_msg_ip_mroute_add_del_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ip_mroute_add_del_reply_hton(vapi_msg_ip_mroute_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_mroute_add_del_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_ip_mroute_add_del_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_ip_mroute_add_del_reply_ntoh(vapi_msg_ip_mroute_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_mroute_add_del_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_ip_mroute_add_del_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ip6_fib_details_payload_hton(vapi_payload_ip6_fib_details *payload)
{
  payload->table_id = htobe32(payload->table_id);
  payload->count = htobe32(payload->count);
  do { unsigned i; for (i = 0; i < be32toh(payload->count); ++i) { vapi_type_fib_path_hton(&payload->path[i]); } } while(0);
}

static inline void vapi_msg_ip6_fib_details_payload_ntoh(vapi_payload_ip6_fib_details *payload)
{
  payload->table_id = be32toh(payload->table_id);
  payload->count = be32toh(payload->count);
  do { unsigned i; for (i = 0; i < payload->count; ++i) { vapi_type_fib_path_ntoh(&payload->path[i]); } } while(0);
}

static inline uword vapi_calc_ip6_fib_details_msg_size(vapi_msg_ip6_fib_details *msg)
{
  return sizeof(*msg)+ msg->payload.count * sizeof(msg->payload.path[0]);
}

static inline void vapi_msg_ip6_fib_details_hton(vapi_msg_ip6_fib_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip6_fib_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_ip6_fib_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_ip6_fib_details_ntoh(vapi_msg_ip6_fib_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip6_fib_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_ip6_fib_details_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_ip6_fib_dump_msg_size(vapi_msg_ip6_fib_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ip6_fib_dump_hton(vapi_msg_ip6_fib_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip6_fib_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_ip6_fib_dump_ntoh(vapi_msg_ip6_fib_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip6_fib_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_sw_interface_ip6nd_ra_prefix_reply_payload_hton(vapi_payload_sw_interface_ip6nd_ra_prefix_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_sw_interface_ip6nd_ra_prefix_reply_payload_ntoh(vapi_payload_sw_interface_ip6nd_ra_prefix_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_sw_interface_ip6nd_ra_prefix_reply_msg_size(vapi_msg_sw_interface_ip6nd_ra_prefix_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_ip6nd_ra_prefix_reply_hton(vapi_msg_sw_interface_ip6nd_ra_prefix_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_ip6nd_ra_prefix_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_sw_interface_ip6nd_ra_prefix_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_ip6nd_ra_prefix_reply_ntoh(vapi_msg_sw_interface_ip6nd_ra_prefix_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_ip6nd_ra_prefix_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_sw_interface_ip6nd_ra_prefix_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ip_details_payload_hton(vapi_payload_ip_details *payload)
{
  payload->_vl_msg_id = htobe16(payload->_vl_msg_id);
  payload->sw_if_index = htobe32(payload->sw_if_index);
  payload->context = htobe32(payload->context);
}

static inline void vapi_msg_ip_details_payload_ntoh(vapi_payload_ip_details *payload)
{
  payload->_vl_msg_id = be16toh(payload->_vl_msg_id);
  payload->sw_if_index = be32toh(payload->sw_if_index);
  payload->context = be32toh(payload->context);
}

static inline uword vapi_calc_ip_details_msg_size(vapi_msg_ip_details *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ip_details_hton(vapi_msg_ip_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_details'@%p to big endian", msg);

  vapi_msg_ip_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_ip_details_ntoh(vapi_msg_ip_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_details'@%p to host byte order", msg);

  vapi_msg_ip_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ip6nd_proxy_add_del_payload_hton(vapi_payload_ip6nd_proxy_add_del *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_ip6nd_proxy_add_del_payload_ntoh(vapi_payload_ip6nd_proxy_add_del *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_ip6nd_proxy_add_del_msg_size(vapi_msg_ip6nd_proxy_add_del *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ip6nd_proxy_add_del_hton(vapi_msg_ip6nd_proxy_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip6nd_proxy_add_del'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_ip6nd_proxy_add_del_payload_hton(&msg->payload);
}

static inline void vapi_msg_ip6nd_proxy_add_del_ntoh(vapi_msg_ip6nd_proxy_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip6nd_proxy_add_del'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_ip6nd_proxy_add_del_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ip_add_del_route_reply_payload_hton(vapi_payload_ip_add_del_route_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_ip_add_del_route_reply_payload_ntoh(vapi_payload_ip_add_del_route_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_ip_add_del_route_reply_msg_size(vapi_msg_ip_add_del_route_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ip_add_del_route_reply_hton(vapi_msg_ip_add_del_route_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_add_del_route_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_ip_add_del_route_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_ip_add_del_route_reply_ntoh(vapi_msg_ip_add_del_route_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_add_del_route_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_ip_add_del_route_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ip_table_add_del_payload_hton(vapi_payload_ip_table_add_del *payload)
{
  payload->table_id = htobe32(payload->table_id);
}

static inline void vapi_msg_ip_table_add_del_payload_ntoh(vapi_payload_ip_table_add_del *payload)
{
  payload->table_id = be32toh(payload->table_id);
}

static inline uword vapi_calc_ip_table_add_del_msg_size(vapi_msg_ip_table_add_del *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ip_table_add_del_hton(vapi_msg_ip_table_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_table_add_del'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_ip_table_add_del_payload_hton(&msg->payload);
}

static inline void vapi_msg_ip_table_add_del_ntoh(vapi_msg_ip_table_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_table_add_del'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_ip_table_add_del_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_ip6_set_link_local_address_payload_hton(vapi_payload_sw_interface_ip6_set_link_local_address *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_sw_interface_ip6_set_link_local_address_payload_ntoh(vapi_payload_sw_interface_ip6_set_link_local_address *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_sw_interface_ip6_set_link_local_address_msg_size(vapi_msg_sw_interface_ip6_set_link_local_address *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_ip6_set_link_local_address_hton(vapi_msg_sw_interface_ip6_set_link_local_address *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_ip6_set_link_local_address'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_sw_interface_ip6_set_link_local_address_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_ip6_set_link_local_address_ntoh(vapi_msg_sw_interface_ip6_set_link_local_address *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_ip6_set_link_local_address'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_sw_interface_ip6_set_link_local_address_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ip_fib_details_payload_hton(vapi_payload_ip_fib_details *payload)
{
  payload->table_id = htobe32(payload->table_id);
  payload->count = htobe32(payload->count);
  do { unsigned i; for (i = 0; i < be32toh(payload->count); ++i) { vapi_type_fib_path_hton(&payload->path[i]); } } while(0);
}

static inline void vapi_msg_ip_fib_details_payload_ntoh(vapi_payload_ip_fib_details *payload)
{
  payload->table_id = be32toh(payload->table_id);
  payload->count = be32toh(payload->count);
  do { unsigned i; for (i = 0; i < payload->count; ++i) { vapi_type_fib_path_ntoh(&payload->path[i]); } } while(0);
}

static inline uword vapi_calc_ip_fib_details_msg_size(vapi_msg_ip_fib_details *msg)
{
  return sizeof(*msg)+ msg->payload.count * sizeof(msg->payload.path[0]);
}

static inline void vapi_msg_ip_fib_details_hton(vapi_msg_ip_fib_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_fib_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_ip_fib_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_ip_fib_details_ntoh(vapi_msg_ip_fib_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_fib_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_ip_fib_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ip6nd_proxy_details_payload_hton(vapi_payload_ip6nd_proxy_details *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_ip6nd_proxy_details_payload_ntoh(vapi_payload_ip6nd_proxy_details *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_ip6nd_proxy_details_msg_size(vapi_msg_ip6nd_proxy_details *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ip6nd_proxy_details_hton(vapi_msg_ip6nd_proxy_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip6nd_proxy_details'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_ip6nd_proxy_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_ip6nd_proxy_details_ntoh(vapi_msg_ip6nd_proxy_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip6nd_proxy_details'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_ip6nd_proxy_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_ip6_set_link_local_address_reply_payload_hton(vapi_payload_sw_interface_ip6_set_link_local_address_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_sw_interface_ip6_set_link_local_address_reply_payload_ntoh(vapi_payload_sw_interface_ip6_set_link_local_address_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_sw_interface_ip6_set_link_local_address_reply_msg_size(vapi_msg_sw_interface_ip6_set_link_local_address_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_ip6_set_link_local_address_reply_hton(vapi_msg_sw_interface_ip6_set_link_local_address_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_ip6_set_link_local_address_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_sw_interface_ip6_set_link_local_address_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_ip6_set_link_local_address_reply_ntoh(vapi_msg_sw_interface_ip6_set_link_local_address_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_ip6_set_link_local_address_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_sw_interface_ip6_set_link_local_address_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ip_neighbor_add_del_reply_payload_hton(vapi_payload_ip_neighbor_add_del_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_ip_neighbor_add_del_reply_payload_ntoh(vapi_payload_ip_neighbor_add_del_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_ip_neighbor_add_del_reply_msg_size(vapi_msg_ip_neighbor_add_del_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ip_neighbor_add_del_reply_hton(vapi_msg_ip_neighbor_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_neighbor_add_del_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_ip_neighbor_add_del_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_ip_neighbor_add_del_reply_ntoh(vapi_msg_ip_neighbor_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_neighbor_add_del_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_ip_neighbor_add_del_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ip_table_add_del_reply_payload_hton(vapi_payload_ip_table_add_del_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_ip_table_add_del_reply_payload_ntoh(vapi_payload_ip_table_add_del_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_ip_table_add_del_reply_msg_size(vapi_msg_ip_table_add_del_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ip_table_add_del_reply_hton(vapi_msg_ip_table_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_table_add_del_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_ip_table_add_del_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_ip_table_add_del_reply_ntoh(vapi_msg_ip_table_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_table_add_del_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_ip_table_add_del_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_ip6nd_ra_prefix_payload_hton(vapi_payload_sw_interface_ip6nd_ra_prefix *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
  payload->val_lifetime = htobe32(payload->val_lifetime);
  payload->pref_lifetime = htobe32(payload->pref_lifetime);
}

static inline void vapi_msg_sw_interface_ip6nd_ra_prefix_payload_ntoh(vapi_payload_sw_interface_ip6nd_ra_prefix *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
  payload->val_lifetime = be32toh(payload->val_lifetime);
  payload->pref_lifetime = be32toh(payload->pref_lifetime);
}

static inline uword vapi_calc_sw_interface_ip6nd_ra_prefix_msg_size(vapi_msg_sw_interface_ip6nd_ra_prefix *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_ip6nd_ra_prefix_hton(vapi_msg_sw_interface_ip6nd_ra_prefix *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_ip6nd_ra_prefix'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_sw_interface_ip6nd_ra_prefix_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_ip6nd_ra_prefix_ntoh(vapi_msg_sw_interface_ip6nd_ra_prefix *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_ip6nd_ra_prefix'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_sw_interface_ip6nd_ra_prefix_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_ip6_mfib_dump_msg_size(vapi_msg_ip6_mfib_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ip6_mfib_dump_hton(vapi_msg_ip6_mfib_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip6_mfib_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_ip6_mfib_dump_ntoh(vapi_msg_ip6_mfib_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip6_mfib_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_sw_interface_ip6nd_ra_config_payload_hton(vapi_payload_sw_interface_ip6nd_ra_config *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
  payload->max_interval = htobe32(payload->max_interval);
  payload->min_interval = htobe32(payload->min_interval);
  payload->lifetime = htobe32(payload->lifetime);
  payload->initial_count = htobe32(payload->initial_count);
  payload->initial_interval = htobe32(payload->initial_interval);
}

static inline void vapi_msg_sw_interface_ip6nd_ra_config_payload_ntoh(vapi_payload_sw_interface_ip6nd_ra_config *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
  payload->max_interval = be32toh(payload->max_interval);
  payload->min_interval = be32toh(payload->min_interval);
  payload->lifetime = be32toh(payload->lifetime);
  payload->initial_count = be32toh(payload->initial_count);
  payload->initial_interval = be32toh(payload->initial_interval);
}

static inline uword vapi_calc_sw_interface_ip6nd_ra_config_msg_size(vapi_msg_sw_interface_ip6nd_ra_config *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_ip6nd_ra_config_hton(vapi_msg_sw_interface_ip6nd_ra_config *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_ip6nd_ra_config'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_sw_interface_ip6nd_ra_config_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_ip6nd_ra_config_ntoh(vapi_msg_sw_interface_ip6nd_ra_config *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_ip6nd_ra_config'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_sw_interface_ip6nd_ra_config_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_ip6_enable_disable_payload_hton(vapi_payload_sw_interface_ip6_enable_disable *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_sw_interface_ip6_enable_disable_payload_ntoh(vapi_payload_sw_interface_ip6_enable_disable *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_sw_interface_ip6_enable_disable_msg_size(vapi_msg_sw_interface_ip6_enable_disable *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_ip6_enable_disable_hton(vapi_msg_sw_interface_ip6_enable_disable *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_ip6_enable_disable'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_sw_interface_ip6_enable_disable_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_ip6_enable_disable_ntoh(vapi_msg_sw_interface_ip6_enable_disable *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_ip6_enable_disable'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_sw_interface_ip6_enable_disable_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ip_mfib_details_payload_hton(vapi_payload_ip_mfib_details *payload)
{
  payload->table_id = htobe32(payload->table_id);
  payload->entry_flags = htobe32(payload->entry_flags);
  payload->rpf_id = htobe32(payload->rpf_id);
  payload->count = htobe32(payload->count);
  do { unsigned i; for (i = 0; i < be32toh(payload->count); ++i) { vapi_type_fib_path_hton(&payload->path[i]); } } while(0);
}

static inline void vapi_msg_ip_mfib_details_payload_ntoh(vapi_payload_ip_mfib_details *payload)
{
  payload->table_id = be32toh(payload->table_id);
  payload->entry_flags = be32toh(payload->entry_flags);
  payload->rpf_id = be32toh(payload->rpf_id);
  payload->count = be32toh(payload->count);
  do { unsigned i; for (i = 0; i < payload->count; ++i) { vapi_type_fib_path_ntoh(&payload->path[i]); } } while(0);
}

static inline uword vapi_calc_ip_mfib_details_msg_size(vapi_msg_ip_mfib_details *msg)
{
  return sizeof(*msg)+ msg->payload.count * sizeof(msg->payload.path[0]);
}

static inline void vapi_msg_ip_mfib_details_hton(vapi_msg_ip_mfib_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_mfib_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_ip_mfib_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_ip_mfib_details_ntoh(vapi_msg_ip_mfib_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_mfib_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_ip_mfib_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_ip6_enable_disable_reply_payload_hton(vapi_payload_sw_interface_ip6_enable_disable_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_sw_interface_ip6_enable_disable_reply_payload_ntoh(vapi_payload_sw_interface_ip6_enable_disable_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_sw_interface_ip6_enable_disable_reply_msg_size(vapi_msg_sw_interface_ip6_enable_disable_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_ip6_enable_disable_reply_hton(vapi_msg_sw_interface_ip6_enable_disable_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_ip6_enable_disable_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_sw_interface_ip6_enable_disable_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_ip6_enable_disable_reply_ntoh(vapi_msg_sw_interface_ip6_enable_disable_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_ip6_enable_disable_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_sw_interface_ip6_enable_disable_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ip_address_details_payload_hton(vapi_payload_ip_address_details *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_ip_address_details_payload_ntoh(vapi_payload_ip_address_details *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_ip_address_details_msg_size(vapi_msg_ip_address_details *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ip_address_details_hton(vapi_msg_ip_address_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_address_details'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_ip_address_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_ip_address_details_ntoh(vapi_msg_ip_address_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_address_details'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_ip_address_details_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_mfib_signal_dump_msg_size(vapi_msg_mfib_signal_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_mfib_signal_dump_hton(vapi_msg_mfib_signal_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_mfib_signal_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_mfib_signal_dump_ntoh(vapi_msg_mfib_signal_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_mfib_signal_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline uword vapi_calc_ip_mfib_dump_msg_size(vapi_msg_ip_mfib_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ip_mfib_dump_hton(vapi_msg_ip_mfib_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_mfib_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_ip_mfib_dump_ntoh(vapi_msg_ip_mfib_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_mfib_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_ip_dump_payload_hton(vapi_payload_ip_dump *payload)
{

}

static inline void vapi_msg_ip_dump_payload_ntoh(vapi_payload_ip_dump *payload)
{

}

static inline uword vapi_calc_ip_dump_msg_size(vapi_msg_ip_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ip_dump_hton(vapi_msg_ip_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_ip_dump_payload_hton(&msg->payload);
}

static inline void vapi_msg_ip_dump_ntoh(vapi_msg_ip_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_ip_dump_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_ip6nd_ra_config_reply_payload_hton(vapi_payload_sw_interface_ip6nd_ra_config_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_sw_interface_ip6nd_ra_config_reply_payload_ntoh(vapi_payload_sw_interface_ip6nd_ra_config_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_sw_interface_ip6nd_ra_config_reply_msg_size(vapi_msg_sw_interface_ip6nd_ra_config_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_ip6nd_ra_config_reply_hton(vapi_msg_sw_interface_ip6nd_ra_config_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_ip6nd_ra_config_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_sw_interface_ip6nd_ra_config_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_ip6nd_ra_config_reply_ntoh(vapi_msg_sw_interface_ip6nd_ra_config_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_ip6nd_ra_config_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_sw_interface_ip6nd_ra_config_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ip_neighbor_add_del_payload_hton(vapi_payload_ip_neighbor_add_del *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_ip_neighbor_add_del_payload_ntoh(vapi_payload_ip_neighbor_add_del *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_ip_neighbor_add_del_msg_size(vapi_msg_ip_neighbor_add_del *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ip_neighbor_add_del_hton(vapi_msg_ip_neighbor_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_neighbor_add_del'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_ip_neighbor_add_del_payload_hton(&msg->payload);
}

static inline void vapi_msg_ip_neighbor_add_del_ntoh(vapi_msg_ip_neighbor_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_neighbor_add_del'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_ip_neighbor_add_del_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ip_neighbor_dump_payload_hton(vapi_payload_ip_neighbor_dump *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_ip_neighbor_dump_payload_ntoh(vapi_payload_ip_neighbor_dump *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_ip_neighbor_dump_msg_size(vapi_msg_ip_neighbor_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ip_neighbor_dump_hton(vapi_msg_ip_neighbor_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_neighbor_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_ip_neighbor_dump_payload_hton(&msg->payload);
}

static inline void vapi_msg_ip_neighbor_dump_ntoh(vapi_msg_ip_neighbor_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_neighbor_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_ip_neighbor_dump_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ip_add_del_route_payload_hton(vapi_payload_ip_add_del_route *payload)
{
  payload->next_hop_sw_if_index = htobe32(payload->next_hop_sw_if_index);
  payload->table_id = htobe32(payload->table_id);
  payload->classify_table_index = htobe32(payload->classify_table_index);
  payload->next_hop_table_id = htobe32(payload->next_hop_table_id);
  payload->next_hop_via_label = htobe32(payload->next_hop_via_label);
  do { unsigned i; for (i = 0; i < payload->next_hop_n_out_labels; ++i) { payload->next_hop_out_label_stack[i] = htobe32(payload->next_hop_out_label_stack[i]); } } while(0);
}

static inline void vapi_msg_ip_add_del_route_payload_ntoh(vapi_payload_ip_add_del_route *payload)
{
  payload->next_hop_sw_if_index = be32toh(payload->next_hop_sw_if_index);
  payload->table_id = be32toh(payload->table_id);
  payload->classify_table_index = be32toh(payload->classify_table_index);
  payload->next_hop_table_id = be32toh(payload->next_hop_table_id);
  payload->next_hop_via_label = be32toh(payload->next_hop_via_label);
  do { unsigned i; for (i = 0; i < payload->next_hop_n_out_labels; ++i) { payload->next_hop_out_label_stack[i] = be32toh(payload->next_hop_out_label_stack[i]); } } while(0);
}

static inline uword vapi_calc_ip_add_del_route_msg_size(vapi_msg_ip_add_del_route *msg)
{
  return sizeof(*msg)+ msg->payload.next_hop_n_out_labels * sizeof(msg->payload.next_hop_out_label_stack[0]);
}

static inline void vapi_msg_ip_add_del_route_hton(vapi_msg_ip_add_del_route *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_add_del_route'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_ip_add_del_route_payload_hton(&msg->payload);
}

static inline void vapi_msg_ip_add_del_route_ntoh(vapi_msg_ip_add_del_route *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_add_del_route'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_ip_add_del_route_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_ip6nd_proxy_dump_msg_size(vapi_msg_ip6nd_proxy_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ip6nd_proxy_dump_hton(vapi_msg_ip6nd_proxy_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip6nd_proxy_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_ip6nd_proxy_dump_ntoh(vapi_msg_ip6nd_proxy_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip6nd_proxy_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline uword vapi_calc_ip_fib_dump_msg_size(vapi_msg_ip_fib_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ip_fib_dump_hton(vapi_msg_ip_fib_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_fib_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_ip_fib_dump_ntoh(vapi_msg_ip_fib_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_fib_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_ip_neighbor_details_payload_hton(vapi_payload_ip_neighbor_details *payload)
{

}

static inline void vapi_msg_ip_neighbor_details_payload_ntoh(vapi_payload_ip_neighbor_details *payload)
{

}

static inline uword vapi_calc_ip_neighbor_details_msg_size(vapi_msg_ip_neighbor_details *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ip_neighbor_details_hton(vapi_msg_ip_neighbor_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_neighbor_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_ip_neighbor_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_ip_neighbor_details_ntoh(vapi_msg_ip_neighbor_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_neighbor_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_ip_neighbor_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ip6nd_proxy_add_del_reply_payload_hton(vapi_payload_ip6nd_proxy_add_del_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_ip6nd_proxy_add_del_reply_payload_ntoh(vapi_payload_ip6nd_proxy_add_del_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_ip6nd_proxy_add_del_reply_msg_size(vapi_msg_ip6nd_proxy_add_del_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ip6nd_proxy_add_del_reply_hton(vapi_msg_ip6nd_proxy_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip6nd_proxy_add_del_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_ip6nd_proxy_add_del_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_ip6nd_proxy_add_del_reply_ntoh(vapi_msg_ip6nd_proxy_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip6nd_proxy_add_del_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_ip6nd_proxy_add_del_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ip_mroute_add_del_payload_hton(vapi_payload_ip_mroute_add_del *payload)
{
  payload->next_hop_sw_if_index = htobe32(payload->next_hop_sw_if_index);
  payload->table_id = htobe32(payload->table_id);
  payload->entry_flags = htobe32(payload->entry_flags);
  payload->itf_flags = htobe32(payload->itf_flags);
  payload->rpf_id = htobe32(payload->rpf_id);
  payload->grp_address_length = htobe16(payload->grp_address_length);
}

static inline void vapi_msg_ip_mroute_add_del_payload_ntoh(vapi_payload_ip_mroute_add_del *payload)
{
  payload->next_hop_sw_if_index = be32toh(payload->next_hop_sw_if_index);
  payload->table_id = be32toh(payload->table_id);
  payload->entry_flags = be32toh(payload->entry_flags);
  payload->itf_flags = be32toh(payload->itf_flags);
  payload->rpf_id = be32toh(payload->rpf_id);
  payload->grp_address_length = be16toh(payload->grp_address_length);
}

static inline uword vapi_calc_ip_mroute_add_del_msg_size(vapi_msg_ip_mroute_add_del *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ip_mroute_add_del_hton(vapi_msg_ip_mroute_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_mroute_add_del'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_ip_mroute_add_del_payload_hton(&msg->payload);
}

static inline void vapi_msg_ip_mroute_add_del_ntoh(vapi_msg_ip_mroute_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_mroute_add_del'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_ip_mroute_add_del_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_mfib_signal_details_payload_hton(vapi_payload_mfib_signal_details *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
  payload->table_id = htobe32(payload->table_id);
  payload->grp_address_len = htobe16(payload->grp_address_len);
  payload->ip_packet_len = htobe16(payload->ip_packet_len);
}

static inline void vapi_msg_mfib_signal_details_payload_ntoh(vapi_payload_mfib_signal_details *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
  payload->table_id = be32toh(payload->table_id);
  payload->grp_address_len = be16toh(payload->grp_address_len);
  payload->ip_packet_len = be16toh(payload->ip_packet_len);
}

static inline uword vapi_calc_mfib_signal_details_msg_size(vapi_msg_mfib_signal_details *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_mfib_signal_details_hton(vapi_msg_mfib_signal_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_mfib_signal_details'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_mfib_signal_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_mfib_signal_details_ntoh(vapi_msg_mfib_signal_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_mfib_signal_details'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_mfib_signal_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_set_ip_flow_hash_payload_hton(vapi_payload_set_ip_flow_hash *payload)
{
  payload->vrf_id = htobe32(payload->vrf_id);
}

static inline void vapi_msg_set_ip_flow_hash_payload_ntoh(vapi_payload_set_ip_flow_hash *payload)
{
  payload->vrf_id = be32toh(payload->vrf_id);
}

static inline uword vapi_calc_set_ip_flow_hash_msg_size(vapi_msg_set_ip_flow_hash *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_set_ip_flow_hash_hton(vapi_msg_set_ip_flow_hash *msg)
{
  VAPI_DBG("Swapping `vapi_msg_set_ip_flow_hash'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_set_ip_flow_hash_payload_hton(&msg->payload);
}

static inline void vapi_msg_set_ip_flow_hash_ntoh(vapi_msg_set_ip_flow_hash *msg)
{
  VAPI_DBG("Swapping `vapi_msg_set_ip_flow_hash'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_set_ip_flow_hash_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ip6_mfib_details_payload_hton(vapi_payload_ip6_mfib_details *payload)
{
  payload->table_id = htobe32(payload->table_id);
  payload->count = htobe32(payload->count);
  do { unsigned i; for (i = 0; i < be32toh(payload->count); ++i) { vapi_type_fib_path_hton(&payload->path[i]); } } while(0);
}

static inline void vapi_msg_ip6_mfib_details_payload_ntoh(vapi_payload_ip6_mfib_details *payload)
{
  payload->table_id = be32toh(payload->table_id);
  payload->count = be32toh(payload->count);
  do { unsigned i; for (i = 0; i < payload->count; ++i) { vapi_type_fib_path_ntoh(&payload->path[i]); } } while(0);
}

static inline uword vapi_calc_ip6_mfib_details_msg_size(vapi_msg_ip6_mfib_details *msg)
{
  return sizeof(*msg)+ msg->payload.count * sizeof(msg->payload.path[0]);
}

static inline void vapi_msg_ip6_mfib_details_hton(vapi_msg_ip6_mfib_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip6_mfib_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_ip6_mfib_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_ip6_mfib_details_ntoh(vapi_msg_ip6_mfib_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip6_mfib_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_ip6_mfib_details_payload_ntoh(&msg->payload);
}

static inline vapi_msg_ip_address_dump* vapi_alloc_ip_address_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_ip_address_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_ip_address_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_ip_address_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_ip_address_dump);

  return msg;
}

static inline vapi_error_e vapi_ip_address_dump(struct vapi_ctx_s *ctx,
  vapi_msg_ip_address_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_ip_address_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_ip_address_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_ip_address_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_ip6_fib_dump* vapi_alloc_ip6_fib_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_ip6_fib_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_ip6_fib_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_ip6_fib_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_ip6_fib_dump);

  return msg;
}

static inline vapi_error_e vapi_ip6_fib_dump(struct vapi_ctx_s *ctx,
  vapi_msg_ip6_fib_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_ip6_fib_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_ip6_fib_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_ip6_fib_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_ip6nd_proxy_add_del* vapi_alloc_ip6nd_proxy_add_del(struct vapi_ctx_s *ctx)
{
  vapi_msg_ip6nd_proxy_add_del *msg = NULL;
  const size_t size = sizeof(vapi_msg_ip6nd_proxy_add_del);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_ip6nd_proxy_add_del*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_ip6nd_proxy_add_del);

  return msg;
}

static inline vapi_error_e vapi_ip6nd_proxy_add_del(struct vapi_ctx_s *ctx,
  vapi_msg_ip6nd_proxy_add_del *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_ip6nd_proxy_add_del_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_ip6nd_proxy_add_del_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_ip6nd_proxy_add_del_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_ip_table_add_del* vapi_alloc_ip_table_add_del(struct vapi_ctx_s *ctx)
{
  vapi_msg_ip_table_add_del *msg = NULL;
  const size_t size = sizeof(vapi_msg_ip_table_add_del);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_ip_table_add_del*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_ip_table_add_del);

  return msg;
}

static inline vapi_error_e vapi_ip_table_add_del(struct vapi_ctx_s *ctx,
  vapi_msg_ip_table_add_del *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_ip_table_add_del_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_ip_table_add_del_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_ip_table_add_del_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_sw_interface_ip6_set_link_local_address* vapi_alloc_sw_interface_ip6_set_link_local_address(struct vapi_ctx_s *ctx)
{
  vapi_msg_sw_interface_ip6_set_link_local_address *msg = NULL;
  const size_t size = sizeof(vapi_msg_sw_interface_ip6_set_link_local_address);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_sw_interface_ip6_set_link_local_address*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_sw_interface_ip6_set_link_local_address);

  return msg;
}

static inline vapi_error_e vapi_sw_interface_ip6_set_link_local_address(struct vapi_ctx_s *ctx,
  vapi_msg_sw_interface_ip6_set_link_local_address *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_sw_interface_ip6_set_link_local_address_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_sw_interface_ip6_set_link_local_address_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_sw_interface_ip6_set_link_local_address_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_sw_interface_ip6nd_ra_prefix* vapi_alloc_sw_interface_ip6nd_ra_prefix(struct vapi_ctx_s *ctx)
{
  vapi_msg_sw_interface_ip6nd_ra_prefix *msg = NULL;
  const size_t size = sizeof(vapi_msg_sw_interface_ip6nd_ra_prefix);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_sw_interface_ip6nd_ra_prefix*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_sw_interface_ip6nd_ra_prefix);

  return msg;
}

static inline vapi_error_e vapi_sw_interface_ip6nd_ra_prefix(struct vapi_ctx_s *ctx,
  vapi_msg_sw_interface_ip6nd_ra_prefix *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_sw_interface_ip6nd_ra_prefix_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_sw_interface_ip6nd_ra_prefix_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_sw_interface_ip6nd_ra_prefix_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_ip6_mfib_dump* vapi_alloc_ip6_mfib_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_ip6_mfib_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_ip6_mfib_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_ip6_mfib_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_ip6_mfib_dump);

  return msg;
}

static inline vapi_error_e vapi_ip6_mfib_dump(struct vapi_ctx_s *ctx,
  vapi_msg_ip6_mfib_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_ip6_mfib_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_ip6_mfib_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_ip6_mfib_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_sw_interface_ip6nd_ra_config* vapi_alloc_sw_interface_ip6nd_ra_config(struct vapi_ctx_s *ctx)
{
  vapi_msg_sw_interface_ip6nd_ra_config *msg = NULL;
  const size_t size = sizeof(vapi_msg_sw_interface_ip6nd_ra_config);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_sw_interface_ip6nd_ra_config*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_sw_interface_ip6nd_ra_config);

  return msg;
}

static inline vapi_error_e vapi_sw_interface_ip6nd_ra_config(struct vapi_ctx_s *ctx,
  vapi_msg_sw_interface_ip6nd_ra_config *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_sw_interface_ip6nd_ra_config_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_sw_interface_ip6nd_ra_config_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_sw_interface_ip6nd_ra_config_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_sw_interface_ip6_enable_disable* vapi_alloc_sw_interface_ip6_enable_disable(struct vapi_ctx_s *ctx)
{
  vapi_msg_sw_interface_ip6_enable_disable *msg = NULL;
  const size_t size = sizeof(vapi_msg_sw_interface_ip6_enable_disable);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_sw_interface_ip6_enable_disable*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_sw_interface_ip6_enable_disable);

  return msg;
}

static inline vapi_error_e vapi_sw_interface_ip6_enable_disable(struct vapi_ctx_s *ctx,
  vapi_msg_sw_interface_ip6_enable_disable *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_sw_interface_ip6_enable_disable_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_sw_interface_ip6_enable_disable_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_sw_interface_ip6_enable_disable_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_mfib_signal_dump* vapi_alloc_mfib_signal_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_mfib_signal_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_mfib_signal_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_mfib_signal_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_mfib_signal_dump);

  return msg;
}

static inline vapi_error_e vapi_mfib_signal_dump(struct vapi_ctx_s *ctx,
  vapi_msg_mfib_signal_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_mfib_signal_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_mfib_signal_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_mfib_signal_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_ip_mfib_dump* vapi_alloc_ip_mfib_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_ip_mfib_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_ip_mfib_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_ip_mfib_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_ip_mfib_dump);

  return msg;
}

static inline vapi_error_e vapi_ip_mfib_dump(struct vapi_ctx_s *ctx,
  vapi_msg_ip_mfib_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_ip_mfib_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_ip_mfib_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_ip_mfib_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_ip_dump* vapi_alloc_ip_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_ip_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_ip_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_ip_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_ip_dump);

  return msg;
}

static inline vapi_error_e vapi_ip_dump(struct vapi_ctx_s *ctx,
  vapi_msg_ip_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_ip_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_ip_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_ip_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_ip_neighbor_add_del* vapi_alloc_ip_neighbor_add_del(struct vapi_ctx_s *ctx)
{
  vapi_msg_ip_neighbor_add_del *msg = NULL;
  const size_t size = sizeof(vapi_msg_ip_neighbor_add_del);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_ip_neighbor_add_del*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_ip_neighbor_add_del);

  return msg;
}

static inline vapi_error_e vapi_ip_neighbor_add_del(struct vapi_ctx_s *ctx,
  vapi_msg_ip_neighbor_add_del *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_ip_neighbor_add_del_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_ip_neighbor_add_del_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_ip_neighbor_add_del_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_ip_neighbor_dump* vapi_alloc_ip_neighbor_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_ip_neighbor_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_ip_neighbor_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_ip_neighbor_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_ip_neighbor_dump);

  return msg;
}

static inline vapi_error_e vapi_ip_neighbor_dump(struct vapi_ctx_s *ctx,
  vapi_msg_ip_neighbor_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_ip_neighbor_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_ip_neighbor_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_ip_neighbor_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_ip_add_del_route* vapi_alloc_ip_add_del_route(struct vapi_ctx_s *ctx, size_t next_hop_out_label_stack_array_size)
{
  vapi_msg_ip_add_del_route *msg = NULL;
  const size_t size = sizeof(vapi_msg_ip_add_del_route) + sizeof(msg->payload.next_hop_out_label_stack[0]) * next_hop_out_label_stack_array_size;
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_ip_add_del_route*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_ip_add_del_route);
  msg->payload.next_hop_n_out_labels = next_hop_out_label_stack_array_size;
  return msg;
}

static inline vapi_error_e vapi_ip_add_del_route(struct vapi_ctx_s *ctx,
  vapi_msg_ip_add_del_route *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_ip_add_del_route_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_ip_add_del_route_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_ip_add_del_route_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_ip6nd_proxy_dump* vapi_alloc_ip6nd_proxy_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_ip6nd_proxy_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_ip6nd_proxy_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_ip6nd_proxy_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_ip6nd_proxy_dump);

  return msg;
}

static inline vapi_error_e vapi_ip6nd_proxy_dump(struct vapi_ctx_s *ctx,
  vapi_msg_ip6nd_proxy_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_ip6nd_proxy_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_ip6nd_proxy_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_ip6nd_proxy_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_ip_fib_dump* vapi_alloc_ip_fib_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_ip_fib_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_ip_fib_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_ip_fib_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_ip_fib_dump);

  return msg;
}

static inline vapi_error_e vapi_ip_fib_dump(struct vapi_ctx_s *ctx,
  vapi_msg_ip_fib_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_ip_fib_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_ip_fib_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_ip_fib_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_ip_mroute_add_del* vapi_alloc_ip_mroute_add_del(struct vapi_ctx_s *ctx)
{
  vapi_msg_ip_mroute_add_del *msg = NULL;
  const size_t size = sizeof(vapi_msg_ip_mroute_add_del);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_ip_mroute_add_del*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_ip_mroute_add_del);

  return msg;
}

static inline vapi_error_e vapi_ip_mroute_add_del(struct vapi_ctx_s *ctx,
  vapi_msg_ip_mroute_add_del *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_ip_mroute_add_del_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_ip_mroute_add_del_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_ip_mroute_add_del_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_set_ip_flow_hash* vapi_alloc_set_ip_flow_hash(struct vapi_ctx_s *ctx)
{
  vapi_msg_set_ip_flow_hash *msg = NULL;
  const size_t size = sizeof(vapi_msg_set_ip_flow_hash);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_set_ip_flow_hash*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_set_ip_flow_hash);

  return msg;
}

static inline vapi_error_e vapi_set_ip_flow_hash(struct vapi_ctx_s *ctx,
  vapi_msg_set_ip_flow_hash *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_set_ip_flow_hash_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_set_ip_flow_hash_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_set_ip_flow_hash_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}



static void __attribute__((constructor)) __vapi_constructor_set_ip_flow_hash_reply()
{
  static const char name[] = "set_ip_flow_hash_reply";
  static const char name_with_crc[] = "set_ip_flow_hash_reply_35a9e5eb";
  static vapi_message_desc_t __vapi_metadata_set_ip_flow_hash_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_set_ip_flow_hash_reply, payload),
    sizeof(vapi_msg_set_ip_flow_hash_reply),
    (generic_swap_fn_t)vapi_msg_set_ip_flow_hash_reply_hton,
    (generic_swap_fn_t)vapi_msg_set_ip_flow_hash_reply_ntoh,
    ~0,
  };

  vapi_msg_id_set_ip_flow_hash_reply = vapi_register_msg(&__vapi_metadata_set_ip_flow_hash_reply);
  VAPI_DBG("Assigned msg id %d to set_ip_flow_hash_reply", vapi_msg_id_set_ip_flow_hash_reply);
}

static void __attribute__((constructor)) __vapi_constructor_ip_address_dump()
{
  static const char name[] = "ip_address_dump";
  static const char name_with_crc[] = "ip_address_dump_632e859a";
  static vapi_message_desc_t __vapi_metadata_ip_address_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_ip_address_dump, payload),
    sizeof(vapi_msg_ip_address_dump),
    (generic_swap_fn_t)vapi_msg_ip_address_dump_hton,
    (generic_swap_fn_t)vapi_msg_ip_address_dump_ntoh,
    ~0,
  };

  vapi_msg_id_ip_address_dump = vapi_register_msg(&__vapi_metadata_ip_address_dump);
  VAPI_DBG("Assigned msg id %d to ip_address_dump", vapi_msg_id_ip_address_dump);
}

static void __attribute__((constructor)) __vapi_constructor_ip_mroute_add_del_reply()
{
  static const char name[] = "ip_mroute_add_del_reply";
  static const char name_with_crc[] = "ip_mroute_add_del_reply_8cabe02c";
  static vapi_message_desc_t __vapi_metadata_ip_mroute_add_del_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_ip_mroute_add_del_reply, payload),
    sizeof(vapi_msg_ip_mroute_add_del_reply),
    (generic_swap_fn_t)vapi_msg_ip_mroute_add_del_reply_hton,
    (generic_swap_fn_t)vapi_msg_ip_mroute_add_del_reply_ntoh,
    ~0,
  };

  vapi_msg_id_ip_mroute_add_del_reply = vapi_register_msg(&__vapi_metadata_ip_mroute_add_del_reply);
  VAPI_DBG("Assigned msg id %d to ip_mroute_add_del_reply", vapi_msg_id_ip_mroute_add_del_reply);
}

static void __attribute__((constructor)) __vapi_constructor_ip6_fib_details()
{
  static const char name[] = "ip6_fib_details";
  static const char name_with_crc[] = "ip6_fib_details_f5f9e17e";
  static vapi_message_desc_t __vapi_metadata_ip6_fib_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_ip6_fib_details, payload),
    sizeof(vapi_msg_ip6_fib_details),
    (generic_swap_fn_t)vapi_msg_ip6_fib_details_hton,
    (generic_swap_fn_t)vapi_msg_ip6_fib_details_ntoh,
    ~0,
  };

  vapi_msg_id_ip6_fib_details = vapi_register_msg(&__vapi_metadata_ip6_fib_details);
  VAPI_DBG("Assigned msg id %d to ip6_fib_details", vapi_msg_id_ip6_fib_details);
}

static void __attribute__((constructor)) __vapi_constructor_ip6_fib_dump()
{
  static const char name[] = "ip6_fib_dump";
  static const char name_with_crc[] = "ip6_fib_dump_25c89676";
  static vapi_message_desc_t __vapi_metadata_ip6_fib_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_ip6_fib_dump),
    (generic_swap_fn_t)vapi_msg_ip6_fib_dump_hton,
    (generic_swap_fn_t)vapi_msg_ip6_fib_dump_ntoh,
    ~0,
  };

  vapi_msg_id_ip6_fib_dump = vapi_register_msg(&__vapi_metadata_ip6_fib_dump);
  VAPI_DBG("Assigned msg id %d to ip6_fib_dump", vapi_msg_id_ip6_fib_dump);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_ip6nd_ra_prefix_reply()
{
  static const char name[] = "sw_interface_ip6nd_ra_prefix_reply";
  static const char name_with_crc[] = "sw_interface_ip6nd_ra_prefix_reply_8050adb3";
  static vapi_message_desc_t __vapi_metadata_sw_interface_ip6nd_ra_prefix_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_sw_interface_ip6nd_ra_prefix_reply, payload),
    sizeof(vapi_msg_sw_interface_ip6nd_ra_prefix_reply),
    (generic_swap_fn_t)vapi_msg_sw_interface_ip6nd_ra_prefix_reply_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_ip6nd_ra_prefix_reply_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_ip6nd_ra_prefix_reply = vapi_register_msg(&__vapi_metadata_sw_interface_ip6nd_ra_prefix_reply);
  VAPI_DBG("Assigned msg id %d to sw_interface_ip6nd_ra_prefix_reply", vapi_msg_id_sw_interface_ip6nd_ra_prefix_reply);
}

static void __attribute__((constructor)) __vapi_constructor_ip_details()
{
  static const char name[] = "ip_details";
  static const char name_with_crc[] = "ip_details_695c8227";
  static vapi_message_desc_t __vapi_metadata_ip_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    false,
    0,
    offsetof(vapi_msg_ip_details, payload),
    sizeof(vapi_msg_ip_details),
    (generic_swap_fn_t)vapi_msg_ip_details_hton,
    (generic_swap_fn_t)vapi_msg_ip_details_ntoh,
    ~0,
  };

  vapi_msg_id_ip_details = vapi_register_msg(&__vapi_metadata_ip_details);
  VAPI_DBG("Assigned msg id %d to ip_details", vapi_msg_id_ip_details);
}

static void __attribute__((constructor)) __vapi_constructor_ip6nd_proxy_add_del()
{
  static const char name[] = "ip6nd_proxy_add_del";
  static const char name_with_crc[] = "ip6nd_proxy_add_del_c56f802d";
  static vapi_message_desc_t __vapi_metadata_ip6nd_proxy_add_del = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_ip6nd_proxy_add_del, payload),
    sizeof(vapi_msg_ip6nd_proxy_add_del),
    (generic_swap_fn_t)vapi_msg_ip6nd_proxy_add_del_hton,
    (generic_swap_fn_t)vapi_msg_ip6nd_proxy_add_del_ntoh,
    ~0,
  };

  vapi_msg_id_ip6nd_proxy_add_del = vapi_register_msg(&__vapi_metadata_ip6nd_proxy_add_del);
  VAPI_DBG("Assigned msg id %d to ip6nd_proxy_add_del", vapi_msg_id_ip6nd_proxy_add_del);
}

static void __attribute__((constructor)) __vapi_constructor_ip_add_del_route_reply()
{
  static const char name[] = "ip_add_del_route_reply";
  static const char name_with_crc[] = "ip_add_del_route_reply_ea57492b";
  static vapi_message_desc_t __vapi_metadata_ip_add_del_route_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_ip_add_del_route_reply, payload),
    sizeof(vapi_msg_ip_add_del_route_reply),
    (generic_swap_fn_t)vapi_msg_ip_add_del_route_reply_hton,
    (generic_swap_fn_t)vapi_msg_ip_add_del_route_reply_ntoh,
    ~0,
  };

  vapi_msg_id_ip_add_del_route_reply = vapi_register_msg(&__vapi_metadata_ip_add_del_route_reply);
  VAPI_DBG("Assigned msg id %d to ip_add_del_route_reply", vapi_msg_id_ip_add_del_route_reply);
}

static void __attribute__((constructor)) __vapi_constructor_ip_table_add_del()
{
  static const char name[] = "ip_table_add_del";
  static const char name_with_crc[] = "ip_table_add_del_7192123e";
  static vapi_message_desc_t __vapi_metadata_ip_table_add_del = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_ip_table_add_del, payload),
    sizeof(vapi_msg_ip_table_add_del),
    (generic_swap_fn_t)vapi_msg_ip_table_add_del_hton,
    (generic_swap_fn_t)vapi_msg_ip_table_add_del_ntoh,
    ~0,
  };

  vapi_msg_id_ip_table_add_del = vapi_register_msg(&__vapi_metadata_ip_table_add_del);
  VAPI_DBG("Assigned msg id %d to ip_table_add_del", vapi_msg_id_ip_table_add_del);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_ip6_set_link_local_address()
{
  static const char name[] = "sw_interface_ip6_set_link_local_address";
  static const char name_with_crc[] = "sw_interface_ip6_set_link_local_address_3db6d52b";
  static vapi_message_desc_t __vapi_metadata_sw_interface_ip6_set_link_local_address = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_sw_interface_ip6_set_link_local_address, payload),
    sizeof(vapi_msg_sw_interface_ip6_set_link_local_address),
    (generic_swap_fn_t)vapi_msg_sw_interface_ip6_set_link_local_address_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_ip6_set_link_local_address_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_ip6_set_link_local_address = vapi_register_msg(&__vapi_metadata_sw_interface_ip6_set_link_local_address);
  VAPI_DBG("Assigned msg id %d to sw_interface_ip6_set_link_local_address", vapi_msg_id_sw_interface_ip6_set_link_local_address);
}

static void __attribute__((constructor)) __vapi_constructor_ip_fib_details()
{
  static const char name[] = "ip_fib_details";
  static const char name_with_crc[] = "ip_fib_details_273e00c4";
  static vapi_message_desc_t __vapi_metadata_ip_fib_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_ip_fib_details, payload),
    sizeof(vapi_msg_ip_fib_details),
    (generic_swap_fn_t)vapi_msg_ip_fib_details_hton,
    (generic_swap_fn_t)vapi_msg_ip_fib_details_ntoh,
    ~0,
  };

  vapi_msg_id_ip_fib_details = vapi_register_msg(&__vapi_metadata_ip_fib_details);
  VAPI_DBG("Assigned msg id %d to ip_fib_details", vapi_msg_id_ip_fib_details);
}

static void __attribute__((constructor)) __vapi_constructor_ip6nd_proxy_details()
{
  static const char name[] = "ip6nd_proxy_details";
  static const char name_with_crc[] = "ip6nd_proxy_details_f805ccc1";
  static vapi_message_desc_t __vapi_metadata_ip6nd_proxy_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_ip6nd_proxy_details, payload),
    sizeof(vapi_msg_ip6nd_proxy_details),
    (generic_swap_fn_t)vapi_msg_ip6nd_proxy_details_hton,
    (generic_swap_fn_t)vapi_msg_ip6nd_proxy_details_ntoh,
    ~0,
  };

  vapi_msg_id_ip6nd_proxy_details = vapi_register_msg(&__vapi_metadata_ip6nd_proxy_details);
  VAPI_DBG("Assigned msg id %d to ip6nd_proxy_details", vapi_msg_id_ip6nd_proxy_details);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_ip6_set_link_local_address_reply()
{
  static const char name[] = "sw_interface_ip6_set_link_local_address_reply";
  static const char name_with_crc[] = "sw_interface_ip6_set_link_local_address_reply_0a781e17";
  static vapi_message_desc_t __vapi_metadata_sw_interface_ip6_set_link_local_address_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_sw_interface_ip6_set_link_local_address_reply, payload),
    sizeof(vapi_msg_sw_interface_ip6_set_link_local_address_reply),
    (generic_swap_fn_t)vapi_msg_sw_interface_ip6_set_link_local_address_reply_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_ip6_set_link_local_address_reply_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_ip6_set_link_local_address_reply = vapi_register_msg(&__vapi_metadata_sw_interface_ip6_set_link_local_address_reply);
  VAPI_DBG("Assigned msg id %d to sw_interface_ip6_set_link_local_address_reply", vapi_msg_id_sw_interface_ip6_set_link_local_address_reply);
}

static void __attribute__((constructor)) __vapi_constructor_ip_neighbor_add_del_reply()
{
  static const char name[] = "ip_neighbor_add_del_reply";
  static const char name_with_crc[] = "ip_neighbor_add_del_reply_e5b0f318";
  static vapi_message_desc_t __vapi_metadata_ip_neighbor_add_del_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_ip_neighbor_add_del_reply, payload),
    sizeof(vapi_msg_ip_neighbor_add_del_reply),
    (generic_swap_fn_t)vapi_msg_ip_neighbor_add_del_reply_hton,
    (generic_swap_fn_t)vapi_msg_ip_neighbor_add_del_reply_ntoh,
    ~0,
  };

  vapi_msg_id_ip_neighbor_add_del_reply = vapi_register_msg(&__vapi_metadata_ip_neighbor_add_del_reply);
  VAPI_DBG("Assigned msg id %d to ip_neighbor_add_del_reply", vapi_msg_id_ip_neighbor_add_del_reply);
}

static void __attribute__((constructor)) __vapi_constructor_ip_table_add_del_reply()
{
  static const char name[] = "ip_table_add_del_reply";
  static const char name_with_crc[] = "ip_table_add_del_reply_7da725be";
  static vapi_message_desc_t __vapi_metadata_ip_table_add_del_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_ip_table_add_del_reply, payload),
    sizeof(vapi_msg_ip_table_add_del_reply),
    (generic_swap_fn_t)vapi_msg_ip_table_add_del_reply_hton,
    (generic_swap_fn_t)vapi_msg_ip_table_add_del_reply_ntoh,
    ~0,
  };

  vapi_msg_id_ip_table_add_del_reply = vapi_register_msg(&__vapi_metadata_ip_table_add_del_reply);
  VAPI_DBG("Assigned msg id %d to ip_table_add_del_reply", vapi_msg_id_ip_table_add_del_reply);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_ip6nd_ra_prefix()
{
  static const char name[] = "sw_interface_ip6nd_ra_prefix";
  static const char name_with_crc[] = "sw_interface_ip6nd_ra_prefix_5db6555c";
  static vapi_message_desc_t __vapi_metadata_sw_interface_ip6nd_ra_prefix = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_sw_interface_ip6nd_ra_prefix, payload),
    sizeof(vapi_msg_sw_interface_ip6nd_ra_prefix),
    (generic_swap_fn_t)vapi_msg_sw_interface_ip6nd_ra_prefix_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_ip6nd_ra_prefix_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_ip6nd_ra_prefix = vapi_register_msg(&__vapi_metadata_sw_interface_ip6nd_ra_prefix);
  VAPI_DBG("Assigned msg id %d to sw_interface_ip6nd_ra_prefix", vapi_msg_id_sw_interface_ip6nd_ra_prefix);
}

static void __attribute__((constructor)) __vapi_constructor_ip6_mfib_dump()
{
  static const char name[] = "ip6_mfib_dump";
  static const char name_with_crc[] = "ip6_mfib_dump_0839e143";
  static vapi_message_desc_t __vapi_metadata_ip6_mfib_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_ip6_mfib_dump),
    (generic_swap_fn_t)vapi_msg_ip6_mfib_dump_hton,
    (generic_swap_fn_t)vapi_msg_ip6_mfib_dump_ntoh,
    ~0,
  };

  vapi_msg_id_ip6_mfib_dump = vapi_register_msg(&__vapi_metadata_ip6_mfib_dump);
  VAPI_DBG("Assigned msg id %d to ip6_mfib_dump", vapi_msg_id_ip6_mfib_dump);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_ip6nd_ra_config()
{
  static const char name[] = "sw_interface_ip6nd_ra_config";
  static const char name_with_crc[] = "sw_interface_ip6nd_ra_config_ec4a29f6";
  static vapi_message_desc_t __vapi_metadata_sw_interface_ip6nd_ra_config = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_sw_interface_ip6nd_ra_config, payload),
    sizeof(vapi_msg_sw_interface_ip6nd_ra_config),
    (generic_swap_fn_t)vapi_msg_sw_interface_ip6nd_ra_config_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_ip6nd_ra_config_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_ip6nd_ra_config = vapi_register_msg(&__vapi_metadata_sw_interface_ip6nd_ra_config);
  VAPI_DBG("Assigned msg id %d to sw_interface_ip6nd_ra_config", vapi_msg_id_sw_interface_ip6nd_ra_config);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_ip6_enable_disable()
{
  static const char name[] = "sw_interface_ip6_enable_disable";
  static const char name_with_crc[] = "sw_interface_ip6_enable_disable_4a4e5405";
  static vapi_message_desc_t __vapi_metadata_sw_interface_ip6_enable_disable = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_sw_interface_ip6_enable_disable, payload),
    sizeof(vapi_msg_sw_interface_ip6_enable_disable),
    (generic_swap_fn_t)vapi_msg_sw_interface_ip6_enable_disable_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_ip6_enable_disable_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_ip6_enable_disable = vapi_register_msg(&__vapi_metadata_sw_interface_ip6_enable_disable);
  VAPI_DBG("Assigned msg id %d to sw_interface_ip6_enable_disable", vapi_msg_id_sw_interface_ip6_enable_disable);
}

static void __attribute__((constructor)) __vapi_constructor_ip_mfib_details()
{
  static const char name[] = "ip_mfib_details";
  static const char name_with_crc[] = "ip_mfib_details_395e5699";
  static vapi_message_desc_t __vapi_metadata_ip_mfib_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_ip_mfib_details, payload),
    sizeof(vapi_msg_ip_mfib_details),
    (generic_swap_fn_t)vapi_msg_ip_mfib_details_hton,
    (generic_swap_fn_t)vapi_msg_ip_mfib_details_ntoh,
    ~0,
  };

  vapi_msg_id_ip_mfib_details = vapi_register_msg(&__vapi_metadata_ip_mfib_details);
  VAPI_DBG("Assigned msg id %d to ip_mfib_details", vapi_msg_id_ip_mfib_details);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_ip6_enable_disable_reply()
{
  static const char name[] = "sw_interface_ip6_enable_disable_reply";
  static const char name_with_crc[] = "sw_interface_ip6_enable_disable_reply_eb8b4a40";
  static vapi_message_desc_t __vapi_metadata_sw_interface_ip6_enable_disable_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_sw_interface_ip6_enable_disable_reply, payload),
    sizeof(vapi_msg_sw_interface_ip6_enable_disable_reply),
    (generic_swap_fn_t)vapi_msg_sw_interface_ip6_enable_disable_reply_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_ip6_enable_disable_reply_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_ip6_enable_disable_reply = vapi_register_msg(&__vapi_metadata_sw_interface_ip6_enable_disable_reply);
  VAPI_DBG("Assigned msg id %d to sw_interface_ip6_enable_disable_reply", vapi_msg_id_sw_interface_ip6_enable_disable_reply);
}

static void __attribute__((constructor)) __vapi_constructor_ip_address_details()
{
  static const char name[] = "ip_address_details";
  static const char name_with_crc[] = "ip_address_details_190d4266";
  static vapi_message_desc_t __vapi_metadata_ip_address_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_ip_address_details, payload),
    sizeof(vapi_msg_ip_address_details),
    (generic_swap_fn_t)vapi_msg_ip_address_details_hton,
    (generic_swap_fn_t)vapi_msg_ip_address_details_ntoh,
    ~0,
  };

  vapi_msg_id_ip_address_details = vapi_register_msg(&__vapi_metadata_ip_address_details);
  VAPI_DBG("Assigned msg id %d to ip_address_details", vapi_msg_id_ip_address_details);
}

static void __attribute__((constructor)) __vapi_constructor_mfib_signal_dump()
{
  static const char name[] = "mfib_signal_dump";
  static const char name_with_crc[] = "mfib_signal_dump_bbbbd40d";
  static vapi_message_desc_t __vapi_metadata_mfib_signal_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_mfib_signal_dump),
    (generic_swap_fn_t)vapi_msg_mfib_signal_dump_hton,
    (generic_swap_fn_t)vapi_msg_mfib_signal_dump_ntoh,
    ~0,
  };

  vapi_msg_id_mfib_signal_dump = vapi_register_msg(&__vapi_metadata_mfib_signal_dump);
  VAPI_DBG("Assigned msg id %d to mfib_signal_dump", vapi_msg_id_mfib_signal_dump);
}

static void __attribute__((constructor)) __vapi_constructor_ip_mfib_dump()
{
  static const char name[] = "ip_mfib_dump";
  static const char name_with_crc[] = "ip_mfib_dump_ee61390e";
  static vapi_message_desc_t __vapi_metadata_ip_mfib_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_ip_mfib_dump),
    (generic_swap_fn_t)vapi_msg_ip_mfib_dump_hton,
    (generic_swap_fn_t)vapi_msg_ip_mfib_dump_ntoh,
    ~0,
  };

  vapi_msg_id_ip_mfib_dump = vapi_register_msg(&__vapi_metadata_ip_mfib_dump);
  VAPI_DBG("Assigned msg id %d to ip_mfib_dump", vapi_msg_id_ip_mfib_dump);
}

static void __attribute__((constructor)) __vapi_constructor_ip_dump()
{
  static const char name[] = "ip_dump";
  static const char name_with_crc[] = "ip_dump_3c1e33e0";
  static vapi_message_desc_t __vapi_metadata_ip_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_ip_dump, payload),
    sizeof(vapi_msg_ip_dump),
    (generic_swap_fn_t)vapi_msg_ip_dump_hton,
    (generic_swap_fn_t)vapi_msg_ip_dump_ntoh,
    ~0,
  };

  vapi_msg_id_ip_dump = vapi_register_msg(&__vapi_metadata_ip_dump);
  VAPI_DBG("Assigned msg id %d to ip_dump", vapi_msg_id_ip_dump);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_ip6nd_ra_config_reply()
{
  static const char name[] = "sw_interface_ip6nd_ra_config_reply";
  static const char name_with_crc[] = "sw_interface_ip6nd_ra_config_reply_16e25c5b";
  static vapi_message_desc_t __vapi_metadata_sw_interface_ip6nd_ra_config_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_sw_interface_ip6nd_ra_config_reply, payload),
    sizeof(vapi_msg_sw_interface_ip6nd_ra_config_reply),
    (generic_swap_fn_t)vapi_msg_sw_interface_ip6nd_ra_config_reply_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_ip6nd_ra_config_reply_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_ip6nd_ra_config_reply = vapi_register_msg(&__vapi_metadata_sw_interface_ip6nd_ra_config_reply);
  VAPI_DBG("Assigned msg id %d to sw_interface_ip6nd_ra_config_reply", vapi_msg_id_sw_interface_ip6nd_ra_config_reply);
}

static void __attribute__((constructor)) __vapi_constructor_ip_neighbor_add_del()
{
  static const char name[] = "ip_neighbor_add_del";
  static const char name_with_crc[] = "ip_neighbor_add_del_5a0d070b";
  static vapi_message_desc_t __vapi_metadata_ip_neighbor_add_del = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_ip_neighbor_add_del, payload),
    sizeof(vapi_msg_ip_neighbor_add_del),
    (generic_swap_fn_t)vapi_msg_ip_neighbor_add_del_hton,
    (generic_swap_fn_t)vapi_msg_ip_neighbor_add_del_ntoh,
    ~0,
  };

  vapi_msg_id_ip_neighbor_add_del = vapi_register_msg(&__vapi_metadata_ip_neighbor_add_del);
  VAPI_DBG("Assigned msg id %d to ip_neighbor_add_del", vapi_msg_id_ip_neighbor_add_del);
}

static void __attribute__((constructor)) __vapi_constructor_ip_neighbor_dump()
{
  static const char name[] = "ip_neighbor_dump";
  static const char name_with_crc[] = "ip_neighbor_dump_3289e160";
  static vapi_message_desc_t __vapi_metadata_ip_neighbor_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_ip_neighbor_dump, payload),
    sizeof(vapi_msg_ip_neighbor_dump),
    (generic_swap_fn_t)vapi_msg_ip_neighbor_dump_hton,
    (generic_swap_fn_t)vapi_msg_ip_neighbor_dump_ntoh,
    ~0,
  };

  vapi_msg_id_ip_neighbor_dump = vapi_register_msg(&__vapi_metadata_ip_neighbor_dump);
  VAPI_DBG("Assigned msg id %d to ip_neighbor_dump", vapi_msg_id_ip_neighbor_dump);
}

static void __attribute__((constructor)) __vapi_constructor_ip_add_del_route()
{
  static const char name[] = "ip_add_del_route";
  static const char name_with_crc[] = "ip_add_del_route_93e81ee6";
  static vapi_message_desc_t __vapi_metadata_ip_add_del_route = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_ip_add_del_route, payload),
    sizeof(vapi_msg_ip_add_del_route),
    (generic_swap_fn_t)vapi_msg_ip_add_del_route_hton,
    (generic_swap_fn_t)vapi_msg_ip_add_del_route_ntoh,
    ~0,
  };

  vapi_msg_id_ip_add_del_route = vapi_register_msg(&__vapi_metadata_ip_add_del_route);
  VAPI_DBG("Assigned msg id %d to ip_add_del_route", vapi_msg_id_ip_add_del_route);
}

static void __attribute__((constructor)) __vapi_constructor_ip6nd_proxy_dump()
{
  static const char name[] = "ip6nd_proxy_dump";
  static const char name_with_crc[] = "ip6nd_proxy_dump_21597d88";
  static vapi_message_desc_t __vapi_metadata_ip6nd_proxy_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_ip6nd_proxy_dump),
    (generic_swap_fn_t)vapi_msg_ip6nd_proxy_dump_hton,
    (generic_swap_fn_t)vapi_msg_ip6nd_proxy_dump_ntoh,
    ~0,
  };

  vapi_msg_id_ip6nd_proxy_dump = vapi_register_msg(&__vapi_metadata_ip6nd_proxy_dump);
  VAPI_DBG("Assigned msg id %d to ip6nd_proxy_dump", vapi_msg_id_ip6nd_proxy_dump);
}

static void __attribute__((constructor)) __vapi_constructor_ip_fib_dump()
{
  static const char name[] = "ip_fib_dump";
  static const char name_with_crc[] = "ip_fib_dump_5fe56ca3";
  static vapi_message_desc_t __vapi_metadata_ip_fib_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_ip_fib_dump),
    (generic_swap_fn_t)vapi_msg_ip_fib_dump_hton,
    (generic_swap_fn_t)vapi_msg_ip_fib_dump_ntoh,
    ~0,
  };

  vapi_msg_id_ip_fib_dump = vapi_register_msg(&__vapi_metadata_ip_fib_dump);
  VAPI_DBG("Assigned msg id %d to ip_fib_dump", vapi_msg_id_ip_fib_dump);
}

static void __attribute__((constructor)) __vapi_constructor_ip_neighbor_details()
{
  static const char name[] = "ip_neighbor_details";
  static const char name_with_crc[] = "ip_neighbor_details_3a00e32a";
  static vapi_message_desc_t __vapi_metadata_ip_neighbor_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_ip_neighbor_details, payload),
    sizeof(vapi_msg_ip_neighbor_details),
    (generic_swap_fn_t)vapi_msg_ip_neighbor_details_hton,
    (generic_swap_fn_t)vapi_msg_ip_neighbor_details_ntoh,
    ~0,
  };

  vapi_msg_id_ip_neighbor_details = vapi_register_msg(&__vapi_metadata_ip_neighbor_details);
  VAPI_DBG("Assigned msg id %d to ip_neighbor_details", vapi_msg_id_ip_neighbor_details);
}

static void __attribute__((constructor)) __vapi_constructor_ip6nd_proxy_add_del_reply()
{
  static const char name[] = "ip6nd_proxy_add_del_reply";
  static const char name_with_crc[] = "ip6nd_proxy_add_del_reply_00ddc2d5";
  static vapi_message_desc_t __vapi_metadata_ip6nd_proxy_add_del_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_ip6nd_proxy_add_del_reply, payload),
    sizeof(vapi_msg_ip6nd_proxy_add_del_reply),
    (generic_swap_fn_t)vapi_msg_ip6nd_proxy_add_del_reply_hton,
    (generic_swap_fn_t)vapi_msg_ip6nd_proxy_add_del_reply_ntoh,
    ~0,
  };

  vapi_msg_id_ip6nd_proxy_add_del_reply = vapi_register_msg(&__vapi_metadata_ip6nd_proxy_add_del_reply);
  VAPI_DBG("Assigned msg id %d to ip6nd_proxy_add_del_reply", vapi_msg_id_ip6nd_proxy_add_del_reply);
}

static void __attribute__((constructor)) __vapi_constructor_ip_mroute_add_del()
{
  static const char name[] = "ip_mroute_add_del";
  static const char name_with_crc[] = "ip_mroute_add_del_8f5f21a8";
  static vapi_message_desc_t __vapi_metadata_ip_mroute_add_del = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_ip_mroute_add_del, payload),
    sizeof(vapi_msg_ip_mroute_add_del),
    (generic_swap_fn_t)vapi_msg_ip_mroute_add_del_hton,
    (generic_swap_fn_t)vapi_msg_ip_mroute_add_del_ntoh,
    ~0,
  };

  vapi_msg_id_ip_mroute_add_del = vapi_register_msg(&__vapi_metadata_ip_mroute_add_del);
  VAPI_DBG("Assigned msg id %d to ip_mroute_add_del", vapi_msg_id_ip_mroute_add_del);
}

static void __attribute__((constructor)) __vapi_constructor_mfib_signal_details()
{
  static const char name[] = "mfib_signal_details";
  static const char name_with_crc[] = "mfib_signal_details_6ba92c72";
  static vapi_message_desc_t __vapi_metadata_mfib_signal_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_mfib_signal_details, payload),
    sizeof(vapi_msg_mfib_signal_details),
    (generic_swap_fn_t)vapi_msg_mfib_signal_details_hton,
    (generic_swap_fn_t)vapi_msg_mfib_signal_details_ntoh,
    ~0,
  };

  vapi_msg_id_mfib_signal_details = vapi_register_msg(&__vapi_metadata_mfib_signal_details);
  VAPI_DBG("Assigned msg id %d to mfib_signal_details", vapi_msg_id_mfib_signal_details);
}

static void __attribute__((constructor)) __vapi_constructor_set_ip_flow_hash()
{
  static const char name[] = "set_ip_flow_hash";
  static const char name_with_crc[] = "set_ip_flow_hash_92ad3798";
  static vapi_message_desc_t __vapi_metadata_set_ip_flow_hash = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_set_ip_flow_hash, payload),
    sizeof(vapi_msg_set_ip_flow_hash),
    (generic_swap_fn_t)vapi_msg_set_ip_flow_hash_hton,
    (generic_swap_fn_t)vapi_msg_set_ip_flow_hash_ntoh,
    ~0,
  };

  vapi_msg_id_set_ip_flow_hash = vapi_register_msg(&__vapi_metadata_set_ip_flow_hash);
  VAPI_DBG("Assigned msg id %d to set_ip_flow_hash", vapi_msg_id_set_ip_flow_hash);
}

static void __attribute__((constructor)) __vapi_constructor_ip6_mfib_details()
{
  static const char name[] = "ip6_mfib_details";
  static const char name_with_crc[] = "ip6_mfib_details_921b153f";
  static vapi_message_desc_t __vapi_metadata_ip6_mfib_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_ip6_mfib_details, payload),
    sizeof(vapi_msg_ip6_mfib_details),
    (generic_swap_fn_t)vapi_msg_ip6_mfib_details_hton,
    (generic_swap_fn_t)vapi_msg_ip6_mfib_details_ntoh,
    ~0,
  };

  vapi_msg_id_ip6_mfib_details = vapi_register_msg(&__vapi_metadata_ip6_mfib_details);
  VAPI_DBG("Assigned msg id %d to ip6_mfib_details", vapi_msg_id_ip6_mfib_details);
}


static inline void vapi_set_vapi_msg_set_ip_flow_hash_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_set_ip_flow_hash_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_set_ip_flow_hash_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ip_mroute_add_del_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ip_mroute_add_del_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ip_mroute_add_del_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ip6_fib_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ip6_fib_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ip6_fib_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_sw_interface_ip6nd_ra_prefix_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_sw_interface_ip6nd_ra_prefix_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_sw_interface_ip6nd_ra_prefix_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ip_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ip_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ip_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ip_add_del_route_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ip_add_del_route_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ip_add_del_route_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ip_fib_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ip_fib_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ip_fib_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ip6nd_proxy_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ip6nd_proxy_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ip6nd_proxy_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_sw_interface_ip6_set_link_local_address_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_sw_interface_ip6_set_link_local_address_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_sw_interface_ip6_set_link_local_address_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ip_neighbor_add_del_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ip_neighbor_add_del_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ip_neighbor_add_del_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ip_table_add_del_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ip_table_add_del_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ip_table_add_del_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ip_mfib_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ip_mfib_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ip_mfib_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_sw_interface_ip6_enable_disable_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_sw_interface_ip6_enable_disable_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_sw_interface_ip6_enable_disable_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ip_address_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ip_address_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ip_address_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_sw_interface_ip6nd_ra_config_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_sw_interface_ip6nd_ra_config_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_sw_interface_ip6nd_ra_config_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ip_neighbor_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ip_neighbor_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ip_neighbor_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ip6nd_proxy_add_del_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ip6nd_proxy_add_del_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ip6nd_proxy_add_del_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_mfib_signal_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_mfib_signal_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_mfib_signal_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ip6_mfib_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ip6_mfib_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ip6_mfib_details, (vapi_event_cb)callback, callback_ctx);
};


#ifdef __cplusplus
}
#endif

#endif
