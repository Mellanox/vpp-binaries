#ifndef __included_hpp_ip_api_json
#define __included_hpp_ip_api_json

#include <vapi/vapi.hpp>
#include <vapi/ip.api.vapi.h>

namespace vapi {

template <> inline void vapi_swap_to_be<vapi_msg_set_ip_flow_hash_reply>(vapi_msg_set_ip_flow_hash_reply *msg)
{
  vapi_msg_set_ip_flow_hash_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_set_ip_flow_hash_reply>(vapi_msg_set_ip_flow_hash_reply *msg)
{
  vapi_msg_set_ip_flow_hash_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_set_ip_flow_hash_reply>()
{
  return ::vapi_msg_id_set_ip_flow_hash_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_set_ip_flow_hash_reply>>()
{
  return ::vapi_msg_id_set_ip_flow_hash_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_set_ip_flow_hash_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_set_ip_flow_hash_reply>(vapi_msg_id_set_ip_flow_hash_reply);
}

template class Msg<vapi_msg_set_ip_flow_hash_reply>;

using Set_ip_flow_hash_reply = Msg<vapi_msg_set_ip_flow_hash_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_ip_address_dump>(vapi_msg_ip_address_dump *msg)
{
  vapi_msg_ip_address_dump_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip_address_dump>(vapi_msg_ip_address_dump *msg)
{
  vapi_msg_ip_address_dump_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip_address_dump>()
{
  return ::vapi_msg_id_ip_address_dump; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip_address_dump>>()
{
  return ::vapi_msg_id_ip_address_dump; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip_address_dump()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip_address_dump>(vapi_msg_id_ip_address_dump);
}

template <> inline vapi_msg_ip_address_dump* vapi_alloc<vapi_msg_ip_address_dump>(Connection &con)
{
  vapi_msg_ip_address_dump* result = vapi_alloc_ip_address_dump(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_ip_address_dump>;

template class Dump<vapi_msg_ip_address_dump, vapi_msg_ip_address_details>;

using Ip_address_dump = Dump<vapi_msg_ip_address_dump, vapi_msg_ip_address_details>;

template <> inline void vapi_swap_to_be<vapi_msg_ip_mroute_add_del_reply>(vapi_msg_ip_mroute_add_del_reply *msg)
{
  vapi_msg_ip_mroute_add_del_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip_mroute_add_del_reply>(vapi_msg_ip_mroute_add_del_reply *msg)
{
  vapi_msg_ip_mroute_add_del_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip_mroute_add_del_reply>()
{
  return ::vapi_msg_id_ip_mroute_add_del_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip_mroute_add_del_reply>>()
{
  return ::vapi_msg_id_ip_mroute_add_del_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip_mroute_add_del_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip_mroute_add_del_reply>(vapi_msg_id_ip_mroute_add_del_reply);
}

template class Msg<vapi_msg_ip_mroute_add_del_reply>;

using Ip_mroute_add_del_reply = Msg<vapi_msg_ip_mroute_add_del_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_ip6_fib_details>(vapi_msg_ip6_fib_details *msg)
{
  vapi_msg_ip6_fib_details_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip6_fib_details>(vapi_msg_ip6_fib_details *msg)
{
  vapi_msg_ip6_fib_details_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip6_fib_details>()
{
  return ::vapi_msg_id_ip6_fib_details; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip6_fib_details>>()
{
  return ::vapi_msg_id_ip6_fib_details; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip6_fib_details()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip6_fib_details>(vapi_msg_id_ip6_fib_details);
}

template class Msg<vapi_msg_ip6_fib_details>;

using Ip6_fib_details = Msg<vapi_msg_ip6_fib_details>;
template <> inline void vapi_swap_to_be<vapi_msg_ip6_fib_dump>(vapi_msg_ip6_fib_dump *msg)
{
  vapi_msg_ip6_fib_dump_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip6_fib_dump>(vapi_msg_ip6_fib_dump *msg)
{
  vapi_msg_ip6_fib_dump_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip6_fib_dump>()
{
  return ::vapi_msg_id_ip6_fib_dump; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip6_fib_dump>>()
{
  return ::vapi_msg_id_ip6_fib_dump; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip6_fib_dump()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip6_fib_dump>(vapi_msg_id_ip6_fib_dump);
}

template <> inline vapi_msg_ip6_fib_dump* vapi_alloc<vapi_msg_ip6_fib_dump>(Connection &con)
{
  vapi_msg_ip6_fib_dump* result = vapi_alloc_ip6_fib_dump(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_ip6_fib_dump>;

template class Dump<vapi_msg_ip6_fib_dump, vapi_msg_ip6_fib_details>;

using Ip6_fib_dump = Dump<vapi_msg_ip6_fib_dump, vapi_msg_ip6_fib_details>;

template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_ip6nd_ra_prefix_reply>(vapi_msg_sw_interface_ip6nd_ra_prefix_reply *msg)
{
  vapi_msg_sw_interface_ip6nd_ra_prefix_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_ip6nd_ra_prefix_reply>(vapi_msg_sw_interface_ip6nd_ra_prefix_reply *msg)
{
  vapi_msg_sw_interface_ip6nd_ra_prefix_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_ip6nd_ra_prefix_reply>()
{
  return ::vapi_msg_id_sw_interface_ip6nd_ra_prefix_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_ip6nd_ra_prefix_reply>>()
{
  return ::vapi_msg_id_sw_interface_ip6nd_ra_prefix_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_ip6nd_ra_prefix_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_ip6nd_ra_prefix_reply>(vapi_msg_id_sw_interface_ip6nd_ra_prefix_reply);
}

template class Msg<vapi_msg_sw_interface_ip6nd_ra_prefix_reply>;

using Sw_interface_ip6nd_ra_prefix_reply = Msg<vapi_msg_sw_interface_ip6nd_ra_prefix_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_ip_details>(vapi_msg_ip_details *msg)
{
  vapi_msg_ip_details_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip_details>(vapi_msg_ip_details *msg)
{
  vapi_msg_ip_details_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip_details>()
{
  return ::vapi_msg_id_ip_details; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip_details>>()
{
  return ::vapi_msg_id_ip_details; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip_details()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip_details>(vapi_msg_id_ip_details);
}

template class Msg<vapi_msg_ip_details>;

using Ip_details = Msg<vapi_msg_ip_details>;
template <> inline void vapi_swap_to_be<vapi_msg_ip6nd_proxy_add_del>(vapi_msg_ip6nd_proxy_add_del *msg)
{
  vapi_msg_ip6nd_proxy_add_del_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip6nd_proxy_add_del>(vapi_msg_ip6nd_proxy_add_del *msg)
{
  vapi_msg_ip6nd_proxy_add_del_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip6nd_proxy_add_del>()
{
  return ::vapi_msg_id_ip6nd_proxy_add_del; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip6nd_proxy_add_del>>()
{
  return ::vapi_msg_id_ip6nd_proxy_add_del; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip6nd_proxy_add_del()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip6nd_proxy_add_del>(vapi_msg_id_ip6nd_proxy_add_del);
}

template <> inline vapi_msg_ip6nd_proxy_add_del* vapi_alloc<vapi_msg_ip6nd_proxy_add_del>(Connection &con)
{
  vapi_msg_ip6nd_proxy_add_del* result = vapi_alloc_ip6nd_proxy_add_del(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_ip6nd_proxy_add_del>;

template class Request<vapi_msg_ip6nd_proxy_add_del, vapi_msg_ip6nd_proxy_add_del_reply>;

using Ip6nd_proxy_add_del = Request<vapi_msg_ip6nd_proxy_add_del, vapi_msg_ip6nd_proxy_add_del_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_ip_add_del_route_reply>(vapi_msg_ip_add_del_route_reply *msg)
{
  vapi_msg_ip_add_del_route_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip_add_del_route_reply>(vapi_msg_ip_add_del_route_reply *msg)
{
  vapi_msg_ip_add_del_route_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip_add_del_route_reply>()
{
  return ::vapi_msg_id_ip_add_del_route_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip_add_del_route_reply>>()
{
  return ::vapi_msg_id_ip_add_del_route_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip_add_del_route_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip_add_del_route_reply>(vapi_msg_id_ip_add_del_route_reply);
}

template class Msg<vapi_msg_ip_add_del_route_reply>;

using Ip_add_del_route_reply = Msg<vapi_msg_ip_add_del_route_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_ip_table_add_del>(vapi_msg_ip_table_add_del *msg)
{
  vapi_msg_ip_table_add_del_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip_table_add_del>(vapi_msg_ip_table_add_del *msg)
{
  vapi_msg_ip_table_add_del_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip_table_add_del>()
{
  return ::vapi_msg_id_ip_table_add_del; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip_table_add_del>>()
{
  return ::vapi_msg_id_ip_table_add_del; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip_table_add_del()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip_table_add_del>(vapi_msg_id_ip_table_add_del);
}

template <> inline vapi_msg_ip_table_add_del* vapi_alloc<vapi_msg_ip_table_add_del>(Connection &con)
{
  vapi_msg_ip_table_add_del* result = vapi_alloc_ip_table_add_del(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_ip_table_add_del>;

template class Request<vapi_msg_ip_table_add_del, vapi_msg_ip_table_add_del_reply>;

using Ip_table_add_del = Request<vapi_msg_ip_table_add_del, vapi_msg_ip_table_add_del_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_ip6_set_link_local_address>(vapi_msg_sw_interface_ip6_set_link_local_address *msg)
{
  vapi_msg_sw_interface_ip6_set_link_local_address_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_ip6_set_link_local_address>(vapi_msg_sw_interface_ip6_set_link_local_address *msg)
{
  vapi_msg_sw_interface_ip6_set_link_local_address_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_ip6_set_link_local_address>()
{
  return ::vapi_msg_id_sw_interface_ip6_set_link_local_address; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_ip6_set_link_local_address>>()
{
  return ::vapi_msg_id_sw_interface_ip6_set_link_local_address; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_ip6_set_link_local_address()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_ip6_set_link_local_address>(vapi_msg_id_sw_interface_ip6_set_link_local_address);
}

template <> inline vapi_msg_sw_interface_ip6_set_link_local_address* vapi_alloc<vapi_msg_sw_interface_ip6_set_link_local_address>(Connection &con)
{
  vapi_msg_sw_interface_ip6_set_link_local_address* result = vapi_alloc_sw_interface_ip6_set_link_local_address(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sw_interface_ip6_set_link_local_address>;

template class Request<vapi_msg_sw_interface_ip6_set_link_local_address, vapi_msg_sw_interface_ip6_set_link_local_address_reply>;

using Sw_interface_ip6_set_link_local_address = Request<vapi_msg_sw_interface_ip6_set_link_local_address, vapi_msg_sw_interface_ip6_set_link_local_address_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_ip_fib_details>(vapi_msg_ip_fib_details *msg)
{
  vapi_msg_ip_fib_details_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip_fib_details>(vapi_msg_ip_fib_details *msg)
{
  vapi_msg_ip_fib_details_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip_fib_details>()
{
  return ::vapi_msg_id_ip_fib_details; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip_fib_details>>()
{
  return ::vapi_msg_id_ip_fib_details; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip_fib_details()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip_fib_details>(vapi_msg_id_ip_fib_details);
}

template class Msg<vapi_msg_ip_fib_details>;

using Ip_fib_details = Msg<vapi_msg_ip_fib_details>;
template <> inline void vapi_swap_to_be<vapi_msg_ip6nd_proxy_details>(vapi_msg_ip6nd_proxy_details *msg)
{
  vapi_msg_ip6nd_proxy_details_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip6nd_proxy_details>(vapi_msg_ip6nd_proxy_details *msg)
{
  vapi_msg_ip6nd_proxy_details_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip6nd_proxy_details>()
{
  return ::vapi_msg_id_ip6nd_proxy_details; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip6nd_proxy_details>>()
{
  return ::vapi_msg_id_ip6nd_proxy_details; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip6nd_proxy_details()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip6nd_proxy_details>(vapi_msg_id_ip6nd_proxy_details);
}

template class Msg<vapi_msg_ip6nd_proxy_details>;

using Ip6nd_proxy_details = Msg<vapi_msg_ip6nd_proxy_details>;
template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_ip6_set_link_local_address_reply>(vapi_msg_sw_interface_ip6_set_link_local_address_reply *msg)
{
  vapi_msg_sw_interface_ip6_set_link_local_address_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_ip6_set_link_local_address_reply>(vapi_msg_sw_interface_ip6_set_link_local_address_reply *msg)
{
  vapi_msg_sw_interface_ip6_set_link_local_address_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_ip6_set_link_local_address_reply>()
{
  return ::vapi_msg_id_sw_interface_ip6_set_link_local_address_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_ip6_set_link_local_address_reply>>()
{
  return ::vapi_msg_id_sw_interface_ip6_set_link_local_address_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_ip6_set_link_local_address_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_ip6_set_link_local_address_reply>(vapi_msg_id_sw_interface_ip6_set_link_local_address_reply);
}

template class Msg<vapi_msg_sw_interface_ip6_set_link_local_address_reply>;

using Sw_interface_ip6_set_link_local_address_reply = Msg<vapi_msg_sw_interface_ip6_set_link_local_address_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_ip_neighbor_add_del_reply>(vapi_msg_ip_neighbor_add_del_reply *msg)
{
  vapi_msg_ip_neighbor_add_del_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip_neighbor_add_del_reply>(vapi_msg_ip_neighbor_add_del_reply *msg)
{
  vapi_msg_ip_neighbor_add_del_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip_neighbor_add_del_reply>()
{
  return ::vapi_msg_id_ip_neighbor_add_del_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip_neighbor_add_del_reply>>()
{
  return ::vapi_msg_id_ip_neighbor_add_del_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip_neighbor_add_del_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip_neighbor_add_del_reply>(vapi_msg_id_ip_neighbor_add_del_reply);
}

template class Msg<vapi_msg_ip_neighbor_add_del_reply>;

using Ip_neighbor_add_del_reply = Msg<vapi_msg_ip_neighbor_add_del_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_ip_table_add_del_reply>(vapi_msg_ip_table_add_del_reply *msg)
{
  vapi_msg_ip_table_add_del_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip_table_add_del_reply>(vapi_msg_ip_table_add_del_reply *msg)
{
  vapi_msg_ip_table_add_del_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip_table_add_del_reply>()
{
  return ::vapi_msg_id_ip_table_add_del_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip_table_add_del_reply>>()
{
  return ::vapi_msg_id_ip_table_add_del_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip_table_add_del_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip_table_add_del_reply>(vapi_msg_id_ip_table_add_del_reply);
}

template class Msg<vapi_msg_ip_table_add_del_reply>;

using Ip_table_add_del_reply = Msg<vapi_msg_ip_table_add_del_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_ip6nd_ra_prefix>(vapi_msg_sw_interface_ip6nd_ra_prefix *msg)
{
  vapi_msg_sw_interface_ip6nd_ra_prefix_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_ip6nd_ra_prefix>(vapi_msg_sw_interface_ip6nd_ra_prefix *msg)
{
  vapi_msg_sw_interface_ip6nd_ra_prefix_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_ip6nd_ra_prefix>()
{
  return ::vapi_msg_id_sw_interface_ip6nd_ra_prefix; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_ip6nd_ra_prefix>>()
{
  return ::vapi_msg_id_sw_interface_ip6nd_ra_prefix; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_ip6nd_ra_prefix()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_ip6nd_ra_prefix>(vapi_msg_id_sw_interface_ip6nd_ra_prefix);
}

template <> inline vapi_msg_sw_interface_ip6nd_ra_prefix* vapi_alloc<vapi_msg_sw_interface_ip6nd_ra_prefix>(Connection &con)
{
  vapi_msg_sw_interface_ip6nd_ra_prefix* result = vapi_alloc_sw_interface_ip6nd_ra_prefix(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sw_interface_ip6nd_ra_prefix>;

template class Request<vapi_msg_sw_interface_ip6nd_ra_prefix, vapi_msg_sw_interface_ip6nd_ra_prefix_reply>;

using Sw_interface_ip6nd_ra_prefix = Request<vapi_msg_sw_interface_ip6nd_ra_prefix, vapi_msg_sw_interface_ip6nd_ra_prefix_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_ip6_mfib_dump>(vapi_msg_ip6_mfib_dump *msg)
{
  vapi_msg_ip6_mfib_dump_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip6_mfib_dump>(vapi_msg_ip6_mfib_dump *msg)
{
  vapi_msg_ip6_mfib_dump_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip6_mfib_dump>()
{
  return ::vapi_msg_id_ip6_mfib_dump; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip6_mfib_dump>>()
{
  return ::vapi_msg_id_ip6_mfib_dump; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip6_mfib_dump()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip6_mfib_dump>(vapi_msg_id_ip6_mfib_dump);
}

template <> inline vapi_msg_ip6_mfib_dump* vapi_alloc<vapi_msg_ip6_mfib_dump>(Connection &con)
{
  vapi_msg_ip6_mfib_dump* result = vapi_alloc_ip6_mfib_dump(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_ip6_mfib_dump>;

template class Dump<vapi_msg_ip6_mfib_dump, vapi_msg_ip6_mfib_details>;

using Ip6_mfib_dump = Dump<vapi_msg_ip6_mfib_dump, vapi_msg_ip6_mfib_details>;

template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_ip6nd_ra_config>(vapi_msg_sw_interface_ip6nd_ra_config *msg)
{
  vapi_msg_sw_interface_ip6nd_ra_config_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_ip6nd_ra_config>(vapi_msg_sw_interface_ip6nd_ra_config *msg)
{
  vapi_msg_sw_interface_ip6nd_ra_config_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_ip6nd_ra_config>()
{
  return ::vapi_msg_id_sw_interface_ip6nd_ra_config; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_ip6nd_ra_config>>()
{
  return ::vapi_msg_id_sw_interface_ip6nd_ra_config; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_ip6nd_ra_config()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_ip6nd_ra_config>(vapi_msg_id_sw_interface_ip6nd_ra_config);
}

template <> inline vapi_msg_sw_interface_ip6nd_ra_config* vapi_alloc<vapi_msg_sw_interface_ip6nd_ra_config>(Connection &con)
{
  vapi_msg_sw_interface_ip6nd_ra_config* result = vapi_alloc_sw_interface_ip6nd_ra_config(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sw_interface_ip6nd_ra_config>;

template class Request<vapi_msg_sw_interface_ip6nd_ra_config, vapi_msg_sw_interface_ip6nd_ra_config_reply>;

using Sw_interface_ip6nd_ra_config = Request<vapi_msg_sw_interface_ip6nd_ra_config, vapi_msg_sw_interface_ip6nd_ra_config_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_ip6_enable_disable>(vapi_msg_sw_interface_ip6_enable_disable *msg)
{
  vapi_msg_sw_interface_ip6_enable_disable_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_ip6_enable_disable>(vapi_msg_sw_interface_ip6_enable_disable *msg)
{
  vapi_msg_sw_interface_ip6_enable_disable_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_ip6_enable_disable>()
{
  return ::vapi_msg_id_sw_interface_ip6_enable_disable; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_ip6_enable_disable>>()
{
  return ::vapi_msg_id_sw_interface_ip6_enable_disable; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_ip6_enable_disable()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_ip6_enable_disable>(vapi_msg_id_sw_interface_ip6_enable_disable);
}

template <> inline vapi_msg_sw_interface_ip6_enable_disable* vapi_alloc<vapi_msg_sw_interface_ip6_enable_disable>(Connection &con)
{
  vapi_msg_sw_interface_ip6_enable_disable* result = vapi_alloc_sw_interface_ip6_enable_disable(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sw_interface_ip6_enable_disable>;

template class Request<vapi_msg_sw_interface_ip6_enable_disable, vapi_msg_sw_interface_ip6_enable_disable_reply>;

using Sw_interface_ip6_enable_disable = Request<vapi_msg_sw_interface_ip6_enable_disable, vapi_msg_sw_interface_ip6_enable_disable_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_ip_mfib_details>(vapi_msg_ip_mfib_details *msg)
{
  vapi_msg_ip_mfib_details_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip_mfib_details>(vapi_msg_ip_mfib_details *msg)
{
  vapi_msg_ip_mfib_details_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip_mfib_details>()
{
  return ::vapi_msg_id_ip_mfib_details; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip_mfib_details>>()
{
  return ::vapi_msg_id_ip_mfib_details; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip_mfib_details()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip_mfib_details>(vapi_msg_id_ip_mfib_details);
}

template class Msg<vapi_msg_ip_mfib_details>;

using Ip_mfib_details = Msg<vapi_msg_ip_mfib_details>;
template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_ip6_enable_disable_reply>(vapi_msg_sw_interface_ip6_enable_disable_reply *msg)
{
  vapi_msg_sw_interface_ip6_enable_disable_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_ip6_enable_disable_reply>(vapi_msg_sw_interface_ip6_enable_disable_reply *msg)
{
  vapi_msg_sw_interface_ip6_enable_disable_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_ip6_enable_disable_reply>()
{
  return ::vapi_msg_id_sw_interface_ip6_enable_disable_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_ip6_enable_disable_reply>>()
{
  return ::vapi_msg_id_sw_interface_ip6_enable_disable_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_ip6_enable_disable_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_ip6_enable_disable_reply>(vapi_msg_id_sw_interface_ip6_enable_disable_reply);
}

template class Msg<vapi_msg_sw_interface_ip6_enable_disable_reply>;

using Sw_interface_ip6_enable_disable_reply = Msg<vapi_msg_sw_interface_ip6_enable_disable_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_ip_address_details>(vapi_msg_ip_address_details *msg)
{
  vapi_msg_ip_address_details_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip_address_details>(vapi_msg_ip_address_details *msg)
{
  vapi_msg_ip_address_details_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip_address_details>()
{
  return ::vapi_msg_id_ip_address_details; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip_address_details>>()
{
  return ::vapi_msg_id_ip_address_details; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip_address_details()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip_address_details>(vapi_msg_id_ip_address_details);
}

template class Msg<vapi_msg_ip_address_details>;

using Ip_address_details = Msg<vapi_msg_ip_address_details>;
template <> inline void vapi_swap_to_be<vapi_msg_mfib_signal_dump>(vapi_msg_mfib_signal_dump *msg)
{
  vapi_msg_mfib_signal_dump_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_mfib_signal_dump>(vapi_msg_mfib_signal_dump *msg)
{
  vapi_msg_mfib_signal_dump_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_mfib_signal_dump>()
{
  return ::vapi_msg_id_mfib_signal_dump; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_mfib_signal_dump>>()
{
  return ::vapi_msg_id_mfib_signal_dump; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_mfib_signal_dump()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_mfib_signal_dump>(vapi_msg_id_mfib_signal_dump);
}

template <> inline vapi_msg_mfib_signal_dump* vapi_alloc<vapi_msg_mfib_signal_dump>(Connection &con)
{
  vapi_msg_mfib_signal_dump* result = vapi_alloc_mfib_signal_dump(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_mfib_signal_dump>;

template class Dump<vapi_msg_mfib_signal_dump, vapi_msg_mfib_signal_details>;

using Mfib_signal_dump = Dump<vapi_msg_mfib_signal_dump, vapi_msg_mfib_signal_details>;

template <> inline void vapi_swap_to_be<vapi_msg_ip_mfib_dump>(vapi_msg_ip_mfib_dump *msg)
{
  vapi_msg_ip_mfib_dump_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip_mfib_dump>(vapi_msg_ip_mfib_dump *msg)
{
  vapi_msg_ip_mfib_dump_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip_mfib_dump>()
{
  return ::vapi_msg_id_ip_mfib_dump; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip_mfib_dump>>()
{
  return ::vapi_msg_id_ip_mfib_dump; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip_mfib_dump()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip_mfib_dump>(vapi_msg_id_ip_mfib_dump);
}

template <> inline vapi_msg_ip_mfib_dump* vapi_alloc<vapi_msg_ip_mfib_dump>(Connection &con)
{
  vapi_msg_ip_mfib_dump* result = vapi_alloc_ip_mfib_dump(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_ip_mfib_dump>;

template class Dump<vapi_msg_ip_mfib_dump, vapi_msg_ip_mfib_details>;

using Ip_mfib_dump = Dump<vapi_msg_ip_mfib_dump, vapi_msg_ip_mfib_details>;

template <> inline void vapi_swap_to_be<vapi_msg_ip_dump>(vapi_msg_ip_dump *msg)
{
  vapi_msg_ip_dump_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip_dump>(vapi_msg_ip_dump *msg)
{
  vapi_msg_ip_dump_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip_dump>()
{
  return ::vapi_msg_id_ip_dump; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip_dump>>()
{
  return ::vapi_msg_id_ip_dump; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip_dump()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip_dump>(vapi_msg_id_ip_dump);
}

template <> inline vapi_msg_ip_dump* vapi_alloc<vapi_msg_ip_dump>(Connection &con)
{
  vapi_msg_ip_dump* result = vapi_alloc_ip_dump(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_ip_dump>;

template class Dump<vapi_msg_ip_dump, vapi_msg_ip_details>;

using Ip_dump = Dump<vapi_msg_ip_dump, vapi_msg_ip_details>;

template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_ip6nd_ra_config_reply>(vapi_msg_sw_interface_ip6nd_ra_config_reply *msg)
{
  vapi_msg_sw_interface_ip6nd_ra_config_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_ip6nd_ra_config_reply>(vapi_msg_sw_interface_ip6nd_ra_config_reply *msg)
{
  vapi_msg_sw_interface_ip6nd_ra_config_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_ip6nd_ra_config_reply>()
{
  return ::vapi_msg_id_sw_interface_ip6nd_ra_config_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_ip6nd_ra_config_reply>>()
{
  return ::vapi_msg_id_sw_interface_ip6nd_ra_config_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_ip6nd_ra_config_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_ip6nd_ra_config_reply>(vapi_msg_id_sw_interface_ip6nd_ra_config_reply);
}

template class Msg<vapi_msg_sw_interface_ip6nd_ra_config_reply>;

using Sw_interface_ip6nd_ra_config_reply = Msg<vapi_msg_sw_interface_ip6nd_ra_config_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_ip_neighbor_add_del>(vapi_msg_ip_neighbor_add_del *msg)
{
  vapi_msg_ip_neighbor_add_del_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip_neighbor_add_del>(vapi_msg_ip_neighbor_add_del *msg)
{
  vapi_msg_ip_neighbor_add_del_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip_neighbor_add_del>()
{
  return ::vapi_msg_id_ip_neighbor_add_del; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip_neighbor_add_del>>()
{
  return ::vapi_msg_id_ip_neighbor_add_del; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip_neighbor_add_del()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip_neighbor_add_del>(vapi_msg_id_ip_neighbor_add_del);
}

template <> inline vapi_msg_ip_neighbor_add_del* vapi_alloc<vapi_msg_ip_neighbor_add_del>(Connection &con)
{
  vapi_msg_ip_neighbor_add_del* result = vapi_alloc_ip_neighbor_add_del(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_ip_neighbor_add_del>;

template class Request<vapi_msg_ip_neighbor_add_del, vapi_msg_ip_neighbor_add_del_reply>;

using Ip_neighbor_add_del = Request<vapi_msg_ip_neighbor_add_del, vapi_msg_ip_neighbor_add_del_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_ip_neighbor_dump>(vapi_msg_ip_neighbor_dump *msg)
{
  vapi_msg_ip_neighbor_dump_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip_neighbor_dump>(vapi_msg_ip_neighbor_dump *msg)
{
  vapi_msg_ip_neighbor_dump_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip_neighbor_dump>()
{
  return ::vapi_msg_id_ip_neighbor_dump; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip_neighbor_dump>>()
{
  return ::vapi_msg_id_ip_neighbor_dump; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip_neighbor_dump()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip_neighbor_dump>(vapi_msg_id_ip_neighbor_dump);
}

template <> inline vapi_msg_ip_neighbor_dump* vapi_alloc<vapi_msg_ip_neighbor_dump>(Connection &con)
{
  vapi_msg_ip_neighbor_dump* result = vapi_alloc_ip_neighbor_dump(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_ip_neighbor_dump>;

template class Dump<vapi_msg_ip_neighbor_dump, vapi_msg_ip_neighbor_details>;

using Ip_neighbor_dump = Dump<vapi_msg_ip_neighbor_dump, vapi_msg_ip_neighbor_details>;

template <> inline void vapi_swap_to_be<vapi_msg_ip_add_del_route>(vapi_msg_ip_add_del_route *msg)
{
  vapi_msg_ip_add_del_route_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip_add_del_route>(vapi_msg_ip_add_del_route *msg)
{
  vapi_msg_ip_add_del_route_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip_add_del_route>()
{
  return ::vapi_msg_id_ip_add_del_route; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip_add_del_route>>()
{
  return ::vapi_msg_id_ip_add_del_route; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip_add_del_route()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip_add_del_route>(vapi_msg_id_ip_add_del_route);
}

template <> inline vapi_msg_ip_add_del_route* vapi_alloc<vapi_msg_ip_add_del_route, size_t>(Connection &con, size_t next_hop_out_label_stack_array_size)
{
  vapi_msg_ip_add_del_route* result = vapi_alloc_ip_add_del_route(con.vapi_ctx, next_hop_out_label_stack_array_size);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_ip_add_del_route>;

template class Request<vapi_msg_ip_add_del_route, vapi_msg_ip_add_del_route_reply, size_t>;

using Ip_add_del_route = Request<vapi_msg_ip_add_del_route, vapi_msg_ip_add_del_route_reply, size_t>;

template <> inline void vapi_swap_to_be<vapi_msg_ip6nd_proxy_dump>(vapi_msg_ip6nd_proxy_dump *msg)
{
  vapi_msg_ip6nd_proxy_dump_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip6nd_proxy_dump>(vapi_msg_ip6nd_proxy_dump *msg)
{
  vapi_msg_ip6nd_proxy_dump_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip6nd_proxy_dump>()
{
  return ::vapi_msg_id_ip6nd_proxy_dump; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip6nd_proxy_dump>>()
{
  return ::vapi_msg_id_ip6nd_proxy_dump; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip6nd_proxy_dump()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip6nd_proxy_dump>(vapi_msg_id_ip6nd_proxy_dump);
}

template <> inline vapi_msg_ip6nd_proxy_dump* vapi_alloc<vapi_msg_ip6nd_proxy_dump>(Connection &con)
{
  vapi_msg_ip6nd_proxy_dump* result = vapi_alloc_ip6nd_proxy_dump(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_ip6nd_proxy_dump>;

template class Dump<vapi_msg_ip6nd_proxy_dump, vapi_msg_ip6nd_proxy_details>;

using Ip6nd_proxy_dump = Dump<vapi_msg_ip6nd_proxy_dump, vapi_msg_ip6nd_proxy_details>;

template <> inline void vapi_swap_to_be<vapi_msg_ip_fib_dump>(vapi_msg_ip_fib_dump *msg)
{
  vapi_msg_ip_fib_dump_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip_fib_dump>(vapi_msg_ip_fib_dump *msg)
{
  vapi_msg_ip_fib_dump_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip_fib_dump>()
{
  return ::vapi_msg_id_ip_fib_dump; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip_fib_dump>>()
{
  return ::vapi_msg_id_ip_fib_dump; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip_fib_dump()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip_fib_dump>(vapi_msg_id_ip_fib_dump);
}

template <> inline vapi_msg_ip_fib_dump* vapi_alloc<vapi_msg_ip_fib_dump>(Connection &con)
{
  vapi_msg_ip_fib_dump* result = vapi_alloc_ip_fib_dump(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_ip_fib_dump>;

template class Dump<vapi_msg_ip_fib_dump, vapi_msg_ip_fib_details>;

using Ip_fib_dump = Dump<vapi_msg_ip_fib_dump, vapi_msg_ip_fib_details>;

template <> inline void vapi_swap_to_be<vapi_msg_ip_neighbor_details>(vapi_msg_ip_neighbor_details *msg)
{
  vapi_msg_ip_neighbor_details_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip_neighbor_details>(vapi_msg_ip_neighbor_details *msg)
{
  vapi_msg_ip_neighbor_details_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip_neighbor_details>()
{
  return ::vapi_msg_id_ip_neighbor_details; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip_neighbor_details>>()
{
  return ::vapi_msg_id_ip_neighbor_details; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip_neighbor_details()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip_neighbor_details>(vapi_msg_id_ip_neighbor_details);
}

template class Msg<vapi_msg_ip_neighbor_details>;

using Ip_neighbor_details = Msg<vapi_msg_ip_neighbor_details>;
template <> inline void vapi_swap_to_be<vapi_msg_ip6nd_proxy_add_del_reply>(vapi_msg_ip6nd_proxy_add_del_reply *msg)
{
  vapi_msg_ip6nd_proxy_add_del_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip6nd_proxy_add_del_reply>(vapi_msg_ip6nd_proxy_add_del_reply *msg)
{
  vapi_msg_ip6nd_proxy_add_del_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip6nd_proxy_add_del_reply>()
{
  return ::vapi_msg_id_ip6nd_proxy_add_del_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip6nd_proxy_add_del_reply>>()
{
  return ::vapi_msg_id_ip6nd_proxy_add_del_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip6nd_proxy_add_del_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip6nd_proxy_add_del_reply>(vapi_msg_id_ip6nd_proxy_add_del_reply);
}

template class Msg<vapi_msg_ip6nd_proxy_add_del_reply>;

using Ip6nd_proxy_add_del_reply = Msg<vapi_msg_ip6nd_proxy_add_del_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_ip_mroute_add_del>(vapi_msg_ip_mroute_add_del *msg)
{
  vapi_msg_ip_mroute_add_del_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip_mroute_add_del>(vapi_msg_ip_mroute_add_del *msg)
{
  vapi_msg_ip_mroute_add_del_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip_mroute_add_del>()
{
  return ::vapi_msg_id_ip_mroute_add_del; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip_mroute_add_del>>()
{
  return ::vapi_msg_id_ip_mroute_add_del; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip_mroute_add_del()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip_mroute_add_del>(vapi_msg_id_ip_mroute_add_del);
}

template <> inline vapi_msg_ip_mroute_add_del* vapi_alloc<vapi_msg_ip_mroute_add_del>(Connection &con)
{
  vapi_msg_ip_mroute_add_del* result = vapi_alloc_ip_mroute_add_del(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_ip_mroute_add_del>;

template class Request<vapi_msg_ip_mroute_add_del, vapi_msg_ip_mroute_add_del_reply>;

using Ip_mroute_add_del = Request<vapi_msg_ip_mroute_add_del, vapi_msg_ip_mroute_add_del_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_mfib_signal_details>(vapi_msg_mfib_signal_details *msg)
{
  vapi_msg_mfib_signal_details_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_mfib_signal_details>(vapi_msg_mfib_signal_details *msg)
{
  vapi_msg_mfib_signal_details_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_mfib_signal_details>()
{
  return ::vapi_msg_id_mfib_signal_details; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_mfib_signal_details>>()
{
  return ::vapi_msg_id_mfib_signal_details; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_mfib_signal_details()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_mfib_signal_details>(vapi_msg_id_mfib_signal_details);
}

template class Msg<vapi_msg_mfib_signal_details>;

using Mfib_signal_details = Msg<vapi_msg_mfib_signal_details>;
template <> inline void vapi_swap_to_be<vapi_msg_set_ip_flow_hash>(vapi_msg_set_ip_flow_hash *msg)
{
  vapi_msg_set_ip_flow_hash_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_set_ip_flow_hash>(vapi_msg_set_ip_flow_hash *msg)
{
  vapi_msg_set_ip_flow_hash_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_set_ip_flow_hash>()
{
  return ::vapi_msg_id_set_ip_flow_hash; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_set_ip_flow_hash>>()
{
  return ::vapi_msg_id_set_ip_flow_hash; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_set_ip_flow_hash()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_set_ip_flow_hash>(vapi_msg_id_set_ip_flow_hash);
}

template <> inline vapi_msg_set_ip_flow_hash* vapi_alloc<vapi_msg_set_ip_flow_hash>(Connection &con)
{
  vapi_msg_set_ip_flow_hash* result = vapi_alloc_set_ip_flow_hash(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_set_ip_flow_hash>;

template class Request<vapi_msg_set_ip_flow_hash, vapi_msg_set_ip_flow_hash_reply>;

using Set_ip_flow_hash = Request<vapi_msg_set_ip_flow_hash, vapi_msg_set_ip_flow_hash_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_ip6_mfib_details>(vapi_msg_ip6_mfib_details *msg)
{
  vapi_msg_ip6_mfib_details_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip6_mfib_details>(vapi_msg_ip6_mfib_details *msg)
{
  vapi_msg_ip6_mfib_details_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip6_mfib_details>()
{
  return ::vapi_msg_id_ip6_mfib_details; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip6_mfib_details>>()
{
  return ::vapi_msg_id_ip6_mfib_details; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip6_mfib_details()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip6_mfib_details>(vapi_msg_id_ip6_mfib_details);
}

template class Msg<vapi_msg_ip6_mfib_details>;

using Ip6_mfib_details = Msg<vapi_msg_ip6_mfib_details>;
}
#endif
