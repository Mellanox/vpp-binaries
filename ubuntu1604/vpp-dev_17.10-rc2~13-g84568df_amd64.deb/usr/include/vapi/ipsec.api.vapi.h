#ifndef __included_ipsec_api_json
#define __included_ipsec_api_json

#include <stdlib.h>
#include <stddef.h>
#include <arpa/inet.h>
#include <vapi/vapi_internal.h>
#include <vapi/vapi.h>
#include <vapi/vapi_dbg.h>

#ifdef __cplusplus
extern "C" {
#endif
#include <vapi/vpe.api.vapi.h>

extern vapi_msg_id_t vapi_msg_id_ipsec_spd_add_del;
extern vapi_msg_id_t vapi_msg_id_ipsec_interface_add_del_spd;
extern vapi_msg_id_t vapi_msg_id_ikev2_set_responder;
extern vapi_msg_id_t vapi_msg_id_ipsec_sa_set_key_reply;
extern vapi_msg_id_t vapi_msg_id_ikev2_profile_set_ts;
extern vapi_msg_id_t vapi_msg_id_ikev2_set_responder_reply;
extern vapi_msg_id_t vapi_msg_id_ikev2_set_esp_transforms_reply;
extern vapi_msg_id_t vapi_msg_id_ikev2_set_ike_transforms_reply;
extern vapi_msg_id_t vapi_msg_id_ipsec_spd_add_del_reply;
extern vapi_msg_id_t vapi_msg_id_ikev2_initiate_del_ike_sa;
extern vapi_msg_id_t vapi_msg_id_ikev2_initiate_rekey_child_sa_reply;
extern vapi_msg_id_t vapi_msg_id_ikev2_profile_add_del_reply;
extern vapi_msg_id_t vapi_msg_id_ipsec_sad_add_del_entry_reply;
extern vapi_msg_id_t vapi_msg_id_ikev2_profile_add_del;
extern vapi_msg_id_t vapi_msg_id_ikev2_initiate_sa_init;
extern vapi_msg_id_t vapi_msg_id_ipsec_sa_set_key;
extern vapi_msg_id_t vapi_msg_id_ipsec_tunnel_if_add_del_reply;
extern vapi_msg_id_t vapi_msg_id_ikev2_set_sa_lifetime;
extern vapi_msg_id_t vapi_msg_id_ikev2_initiate_rekey_child_sa;
extern vapi_msg_id_t vapi_msg_id_ikev2_set_sa_lifetime_reply;
extern vapi_msg_id_t vapi_msg_id_ipsec_sad_add_del_entry;
extern vapi_msg_id_t vapi_msg_id_ipsec_interface_add_del_spd_reply;
extern vapi_msg_id_t vapi_msg_id_ipsec_spd_add_del_entry_reply;
extern vapi_msg_id_t vapi_msg_id_ikev2_initiate_del_child_sa_reply;
extern vapi_msg_id_t vapi_msg_id_ikev2_initiate_del_ike_sa_reply;
extern vapi_msg_id_t vapi_msg_id_ipsec_spd_details;
extern vapi_msg_id_t vapi_msg_id_ipsec_spd_dump;
extern vapi_msg_id_t vapi_msg_id_ikev2_set_ike_transforms;
extern vapi_msg_id_t vapi_msg_id_ikev2_set_esp_transforms;
extern vapi_msg_id_t vapi_msg_id_ipsec_spd_add_del_entry;
extern vapi_msg_id_t vapi_msg_id_ikev2_set_local_key_reply;
extern vapi_msg_id_t vapi_msg_id_ikev2_initiate_del_child_sa;
extern vapi_msg_id_t vapi_msg_id_ikev2_set_local_key;
extern vapi_msg_id_t vapi_msg_id_ipsec_tunnel_if_add_del;
extern vapi_msg_id_t vapi_msg_id_ikev2_initiate_sa_init_reply;
extern vapi_msg_id_t vapi_msg_id_ikev2_profile_set_id_reply;
extern vapi_msg_id_t vapi_msg_id_ikev2_profile_set_ts_reply;
extern vapi_msg_id_t vapi_msg_id_ikev2_profile_set_auth_reply;

#define DEFINE_VAPI_MSG_IDS_IPSEC_API_JSON\
  vapi_msg_id_t vapi_msg_id_ipsec_spd_add_del;\
  vapi_msg_id_t vapi_msg_id_ipsec_interface_add_del_spd;\
  vapi_msg_id_t vapi_msg_id_ikev2_set_responder;\
  vapi_msg_id_t vapi_msg_id_ipsec_sa_set_key_reply;\
  vapi_msg_id_t vapi_msg_id_ikev2_profile_set_ts;\
  vapi_msg_id_t vapi_msg_id_ikev2_set_responder_reply;\
  vapi_msg_id_t vapi_msg_id_ikev2_set_esp_transforms_reply;\
  vapi_msg_id_t vapi_msg_id_ikev2_set_ike_transforms_reply;\
  vapi_msg_id_t vapi_msg_id_ipsec_spd_add_del_reply;\
  vapi_msg_id_t vapi_msg_id_ikev2_initiate_del_ike_sa;\
  vapi_msg_id_t vapi_msg_id_ikev2_initiate_rekey_child_sa_reply;\
  vapi_msg_id_t vapi_msg_id_ikev2_profile_add_del_reply;\
  vapi_msg_id_t vapi_msg_id_ipsec_sad_add_del_entry_reply;\
  vapi_msg_id_t vapi_msg_id_ikev2_profile_add_del;\
  vapi_msg_id_t vapi_msg_id_ikev2_initiate_sa_init;\
  vapi_msg_id_t vapi_msg_id_ipsec_sa_set_key;\
  vapi_msg_id_t vapi_msg_id_ipsec_tunnel_if_add_del_reply;\
  vapi_msg_id_t vapi_msg_id_ikev2_set_sa_lifetime;\
  vapi_msg_id_t vapi_msg_id_ikev2_initiate_rekey_child_sa;\
  vapi_msg_id_t vapi_msg_id_ikev2_set_sa_lifetime_reply;\
  vapi_msg_id_t vapi_msg_id_ipsec_sad_add_del_entry;\
  vapi_msg_id_t vapi_msg_id_ipsec_interface_add_del_spd_reply;\
  vapi_msg_id_t vapi_msg_id_ipsec_spd_add_del_entry_reply;\
  vapi_msg_id_t vapi_msg_id_ikev2_initiate_del_child_sa_reply;\
  vapi_msg_id_t vapi_msg_id_ikev2_initiate_del_ike_sa_reply;\
  vapi_msg_id_t vapi_msg_id_ipsec_spd_details;\
  vapi_msg_id_t vapi_msg_id_ipsec_spd_dump;\
  vapi_msg_id_t vapi_msg_id_ikev2_set_ike_transforms;\
  vapi_msg_id_t vapi_msg_id_ikev2_set_esp_transforms;\
  vapi_msg_id_t vapi_msg_id_ipsec_spd_add_del_entry;\
  vapi_msg_id_t vapi_msg_id_ikev2_set_local_key_reply;\
  vapi_msg_id_t vapi_msg_id_ikev2_initiate_del_child_sa;\
  vapi_msg_id_t vapi_msg_id_ikev2_set_local_key;\
  vapi_msg_id_t vapi_msg_id_ipsec_tunnel_if_add_del;\
  vapi_msg_id_t vapi_msg_id_ikev2_initiate_sa_init_reply;\
  vapi_msg_id_t vapi_msg_id_ikev2_profile_set_id_reply;\
  vapi_msg_id_t vapi_msg_id_ikev2_profile_set_ts_reply;\
  vapi_msg_id_t vapi_msg_id_ikev2_profile_set_auth_reply;


typedef struct __attribute__ ((__packed__)) {
  u8 is_add;
  u32 spd_id; 
} vapi_payload_ipsec_spd_add_del;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_ipsec_spd_add_del payload;
} vapi_msg_ipsec_spd_add_del;

typedef struct __attribute__ ((__packed__)) {
  u8 is_add;
  u32 sw_if_index;
  u32 spd_id; 
} vapi_payload_ipsec_interface_add_del_spd;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_ipsec_interface_add_del_spd payload;
} vapi_msg_ipsec_interface_add_del_spd;

typedef struct __attribute__ ((__packed__)) {
  u8 name[64];
  u32 sw_if_index;
  u8 address[4]; 
} vapi_payload_ikev2_set_responder;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_ikev2_set_responder payload;
} vapi_msg_ikev2_set_responder;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_ipsec_sa_set_key_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_ipsec_sa_set_key_reply payload;
} vapi_msg_ipsec_sa_set_key_reply;

typedef struct __attribute__ ((__packed__)) {
  u8 name[64];
  u8 is_local;
  u8 proto;
  u16 start_port;
  u16 end_port;
  u32 start_addr;
  u32 end_addr; 
} vapi_payload_ikev2_profile_set_ts;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_ikev2_profile_set_ts payload;
} vapi_msg_ikev2_profile_set_ts;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_ikev2_set_responder_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_ikev2_set_responder_reply payload;
} vapi_msg_ikev2_set_responder_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_ikev2_set_esp_transforms_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_ikev2_set_esp_transforms_reply payload;
} vapi_msg_ikev2_set_esp_transforms_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_ikev2_set_ike_transforms_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_ikev2_set_ike_transforms_reply payload;
} vapi_msg_ikev2_set_ike_transforms_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_ipsec_spd_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_ipsec_spd_add_del_reply payload;
} vapi_msg_ipsec_spd_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  u64 ispi; 
} vapi_payload_ikev2_initiate_del_ike_sa;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_ikev2_initiate_del_ike_sa payload;
} vapi_msg_ikev2_initiate_del_ike_sa;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_ikev2_initiate_rekey_child_sa_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_ikev2_initiate_rekey_child_sa_reply payload;
} vapi_msg_ikev2_initiate_rekey_child_sa_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_ikev2_profile_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_ikev2_profile_add_del_reply payload;
} vapi_msg_ikev2_profile_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_ipsec_sad_add_del_entry_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_ipsec_sad_add_del_entry_reply payload;
} vapi_msg_ipsec_sad_add_del_entry_reply;

typedef struct __attribute__ ((__packed__)) {
  u8 name[64];
  u8 is_add; 
} vapi_payload_ikev2_profile_add_del;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_ikev2_profile_add_del payload;
} vapi_msg_ikev2_profile_add_del;

typedef struct __attribute__ ((__packed__)) {
  u8 name[64]; 
} vapi_payload_ikev2_initiate_sa_init;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_ikev2_initiate_sa_init payload;
} vapi_msg_ikev2_initiate_sa_init;

typedef struct __attribute__ ((__packed__)) {
  u32 sa_id;
  u8 crypto_key_length;
  u8 crypto_key[128];
  u8 integrity_key_length;
  u8 integrity_key[128]; 
} vapi_payload_ipsec_sa_set_key;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_ipsec_sa_set_key payload;
} vapi_msg_ipsec_sa_set_key;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u32 sw_if_index; 
} vapi_payload_ipsec_tunnel_if_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_ipsec_tunnel_if_add_del_reply payload;
} vapi_msg_ipsec_tunnel_if_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  u8 name[64];
  u64 lifetime;
  u32 lifetime_jitter;
  u32 handover;
  u64 lifetime_maxdata; 
} vapi_payload_ikev2_set_sa_lifetime;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_ikev2_set_sa_lifetime payload;
} vapi_msg_ikev2_set_sa_lifetime;

typedef struct __attribute__ ((__packed__)) {
  u32 ispi; 
} vapi_payload_ikev2_initiate_rekey_child_sa;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_ikev2_initiate_rekey_child_sa payload;
} vapi_msg_ikev2_initiate_rekey_child_sa;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_ikev2_set_sa_lifetime_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_ikev2_set_sa_lifetime_reply payload;
} vapi_msg_ikev2_set_sa_lifetime_reply;

typedef struct __attribute__ ((__packed__)) {
  u8 is_add;
  u32 sad_id;
  u32 spi;
  u8 protocol;
  u8 crypto_algorithm;
  u8 crypto_key_length;
  u8 crypto_key[128];
  u8 integrity_algorithm;
  u8 integrity_key_length;
  u8 integrity_key[128];
  u8 use_extended_sequence_number;
  u8 is_tunnel;
  u8 is_tunnel_ipv6;
  u8 tunnel_src_address[16];
  u8 tunnel_dst_address[16]; 
} vapi_payload_ipsec_sad_add_del_entry;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_ipsec_sad_add_del_entry payload;
} vapi_msg_ipsec_sad_add_del_entry;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_ipsec_interface_add_del_spd_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_ipsec_interface_add_del_spd_reply payload;
} vapi_msg_ipsec_interface_add_del_spd_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_ipsec_spd_add_del_entry_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_ipsec_spd_add_del_entry_reply payload;
} vapi_msg_ipsec_spd_add_del_entry_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_ikev2_initiate_del_child_sa_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_ikev2_initiate_del_child_sa_reply payload;
} vapi_msg_ikev2_initiate_del_child_sa_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_ikev2_initiate_del_ike_sa_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_ikev2_initiate_del_ike_sa_reply payload;
} vapi_msg_ikev2_initiate_del_ike_sa_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 spd_id;
  i32 priority;
  u8 is_outbound;
  u8 is_ipv6;
  u8 local_start_addr[16];
  u8 local_stop_addr[16];
  u16 local_start_port;
  u16 local_stop_port;
  u8 remote_start_addr[16];
  u8 remote_stop_addr[16];
  u16 remote_start_port;
  u16 remote_stop_port;
  u8 protocol;
  u8 policy;
  u32 sa_id;
  u64 bytes;
  u64 packets; 
} vapi_payload_ipsec_spd_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_ipsec_spd_details payload;
} vapi_msg_ipsec_spd_details;

typedef struct __attribute__ ((__packed__)) {
  u32 spd_id;
  u32 sa_id; 
} vapi_payload_ipsec_spd_dump;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_ipsec_spd_dump payload;
} vapi_msg_ipsec_spd_dump;

typedef struct __attribute__ ((__packed__)) {
  u8 name[64];
  u32 crypto_alg;
  u32 crypto_key_size;
  u32 integ_alg;
  u32 dh_group; 
} vapi_payload_ikev2_set_ike_transforms;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_ikev2_set_ike_transforms payload;
} vapi_msg_ikev2_set_ike_transforms;

typedef struct __attribute__ ((__packed__)) {
  u8 name[64];
  u32 crypto_alg;
  u32 crypto_key_size;
  u32 integ_alg;
  u32 dh_group; 
} vapi_payload_ikev2_set_esp_transforms;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_ikev2_set_esp_transforms payload;
} vapi_msg_ikev2_set_esp_transforms;

typedef struct __attribute__ ((__packed__)) {
  u8 is_add;
  u32 spd_id;
  i32 priority;
  u8 is_outbound;
  u8 is_ipv6;
  u8 is_ip_any;
  u8 remote_address_start[16];
  u8 remote_address_stop[16];
  u8 local_address_start[16];
  u8 local_address_stop[16];
  u8 protocol;
  u16 remote_port_start;
  u16 remote_port_stop;
  u16 local_port_start;
  u16 local_port_stop;
  u8 policy;
  u32 sa_id; 
} vapi_payload_ipsec_spd_add_del_entry;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_ipsec_spd_add_del_entry payload;
} vapi_msg_ipsec_spd_add_del_entry;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_ikev2_set_local_key_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_ikev2_set_local_key_reply payload;
} vapi_msg_ikev2_set_local_key_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 ispi; 
} vapi_payload_ikev2_initiate_del_child_sa;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_ikev2_initiate_del_child_sa payload;
} vapi_msg_ikev2_initiate_del_child_sa;

typedef struct __attribute__ ((__packed__)) {
  u8 key_file[256]; 
} vapi_payload_ikev2_set_local_key;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_ikev2_set_local_key payload;
} vapi_msg_ikev2_set_local_key;

typedef struct __attribute__ ((__packed__)) {
  u8 is_add;
  u8 esn;
  u8 anti_replay;
  u8 local_ip[4];
  u8 remote_ip[4];
  u32 local_spi;
  u32 remote_spi;
  u8 crypto_alg;
  u8 local_crypto_key_len;
  u8 local_crypto_key[128];
  u8 remote_crypto_key_len;
  u8 remote_crypto_key[128];
  u8 integ_alg;
  u8 local_integ_key_len;
  u8 local_integ_key[128];
  u8 remote_integ_key_len;
  u8 remote_integ_key[128]; 
} vapi_payload_ipsec_tunnel_if_add_del;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_ipsec_tunnel_if_add_del payload;
} vapi_msg_ipsec_tunnel_if_add_del;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_ikev2_initiate_sa_init_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_ikev2_initiate_sa_init_reply payload;
} vapi_msg_ikev2_initiate_sa_init_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_ikev2_profile_set_id_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_ikev2_profile_set_id_reply payload;
} vapi_msg_ikev2_profile_set_id_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_ikev2_profile_set_ts_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_ikev2_profile_set_ts_reply payload;
} vapi_msg_ikev2_profile_set_ts_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_ikev2_profile_set_auth_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_ikev2_profile_set_auth_reply payload;
} vapi_msg_ikev2_profile_set_auth_reply;


static inline void vapi_msg_ipsec_spd_add_del_payload_hton(vapi_payload_ipsec_spd_add_del *payload)
{
  payload->spd_id = htobe32(payload->spd_id);
}

static inline void vapi_msg_ipsec_spd_add_del_payload_ntoh(vapi_payload_ipsec_spd_add_del *payload)
{
  payload->spd_id = be32toh(payload->spd_id);
}

static inline uword vapi_calc_ipsec_spd_add_del_msg_size(vapi_msg_ipsec_spd_add_del *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ipsec_spd_add_del_hton(vapi_msg_ipsec_spd_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ipsec_spd_add_del'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_ipsec_spd_add_del_payload_hton(&msg->payload);
}

static inline void vapi_msg_ipsec_spd_add_del_ntoh(vapi_msg_ipsec_spd_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ipsec_spd_add_del'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_ipsec_spd_add_del_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ipsec_interface_add_del_spd_payload_hton(vapi_payload_ipsec_interface_add_del_spd *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
  payload->spd_id = htobe32(payload->spd_id);
}

static inline void vapi_msg_ipsec_interface_add_del_spd_payload_ntoh(vapi_payload_ipsec_interface_add_del_spd *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
  payload->spd_id = be32toh(payload->spd_id);
}

static inline uword vapi_calc_ipsec_interface_add_del_spd_msg_size(vapi_msg_ipsec_interface_add_del_spd *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ipsec_interface_add_del_spd_hton(vapi_msg_ipsec_interface_add_del_spd *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ipsec_interface_add_del_spd'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_ipsec_interface_add_del_spd_payload_hton(&msg->payload);
}

static inline void vapi_msg_ipsec_interface_add_del_spd_ntoh(vapi_msg_ipsec_interface_add_del_spd *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ipsec_interface_add_del_spd'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_ipsec_interface_add_del_spd_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ikev2_set_responder_payload_hton(vapi_payload_ikev2_set_responder *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_ikev2_set_responder_payload_ntoh(vapi_payload_ikev2_set_responder *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_ikev2_set_responder_msg_size(vapi_msg_ikev2_set_responder *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ikev2_set_responder_hton(vapi_msg_ikev2_set_responder *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_set_responder'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_ikev2_set_responder_payload_hton(&msg->payload);
}

static inline void vapi_msg_ikev2_set_responder_ntoh(vapi_msg_ikev2_set_responder *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_set_responder'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_ikev2_set_responder_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ipsec_sa_set_key_reply_payload_hton(vapi_payload_ipsec_sa_set_key_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_ipsec_sa_set_key_reply_payload_ntoh(vapi_payload_ipsec_sa_set_key_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_ipsec_sa_set_key_reply_msg_size(vapi_msg_ipsec_sa_set_key_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ipsec_sa_set_key_reply_hton(vapi_msg_ipsec_sa_set_key_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ipsec_sa_set_key_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_ipsec_sa_set_key_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_ipsec_sa_set_key_reply_ntoh(vapi_msg_ipsec_sa_set_key_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ipsec_sa_set_key_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_ipsec_sa_set_key_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ikev2_profile_set_ts_payload_hton(vapi_payload_ikev2_profile_set_ts *payload)
{
  payload->start_port = htobe16(payload->start_port);
  payload->end_port = htobe16(payload->end_port);
  payload->start_addr = htobe32(payload->start_addr);
  payload->end_addr = htobe32(payload->end_addr);
}

static inline void vapi_msg_ikev2_profile_set_ts_payload_ntoh(vapi_payload_ikev2_profile_set_ts *payload)
{
  payload->start_port = be16toh(payload->start_port);
  payload->end_port = be16toh(payload->end_port);
  payload->start_addr = be32toh(payload->start_addr);
  payload->end_addr = be32toh(payload->end_addr);
}

static inline uword vapi_calc_ikev2_profile_set_ts_msg_size(vapi_msg_ikev2_profile_set_ts *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ikev2_profile_set_ts_hton(vapi_msg_ikev2_profile_set_ts *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_profile_set_ts'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_ikev2_profile_set_ts_payload_hton(&msg->payload);
}

static inline void vapi_msg_ikev2_profile_set_ts_ntoh(vapi_msg_ikev2_profile_set_ts *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_profile_set_ts'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_ikev2_profile_set_ts_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ikev2_set_responder_reply_payload_hton(vapi_payload_ikev2_set_responder_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_ikev2_set_responder_reply_payload_ntoh(vapi_payload_ikev2_set_responder_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_ikev2_set_responder_reply_msg_size(vapi_msg_ikev2_set_responder_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ikev2_set_responder_reply_hton(vapi_msg_ikev2_set_responder_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_set_responder_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_ikev2_set_responder_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_ikev2_set_responder_reply_ntoh(vapi_msg_ikev2_set_responder_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_set_responder_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_ikev2_set_responder_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ikev2_set_esp_transforms_reply_payload_hton(vapi_payload_ikev2_set_esp_transforms_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_ikev2_set_esp_transforms_reply_payload_ntoh(vapi_payload_ikev2_set_esp_transforms_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_ikev2_set_esp_transforms_reply_msg_size(vapi_msg_ikev2_set_esp_transforms_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ikev2_set_esp_transforms_reply_hton(vapi_msg_ikev2_set_esp_transforms_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_set_esp_transforms_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_ikev2_set_esp_transforms_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_ikev2_set_esp_transforms_reply_ntoh(vapi_msg_ikev2_set_esp_transforms_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_set_esp_transforms_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_ikev2_set_esp_transforms_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ikev2_set_ike_transforms_reply_payload_hton(vapi_payload_ikev2_set_ike_transforms_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_ikev2_set_ike_transforms_reply_payload_ntoh(vapi_payload_ikev2_set_ike_transforms_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_ikev2_set_ike_transforms_reply_msg_size(vapi_msg_ikev2_set_ike_transforms_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ikev2_set_ike_transforms_reply_hton(vapi_msg_ikev2_set_ike_transforms_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_set_ike_transforms_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_ikev2_set_ike_transforms_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_ikev2_set_ike_transforms_reply_ntoh(vapi_msg_ikev2_set_ike_transforms_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_set_ike_transforms_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_ikev2_set_ike_transforms_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ipsec_spd_add_del_reply_payload_hton(vapi_payload_ipsec_spd_add_del_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_ipsec_spd_add_del_reply_payload_ntoh(vapi_payload_ipsec_spd_add_del_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_ipsec_spd_add_del_reply_msg_size(vapi_msg_ipsec_spd_add_del_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ipsec_spd_add_del_reply_hton(vapi_msg_ipsec_spd_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ipsec_spd_add_del_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_ipsec_spd_add_del_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_ipsec_spd_add_del_reply_ntoh(vapi_msg_ipsec_spd_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ipsec_spd_add_del_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_ipsec_spd_add_del_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ikev2_initiate_del_ike_sa_payload_hton(vapi_payload_ikev2_initiate_del_ike_sa *payload)
{
  payload->ispi = htobe64(payload->ispi);
}

static inline void vapi_msg_ikev2_initiate_del_ike_sa_payload_ntoh(vapi_payload_ikev2_initiate_del_ike_sa *payload)
{
  payload->ispi = be64toh(payload->ispi);
}

static inline uword vapi_calc_ikev2_initiate_del_ike_sa_msg_size(vapi_msg_ikev2_initiate_del_ike_sa *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ikev2_initiate_del_ike_sa_hton(vapi_msg_ikev2_initiate_del_ike_sa *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_initiate_del_ike_sa'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_ikev2_initiate_del_ike_sa_payload_hton(&msg->payload);
}

static inline void vapi_msg_ikev2_initiate_del_ike_sa_ntoh(vapi_msg_ikev2_initiate_del_ike_sa *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_initiate_del_ike_sa'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_ikev2_initiate_del_ike_sa_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ikev2_initiate_rekey_child_sa_reply_payload_hton(vapi_payload_ikev2_initiate_rekey_child_sa_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_ikev2_initiate_rekey_child_sa_reply_payload_ntoh(vapi_payload_ikev2_initiate_rekey_child_sa_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_ikev2_initiate_rekey_child_sa_reply_msg_size(vapi_msg_ikev2_initiate_rekey_child_sa_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ikev2_initiate_rekey_child_sa_reply_hton(vapi_msg_ikev2_initiate_rekey_child_sa_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_initiate_rekey_child_sa_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_ikev2_initiate_rekey_child_sa_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_ikev2_initiate_rekey_child_sa_reply_ntoh(vapi_msg_ikev2_initiate_rekey_child_sa_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_initiate_rekey_child_sa_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_ikev2_initiate_rekey_child_sa_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ikev2_profile_add_del_reply_payload_hton(vapi_payload_ikev2_profile_add_del_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_ikev2_profile_add_del_reply_payload_ntoh(vapi_payload_ikev2_profile_add_del_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_ikev2_profile_add_del_reply_msg_size(vapi_msg_ikev2_profile_add_del_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ikev2_profile_add_del_reply_hton(vapi_msg_ikev2_profile_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_profile_add_del_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_ikev2_profile_add_del_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_ikev2_profile_add_del_reply_ntoh(vapi_msg_ikev2_profile_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_profile_add_del_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_ikev2_profile_add_del_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ipsec_sad_add_del_entry_reply_payload_hton(vapi_payload_ipsec_sad_add_del_entry_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_ipsec_sad_add_del_entry_reply_payload_ntoh(vapi_payload_ipsec_sad_add_del_entry_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_ipsec_sad_add_del_entry_reply_msg_size(vapi_msg_ipsec_sad_add_del_entry_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ipsec_sad_add_del_entry_reply_hton(vapi_msg_ipsec_sad_add_del_entry_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ipsec_sad_add_del_entry_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_ipsec_sad_add_del_entry_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_ipsec_sad_add_del_entry_reply_ntoh(vapi_msg_ipsec_sad_add_del_entry_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ipsec_sad_add_del_entry_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_ipsec_sad_add_del_entry_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ikev2_profile_add_del_payload_hton(vapi_payload_ikev2_profile_add_del *payload)
{

}

static inline void vapi_msg_ikev2_profile_add_del_payload_ntoh(vapi_payload_ikev2_profile_add_del *payload)
{

}

static inline uword vapi_calc_ikev2_profile_add_del_msg_size(vapi_msg_ikev2_profile_add_del *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ikev2_profile_add_del_hton(vapi_msg_ikev2_profile_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_profile_add_del'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_ikev2_profile_add_del_payload_hton(&msg->payload);
}

static inline void vapi_msg_ikev2_profile_add_del_ntoh(vapi_msg_ikev2_profile_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_profile_add_del'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_ikev2_profile_add_del_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ikev2_initiate_sa_init_payload_hton(vapi_payload_ikev2_initiate_sa_init *payload)
{

}

static inline void vapi_msg_ikev2_initiate_sa_init_payload_ntoh(vapi_payload_ikev2_initiate_sa_init *payload)
{

}

static inline uword vapi_calc_ikev2_initiate_sa_init_msg_size(vapi_msg_ikev2_initiate_sa_init *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ikev2_initiate_sa_init_hton(vapi_msg_ikev2_initiate_sa_init *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_initiate_sa_init'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_ikev2_initiate_sa_init_payload_hton(&msg->payload);
}

static inline void vapi_msg_ikev2_initiate_sa_init_ntoh(vapi_msg_ikev2_initiate_sa_init *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_initiate_sa_init'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_ikev2_initiate_sa_init_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ipsec_sa_set_key_payload_hton(vapi_payload_ipsec_sa_set_key *payload)
{
  payload->sa_id = htobe32(payload->sa_id);
}

static inline void vapi_msg_ipsec_sa_set_key_payload_ntoh(vapi_payload_ipsec_sa_set_key *payload)
{
  payload->sa_id = be32toh(payload->sa_id);
}

static inline uword vapi_calc_ipsec_sa_set_key_msg_size(vapi_msg_ipsec_sa_set_key *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ipsec_sa_set_key_hton(vapi_msg_ipsec_sa_set_key *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ipsec_sa_set_key'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_ipsec_sa_set_key_payload_hton(&msg->payload);
}

static inline void vapi_msg_ipsec_sa_set_key_ntoh(vapi_msg_ipsec_sa_set_key *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ipsec_sa_set_key'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_ipsec_sa_set_key_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ipsec_tunnel_if_add_del_reply_payload_hton(vapi_payload_ipsec_tunnel_if_add_del_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_ipsec_tunnel_if_add_del_reply_payload_ntoh(vapi_payload_ipsec_tunnel_if_add_del_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_ipsec_tunnel_if_add_del_reply_msg_size(vapi_msg_ipsec_tunnel_if_add_del_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ipsec_tunnel_if_add_del_reply_hton(vapi_msg_ipsec_tunnel_if_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ipsec_tunnel_if_add_del_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_ipsec_tunnel_if_add_del_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_ipsec_tunnel_if_add_del_reply_ntoh(vapi_msg_ipsec_tunnel_if_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ipsec_tunnel_if_add_del_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_ipsec_tunnel_if_add_del_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ikev2_set_sa_lifetime_payload_hton(vapi_payload_ikev2_set_sa_lifetime *payload)
{
  payload->lifetime = htobe64(payload->lifetime);
  payload->lifetime_jitter = htobe32(payload->lifetime_jitter);
  payload->handover = htobe32(payload->handover);
  payload->lifetime_maxdata = htobe64(payload->lifetime_maxdata);
}

static inline void vapi_msg_ikev2_set_sa_lifetime_payload_ntoh(vapi_payload_ikev2_set_sa_lifetime *payload)
{
  payload->lifetime = be64toh(payload->lifetime);
  payload->lifetime_jitter = be32toh(payload->lifetime_jitter);
  payload->handover = be32toh(payload->handover);
  payload->lifetime_maxdata = be64toh(payload->lifetime_maxdata);
}

static inline uword vapi_calc_ikev2_set_sa_lifetime_msg_size(vapi_msg_ikev2_set_sa_lifetime *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ikev2_set_sa_lifetime_hton(vapi_msg_ikev2_set_sa_lifetime *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_set_sa_lifetime'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_ikev2_set_sa_lifetime_payload_hton(&msg->payload);
}

static inline void vapi_msg_ikev2_set_sa_lifetime_ntoh(vapi_msg_ikev2_set_sa_lifetime *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_set_sa_lifetime'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_ikev2_set_sa_lifetime_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ikev2_initiate_rekey_child_sa_payload_hton(vapi_payload_ikev2_initiate_rekey_child_sa *payload)
{
  payload->ispi = htobe32(payload->ispi);
}

static inline void vapi_msg_ikev2_initiate_rekey_child_sa_payload_ntoh(vapi_payload_ikev2_initiate_rekey_child_sa *payload)
{
  payload->ispi = be32toh(payload->ispi);
}

static inline uword vapi_calc_ikev2_initiate_rekey_child_sa_msg_size(vapi_msg_ikev2_initiate_rekey_child_sa *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ikev2_initiate_rekey_child_sa_hton(vapi_msg_ikev2_initiate_rekey_child_sa *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_initiate_rekey_child_sa'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_ikev2_initiate_rekey_child_sa_payload_hton(&msg->payload);
}

static inline void vapi_msg_ikev2_initiate_rekey_child_sa_ntoh(vapi_msg_ikev2_initiate_rekey_child_sa *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_initiate_rekey_child_sa'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_ikev2_initiate_rekey_child_sa_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ikev2_set_sa_lifetime_reply_payload_hton(vapi_payload_ikev2_set_sa_lifetime_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_ikev2_set_sa_lifetime_reply_payload_ntoh(vapi_payload_ikev2_set_sa_lifetime_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_ikev2_set_sa_lifetime_reply_msg_size(vapi_msg_ikev2_set_sa_lifetime_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ikev2_set_sa_lifetime_reply_hton(vapi_msg_ikev2_set_sa_lifetime_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_set_sa_lifetime_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_ikev2_set_sa_lifetime_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_ikev2_set_sa_lifetime_reply_ntoh(vapi_msg_ikev2_set_sa_lifetime_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_set_sa_lifetime_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_ikev2_set_sa_lifetime_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ipsec_sad_add_del_entry_payload_hton(vapi_payload_ipsec_sad_add_del_entry *payload)
{
  payload->sad_id = htobe32(payload->sad_id);
  payload->spi = htobe32(payload->spi);
}

static inline void vapi_msg_ipsec_sad_add_del_entry_payload_ntoh(vapi_payload_ipsec_sad_add_del_entry *payload)
{
  payload->sad_id = be32toh(payload->sad_id);
  payload->spi = be32toh(payload->spi);
}

static inline uword vapi_calc_ipsec_sad_add_del_entry_msg_size(vapi_msg_ipsec_sad_add_del_entry *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ipsec_sad_add_del_entry_hton(vapi_msg_ipsec_sad_add_del_entry *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ipsec_sad_add_del_entry'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_ipsec_sad_add_del_entry_payload_hton(&msg->payload);
}

static inline void vapi_msg_ipsec_sad_add_del_entry_ntoh(vapi_msg_ipsec_sad_add_del_entry *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ipsec_sad_add_del_entry'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_ipsec_sad_add_del_entry_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ipsec_interface_add_del_spd_reply_payload_hton(vapi_payload_ipsec_interface_add_del_spd_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_ipsec_interface_add_del_spd_reply_payload_ntoh(vapi_payload_ipsec_interface_add_del_spd_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_ipsec_interface_add_del_spd_reply_msg_size(vapi_msg_ipsec_interface_add_del_spd_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ipsec_interface_add_del_spd_reply_hton(vapi_msg_ipsec_interface_add_del_spd_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ipsec_interface_add_del_spd_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_ipsec_interface_add_del_spd_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_ipsec_interface_add_del_spd_reply_ntoh(vapi_msg_ipsec_interface_add_del_spd_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ipsec_interface_add_del_spd_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_ipsec_interface_add_del_spd_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ipsec_spd_add_del_entry_reply_payload_hton(vapi_payload_ipsec_spd_add_del_entry_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_ipsec_spd_add_del_entry_reply_payload_ntoh(vapi_payload_ipsec_spd_add_del_entry_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_ipsec_spd_add_del_entry_reply_msg_size(vapi_msg_ipsec_spd_add_del_entry_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ipsec_spd_add_del_entry_reply_hton(vapi_msg_ipsec_spd_add_del_entry_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ipsec_spd_add_del_entry_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_ipsec_spd_add_del_entry_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_ipsec_spd_add_del_entry_reply_ntoh(vapi_msg_ipsec_spd_add_del_entry_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ipsec_spd_add_del_entry_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_ipsec_spd_add_del_entry_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ikev2_initiate_del_child_sa_reply_payload_hton(vapi_payload_ikev2_initiate_del_child_sa_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_ikev2_initiate_del_child_sa_reply_payload_ntoh(vapi_payload_ikev2_initiate_del_child_sa_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_ikev2_initiate_del_child_sa_reply_msg_size(vapi_msg_ikev2_initiate_del_child_sa_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ikev2_initiate_del_child_sa_reply_hton(vapi_msg_ikev2_initiate_del_child_sa_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_initiate_del_child_sa_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_ikev2_initiate_del_child_sa_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_ikev2_initiate_del_child_sa_reply_ntoh(vapi_msg_ikev2_initiate_del_child_sa_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_initiate_del_child_sa_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_ikev2_initiate_del_child_sa_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ikev2_initiate_del_ike_sa_reply_payload_hton(vapi_payload_ikev2_initiate_del_ike_sa_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_ikev2_initiate_del_ike_sa_reply_payload_ntoh(vapi_payload_ikev2_initiate_del_ike_sa_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_ikev2_initiate_del_ike_sa_reply_msg_size(vapi_msg_ikev2_initiate_del_ike_sa_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ikev2_initiate_del_ike_sa_reply_hton(vapi_msg_ikev2_initiate_del_ike_sa_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_initiate_del_ike_sa_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_ikev2_initiate_del_ike_sa_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_ikev2_initiate_del_ike_sa_reply_ntoh(vapi_msg_ikev2_initiate_del_ike_sa_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_initiate_del_ike_sa_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_ikev2_initiate_del_ike_sa_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ipsec_spd_details_payload_hton(vapi_payload_ipsec_spd_details *payload)
{
  payload->spd_id = htobe32(payload->spd_id);
  payload->priority = htobe32(payload->priority);
  payload->local_start_port = htobe16(payload->local_start_port);
  payload->local_stop_port = htobe16(payload->local_stop_port);
  payload->remote_start_port = htobe16(payload->remote_start_port);
  payload->remote_stop_port = htobe16(payload->remote_stop_port);
  payload->sa_id = htobe32(payload->sa_id);
  payload->bytes = htobe64(payload->bytes);
  payload->packets = htobe64(payload->packets);
}

static inline void vapi_msg_ipsec_spd_details_payload_ntoh(vapi_payload_ipsec_spd_details *payload)
{
  payload->spd_id = be32toh(payload->spd_id);
  payload->priority = be32toh(payload->priority);
  payload->local_start_port = be16toh(payload->local_start_port);
  payload->local_stop_port = be16toh(payload->local_stop_port);
  payload->remote_start_port = be16toh(payload->remote_start_port);
  payload->remote_stop_port = be16toh(payload->remote_stop_port);
  payload->sa_id = be32toh(payload->sa_id);
  payload->bytes = be64toh(payload->bytes);
  payload->packets = be64toh(payload->packets);
}

static inline uword vapi_calc_ipsec_spd_details_msg_size(vapi_msg_ipsec_spd_details *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ipsec_spd_details_hton(vapi_msg_ipsec_spd_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ipsec_spd_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_ipsec_spd_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_ipsec_spd_details_ntoh(vapi_msg_ipsec_spd_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ipsec_spd_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_ipsec_spd_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ipsec_spd_dump_payload_hton(vapi_payload_ipsec_spd_dump *payload)
{
  payload->spd_id = htobe32(payload->spd_id);
  payload->sa_id = htobe32(payload->sa_id);
}

static inline void vapi_msg_ipsec_spd_dump_payload_ntoh(vapi_payload_ipsec_spd_dump *payload)
{
  payload->spd_id = be32toh(payload->spd_id);
  payload->sa_id = be32toh(payload->sa_id);
}

static inline uword vapi_calc_ipsec_spd_dump_msg_size(vapi_msg_ipsec_spd_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ipsec_spd_dump_hton(vapi_msg_ipsec_spd_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ipsec_spd_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_ipsec_spd_dump_payload_hton(&msg->payload);
}

static inline void vapi_msg_ipsec_spd_dump_ntoh(vapi_msg_ipsec_spd_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ipsec_spd_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_ipsec_spd_dump_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ikev2_set_ike_transforms_payload_hton(vapi_payload_ikev2_set_ike_transforms *payload)
{
  payload->crypto_alg = htobe32(payload->crypto_alg);
  payload->crypto_key_size = htobe32(payload->crypto_key_size);
  payload->integ_alg = htobe32(payload->integ_alg);
  payload->dh_group = htobe32(payload->dh_group);
}

static inline void vapi_msg_ikev2_set_ike_transforms_payload_ntoh(vapi_payload_ikev2_set_ike_transforms *payload)
{
  payload->crypto_alg = be32toh(payload->crypto_alg);
  payload->crypto_key_size = be32toh(payload->crypto_key_size);
  payload->integ_alg = be32toh(payload->integ_alg);
  payload->dh_group = be32toh(payload->dh_group);
}

static inline uword vapi_calc_ikev2_set_ike_transforms_msg_size(vapi_msg_ikev2_set_ike_transforms *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ikev2_set_ike_transforms_hton(vapi_msg_ikev2_set_ike_transforms *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_set_ike_transforms'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_ikev2_set_ike_transforms_payload_hton(&msg->payload);
}

static inline void vapi_msg_ikev2_set_ike_transforms_ntoh(vapi_msg_ikev2_set_ike_transforms *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_set_ike_transforms'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_ikev2_set_ike_transforms_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ikev2_set_esp_transforms_payload_hton(vapi_payload_ikev2_set_esp_transforms *payload)
{
  payload->crypto_alg = htobe32(payload->crypto_alg);
  payload->crypto_key_size = htobe32(payload->crypto_key_size);
  payload->integ_alg = htobe32(payload->integ_alg);
  payload->dh_group = htobe32(payload->dh_group);
}

static inline void vapi_msg_ikev2_set_esp_transforms_payload_ntoh(vapi_payload_ikev2_set_esp_transforms *payload)
{
  payload->crypto_alg = be32toh(payload->crypto_alg);
  payload->crypto_key_size = be32toh(payload->crypto_key_size);
  payload->integ_alg = be32toh(payload->integ_alg);
  payload->dh_group = be32toh(payload->dh_group);
}

static inline uword vapi_calc_ikev2_set_esp_transforms_msg_size(vapi_msg_ikev2_set_esp_transforms *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ikev2_set_esp_transforms_hton(vapi_msg_ikev2_set_esp_transforms *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_set_esp_transforms'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_ikev2_set_esp_transforms_payload_hton(&msg->payload);
}

static inline void vapi_msg_ikev2_set_esp_transforms_ntoh(vapi_msg_ikev2_set_esp_transforms *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_set_esp_transforms'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_ikev2_set_esp_transforms_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ipsec_spd_add_del_entry_payload_hton(vapi_payload_ipsec_spd_add_del_entry *payload)
{
  payload->spd_id = htobe32(payload->spd_id);
  payload->priority = htobe32(payload->priority);
  payload->remote_port_start = htobe16(payload->remote_port_start);
  payload->remote_port_stop = htobe16(payload->remote_port_stop);
  payload->local_port_start = htobe16(payload->local_port_start);
  payload->local_port_stop = htobe16(payload->local_port_stop);
  payload->sa_id = htobe32(payload->sa_id);
}

static inline void vapi_msg_ipsec_spd_add_del_entry_payload_ntoh(vapi_payload_ipsec_spd_add_del_entry *payload)
{
  payload->spd_id = be32toh(payload->spd_id);
  payload->priority = be32toh(payload->priority);
  payload->remote_port_start = be16toh(payload->remote_port_start);
  payload->remote_port_stop = be16toh(payload->remote_port_stop);
  payload->local_port_start = be16toh(payload->local_port_start);
  payload->local_port_stop = be16toh(payload->local_port_stop);
  payload->sa_id = be32toh(payload->sa_id);
}

static inline uword vapi_calc_ipsec_spd_add_del_entry_msg_size(vapi_msg_ipsec_spd_add_del_entry *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ipsec_spd_add_del_entry_hton(vapi_msg_ipsec_spd_add_del_entry *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ipsec_spd_add_del_entry'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_ipsec_spd_add_del_entry_payload_hton(&msg->payload);
}

static inline void vapi_msg_ipsec_spd_add_del_entry_ntoh(vapi_msg_ipsec_spd_add_del_entry *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ipsec_spd_add_del_entry'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_ipsec_spd_add_del_entry_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ikev2_set_local_key_reply_payload_hton(vapi_payload_ikev2_set_local_key_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_ikev2_set_local_key_reply_payload_ntoh(vapi_payload_ikev2_set_local_key_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_ikev2_set_local_key_reply_msg_size(vapi_msg_ikev2_set_local_key_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ikev2_set_local_key_reply_hton(vapi_msg_ikev2_set_local_key_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_set_local_key_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_ikev2_set_local_key_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_ikev2_set_local_key_reply_ntoh(vapi_msg_ikev2_set_local_key_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_set_local_key_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_ikev2_set_local_key_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ikev2_initiate_del_child_sa_payload_hton(vapi_payload_ikev2_initiate_del_child_sa *payload)
{
  payload->ispi = htobe32(payload->ispi);
}

static inline void vapi_msg_ikev2_initiate_del_child_sa_payload_ntoh(vapi_payload_ikev2_initiate_del_child_sa *payload)
{
  payload->ispi = be32toh(payload->ispi);
}

static inline uword vapi_calc_ikev2_initiate_del_child_sa_msg_size(vapi_msg_ikev2_initiate_del_child_sa *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ikev2_initiate_del_child_sa_hton(vapi_msg_ikev2_initiate_del_child_sa *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_initiate_del_child_sa'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_ikev2_initiate_del_child_sa_payload_hton(&msg->payload);
}

static inline void vapi_msg_ikev2_initiate_del_child_sa_ntoh(vapi_msg_ikev2_initiate_del_child_sa *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_initiate_del_child_sa'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_ikev2_initiate_del_child_sa_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ikev2_set_local_key_payload_hton(vapi_payload_ikev2_set_local_key *payload)
{

}

static inline void vapi_msg_ikev2_set_local_key_payload_ntoh(vapi_payload_ikev2_set_local_key *payload)
{

}

static inline uword vapi_calc_ikev2_set_local_key_msg_size(vapi_msg_ikev2_set_local_key *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ikev2_set_local_key_hton(vapi_msg_ikev2_set_local_key *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_set_local_key'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_ikev2_set_local_key_payload_hton(&msg->payload);
}

static inline void vapi_msg_ikev2_set_local_key_ntoh(vapi_msg_ikev2_set_local_key *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_set_local_key'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_ikev2_set_local_key_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ipsec_tunnel_if_add_del_payload_hton(vapi_payload_ipsec_tunnel_if_add_del *payload)
{
  payload->local_spi = htobe32(payload->local_spi);
  payload->remote_spi = htobe32(payload->remote_spi);
}

static inline void vapi_msg_ipsec_tunnel_if_add_del_payload_ntoh(vapi_payload_ipsec_tunnel_if_add_del *payload)
{
  payload->local_spi = be32toh(payload->local_spi);
  payload->remote_spi = be32toh(payload->remote_spi);
}

static inline uword vapi_calc_ipsec_tunnel_if_add_del_msg_size(vapi_msg_ipsec_tunnel_if_add_del *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ipsec_tunnel_if_add_del_hton(vapi_msg_ipsec_tunnel_if_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ipsec_tunnel_if_add_del'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_ipsec_tunnel_if_add_del_payload_hton(&msg->payload);
}

static inline void vapi_msg_ipsec_tunnel_if_add_del_ntoh(vapi_msg_ipsec_tunnel_if_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ipsec_tunnel_if_add_del'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_ipsec_tunnel_if_add_del_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ikev2_initiate_sa_init_reply_payload_hton(vapi_payload_ikev2_initiate_sa_init_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_ikev2_initiate_sa_init_reply_payload_ntoh(vapi_payload_ikev2_initiate_sa_init_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_ikev2_initiate_sa_init_reply_msg_size(vapi_msg_ikev2_initiate_sa_init_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ikev2_initiate_sa_init_reply_hton(vapi_msg_ikev2_initiate_sa_init_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_initiate_sa_init_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_ikev2_initiate_sa_init_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_ikev2_initiate_sa_init_reply_ntoh(vapi_msg_ikev2_initiate_sa_init_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_initiate_sa_init_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_ikev2_initiate_sa_init_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ikev2_profile_set_id_reply_payload_hton(vapi_payload_ikev2_profile_set_id_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_ikev2_profile_set_id_reply_payload_ntoh(vapi_payload_ikev2_profile_set_id_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_ikev2_profile_set_id_reply_msg_size(vapi_msg_ikev2_profile_set_id_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ikev2_profile_set_id_reply_hton(vapi_msg_ikev2_profile_set_id_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_profile_set_id_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_ikev2_profile_set_id_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_ikev2_profile_set_id_reply_ntoh(vapi_msg_ikev2_profile_set_id_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_profile_set_id_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_ikev2_profile_set_id_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ikev2_profile_set_ts_reply_payload_hton(vapi_payload_ikev2_profile_set_ts_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_ikev2_profile_set_ts_reply_payload_ntoh(vapi_payload_ikev2_profile_set_ts_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_ikev2_profile_set_ts_reply_msg_size(vapi_msg_ikev2_profile_set_ts_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ikev2_profile_set_ts_reply_hton(vapi_msg_ikev2_profile_set_ts_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_profile_set_ts_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_ikev2_profile_set_ts_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_ikev2_profile_set_ts_reply_ntoh(vapi_msg_ikev2_profile_set_ts_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_profile_set_ts_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_ikev2_profile_set_ts_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ikev2_profile_set_auth_reply_payload_hton(vapi_payload_ikev2_profile_set_auth_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_ikev2_profile_set_auth_reply_payload_ntoh(vapi_payload_ikev2_profile_set_auth_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_ikev2_profile_set_auth_reply_msg_size(vapi_msg_ikev2_profile_set_auth_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ikev2_profile_set_auth_reply_hton(vapi_msg_ikev2_profile_set_auth_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_profile_set_auth_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_ikev2_profile_set_auth_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_ikev2_profile_set_auth_reply_ntoh(vapi_msg_ikev2_profile_set_auth_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ikev2_profile_set_auth_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_ikev2_profile_set_auth_reply_payload_ntoh(&msg->payload);
}

static inline vapi_msg_ipsec_spd_add_del* vapi_alloc_ipsec_spd_add_del(struct vapi_ctx_s *ctx)
{
  vapi_msg_ipsec_spd_add_del *msg = NULL;
  const size_t size = sizeof(vapi_msg_ipsec_spd_add_del);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_ipsec_spd_add_del*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_ipsec_spd_add_del);

  return msg;
}

static inline vapi_error_e vapi_ipsec_spd_add_del(struct vapi_ctx_s *ctx,
  vapi_msg_ipsec_spd_add_del *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_ipsec_spd_add_del_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_ipsec_spd_add_del_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_ipsec_spd_add_del_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_ipsec_interface_add_del_spd* vapi_alloc_ipsec_interface_add_del_spd(struct vapi_ctx_s *ctx)
{
  vapi_msg_ipsec_interface_add_del_spd *msg = NULL;
  const size_t size = sizeof(vapi_msg_ipsec_interface_add_del_spd);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_ipsec_interface_add_del_spd*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_ipsec_interface_add_del_spd);

  return msg;
}

static inline vapi_error_e vapi_ipsec_interface_add_del_spd(struct vapi_ctx_s *ctx,
  vapi_msg_ipsec_interface_add_del_spd *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_ipsec_interface_add_del_spd_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_ipsec_interface_add_del_spd_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_ipsec_interface_add_del_spd_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_ikev2_set_responder* vapi_alloc_ikev2_set_responder(struct vapi_ctx_s *ctx)
{
  vapi_msg_ikev2_set_responder *msg = NULL;
  const size_t size = sizeof(vapi_msg_ikev2_set_responder);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_ikev2_set_responder*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_ikev2_set_responder);

  return msg;
}

static inline vapi_error_e vapi_ikev2_set_responder(struct vapi_ctx_s *ctx,
  vapi_msg_ikev2_set_responder *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_ikev2_set_responder_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_ikev2_set_responder_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_ikev2_set_responder_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_ikev2_profile_set_ts* vapi_alloc_ikev2_profile_set_ts(struct vapi_ctx_s *ctx)
{
  vapi_msg_ikev2_profile_set_ts *msg = NULL;
  const size_t size = sizeof(vapi_msg_ikev2_profile_set_ts);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_ikev2_profile_set_ts*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_ikev2_profile_set_ts);

  return msg;
}

static inline vapi_error_e vapi_ikev2_profile_set_ts(struct vapi_ctx_s *ctx,
  vapi_msg_ikev2_profile_set_ts *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_ikev2_profile_set_ts_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_ikev2_profile_set_ts_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_ikev2_profile_set_ts_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_ikev2_initiate_del_ike_sa* vapi_alloc_ikev2_initiate_del_ike_sa(struct vapi_ctx_s *ctx)
{
  vapi_msg_ikev2_initiate_del_ike_sa *msg = NULL;
  const size_t size = sizeof(vapi_msg_ikev2_initiate_del_ike_sa);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_ikev2_initiate_del_ike_sa*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_ikev2_initiate_del_ike_sa);

  return msg;
}

static inline vapi_error_e vapi_ikev2_initiate_del_ike_sa(struct vapi_ctx_s *ctx,
  vapi_msg_ikev2_initiate_del_ike_sa *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_ikev2_initiate_del_ike_sa_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_ikev2_initiate_del_ike_sa_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_ikev2_initiate_del_ike_sa_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_ikev2_profile_add_del* vapi_alloc_ikev2_profile_add_del(struct vapi_ctx_s *ctx)
{
  vapi_msg_ikev2_profile_add_del *msg = NULL;
  const size_t size = sizeof(vapi_msg_ikev2_profile_add_del);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_ikev2_profile_add_del*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_ikev2_profile_add_del);

  return msg;
}

static inline vapi_error_e vapi_ikev2_profile_add_del(struct vapi_ctx_s *ctx,
  vapi_msg_ikev2_profile_add_del *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_ikev2_profile_add_del_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_ikev2_profile_add_del_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_ikev2_profile_add_del_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_ikev2_initiate_sa_init* vapi_alloc_ikev2_initiate_sa_init(struct vapi_ctx_s *ctx)
{
  vapi_msg_ikev2_initiate_sa_init *msg = NULL;
  const size_t size = sizeof(vapi_msg_ikev2_initiate_sa_init);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_ikev2_initiate_sa_init*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_ikev2_initiate_sa_init);

  return msg;
}

static inline vapi_error_e vapi_ikev2_initiate_sa_init(struct vapi_ctx_s *ctx,
  vapi_msg_ikev2_initiate_sa_init *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_ikev2_initiate_sa_init_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_ikev2_initiate_sa_init_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_ikev2_initiate_sa_init_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_ipsec_sa_set_key* vapi_alloc_ipsec_sa_set_key(struct vapi_ctx_s *ctx)
{
  vapi_msg_ipsec_sa_set_key *msg = NULL;
  const size_t size = sizeof(vapi_msg_ipsec_sa_set_key);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_ipsec_sa_set_key*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_ipsec_sa_set_key);

  return msg;
}

static inline vapi_error_e vapi_ipsec_sa_set_key(struct vapi_ctx_s *ctx,
  vapi_msg_ipsec_sa_set_key *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_ipsec_sa_set_key_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_ipsec_sa_set_key_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_ipsec_sa_set_key_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_ikev2_set_sa_lifetime* vapi_alloc_ikev2_set_sa_lifetime(struct vapi_ctx_s *ctx)
{
  vapi_msg_ikev2_set_sa_lifetime *msg = NULL;
  const size_t size = sizeof(vapi_msg_ikev2_set_sa_lifetime);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_ikev2_set_sa_lifetime*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_ikev2_set_sa_lifetime);

  return msg;
}

static inline vapi_error_e vapi_ikev2_set_sa_lifetime(struct vapi_ctx_s *ctx,
  vapi_msg_ikev2_set_sa_lifetime *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_ikev2_set_sa_lifetime_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_ikev2_set_sa_lifetime_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_ikev2_set_sa_lifetime_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_ikev2_initiate_rekey_child_sa* vapi_alloc_ikev2_initiate_rekey_child_sa(struct vapi_ctx_s *ctx)
{
  vapi_msg_ikev2_initiate_rekey_child_sa *msg = NULL;
  const size_t size = sizeof(vapi_msg_ikev2_initiate_rekey_child_sa);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_ikev2_initiate_rekey_child_sa*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_ikev2_initiate_rekey_child_sa);

  return msg;
}

static inline vapi_error_e vapi_ikev2_initiate_rekey_child_sa(struct vapi_ctx_s *ctx,
  vapi_msg_ikev2_initiate_rekey_child_sa *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_ikev2_initiate_rekey_child_sa_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_ikev2_initiate_rekey_child_sa_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_ikev2_initiate_rekey_child_sa_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_ipsec_sad_add_del_entry* vapi_alloc_ipsec_sad_add_del_entry(struct vapi_ctx_s *ctx)
{
  vapi_msg_ipsec_sad_add_del_entry *msg = NULL;
  const size_t size = sizeof(vapi_msg_ipsec_sad_add_del_entry);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_ipsec_sad_add_del_entry*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_ipsec_sad_add_del_entry);

  return msg;
}

static inline vapi_error_e vapi_ipsec_sad_add_del_entry(struct vapi_ctx_s *ctx,
  vapi_msg_ipsec_sad_add_del_entry *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_ipsec_sad_add_del_entry_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_ipsec_sad_add_del_entry_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_ipsec_sad_add_del_entry_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_ipsec_spd_dump* vapi_alloc_ipsec_spd_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_ipsec_spd_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_ipsec_spd_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_ipsec_spd_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_ipsec_spd_dump);

  return msg;
}

static inline vapi_error_e vapi_ipsec_spd_dump(struct vapi_ctx_s *ctx,
  vapi_msg_ipsec_spd_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_ipsec_spd_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_ipsec_spd_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_ipsec_spd_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_ikev2_set_ike_transforms* vapi_alloc_ikev2_set_ike_transforms(struct vapi_ctx_s *ctx)
{
  vapi_msg_ikev2_set_ike_transforms *msg = NULL;
  const size_t size = sizeof(vapi_msg_ikev2_set_ike_transforms);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_ikev2_set_ike_transforms*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_ikev2_set_ike_transforms);

  return msg;
}

static inline vapi_error_e vapi_ikev2_set_ike_transforms(struct vapi_ctx_s *ctx,
  vapi_msg_ikev2_set_ike_transforms *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_ikev2_set_ike_transforms_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_ikev2_set_ike_transforms_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_ikev2_set_ike_transforms_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_ikev2_set_esp_transforms* vapi_alloc_ikev2_set_esp_transforms(struct vapi_ctx_s *ctx)
{
  vapi_msg_ikev2_set_esp_transforms *msg = NULL;
  const size_t size = sizeof(vapi_msg_ikev2_set_esp_transforms);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_ikev2_set_esp_transforms*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_ikev2_set_esp_transforms);

  return msg;
}

static inline vapi_error_e vapi_ikev2_set_esp_transforms(struct vapi_ctx_s *ctx,
  vapi_msg_ikev2_set_esp_transforms *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_ikev2_set_esp_transforms_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_ikev2_set_esp_transforms_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_ikev2_set_esp_transforms_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_ipsec_spd_add_del_entry* vapi_alloc_ipsec_spd_add_del_entry(struct vapi_ctx_s *ctx)
{
  vapi_msg_ipsec_spd_add_del_entry *msg = NULL;
  const size_t size = sizeof(vapi_msg_ipsec_spd_add_del_entry);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_ipsec_spd_add_del_entry*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_ipsec_spd_add_del_entry);

  return msg;
}

static inline vapi_error_e vapi_ipsec_spd_add_del_entry(struct vapi_ctx_s *ctx,
  vapi_msg_ipsec_spd_add_del_entry *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_ipsec_spd_add_del_entry_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_ipsec_spd_add_del_entry_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_ipsec_spd_add_del_entry_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_ikev2_initiate_del_child_sa* vapi_alloc_ikev2_initiate_del_child_sa(struct vapi_ctx_s *ctx)
{
  vapi_msg_ikev2_initiate_del_child_sa *msg = NULL;
  const size_t size = sizeof(vapi_msg_ikev2_initiate_del_child_sa);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_ikev2_initiate_del_child_sa*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_ikev2_initiate_del_child_sa);

  return msg;
}

static inline vapi_error_e vapi_ikev2_initiate_del_child_sa(struct vapi_ctx_s *ctx,
  vapi_msg_ikev2_initiate_del_child_sa *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_ikev2_initiate_del_child_sa_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_ikev2_initiate_del_child_sa_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_ikev2_initiate_del_child_sa_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_ikev2_set_local_key* vapi_alloc_ikev2_set_local_key(struct vapi_ctx_s *ctx)
{
  vapi_msg_ikev2_set_local_key *msg = NULL;
  const size_t size = sizeof(vapi_msg_ikev2_set_local_key);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_ikev2_set_local_key*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_ikev2_set_local_key);

  return msg;
}

static inline vapi_error_e vapi_ikev2_set_local_key(struct vapi_ctx_s *ctx,
  vapi_msg_ikev2_set_local_key *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_ikev2_set_local_key_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_ikev2_set_local_key_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_ikev2_set_local_key_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_ipsec_tunnel_if_add_del* vapi_alloc_ipsec_tunnel_if_add_del(struct vapi_ctx_s *ctx)
{
  vapi_msg_ipsec_tunnel_if_add_del *msg = NULL;
  const size_t size = sizeof(vapi_msg_ipsec_tunnel_if_add_del);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_ipsec_tunnel_if_add_del*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_ipsec_tunnel_if_add_del);

  return msg;
}

static inline vapi_error_e vapi_ipsec_tunnel_if_add_del(struct vapi_ctx_s *ctx,
  vapi_msg_ipsec_tunnel_if_add_del *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_ipsec_tunnel_if_add_del_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_ipsec_tunnel_if_add_del_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_ipsec_tunnel_if_add_del_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}



static void __attribute__((constructor)) __vapi_constructor_ipsec_spd_add_del()
{
  static const char name[] = "ipsec_spd_add_del";
  static const char name_with_crc[] = "ipsec_spd_add_del_9b42314b";
  static vapi_message_desc_t __vapi_metadata_ipsec_spd_add_del = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_ipsec_spd_add_del, payload),
    sizeof(vapi_msg_ipsec_spd_add_del),
    (generic_swap_fn_t)vapi_msg_ipsec_spd_add_del_hton,
    (generic_swap_fn_t)vapi_msg_ipsec_spd_add_del_ntoh,
    ~0,
  };

  vapi_msg_id_ipsec_spd_add_del = vapi_register_msg(&__vapi_metadata_ipsec_spd_add_del);
  VAPI_DBG("Assigned msg id %d to ipsec_spd_add_del", vapi_msg_id_ipsec_spd_add_del);
}

static void __attribute__((constructor)) __vapi_constructor_ipsec_interface_add_del_spd()
{
  static const char name[] = "ipsec_interface_add_del_spd";
  static const char name_with_crc[] = "ipsec_interface_add_del_spd_52de89dc";
  static vapi_message_desc_t __vapi_metadata_ipsec_interface_add_del_spd = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_ipsec_interface_add_del_spd, payload),
    sizeof(vapi_msg_ipsec_interface_add_del_spd),
    (generic_swap_fn_t)vapi_msg_ipsec_interface_add_del_spd_hton,
    (generic_swap_fn_t)vapi_msg_ipsec_interface_add_del_spd_ntoh,
    ~0,
  };

  vapi_msg_id_ipsec_interface_add_del_spd = vapi_register_msg(&__vapi_metadata_ipsec_interface_add_del_spd);
  VAPI_DBG("Assigned msg id %d to ipsec_interface_add_del_spd", vapi_msg_id_ipsec_interface_add_del_spd);
}

static void __attribute__((constructor)) __vapi_constructor_ikev2_set_responder()
{
  static const char name[] = "ikev2_set_responder";
  static const char name_with_crc[] = "ikev2_set_responder_519141b4";
  static vapi_message_desc_t __vapi_metadata_ikev2_set_responder = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_ikev2_set_responder, payload),
    sizeof(vapi_msg_ikev2_set_responder),
    (generic_swap_fn_t)vapi_msg_ikev2_set_responder_hton,
    (generic_swap_fn_t)vapi_msg_ikev2_set_responder_ntoh,
    ~0,
  };

  vapi_msg_id_ikev2_set_responder = vapi_register_msg(&__vapi_metadata_ikev2_set_responder);
  VAPI_DBG("Assigned msg id %d to ikev2_set_responder", vapi_msg_id_ikev2_set_responder);
}

static void __attribute__((constructor)) __vapi_constructor_ipsec_sa_set_key_reply()
{
  static const char name[] = "ipsec_sa_set_key_reply";
  static const char name_with_crc[] = "ipsec_sa_set_key_reply_5c5b7b46";
  static vapi_message_desc_t __vapi_metadata_ipsec_sa_set_key_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_ipsec_sa_set_key_reply, payload),
    sizeof(vapi_msg_ipsec_sa_set_key_reply),
    (generic_swap_fn_t)vapi_msg_ipsec_sa_set_key_reply_hton,
    (generic_swap_fn_t)vapi_msg_ipsec_sa_set_key_reply_ntoh,
    ~0,
  };

  vapi_msg_id_ipsec_sa_set_key_reply = vapi_register_msg(&__vapi_metadata_ipsec_sa_set_key_reply);
  VAPI_DBG("Assigned msg id %d to ipsec_sa_set_key_reply", vapi_msg_id_ipsec_sa_set_key_reply);
}

static void __attribute__((constructor)) __vapi_constructor_ikev2_profile_set_ts()
{
  static const char name[] = "ikev2_profile_set_ts";
  static const char name_with_crc[] = "ikev2_profile_set_ts_69587e0e";
  static vapi_message_desc_t __vapi_metadata_ikev2_profile_set_ts = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_ikev2_profile_set_ts, payload),
    sizeof(vapi_msg_ikev2_profile_set_ts),
    (generic_swap_fn_t)vapi_msg_ikev2_profile_set_ts_hton,
    (generic_swap_fn_t)vapi_msg_ikev2_profile_set_ts_ntoh,
    ~0,
  };

  vapi_msg_id_ikev2_profile_set_ts = vapi_register_msg(&__vapi_metadata_ikev2_profile_set_ts);
  VAPI_DBG("Assigned msg id %d to ikev2_profile_set_ts", vapi_msg_id_ikev2_profile_set_ts);
}

static void __attribute__((constructor)) __vapi_constructor_ikev2_set_responder_reply()
{
  static const char name[] = "ikev2_set_responder_reply";
  static const char name_with_crc[] = "ikev2_set_responder_reply_2f1a94d7";
  static vapi_message_desc_t __vapi_metadata_ikev2_set_responder_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_ikev2_set_responder_reply, payload),
    sizeof(vapi_msg_ikev2_set_responder_reply),
    (generic_swap_fn_t)vapi_msg_ikev2_set_responder_reply_hton,
    (generic_swap_fn_t)vapi_msg_ikev2_set_responder_reply_ntoh,
    ~0,
  };

  vapi_msg_id_ikev2_set_responder_reply = vapi_register_msg(&__vapi_metadata_ikev2_set_responder_reply);
  VAPI_DBG("Assigned msg id %d to ikev2_set_responder_reply", vapi_msg_id_ikev2_set_responder_reply);
}

static void __attribute__((constructor)) __vapi_constructor_ikev2_set_esp_transforms_reply()
{
  static const char name[] = "ikev2_set_esp_transforms_reply";
  static const char name_with_crc[] = "ikev2_set_esp_transforms_reply_9f3a1a67";
  static vapi_message_desc_t __vapi_metadata_ikev2_set_esp_transforms_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_ikev2_set_esp_transforms_reply, payload),
    sizeof(vapi_msg_ikev2_set_esp_transforms_reply),
    (generic_swap_fn_t)vapi_msg_ikev2_set_esp_transforms_reply_hton,
    (generic_swap_fn_t)vapi_msg_ikev2_set_esp_transforms_reply_ntoh,
    ~0,
  };

  vapi_msg_id_ikev2_set_esp_transforms_reply = vapi_register_msg(&__vapi_metadata_ikev2_set_esp_transforms_reply);
  VAPI_DBG("Assigned msg id %d to ikev2_set_esp_transforms_reply", vapi_msg_id_ikev2_set_esp_transforms_reply);
}

static void __attribute__((constructor)) __vapi_constructor_ikev2_set_ike_transforms_reply()
{
  static const char name[] = "ikev2_set_ike_transforms_reply";
  static const char name_with_crc[] = "ikev2_set_ike_transforms_reply_18883302";
  static vapi_message_desc_t __vapi_metadata_ikev2_set_ike_transforms_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_ikev2_set_ike_transforms_reply, payload),
    sizeof(vapi_msg_ikev2_set_ike_transforms_reply),
    (generic_swap_fn_t)vapi_msg_ikev2_set_ike_transforms_reply_hton,
    (generic_swap_fn_t)vapi_msg_ikev2_set_ike_transforms_reply_ntoh,
    ~0,
  };

  vapi_msg_id_ikev2_set_ike_transforms_reply = vapi_register_msg(&__vapi_metadata_ikev2_set_ike_transforms_reply);
  VAPI_DBG("Assigned msg id %d to ikev2_set_ike_transforms_reply", vapi_msg_id_ikev2_set_ike_transforms_reply);
}

static void __attribute__((constructor)) __vapi_constructor_ipsec_spd_add_del_reply()
{
  static const char name[] = "ipsec_spd_add_del_reply";
  static const char name_with_crc[] = "ipsec_spd_add_del_reply_c7439119";
  static vapi_message_desc_t __vapi_metadata_ipsec_spd_add_del_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_ipsec_spd_add_del_reply, payload),
    sizeof(vapi_msg_ipsec_spd_add_del_reply),
    (generic_swap_fn_t)vapi_msg_ipsec_spd_add_del_reply_hton,
    (generic_swap_fn_t)vapi_msg_ipsec_spd_add_del_reply_ntoh,
    ~0,
  };

  vapi_msg_id_ipsec_spd_add_del_reply = vapi_register_msg(&__vapi_metadata_ipsec_spd_add_del_reply);
  VAPI_DBG("Assigned msg id %d to ipsec_spd_add_del_reply", vapi_msg_id_ipsec_spd_add_del_reply);
}

static void __attribute__((constructor)) __vapi_constructor_ikev2_initiate_del_ike_sa()
{
  static const char name[] = "ikev2_initiate_del_ike_sa";
  static const char name_with_crc[] = "ikev2_initiate_del_ike_sa_2816f367";
  static vapi_message_desc_t __vapi_metadata_ikev2_initiate_del_ike_sa = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_ikev2_initiate_del_ike_sa, payload),
    sizeof(vapi_msg_ikev2_initiate_del_ike_sa),
    (generic_swap_fn_t)vapi_msg_ikev2_initiate_del_ike_sa_hton,
    (generic_swap_fn_t)vapi_msg_ikev2_initiate_del_ike_sa_ntoh,
    ~0,
  };

  vapi_msg_id_ikev2_initiate_del_ike_sa = vapi_register_msg(&__vapi_metadata_ikev2_initiate_del_ike_sa);
  VAPI_DBG("Assigned msg id %d to ikev2_initiate_del_ike_sa", vapi_msg_id_ikev2_initiate_del_ike_sa);
}

static void __attribute__((constructor)) __vapi_constructor_ikev2_initiate_rekey_child_sa_reply()
{
  static const char name[] = "ikev2_initiate_rekey_child_sa_reply";
  static const char name_with_crc[] = "ikev2_initiate_rekey_child_sa_reply_7e5a8a19";
  static vapi_message_desc_t __vapi_metadata_ikev2_initiate_rekey_child_sa_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_ikev2_initiate_rekey_child_sa_reply, payload),
    sizeof(vapi_msg_ikev2_initiate_rekey_child_sa_reply),
    (generic_swap_fn_t)vapi_msg_ikev2_initiate_rekey_child_sa_reply_hton,
    (generic_swap_fn_t)vapi_msg_ikev2_initiate_rekey_child_sa_reply_ntoh,
    ~0,
  };

  vapi_msg_id_ikev2_initiate_rekey_child_sa_reply = vapi_register_msg(&__vapi_metadata_ikev2_initiate_rekey_child_sa_reply);
  VAPI_DBG("Assigned msg id %d to ikev2_initiate_rekey_child_sa_reply", vapi_msg_id_ikev2_initiate_rekey_child_sa_reply);
}

static void __attribute__((constructor)) __vapi_constructor_ikev2_profile_add_del_reply()
{
  static const char name[] = "ikev2_profile_add_del_reply";
  static const char name_with_crc[] = "ikev2_profile_add_del_reply_7621f627";
  static vapi_message_desc_t __vapi_metadata_ikev2_profile_add_del_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_ikev2_profile_add_del_reply, payload),
    sizeof(vapi_msg_ikev2_profile_add_del_reply),
    (generic_swap_fn_t)vapi_msg_ikev2_profile_add_del_reply_hton,
    (generic_swap_fn_t)vapi_msg_ikev2_profile_add_del_reply_ntoh,
    ~0,
  };

  vapi_msg_id_ikev2_profile_add_del_reply = vapi_register_msg(&__vapi_metadata_ikev2_profile_add_del_reply);
  VAPI_DBG("Assigned msg id %d to ikev2_profile_add_del_reply", vapi_msg_id_ikev2_profile_add_del_reply);
}

static void __attribute__((constructor)) __vapi_constructor_ipsec_sad_add_del_entry_reply()
{
  static const char name[] = "ipsec_sad_add_del_entry_reply";
  static const char name_with_crc[] = "ipsec_sad_add_del_entry_reply_5cf382d8";
  static vapi_message_desc_t __vapi_metadata_ipsec_sad_add_del_entry_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_ipsec_sad_add_del_entry_reply, payload),
    sizeof(vapi_msg_ipsec_sad_add_del_entry_reply),
    (generic_swap_fn_t)vapi_msg_ipsec_sad_add_del_entry_reply_hton,
    (generic_swap_fn_t)vapi_msg_ipsec_sad_add_del_entry_reply_ntoh,
    ~0,
  };

  vapi_msg_id_ipsec_sad_add_del_entry_reply = vapi_register_msg(&__vapi_metadata_ipsec_sad_add_del_entry_reply);
  VAPI_DBG("Assigned msg id %d to ipsec_sad_add_del_entry_reply", vapi_msg_id_ipsec_sad_add_del_entry_reply);
}

static void __attribute__((constructor)) __vapi_constructor_ikev2_profile_add_del()
{
  static const char name[] = "ikev2_profile_add_del";
  static const char name_with_crc[] = "ikev2_profile_add_del_37b6925c";
  static vapi_message_desc_t __vapi_metadata_ikev2_profile_add_del = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_ikev2_profile_add_del, payload),
    sizeof(vapi_msg_ikev2_profile_add_del),
    (generic_swap_fn_t)vapi_msg_ikev2_profile_add_del_hton,
    (generic_swap_fn_t)vapi_msg_ikev2_profile_add_del_ntoh,
    ~0,
  };

  vapi_msg_id_ikev2_profile_add_del = vapi_register_msg(&__vapi_metadata_ikev2_profile_add_del);
  VAPI_DBG("Assigned msg id %d to ikev2_profile_add_del", vapi_msg_id_ikev2_profile_add_del);
}

static void __attribute__((constructor)) __vapi_constructor_ikev2_initiate_sa_init()
{
  static const char name[] = "ikev2_initiate_sa_init";
  static const char name_with_crc[] = "ikev2_initiate_sa_init_991b95f7";
  static vapi_message_desc_t __vapi_metadata_ikev2_initiate_sa_init = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_ikev2_initiate_sa_init, payload),
    sizeof(vapi_msg_ikev2_initiate_sa_init),
    (generic_swap_fn_t)vapi_msg_ikev2_initiate_sa_init_hton,
    (generic_swap_fn_t)vapi_msg_ikev2_initiate_sa_init_ntoh,
    ~0,
  };

  vapi_msg_id_ikev2_initiate_sa_init = vapi_register_msg(&__vapi_metadata_ikev2_initiate_sa_init);
  VAPI_DBG("Assigned msg id %d to ikev2_initiate_sa_init", vapi_msg_id_ikev2_initiate_sa_init);
}

static void __attribute__((constructor)) __vapi_constructor_ipsec_sa_set_key()
{
  static const char name[] = "ipsec_sa_set_key";
  static const char name_with_crc[] = "ipsec_sa_set_key_99a67c60";
  static vapi_message_desc_t __vapi_metadata_ipsec_sa_set_key = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_ipsec_sa_set_key, payload),
    sizeof(vapi_msg_ipsec_sa_set_key),
    (generic_swap_fn_t)vapi_msg_ipsec_sa_set_key_hton,
    (generic_swap_fn_t)vapi_msg_ipsec_sa_set_key_ntoh,
    ~0,
  };

  vapi_msg_id_ipsec_sa_set_key = vapi_register_msg(&__vapi_metadata_ipsec_sa_set_key);
  VAPI_DBG("Assigned msg id %d to ipsec_sa_set_key", vapi_msg_id_ipsec_sa_set_key);
}

static void __attribute__((constructor)) __vapi_constructor_ipsec_tunnel_if_add_del_reply()
{
  static const char name[] = "ipsec_tunnel_if_add_del_reply";
  static const char name_with_crc[] = "ipsec_tunnel_if_add_del_reply_bf5ebd7c";
  static vapi_message_desc_t __vapi_metadata_ipsec_tunnel_if_add_del_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_ipsec_tunnel_if_add_del_reply, payload),
    sizeof(vapi_msg_ipsec_tunnel_if_add_del_reply),
    (generic_swap_fn_t)vapi_msg_ipsec_tunnel_if_add_del_reply_hton,
    (generic_swap_fn_t)vapi_msg_ipsec_tunnel_if_add_del_reply_ntoh,
    ~0,
  };

  vapi_msg_id_ipsec_tunnel_if_add_del_reply = vapi_register_msg(&__vapi_metadata_ipsec_tunnel_if_add_del_reply);
  VAPI_DBG("Assigned msg id %d to ipsec_tunnel_if_add_del_reply", vapi_msg_id_ipsec_tunnel_if_add_del_reply);
}

static void __attribute__((constructor)) __vapi_constructor_ikev2_set_sa_lifetime()
{
  static const char name[] = "ikev2_set_sa_lifetime";
  static const char name_with_crc[] = "ikev2_set_sa_lifetime_61b715bf";
  static vapi_message_desc_t __vapi_metadata_ikev2_set_sa_lifetime = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_ikev2_set_sa_lifetime, payload),
    sizeof(vapi_msg_ikev2_set_sa_lifetime),
    (generic_swap_fn_t)vapi_msg_ikev2_set_sa_lifetime_hton,
    (generic_swap_fn_t)vapi_msg_ikev2_set_sa_lifetime_ntoh,
    ~0,
  };

  vapi_msg_id_ikev2_set_sa_lifetime = vapi_register_msg(&__vapi_metadata_ikev2_set_sa_lifetime);
  VAPI_DBG("Assigned msg id %d to ikev2_set_sa_lifetime", vapi_msg_id_ikev2_set_sa_lifetime);
}

static void __attribute__((constructor)) __vapi_constructor_ikev2_initiate_rekey_child_sa()
{
  static const char name[] = "ikev2_initiate_rekey_child_sa";
  static const char name_with_crc[] = "ikev2_initiate_rekey_child_sa_48a0ad23";
  static vapi_message_desc_t __vapi_metadata_ikev2_initiate_rekey_child_sa = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_ikev2_initiate_rekey_child_sa, payload),
    sizeof(vapi_msg_ikev2_initiate_rekey_child_sa),
    (generic_swap_fn_t)vapi_msg_ikev2_initiate_rekey_child_sa_hton,
    (generic_swap_fn_t)vapi_msg_ikev2_initiate_rekey_child_sa_ntoh,
    ~0,
  };

  vapi_msg_id_ikev2_initiate_rekey_child_sa = vapi_register_msg(&__vapi_metadata_ikev2_initiate_rekey_child_sa);
  VAPI_DBG("Assigned msg id %d to ikev2_initiate_rekey_child_sa", vapi_msg_id_ikev2_initiate_rekey_child_sa);
}

static void __attribute__((constructor)) __vapi_constructor_ikev2_set_sa_lifetime_reply()
{
  static const char name[] = "ikev2_set_sa_lifetime_reply";
  static const char name_with_crc[] = "ikev2_set_sa_lifetime_reply_7f73b9e3";
  static vapi_message_desc_t __vapi_metadata_ikev2_set_sa_lifetime_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_ikev2_set_sa_lifetime_reply, payload),
    sizeof(vapi_msg_ikev2_set_sa_lifetime_reply),
    (generic_swap_fn_t)vapi_msg_ikev2_set_sa_lifetime_reply_hton,
    (generic_swap_fn_t)vapi_msg_ikev2_set_sa_lifetime_reply_ntoh,
    ~0,
  };

  vapi_msg_id_ikev2_set_sa_lifetime_reply = vapi_register_msg(&__vapi_metadata_ikev2_set_sa_lifetime_reply);
  VAPI_DBG("Assigned msg id %d to ikev2_set_sa_lifetime_reply", vapi_msg_id_ikev2_set_sa_lifetime_reply);
}

static void __attribute__((constructor)) __vapi_constructor_ipsec_sad_add_del_entry()
{
  static const char name[] = "ipsec_sad_add_del_entry";
  static const char name_with_crc[] = "ipsec_sad_add_del_entry_7d6709e1";
  static vapi_message_desc_t __vapi_metadata_ipsec_sad_add_del_entry = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_ipsec_sad_add_del_entry, payload),
    sizeof(vapi_msg_ipsec_sad_add_del_entry),
    (generic_swap_fn_t)vapi_msg_ipsec_sad_add_del_entry_hton,
    (generic_swap_fn_t)vapi_msg_ipsec_sad_add_del_entry_ntoh,
    ~0,
  };

  vapi_msg_id_ipsec_sad_add_del_entry = vapi_register_msg(&__vapi_metadata_ipsec_sad_add_del_entry);
  VAPI_DBG("Assigned msg id %d to ipsec_sad_add_del_entry", vapi_msg_id_ipsec_sad_add_del_entry);
}

static void __attribute__((constructor)) __vapi_constructor_ipsec_interface_add_del_spd_reply()
{
  static const char name[] = "ipsec_interface_add_del_spd_reply";
  static const char name_with_crc[] = "ipsec_interface_add_del_spd_reply_977b7be9";
  static vapi_message_desc_t __vapi_metadata_ipsec_interface_add_del_spd_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_ipsec_interface_add_del_spd_reply, payload),
    sizeof(vapi_msg_ipsec_interface_add_del_spd_reply),
    (generic_swap_fn_t)vapi_msg_ipsec_interface_add_del_spd_reply_hton,
    (generic_swap_fn_t)vapi_msg_ipsec_interface_add_del_spd_reply_ntoh,
    ~0,
  };

  vapi_msg_id_ipsec_interface_add_del_spd_reply = vapi_register_msg(&__vapi_metadata_ipsec_interface_add_del_spd_reply);
  VAPI_DBG("Assigned msg id %d to ipsec_interface_add_del_spd_reply", vapi_msg_id_ipsec_interface_add_del_spd_reply);
}

static void __attribute__((constructor)) __vapi_constructor_ipsec_spd_add_del_entry_reply()
{
  static const char name[] = "ipsec_spd_add_del_entry_reply";
  static const char name_with_crc[] = "ipsec_spd_add_del_entry_reply_f96c8b2d";
  static vapi_message_desc_t __vapi_metadata_ipsec_spd_add_del_entry_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_ipsec_spd_add_del_entry_reply, payload),
    sizeof(vapi_msg_ipsec_spd_add_del_entry_reply),
    (generic_swap_fn_t)vapi_msg_ipsec_spd_add_del_entry_reply_hton,
    (generic_swap_fn_t)vapi_msg_ipsec_spd_add_del_entry_reply_ntoh,
    ~0,
  };

  vapi_msg_id_ipsec_spd_add_del_entry_reply = vapi_register_msg(&__vapi_metadata_ipsec_spd_add_del_entry_reply);
  VAPI_DBG("Assigned msg id %d to ipsec_spd_add_del_entry_reply", vapi_msg_id_ipsec_spd_add_del_entry_reply);
}

static void __attribute__((constructor)) __vapi_constructor_ikev2_initiate_del_child_sa_reply()
{
  static const char name[] = "ikev2_initiate_del_child_sa_reply";
  static const char name_with_crc[] = "ikev2_initiate_del_child_sa_reply_b31728ac";
  static vapi_message_desc_t __vapi_metadata_ikev2_initiate_del_child_sa_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_ikev2_initiate_del_child_sa_reply, payload),
    sizeof(vapi_msg_ikev2_initiate_del_child_sa_reply),
    (generic_swap_fn_t)vapi_msg_ikev2_initiate_del_child_sa_reply_hton,
    (generic_swap_fn_t)vapi_msg_ikev2_initiate_del_child_sa_reply_ntoh,
    ~0,
  };

  vapi_msg_id_ikev2_initiate_del_child_sa_reply = vapi_register_msg(&__vapi_metadata_ikev2_initiate_del_child_sa_reply);
  VAPI_DBG("Assigned msg id %d to ikev2_initiate_del_child_sa_reply", vapi_msg_id_ikev2_initiate_del_child_sa_reply);
}

static void __attribute__((constructor)) __vapi_constructor_ikev2_initiate_del_ike_sa_reply()
{
  static const char name[] = "ikev2_initiate_del_ike_sa_reply";
  static const char name_with_crc[] = "ikev2_initiate_del_ike_sa_reply_a5df9a20";
  static vapi_message_desc_t __vapi_metadata_ikev2_initiate_del_ike_sa_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_ikev2_initiate_del_ike_sa_reply, payload),
    sizeof(vapi_msg_ikev2_initiate_del_ike_sa_reply),
    (generic_swap_fn_t)vapi_msg_ikev2_initiate_del_ike_sa_reply_hton,
    (generic_swap_fn_t)vapi_msg_ikev2_initiate_del_ike_sa_reply_ntoh,
    ~0,
  };

  vapi_msg_id_ikev2_initiate_del_ike_sa_reply = vapi_register_msg(&__vapi_metadata_ikev2_initiate_del_ike_sa_reply);
  VAPI_DBG("Assigned msg id %d to ikev2_initiate_del_ike_sa_reply", vapi_msg_id_ikev2_initiate_del_ike_sa_reply);
}

static void __attribute__((constructor)) __vapi_constructor_ipsec_spd_details()
{
  static const char name[] = "ipsec_spd_details";
  static const char name_with_crc[] = "ipsec_spd_details_6f7821b0";
  static vapi_message_desc_t __vapi_metadata_ipsec_spd_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_ipsec_spd_details, payload),
    sizeof(vapi_msg_ipsec_spd_details),
    (generic_swap_fn_t)vapi_msg_ipsec_spd_details_hton,
    (generic_swap_fn_t)vapi_msg_ipsec_spd_details_ntoh,
    ~0,
  };

  vapi_msg_id_ipsec_spd_details = vapi_register_msg(&__vapi_metadata_ipsec_spd_details);
  VAPI_DBG("Assigned msg id %d to ipsec_spd_details", vapi_msg_id_ipsec_spd_details);
}

static void __attribute__((constructor)) __vapi_constructor_ipsec_spd_dump()
{
  static const char name[] = "ipsec_spd_dump";
  static const char name_with_crc[] = "ipsec_spd_dump_5e9ae88e";
  static vapi_message_desc_t __vapi_metadata_ipsec_spd_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_ipsec_spd_dump, payload),
    sizeof(vapi_msg_ipsec_spd_dump),
    (generic_swap_fn_t)vapi_msg_ipsec_spd_dump_hton,
    (generic_swap_fn_t)vapi_msg_ipsec_spd_dump_ntoh,
    ~0,
  };

  vapi_msg_id_ipsec_spd_dump = vapi_register_msg(&__vapi_metadata_ipsec_spd_dump);
  VAPI_DBG("Assigned msg id %d to ipsec_spd_dump", vapi_msg_id_ipsec_spd_dump);
}

static void __attribute__((constructor)) __vapi_constructor_ikev2_set_ike_transforms()
{
  static const char name[] = "ikev2_set_ike_transforms";
  static const char name_with_crc[] = "ikev2_set_ike_transforms_f0bf018e";
  static vapi_message_desc_t __vapi_metadata_ikev2_set_ike_transforms = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_ikev2_set_ike_transforms, payload),
    sizeof(vapi_msg_ikev2_set_ike_transforms),
    (generic_swap_fn_t)vapi_msg_ikev2_set_ike_transforms_hton,
    (generic_swap_fn_t)vapi_msg_ikev2_set_ike_transforms_ntoh,
    ~0,
  };

  vapi_msg_id_ikev2_set_ike_transforms = vapi_register_msg(&__vapi_metadata_ikev2_set_ike_transforms);
  VAPI_DBG("Assigned msg id %d to ikev2_set_ike_transforms", vapi_msg_id_ikev2_set_ike_transforms);
}

static void __attribute__((constructor)) __vapi_constructor_ikev2_set_esp_transforms()
{
  static const char name[] = "ikev2_set_esp_transforms";
  static const char name_with_crc[] = "ikev2_set_esp_transforms_dadd693a";
  static vapi_message_desc_t __vapi_metadata_ikev2_set_esp_transforms = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_ikev2_set_esp_transforms, payload),
    sizeof(vapi_msg_ikev2_set_esp_transforms),
    (generic_swap_fn_t)vapi_msg_ikev2_set_esp_transforms_hton,
    (generic_swap_fn_t)vapi_msg_ikev2_set_esp_transforms_ntoh,
    ~0,
  };

  vapi_msg_id_ikev2_set_esp_transforms = vapi_register_msg(&__vapi_metadata_ikev2_set_esp_transforms);
  VAPI_DBG("Assigned msg id %d to ikev2_set_esp_transforms", vapi_msg_id_ikev2_set_esp_transforms);
}

static void __attribute__((constructor)) __vapi_constructor_ipsec_spd_add_del_entry()
{
  static const char name[] = "ipsec_spd_add_del_entry";
  static const char name_with_crc[] = "ipsec_spd_add_del_entry_d85e0ed5";
  static vapi_message_desc_t __vapi_metadata_ipsec_spd_add_del_entry = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_ipsec_spd_add_del_entry, payload),
    sizeof(vapi_msg_ipsec_spd_add_del_entry),
    (generic_swap_fn_t)vapi_msg_ipsec_spd_add_del_entry_hton,
    (generic_swap_fn_t)vapi_msg_ipsec_spd_add_del_entry_ntoh,
    ~0,
  };

  vapi_msg_id_ipsec_spd_add_del_entry = vapi_register_msg(&__vapi_metadata_ipsec_spd_add_del_entry);
  VAPI_DBG("Assigned msg id %d to ipsec_spd_add_del_entry", vapi_msg_id_ipsec_spd_add_del_entry);
}

static void __attribute__((constructor)) __vapi_constructor_ikev2_set_local_key_reply()
{
  static const char name[] = "ikev2_set_local_key_reply";
  static const char name_with_crc[] = "ikev2_set_local_key_reply_8f7a80e0";
  static vapi_message_desc_t __vapi_metadata_ikev2_set_local_key_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_ikev2_set_local_key_reply, payload),
    sizeof(vapi_msg_ikev2_set_local_key_reply),
    (generic_swap_fn_t)vapi_msg_ikev2_set_local_key_reply_hton,
    (generic_swap_fn_t)vapi_msg_ikev2_set_local_key_reply_ntoh,
    ~0,
  };

  vapi_msg_id_ikev2_set_local_key_reply = vapi_register_msg(&__vapi_metadata_ikev2_set_local_key_reply);
  VAPI_DBG("Assigned msg id %d to ikev2_set_local_key_reply", vapi_msg_id_ikev2_set_local_key_reply);
}

static void __attribute__((constructor)) __vapi_constructor_ikev2_initiate_del_child_sa()
{
  static const char name[] = "ikev2_initiate_del_child_sa";
  static const char name_with_crc[] = "ikev2_initiate_del_child_sa_26eaba1d";
  static vapi_message_desc_t __vapi_metadata_ikev2_initiate_del_child_sa = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_ikev2_initiate_del_child_sa, payload),
    sizeof(vapi_msg_ikev2_initiate_del_child_sa),
    (generic_swap_fn_t)vapi_msg_ikev2_initiate_del_child_sa_hton,
    (generic_swap_fn_t)vapi_msg_ikev2_initiate_del_child_sa_ntoh,
    ~0,
  };

  vapi_msg_id_ikev2_initiate_del_child_sa = vapi_register_msg(&__vapi_metadata_ikev2_initiate_del_child_sa);
  VAPI_DBG("Assigned msg id %d to ikev2_initiate_del_child_sa", vapi_msg_id_ikev2_initiate_del_child_sa);
}

static void __attribute__((constructor)) __vapi_constructor_ikev2_set_local_key()
{
  static const char name[] = "ikev2_set_local_key";
  static const char name_with_crc[] = "ikev2_set_local_key_a99b238a";
  static vapi_message_desc_t __vapi_metadata_ikev2_set_local_key = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_ikev2_set_local_key, payload),
    sizeof(vapi_msg_ikev2_set_local_key),
    (generic_swap_fn_t)vapi_msg_ikev2_set_local_key_hton,
    (generic_swap_fn_t)vapi_msg_ikev2_set_local_key_ntoh,
    ~0,
  };

  vapi_msg_id_ikev2_set_local_key = vapi_register_msg(&__vapi_metadata_ikev2_set_local_key);
  VAPI_DBG("Assigned msg id %d to ikev2_set_local_key", vapi_msg_id_ikev2_set_local_key);
}

static void __attribute__((constructor)) __vapi_constructor_ipsec_tunnel_if_add_del()
{
  static const char name[] = "ipsec_tunnel_if_add_del";
  static const char name_with_crc[] = "ipsec_tunnel_if_add_del_8218980f";
  static vapi_message_desc_t __vapi_metadata_ipsec_tunnel_if_add_del = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_ipsec_tunnel_if_add_del, payload),
    sizeof(vapi_msg_ipsec_tunnel_if_add_del),
    (generic_swap_fn_t)vapi_msg_ipsec_tunnel_if_add_del_hton,
    (generic_swap_fn_t)vapi_msg_ipsec_tunnel_if_add_del_ntoh,
    ~0,
  };

  vapi_msg_id_ipsec_tunnel_if_add_del = vapi_register_msg(&__vapi_metadata_ipsec_tunnel_if_add_del);
  VAPI_DBG("Assigned msg id %d to ipsec_tunnel_if_add_del", vapi_msg_id_ipsec_tunnel_if_add_del);
}

static void __attribute__((constructor)) __vapi_constructor_ikev2_initiate_sa_init_reply()
{
  static const char name[] = "ikev2_initiate_sa_init_reply";
  static const char name_with_crc[] = "ikev2_initiate_sa_init_reply_66860cf0";
  static vapi_message_desc_t __vapi_metadata_ikev2_initiate_sa_init_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_ikev2_initiate_sa_init_reply, payload),
    sizeof(vapi_msg_ikev2_initiate_sa_init_reply),
    (generic_swap_fn_t)vapi_msg_ikev2_initiate_sa_init_reply_hton,
    (generic_swap_fn_t)vapi_msg_ikev2_initiate_sa_init_reply_ntoh,
    ~0,
  };

  vapi_msg_id_ikev2_initiate_sa_init_reply = vapi_register_msg(&__vapi_metadata_ikev2_initiate_sa_init_reply);
  VAPI_DBG("Assigned msg id %d to ikev2_initiate_sa_init_reply", vapi_msg_id_ikev2_initiate_sa_init_reply);
}

static void __attribute__((constructor)) __vapi_constructor_ikev2_profile_set_id_reply()
{
  static const char name[] = "ikev2_profile_set_id_reply";
  static const char name_with_crc[] = "ikev2_profile_set_id_reply_66803be5";
  static vapi_message_desc_t __vapi_metadata_ikev2_profile_set_id_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_ikev2_profile_set_id_reply, payload),
    sizeof(vapi_msg_ikev2_profile_set_id_reply),
    (generic_swap_fn_t)vapi_msg_ikev2_profile_set_id_reply_hton,
    (generic_swap_fn_t)vapi_msg_ikev2_profile_set_id_reply_ntoh,
    ~0,
  };

  vapi_msg_id_ikev2_profile_set_id_reply = vapi_register_msg(&__vapi_metadata_ikev2_profile_set_id_reply);
  VAPI_DBG("Assigned msg id %d to ikev2_profile_set_id_reply", vapi_msg_id_ikev2_profile_set_id_reply);
}

static void __attribute__((constructor)) __vapi_constructor_ikev2_profile_set_ts_reply()
{
  static const char name[] = "ikev2_profile_set_ts_reply";
  static const char name_with_crc[] = "ikev2_profile_set_ts_reply_e1c33583";
  static vapi_message_desc_t __vapi_metadata_ikev2_profile_set_ts_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_ikev2_profile_set_ts_reply, payload),
    sizeof(vapi_msg_ikev2_profile_set_ts_reply),
    (generic_swap_fn_t)vapi_msg_ikev2_profile_set_ts_reply_hton,
    (generic_swap_fn_t)vapi_msg_ikev2_profile_set_ts_reply_ntoh,
    ~0,
  };

  vapi_msg_id_ikev2_profile_set_ts_reply = vapi_register_msg(&__vapi_metadata_ikev2_profile_set_ts_reply);
  VAPI_DBG("Assigned msg id %d to ikev2_profile_set_ts_reply", vapi_msg_id_ikev2_profile_set_ts_reply);
}

static void __attribute__((constructor)) __vapi_constructor_ikev2_profile_set_auth_reply()
{
  static const char name[] = "ikev2_profile_set_auth_reply";
  static const char name_with_crc[] = "ikev2_profile_set_auth_reply_46083d00";
  static vapi_message_desc_t __vapi_metadata_ikev2_profile_set_auth_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_ikev2_profile_set_auth_reply, payload),
    sizeof(vapi_msg_ikev2_profile_set_auth_reply),
    (generic_swap_fn_t)vapi_msg_ikev2_profile_set_auth_reply_hton,
    (generic_swap_fn_t)vapi_msg_ikev2_profile_set_auth_reply_ntoh,
    ~0,
  };

  vapi_msg_id_ikev2_profile_set_auth_reply = vapi_register_msg(&__vapi_metadata_ikev2_profile_set_auth_reply);
  VAPI_DBG("Assigned msg id %d to ikev2_profile_set_auth_reply", vapi_msg_id_ikev2_profile_set_auth_reply);
}


static inline void vapi_set_vapi_msg_ipsec_sa_set_key_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ipsec_sa_set_key_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ipsec_sa_set_key_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ikev2_set_responder_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ikev2_set_responder_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ikev2_set_responder_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ikev2_set_esp_transforms_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ikev2_set_esp_transforms_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ikev2_set_esp_transforms_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ikev2_set_ike_transforms_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ikev2_set_ike_transforms_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ikev2_set_ike_transforms_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ipsec_spd_add_del_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ipsec_spd_add_del_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ipsec_spd_add_del_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ikev2_initiate_rekey_child_sa_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ikev2_initiate_rekey_child_sa_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ikev2_initiate_rekey_child_sa_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ikev2_profile_add_del_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ikev2_profile_add_del_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ikev2_profile_add_del_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ipsec_sad_add_del_entry_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ipsec_sad_add_del_entry_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ipsec_sad_add_del_entry_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ipsec_tunnel_if_add_del_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ipsec_tunnel_if_add_del_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ipsec_tunnel_if_add_del_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ikev2_set_sa_lifetime_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ikev2_set_sa_lifetime_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ikev2_set_sa_lifetime_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ipsec_interface_add_del_spd_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ipsec_interface_add_del_spd_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ipsec_interface_add_del_spd_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ipsec_spd_add_del_entry_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ipsec_spd_add_del_entry_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ipsec_spd_add_del_entry_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ikev2_initiate_del_child_sa_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ikev2_initiate_del_child_sa_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ikev2_initiate_del_child_sa_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ikev2_initiate_del_ike_sa_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ikev2_initiate_del_ike_sa_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ikev2_initiate_del_ike_sa_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ipsec_spd_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ipsec_spd_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ipsec_spd_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ikev2_set_local_key_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ikev2_set_local_key_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ikev2_set_local_key_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ikev2_initiate_sa_init_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ikev2_initiate_sa_init_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ikev2_initiate_sa_init_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ikev2_profile_set_id_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ikev2_profile_set_id_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ikev2_profile_set_id_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ikev2_profile_set_ts_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ikev2_profile_set_ts_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ikev2_profile_set_ts_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ikev2_profile_set_auth_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ikev2_profile_set_auth_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ikev2_profile_set_auth_reply, (vapi_event_cb)callback, callback_ctx);
};


#ifdef __cplusplus
}
#endif

#endif
