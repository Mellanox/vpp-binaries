#ifndef __included_hpp_memclnt_api_json
#define __included_hpp_memclnt_api_json

#include <vapi/vapi.hpp>
#include <vapi/memclnt.api.vapi.h>

namespace vapi {

template <> inline void vapi_swap_to_be<vapi_msg_get_first_msg_id>(vapi_msg_get_first_msg_id *msg)
{
  vapi_msg_get_first_msg_id_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_get_first_msg_id>(vapi_msg_get_first_msg_id *msg)
{
  vapi_msg_get_first_msg_id_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_get_first_msg_id>()
{
  return ::vapi_msg_id_get_first_msg_id; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_get_first_msg_id>>()
{
  return ::vapi_msg_id_get_first_msg_id; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_get_first_msg_id()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_get_first_msg_id>(vapi_msg_id_get_first_msg_id);
}

template <> inline vapi_msg_get_first_msg_id* vapi_alloc<vapi_msg_get_first_msg_id>(Connection &con)
{
  vapi_msg_get_first_msg_id* result = vapi_alloc_get_first_msg_id(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_get_first_msg_id>;

template class Request<vapi_msg_get_first_msg_id, vapi_msg_get_first_msg_id_reply>;

using Get_first_msg_id = Request<vapi_msg_get_first_msg_id, vapi_msg_get_first_msg_id_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_get_first_msg_id_reply>(vapi_msg_get_first_msg_id_reply *msg)
{
  vapi_msg_get_first_msg_id_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_get_first_msg_id_reply>(vapi_msg_get_first_msg_id_reply *msg)
{
  vapi_msg_get_first_msg_id_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_get_first_msg_id_reply>()
{
  return ::vapi_msg_id_get_first_msg_id_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_get_first_msg_id_reply>>()
{
  return ::vapi_msg_id_get_first_msg_id_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_get_first_msg_id_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_get_first_msg_id_reply>(vapi_msg_id_get_first_msg_id_reply);
}

template class Msg<vapi_msg_get_first_msg_id_reply>;

using Get_first_msg_id_reply = Msg<vapi_msg_get_first_msg_id_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_memclnt_delete_reply>(vapi_msg_memclnt_delete_reply *msg)
{
  vapi_msg_memclnt_delete_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_memclnt_delete_reply>(vapi_msg_memclnt_delete_reply *msg)
{
  vapi_msg_memclnt_delete_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_memclnt_delete_reply>()
{
  return ::vapi_msg_id_memclnt_delete_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_memclnt_delete_reply>>()
{
  return ::vapi_msg_id_memclnt_delete_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_memclnt_delete_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_memclnt_delete_reply>(vapi_msg_id_memclnt_delete_reply);
}

template class Msg<vapi_msg_memclnt_delete_reply>;

using Memclnt_delete_reply = Msg<vapi_msg_memclnt_delete_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_memclnt_create_reply>(vapi_msg_memclnt_create_reply *msg)
{
  vapi_msg_memclnt_create_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_memclnt_create_reply>(vapi_msg_memclnt_create_reply *msg)
{
  vapi_msg_memclnt_create_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_memclnt_create_reply>()
{
  return ::vapi_msg_id_memclnt_create_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_memclnt_create_reply>>()
{
  return ::vapi_msg_id_memclnt_create_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_memclnt_create_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_memclnt_create_reply>(vapi_msg_id_memclnt_create_reply);
}

template class Msg<vapi_msg_memclnt_create_reply>;

using Memclnt_create_reply = Msg<vapi_msg_memclnt_create_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_rpc_call_reply>(vapi_msg_rpc_call_reply *msg)
{
  vapi_msg_rpc_call_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_rpc_call_reply>(vapi_msg_rpc_call_reply *msg)
{
  vapi_msg_rpc_call_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_rpc_call_reply>()
{
  return ::vapi_msg_id_rpc_call_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_rpc_call_reply>>()
{
  return ::vapi_msg_id_rpc_call_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_rpc_call_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_rpc_call_reply>(vapi_msg_id_rpc_call_reply);
}

template class Msg<vapi_msg_rpc_call_reply>;

using Rpc_call_reply = Msg<vapi_msg_rpc_call_reply>;
}
#endif
