#ifndef __included_nat_api_json
#define __included_nat_api_json

#include <stdlib.h>
#include <stddef.h>
#include <arpa/inet.h>
#include <vapi/vapi_internal.h>
#include <vapi/vapi.h>
#include <vapi/vapi_dbg.h>

#ifdef __cplusplus
extern "C" {
#endif
#include <vapi/vpe.api.vapi.h>

extern vapi_msg_id_t vapi_msg_id_snat_interface_add_del_feature;
extern vapi_msg_id_t vapi_msg_id_snat_control_ping;
extern vapi_msg_id_t vapi_msg_id_nat_ipfix_enable_disable;
extern vapi_msg_id_t vapi_msg_id_snat_static_mapping_details;
extern vapi_msg_id_t vapi_msg_id_nat_control_ping_reply;
extern vapi_msg_id_t vapi_msg_id_snat_interface_output_feature_details;
extern vapi_msg_id_t vapi_msg_id_nat44_lb_static_mapping_dump;
extern vapi_msg_id_t vapi_msg_id_nat64_pool_addr_dump;
extern vapi_msg_id_t vapi_msg_id_snat_user_session_dump;
extern vapi_msg_id_t vapi_msg_id_nat64_interface_dump;
extern vapi_msg_id_t vapi_msg_id_nat_det_add_del_map;
extern vapi_msg_id_t vapi_msg_id_snat_interface_add_del_feature_reply;
extern vapi_msg_id_t vapi_msg_id_nat64_prefix_details;
extern vapi_msg_id_t vapi_msg_id_snat_ipfix_enable_disable;
extern vapi_msg_id_t vapi_msg_id_nat_det_get_timeouts_reply;
extern vapi_msg_id_t vapi_msg_id_nat_det_reverse_reply;
extern vapi_msg_id_t vapi_msg_id_nat44_user_dump;
extern vapi_msg_id_t vapi_msg_id_snat_det_set_timeouts;
extern vapi_msg_id_t vapi_msg_id_nat44_static_mapping_details;
extern vapi_msg_id_t vapi_msg_id_nat64_add_del_prefix_reply;
extern vapi_msg_id_t vapi_msg_id_nat64_st_details;
extern vapi_msg_id_t vapi_msg_id_snat_show_config_reply;
extern vapi_msg_id_t vapi_msg_id_snat_add_static_mapping;
extern vapi_msg_id_t vapi_msg_id_nat_control_ping;
extern vapi_msg_id_t vapi_msg_id_nat44_interface_add_del_output_feature_reply;
extern vapi_msg_id_t vapi_msg_id_snat_add_static_mapping_reply;
extern vapi_msg_id_t vapi_msg_id_nat64_add_del_interface;
extern vapi_msg_id_t vapi_msg_id_nat_det_close_session_in;
extern vapi_msg_id_t vapi_msg_id_nat44_user_session_dump;
extern vapi_msg_id_t vapi_msg_id_nat44_static_mapping_dump;
extern vapi_msg_id_t vapi_msg_id_snat_worker_details;
extern vapi_msg_id_t vapi_msg_id_snat_det_map_dump;
extern vapi_msg_id_t vapi_msg_id_nat64_set_timeouts_reply;
extern vapi_msg_id_t vapi_msg_id_nat44_user_session_details;
extern vapi_msg_id_t vapi_msg_id_snat_add_del_interface_addr;
extern vapi_msg_id_t vapi_msg_id_snat_ipfix_enable_disable_reply;
extern vapi_msg_id_t vapi_msg_id_snat_address_dump;
extern vapi_msg_id_t vapi_msg_id_snat_set_workers;
extern vapi_msg_id_t vapi_msg_id_nat44_interface_output_feature_dump;
extern vapi_msg_id_t vapi_msg_id_nat44_interface_add_del_feature;
extern vapi_msg_id_t vapi_msg_id_nat44_interface_output_feature_details;
extern vapi_msg_id_t vapi_msg_id_nat_det_reverse;
extern vapi_msg_id_t vapi_msg_id_nat_det_session_details;
extern vapi_msg_id_t vapi_msg_id_snat_interface_add_del_output_feature_reply;
extern vapi_msg_id_t vapi_msg_id_nat44_interface_add_del_feature_reply;
extern vapi_msg_id_t vapi_msg_id_nat44_add_del_address_range_reply;
extern vapi_msg_id_t vapi_msg_id_nat64_add_del_interface_reply;
extern vapi_msg_id_t vapi_msg_id_nat_det_forward;
extern vapi_msg_id_t vapi_msg_id_nat_worker_dump;
extern vapi_msg_id_t vapi_msg_id_snat_interface_addr_dump;
extern vapi_msg_id_t vapi_msg_id_nat_det_get_timeouts;
extern vapi_msg_id_t vapi_msg_id_nat_det_add_del_map_reply;
extern vapi_msg_id_t vapi_msg_id_nat44_interface_addr_dump;
extern vapi_msg_id_t vapi_msg_id_nat_show_config_reply;
extern vapi_msg_id_t vapi_msg_id_nat44_add_del_lb_static_mapping_reply;
extern vapi_msg_id_t vapi_msg_id_snat_det_get_timeouts_reply;
extern vapi_msg_id_t vapi_msg_id_snat_user_details;
extern vapi_msg_id_t vapi_msg_id_snat_det_close_session_in_reply;
extern vapi_msg_id_t vapi_msg_id_nat64_add_del_static_bib_reply;
extern vapi_msg_id_t vapi_msg_id_nat44_address_details;
extern vapi_msg_id_t vapi_msg_id_nat44_add_del_lb_static_mapping;
extern vapi_msg_id_t vapi_msg_id_nat_det_set_timeouts;
extern vapi_msg_id_t vapi_msg_id_snat_user_dump;
extern vapi_msg_id_t vapi_msg_id_snat_add_del_interface_addr_reply;
extern vapi_msg_id_t vapi_msg_id_snat_set_workers_reply;
extern vapi_msg_id_t vapi_msg_id_snat_det_forward_reply;
extern vapi_msg_id_t vapi_msg_id_nat_det_close_session_out;
extern vapi_msg_id_t vapi_msg_id_snat_det_reverse_reply;
extern vapi_msg_id_t vapi_msg_id_nat_det_session_dump;
extern vapi_msg_id_t vapi_msg_id_nat44_user_details;
extern vapi_msg_id_t vapi_msg_id_nat_det_forward_reply;
extern vapi_msg_id_t vapi_msg_id_nat64_set_timeouts;
extern vapi_msg_id_t vapi_msg_id_nat44_interface_addr_details;
extern vapi_msg_id_t vapi_msg_id_snat_address_details;
extern vapi_msg_id_t vapi_msg_id_nat64_add_del_pool_addr_range_reply;
extern vapi_msg_id_t vapi_msg_id_snat_det_session_dump;
extern vapi_msg_id_t vapi_msg_id_nat64_get_timeouts;
extern vapi_msg_id_t vapi_msg_id_snat_add_det_map;
extern vapi_msg_id_t vapi_msg_id_nat_det_close_session_out_reply;
extern vapi_msg_id_t vapi_msg_id_nat_show_config;
extern vapi_msg_id_t vapi_msg_id_snat_det_session_details;
extern vapi_msg_id_t vapi_msg_id_nat44_address_dump;
extern vapi_msg_id_t vapi_msg_id_snat_det_forward;
extern vapi_msg_id_t vapi_msg_id_nat44_interface_dump;
extern vapi_msg_id_t vapi_msg_id_nat64_interface_details;
extern vapi_msg_id_t vapi_msg_id_nat64_bib_dump;
extern vapi_msg_id_t vapi_msg_id_nat64_add_del_pool_addr_range;
extern vapi_msg_id_t vapi_msg_id_nat64_bib_details;
extern vapi_msg_id_t vapi_msg_id_nat64_get_timeouts_reply;
extern vapi_msg_id_t vapi_msg_id_nat64_prefix_dump;
extern vapi_msg_id_t vapi_msg_id_nat_det_map_dump;
extern vapi_msg_id_t vapi_msg_id_snat_interface_addr_details;
extern vapi_msg_id_t vapi_msg_id_nat_det_close_session_in_reply;
extern vapi_msg_id_t vapi_msg_id_snat_det_map_details;
extern vapi_msg_id_t vapi_msg_id_nat_set_workers;
extern vapi_msg_id_t vapi_msg_id_nat64_add_del_prefix;
extern vapi_msg_id_t vapi_msg_id_snat_add_address_range_reply;
extern vapi_msg_id_t vapi_msg_id_nat_ipfix_enable_disable_reply;
extern vapi_msg_id_t vapi_msg_id_nat64_pool_addr_details;
extern vapi_msg_id_t vapi_msg_id_snat_det_reverse;
extern vapi_msg_id_t vapi_msg_id_nat_worker_details;
extern vapi_msg_id_t vapi_msg_id_nat44_interface_add_del_output_feature;
extern vapi_msg_id_t vapi_msg_id_nat44_add_del_static_mapping_reply;
extern vapi_msg_id_t vapi_msg_id_nat44_add_del_interface_addr_reply;
extern vapi_msg_id_t vapi_msg_id_snat_det_close_session_out;
extern vapi_msg_id_t vapi_msg_id_snat_det_close_session_out_reply;
extern vapi_msg_id_t vapi_msg_id_snat_det_set_timeouts_reply;
extern vapi_msg_id_t vapi_msg_id_nat44_add_del_interface_addr;
extern vapi_msg_id_t vapi_msg_id_nat_det_map_details;
extern vapi_msg_id_t vapi_msg_id_nat64_st_dump;
extern vapi_msg_id_t vapi_msg_id_snat_show_config;
extern vapi_msg_id_t vapi_msg_id_nat44_lb_static_mapping_details;
extern vapi_msg_id_t vapi_msg_id_snat_add_address_range;
extern vapi_msg_id_t vapi_msg_id_snat_add_det_map_reply;
extern vapi_msg_id_t vapi_msg_id_snat_static_mapping_dump;
extern vapi_msg_id_t vapi_msg_id_nat44_interface_details;
extern vapi_msg_id_t vapi_msg_id_snat_interface_dump;
extern vapi_msg_id_t vapi_msg_id_nat44_add_del_address_range;
extern vapi_msg_id_t vapi_msg_id_nat_det_set_timeouts_reply;
extern vapi_msg_id_t vapi_msg_id_snat_user_session_details;
extern vapi_msg_id_t vapi_msg_id_snat_control_ping_reply;
extern vapi_msg_id_t vapi_msg_id_snat_interface_add_del_output_feature;
extern vapi_msg_id_t vapi_msg_id_snat_worker_dump;
extern vapi_msg_id_t vapi_msg_id_nat_set_workers_reply;
extern vapi_msg_id_t vapi_msg_id_snat_interface_output_feature_dump;
extern vapi_msg_id_t vapi_msg_id_nat44_add_del_static_mapping;
extern vapi_msg_id_t vapi_msg_id_nat64_add_del_static_bib;
extern vapi_msg_id_t vapi_msg_id_snat_det_close_session_in;
extern vapi_msg_id_t vapi_msg_id_snat_interface_details;
extern vapi_msg_id_t vapi_msg_id_snat_det_get_timeouts;

#define DEFINE_VAPI_MSG_IDS_NAT_API_JSON\
  vapi_msg_id_t vapi_msg_id_snat_interface_add_del_feature;\
  vapi_msg_id_t vapi_msg_id_snat_control_ping;\
  vapi_msg_id_t vapi_msg_id_nat_ipfix_enable_disable;\
  vapi_msg_id_t vapi_msg_id_snat_static_mapping_details;\
  vapi_msg_id_t vapi_msg_id_nat_control_ping_reply;\
  vapi_msg_id_t vapi_msg_id_snat_interface_output_feature_details;\
  vapi_msg_id_t vapi_msg_id_nat44_lb_static_mapping_dump;\
  vapi_msg_id_t vapi_msg_id_nat64_pool_addr_dump;\
  vapi_msg_id_t vapi_msg_id_snat_user_session_dump;\
  vapi_msg_id_t vapi_msg_id_nat64_interface_dump;\
  vapi_msg_id_t vapi_msg_id_nat_det_add_del_map;\
  vapi_msg_id_t vapi_msg_id_snat_interface_add_del_feature_reply;\
  vapi_msg_id_t vapi_msg_id_nat64_prefix_details;\
  vapi_msg_id_t vapi_msg_id_snat_ipfix_enable_disable;\
  vapi_msg_id_t vapi_msg_id_nat_det_get_timeouts_reply;\
  vapi_msg_id_t vapi_msg_id_nat_det_reverse_reply;\
  vapi_msg_id_t vapi_msg_id_nat44_user_dump;\
  vapi_msg_id_t vapi_msg_id_snat_det_set_timeouts;\
  vapi_msg_id_t vapi_msg_id_nat44_static_mapping_details;\
  vapi_msg_id_t vapi_msg_id_nat64_add_del_prefix_reply;\
  vapi_msg_id_t vapi_msg_id_nat64_st_details;\
  vapi_msg_id_t vapi_msg_id_snat_show_config_reply;\
  vapi_msg_id_t vapi_msg_id_snat_add_static_mapping;\
  vapi_msg_id_t vapi_msg_id_nat_control_ping;\
  vapi_msg_id_t vapi_msg_id_nat44_interface_add_del_output_feature_reply;\
  vapi_msg_id_t vapi_msg_id_snat_add_static_mapping_reply;\
  vapi_msg_id_t vapi_msg_id_nat64_add_del_interface;\
  vapi_msg_id_t vapi_msg_id_nat_det_close_session_in;\
  vapi_msg_id_t vapi_msg_id_nat44_user_session_dump;\
  vapi_msg_id_t vapi_msg_id_nat44_static_mapping_dump;\
  vapi_msg_id_t vapi_msg_id_snat_worker_details;\
  vapi_msg_id_t vapi_msg_id_snat_det_map_dump;\
  vapi_msg_id_t vapi_msg_id_nat64_set_timeouts_reply;\
  vapi_msg_id_t vapi_msg_id_nat44_user_session_details;\
  vapi_msg_id_t vapi_msg_id_snat_add_del_interface_addr;\
  vapi_msg_id_t vapi_msg_id_snat_ipfix_enable_disable_reply;\
  vapi_msg_id_t vapi_msg_id_snat_address_dump;\
  vapi_msg_id_t vapi_msg_id_snat_set_workers;\
  vapi_msg_id_t vapi_msg_id_nat44_interface_output_feature_dump;\
  vapi_msg_id_t vapi_msg_id_nat44_interface_add_del_feature;\
  vapi_msg_id_t vapi_msg_id_nat44_interface_output_feature_details;\
  vapi_msg_id_t vapi_msg_id_nat_det_reverse;\
  vapi_msg_id_t vapi_msg_id_nat_det_session_details;\
  vapi_msg_id_t vapi_msg_id_snat_interface_add_del_output_feature_reply;\
  vapi_msg_id_t vapi_msg_id_nat44_interface_add_del_feature_reply;\
  vapi_msg_id_t vapi_msg_id_nat44_add_del_address_range_reply;\
  vapi_msg_id_t vapi_msg_id_nat64_add_del_interface_reply;\
  vapi_msg_id_t vapi_msg_id_nat_det_forward;\
  vapi_msg_id_t vapi_msg_id_nat_worker_dump;\
  vapi_msg_id_t vapi_msg_id_snat_interface_addr_dump;\
  vapi_msg_id_t vapi_msg_id_nat_det_get_timeouts;\
  vapi_msg_id_t vapi_msg_id_nat_det_add_del_map_reply;\
  vapi_msg_id_t vapi_msg_id_nat44_interface_addr_dump;\
  vapi_msg_id_t vapi_msg_id_nat_show_config_reply;\
  vapi_msg_id_t vapi_msg_id_nat44_add_del_lb_static_mapping_reply;\
  vapi_msg_id_t vapi_msg_id_snat_det_get_timeouts_reply;\
  vapi_msg_id_t vapi_msg_id_snat_user_details;\
  vapi_msg_id_t vapi_msg_id_snat_det_close_session_in_reply;\
  vapi_msg_id_t vapi_msg_id_nat64_add_del_static_bib_reply;\
  vapi_msg_id_t vapi_msg_id_nat44_address_details;\
  vapi_msg_id_t vapi_msg_id_nat44_add_del_lb_static_mapping;\
  vapi_msg_id_t vapi_msg_id_nat_det_set_timeouts;\
  vapi_msg_id_t vapi_msg_id_snat_user_dump;\
  vapi_msg_id_t vapi_msg_id_snat_add_del_interface_addr_reply;\
  vapi_msg_id_t vapi_msg_id_snat_set_workers_reply;\
  vapi_msg_id_t vapi_msg_id_snat_det_forward_reply;\
  vapi_msg_id_t vapi_msg_id_nat_det_close_session_out;\
  vapi_msg_id_t vapi_msg_id_snat_det_reverse_reply;\
  vapi_msg_id_t vapi_msg_id_nat_det_session_dump;\
  vapi_msg_id_t vapi_msg_id_nat44_user_details;\
  vapi_msg_id_t vapi_msg_id_nat_det_forward_reply;\
  vapi_msg_id_t vapi_msg_id_nat64_set_timeouts;\
  vapi_msg_id_t vapi_msg_id_nat44_interface_addr_details;\
  vapi_msg_id_t vapi_msg_id_snat_address_details;\
  vapi_msg_id_t vapi_msg_id_nat64_add_del_pool_addr_range_reply;\
  vapi_msg_id_t vapi_msg_id_snat_det_session_dump;\
  vapi_msg_id_t vapi_msg_id_nat64_get_timeouts;\
  vapi_msg_id_t vapi_msg_id_snat_add_det_map;\
  vapi_msg_id_t vapi_msg_id_nat_det_close_session_out_reply;\
  vapi_msg_id_t vapi_msg_id_nat_show_config;\
  vapi_msg_id_t vapi_msg_id_snat_det_session_details;\
  vapi_msg_id_t vapi_msg_id_nat44_address_dump;\
  vapi_msg_id_t vapi_msg_id_snat_det_forward;\
  vapi_msg_id_t vapi_msg_id_nat44_interface_dump;\
  vapi_msg_id_t vapi_msg_id_nat64_interface_details;\
  vapi_msg_id_t vapi_msg_id_nat64_bib_dump;\
  vapi_msg_id_t vapi_msg_id_nat64_add_del_pool_addr_range;\
  vapi_msg_id_t vapi_msg_id_nat64_bib_details;\
  vapi_msg_id_t vapi_msg_id_nat64_get_timeouts_reply;\
  vapi_msg_id_t vapi_msg_id_nat64_prefix_dump;\
  vapi_msg_id_t vapi_msg_id_nat_det_map_dump;\
  vapi_msg_id_t vapi_msg_id_snat_interface_addr_details;\
  vapi_msg_id_t vapi_msg_id_nat_det_close_session_in_reply;\
  vapi_msg_id_t vapi_msg_id_snat_det_map_details;\
  vapi_msg_id_t vapi_msg_id_nat_set_workers;\
  vapi_msg_id_t vapi_msg_id_nat64_add_del_prefix;\
  vapi_msg_id_t vapi_msg_id_snat_add_address_range_reply;\
  vapi_msg_id_t vapi_msg_id_nat_ipfix_enable_disable_reply;\
  vapi_msg_id_t vapi_msg_id_nat64_pool_addr_details;\
  vapi_msg_id_t vapi_msg_id_snat_det_reverse;\
  vapi_msg_id_t vapi_msg_id_nat_worker_details;\
  vapi_msg_id_t vapi_msg_id_nat44_interface_add_del_output_feature;\
  vapi_msg_id_t vapi_msg_id_nat44_add_del_static_mapping_reply;\
  vapi_msg_id_t vapi_msg_id_nat44_add_del_interface_addr_reply;\
  vapi_msg_id_t vapi_msg_id_snat_det_close_session_out;\
  vapi_msg_id_t vapi_msg_id_snat_det_close_session_out_reply;\
  vapi_msg_id_t vapi_msg_id_snat_det_set_timeouts_reply;\
  vapi_msg_id_t vapi_msg_id_nat44_add_del_interface_addr;\
  vapi_msg_id_t vapi_msg_id_nat_det_map_details;\
  vapi_msg_id_t vapi_msg_id_nat64_st_dump;\
  vapi_msg_id_t vapi_msg_id_snat_show_config;\
  vapi_msg_id_t vapi_msg_id_nat44_lb_static_mapping_details;\
  vapi_msg_id_t vapi_msg_id_snat_add_address_range;\
  vapi_msg_id_t vapi_msg_id_snat_add_det_map_reply;\
  vapi_msg_id_t vapi_msg_id_snat_static_mapping_dump;\
  vapi_msg_id_t vapi_msg_id_nat44_interface_details;\
  vapi_msg_id_t vapi_msg_id_snat_interface_dump;\
  vapi_msg_id_t vapi_msg_id_nat44_add_del_address_range;\
  vapi_msg_id_t vapi_msg_id_nat_det_set_timeouts_reply;\
  vapi_msg_id_t vapi_msg_id_snat_user_session_details;\
  vapi_msg_id_t vapi_msg_id_snat_control_ping_reply;\
  vapi_msg_id_t vapi_msg_id_snat_interface_add_del_output_feature;\
  vapi_msg_id_t vapi_msg_id_snat_worker_dump;\
  vapi_msg_id_t vapi_msg_id_nat_set_workers_reply;\
  vapi_msg_id_t vapi_msg_id_snat_interface_output_feature_dump;\
  vapi_msg_id_t vapi_msg_id_nat44_add_del_static_mapping;\
  vapi_msg_id_t vapi_msg_id_nat64_add_del_static_bib;\
  vapi_msg_id_t vapi_msg_id_snat_det_close_session_in;\
  vapi_msg_id_t vapi_msg_id_snat_interface_details;\
  vapi_msg_id_t vapi_msg_id_snat_det_get_timeouts;


typedef struct __attribute__((__packed__)) {
  u8 addr[4];
  u16 port;
  u8 probability;
} vapi_type_nat44_lb_addr_port;

typedef struct __attribute__ ((__packed__)) {
  u8 is_add;
  u8 is_inside;
  u32 sw_if_index; 
} vapi_payload_snat_interface_add_del_feature;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_snat_interface_add_del_feature payload;
} vapi_msg_snat_interface_add_del_feature;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_snat_control_ping;

typedef struct __attribute__ ((__packed__)) {
  u32 domain_id;
  u16 src_port;
  u8 enable; 
} vapi_payload_nat_ipfix_enable_disable;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_nat_ipfix_enable_disable payload;
} vapi_msg_nat_ipfix_enable_disable;

typedef struct __attribute__ ((__packed__)) {
  u8 is_ip4;
  u8 addr_only;
  u8 local_ip_address[16];
  u8 external_ip_address[16];
  u8 protocol;
  u16 local_port;
  u16 external_port;
  u32 external_sw_if_index;
  u32 vrf_id; 
} vapi_payload_snat_static_mapping_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_snat_static_mapping_details payload;
} vapi_msg_snat_static_mapping_details;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u32 client_index;
  u32 vpe_pid; 
} vapi_payload_nat_control_ping_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat_control_ping_reply payload;
} vapi_msg_nat_control_ping_reply;

typedef struct __attribute__ ((__packed__)) {
  u8 is_inside;
  u32 sw_if_index; 
} vapi_payload_snat_interface_output_feature_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_snat_interface_output_feature_details payload;
} vapi_msg_snat_interface_output_feature_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_nat44_lb_static_mapping_dump;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_nat64_pool_addr_dump;

typedef struct __attribute__ ((__packed__)) {
  u8 is_ip4;
  u8 ip_address[16];
  u32 vrf_id; 
} vapi_payload_snat_user_session_dump;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_snat_user_session_dump payload;
} vapi_msg_snat_user_session_dump;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_nat64_interface_dump;

typedef struct __attribute__ ((__packed__)) {
  u8 is_add;
  u8 is_nat44;
  u8 addr_only;
  u8 in_addr[16];
  u8 in_plen;
  u8 out_addr[4];
  u8 out_plen; 
} vapi_payload_nat_det_add_del_map;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_nat_det_add_del_map payload;
} vapi_msg_nat_det_add_del_map;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_snat_interface_add_del_feature_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_snat_interface_add_del_feature_reply payload;
} vapi_msg_snat_interface_add_del_feature_reply;

typedef struct __attribute__ ((__packed__)) {
  u8 prefix[16];
  u8 prefix_len;
  u32 vrf_id; 
} vapi_payload_nat64_prefix_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat64_prefix_details payload;
} vapi_msg_nat64_prefix_details;

typedef struct __attribute__ ((__packed__)) {
  u32 domain_id;
  u16 src_port;
  u8 enable; 
} vapi_payload_snat_ipfix_enable_disable;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_snat_ipfix_enable_disable payload;
} vapi_msg_snat_ipfix_enable_disable;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u32 udp;
  u32 tcp_established;
  u32 tcp_transitory;
  u32 icmp; 
} vapi_payload_nat_det_get_timeouts_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat_det_get_timeouts_reply payload;
} vapi_msg_nat_det_get_timeouts_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u8 is_nat44;
  u8 in_addr[16]; 
} vapi_payload_nat_det_reverse_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat_det_reverse_reply payload;
} vapi_msg_nat_det_reverse_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_nat44_user_dump;

typedef struct __attribute__ ((__packed__)) {
  u32 udp;
  u32 tcp_established;
  u32 tcp_transitory;
  u32 icmp; 
} vapi_payload_snat_det_set_timeouts;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_snat_det_set_timeouts payload;
} vapi_msg_snat_det_set_timeouts;

typedef struct __attribute__ ((__packed__)) {
  u8 addr_only;
  u8 local_ip_address[4];
  u8 external_ip_address[4];
  u8 protocol;
  u16 local_port;
  u16 external_port;
  u32 external_sw_if_index;
  u32 vrf_id; 
} vapi_payload_nat44_static_mapping_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat44_static_mapping_details payload;
} vapi_msg_nat44_static_mapping_details;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_nat64_add_del_prefix_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat64_add_del_prefix_reply payload;
} vapi_msg_nat64_add_del_prefix_reply;

typedef struct __attribute__ ((__packed__)) {
  u8 il_addr[16];
  u8 ol_addr[4];
  u16 il_port;
  u16 ol_port;
  u8 ir_addr[16];
  u8 or_addr[4];
  u16 r_port;
  u32 vrf_id;
  u8 proto; 
} vapi_payload_nat64_st_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat64_st_details payload;
} vapi_msg_nat64_st_details;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u8 static_mapping_only;
  u8 static_mapping_connection_tracking;
  u8 deterministic;
  u32 translation_buckets;
  u32 translation_memory_size;
  u32 user_buckets;
  u32 user_memory_size;
  u32 max_translations_per_user;
  u32 outside_vrf_id;
  u32 inside_vrf_id; 
} vapi_payload_snat_show_config_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_snat_show_config_reply payload;
} vapi_msg_snat_show_config_reply;

typedef struct __attribute__ ((__packed__)) {
  u8 is_add;
  u8 is_ip4;
  u8 addr_only;
  u8 local_ip_address[16];
  u8 external_ip_address[16];
  u8 protocol;
  u16 local_port;
  u16 external_port;
  u32 external_sw_if_index;
  u32 vrf_id; 
} vapi_payload_snat_add_static_mapping;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_snat_add_static_mapping payload;
} vapi_msg_snat_add_static_mapping;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_nat_control_ping;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_nat44_interface_add_del_output_feature_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat44_interface_add_del_output_feature_reply payload;
} vapi_msg_nat44_interface_add_del_output_feature_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_snat_add_static_mapping_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_snat_add_static_mapping_reply payload;
} vapi_msg_snat_add_static_mapping_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u8 is_inside;
  u8 is_add; 
} vapi_payload_nat64_add_del_interface;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_nat64_add_del_interface payload;
} vapi_msg_nat64_add_del_interface;

typedef struct __attribute__ ((__packed__)) {
  u8 is_nat44;
  u8 in_addr[16];
  u16 in_port;
  u8 ext_addr[16];
  u16 ext_port; 
} vapi_payload_nat_det_close_session_in;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_nat_det_close_session_in payload;
} vapi_msg_nat_det_close_session_in;

typedef struct __attribute__ ((__packed__)) {
  u8 ip_address[4];
  u32 vrf_id; 
} vapi_payload_nat44_user_session_dump;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_nat44_user_session_dump payload;
} vapi_msg_nat44_user_session_dump;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_nat44_static_mapping_dump;

typedef struct __attribute__ ((__packed__)) {
  u32 worker_index;
  u32 lcore_id;
  u8 name[64]; 
} vapi_payload_snat_worker_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_snat_worker_details payload;
} vapi_msg_snat_worker_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_snat_det_map_dump;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_nat64_set_timeouts_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat64_set_timeouts_reply payload;
} vapi_msg_nat64_set_timeouts_reply;

typedef struct __attribute__ ((__packed__)) {
  u8 outside_ip_address[4];
  u16 outside_port;
  u8 inside_ip_address[4];
  u16 inside_port;
  u16 protocol;
  u8 is_static;
  u64 last_heard;
  u64 total_bytes;
  u32 total_pkts; 
} vapi_payload_nat44_user_session_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat44_user_session_details payload;
} vapi_msg_nat44_user_session_details;

typedef struct __attribute__ ((__packed__)) {
  u8 is_add;
  u8 is_inside;
  u32 sw_if_index; 
} vapi_payload_snat_add_del_interface_addr;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_snat_add_del_interface_addr payload;
} vapi_msg_snat_add_del_interface_addr;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_snat_ipfix_enable_disable_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_snat_ipfix_enable_disable_reply payload;
} vapi_msg_snat_ipfix_enable_disable_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_snat_address_dump;

typedef struct __attribute__ ((__packed__)) {
  u64 worker_mask; 
} vapi_payload_snat_set_workers;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_snat_set_workers payload;
} vapi_msg_snat_set_workers;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_nat44_interface_output_feature_dump;

typedef struct __attribute__ ((__packed__)) {
  u8 is_add;
  u8 is_inside;
  u32 sw_if_index; 
} vapi_payload_nat44_interface_add_del_feature;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_nat44_interface_add_del_feature payload;
} vapi_msg_nat44_interface_add_del_feature;

typedef struct __attribute__ ((__packed__)) {
  u8 is_inside;
  u32 sw_if_index; 
} vapi_payload_nat44_interface_output_feature_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat44_interface_output_feature_details payload;
} vapi_msg_nat44_interface_output_feature_details;

typedef struct __attribute__ ((__packed__)) {
  u16 out_port;
  u8 out_addr[4]; 
} vapi_payload_nat_det_reverse;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_nat_det_reverse payload;
} vapi_msg_nat_det_reverse;

typedef struct __attribute__ ((__packed__)) {
  u16 in_port;
  u8 ext_addr[4];
  u16 ext_port;
  u16 out_port;
  u8 state;
  u32 expire; 
} vapi_payload_nat_det_session_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_nat_det_session_details payload;
} vapi_msg_nat_det_session_details;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_snat_interface_add_del_output_feature_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_snat_interface_add_del_output_feature_reply payload;
} vapi_msg_snat_interface_add_del_output_feature_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_nat44_interface_add_del_feature_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat44_interface_add_del_feature_reply payload;
} vapi_msg_nat44_interface_add_del_feature_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_nat44_add_del_address_range_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat44_add_del_address_range_reply payload;
} vapi_msg_nat44_add_del_address_range_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_nat64_add_del_interface_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat64_add_del_interface_reply payload;
} vapi_msg_nat64_add_del_interface_reply;

typedef struct __attribute__ ((__packed__)) {
  u8 is_nat44;
  u8 in_addr[16]; 
} vapi_payload_nat_det_forward;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_nat_det_forward payload;
} vapi_msg_nat_det_forward;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_nat_worker_dump;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_snat_interface_addr_dump;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_nat_det_get_timeouts;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_nat_det_add_del_map_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat_det_add_del_map_reply payload;
} vapi_msg_nat_det_add_del_map_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_nat44_interface_addr_dump;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u8 static_mapping_only;
  u8 static_mapping_connection_tracking;
  u8 deterministic;
  u32 translation_buckets;
  u32 translation_memory_size;
  u32 user_buckets;
  u32 user_memory_size;
  u32 max_translations_per_user;
  u32 outside_vrf_id;
  u32 inside_vrf_id; 
} vapi_payload_nat_show_config_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat_show_config_reply payload;
} vapi_msg_nat_show_config_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_nat44_add_del_lb_static_mapping_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat44_add_del_lb_static_mapping_reply payload;
} vapi_msg_nat44_add_del_lb_static_mapping_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u32 udp;
  u32 tcp_established;
  u32 tcp_transitory;
  u32 icmp; 
} vapi_payload_snat_det_get_timeouts_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_snat_det_get_timeouts_reply payload;
} vapi_msg_snat_det_get_timeouts_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 vrf_id;
  u8 is_ip4;
  u8 ip_address[16];
  u32 nsessions;
  u32 nstaticsessions; 
} vapi_payload_snat_user_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_snat_user_details payload;
} vapi_msg_snat_user_details;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_snat_det_close_session_in_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_snat_det_close_session_in_reply payload;
} vapi_msg_snat_det_close_session_in_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_nat64_add_del_static_bib_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat64_add_del_static_bib_reply payload;
} vapi_msg_nat64_add_del_static_bib_reply;

typedef struct __attribute__ ((__packed__)) {
  u8 ip_address[4];
  u32 vrf_id; 
} vapi_payload_nat44_address_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat44_address_details payload;
} vapi_msg_nat44_address_details;

typedef struct __attribute__ ((__packed__)) {
  u8 is_add;
  u8 external_addr[4];
  u16 external_port;
  u8 protocol;
  u32 vrf_id;
  u8 local_num;
  vapi_type_nat44_lb_addr_port locals[0]; 
} vapi_payload_nat44_add_del_lb_static_mapping;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_nat44_add_del_lb_static_mapping payload;
} vapi_msg_nat44_add_del_lb_static_mapping;

typedef struct __attribute__ ((__packed__)) {
  u32 udp;
  u32 tcp_established;
  u32 tcp_transitory;
  u32 icmp; 
} vapi_payload_nat_det_set_timeouts;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_nat_det_set_timeouts payload;
} vapi_msg_nat_det_set_timeouts;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_snat_user_dump;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_snat_add_del_interface_addr_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_snat_add_del_interface_addr_reply payload;
} vapi_msg_snat_add_del_interface_addr_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_snat_set_workers_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_snat_set_workers_reply payload;
} vapi_msg_snat_set_workers_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u16 out_port_lo;
  u16 out_port_hi;
  u8 is_ip4;
  u8 out_addr[16]; 
} vapi_payload_snat_det_forward_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_snat_det_forward_reply payload;
} vapi_msg_snat_det_forward_reply;

typedef struct __attribute__ ((__packed__)) {
  u8 out_addr[4];
  u16 out_port;
  u8 ext_addr[4];
  u16 ext_port; 
} vapi_payload_nat_det_close_session_out;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_nat_det_close_session_out payload;
} vapi_msg_nat_det_close_session_out;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u8 is_ip4;
  u8 in_addr[16]; 
} vapi_payload_snat_det_reverse_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_snat_det_reverse_reply payload;
} vapi_msg_snat_det_reverse_reply;

typedef struct __attribute__ ((__packed__)) {
  u8 is_nat44;
  u8 user_addr[16]; 
} vapi_payload_nat_det_session_dump;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_nat_det_session_dump payload;
} vapi_msg_nat_det_session_dump;

typedef struct __attribute__ ((__packed__)) {
  u32 vrf_id;
  u8 ip_address[4];
  u32 nsessions;
  u32 nstaticsessions; 
} vapi_payload_nat44_user_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat44_user_details payload;
} vapi_msg_nat44_user_details;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u16 out_port_lo;
  u16 out_port_hi;
  u8 out_addr[4]; 
} vapi_payload_nat_det_forward_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat_det_forward_reply payload;
} vapi_msg_nat_det_forward_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 udp;
  u32 icmp;
  u32 tcp_trans;
  u32 tcp_est;
  u32 tcp_incoming_syn; 
} vapi_payload_nat64_set_timeouts;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_nat64_set_timeouts payload;
} vapi_msg_nat64_set_timeouts;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index; 
} vapi_payload_nat44_interface_addr_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat44_interface_addr_details payload;
} vapi_msg_nat44_interface_addr_details;

typedef struct __attribute__ ((__packed__)) {
  u8 is_ip4;
  u8 ip_address[16];
  u32 vrf_id; 
} vapi_payload_snat_address_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_snat_address_details payload;
} vapi_msg_snat_address_details;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_nat64_add_del_pool_addr_range_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat64_add_del_pool_addr_range_reply payload;
} vapi_msg_nat64_add_del_pool_addr_range_reply;

typedef struct __attribute__ ((__packed__)) {
  u8 is_ip4;
  u8 user_addr[16]; 
} vapi_payload_snat_det_session_dump;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_snat_det_session_dump payload;
} vapi_msg_snat_det_session_dump;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_nat64_get_timeouts;

typedef struct __attribute__ ((__packed__)) {
  u8 is_add;
  u8 is_ip4;
  u8 addr_only;
  u8 in_addr[16];
  u8 in_plen;
  u8 out_addr[16];
  u8 out_plen; 
} vapi_payload_snat_add_det_map;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_snat_add_det_map payload;
} vapi_msg_snat_add_det_map;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_nat_det_close_session_out_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat_det_close_session_out_reply payload;
} vapi_msg_nat_det_close_session_out_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_nat_show_config;

typedef struct __attribute__ ((__packed__)) {
  u8 is_ip4;
  u16 in_port;
  u8 ext_addr[16];
  u16 ext_port;
  u16 out_port;
  u8 state;
  u32 expire; 
} vapi_payload_snat_det_session_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_snat_det_session_details payload;
} vapi_msg_snat_det_session_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_nat44_address_dump;

typedef struct __attribute__ ((__packed__)) {
  u8 is_ip4;
  u8 in_addr[16]; 
} vapi_payload_snat_det_forward;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_snat_det_forward payload;
} vapi_msg_snat_det_forward;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_nat44_interface_dump;

typedef struct __attribute__ ((__packed__)) {
  u8 is_inside;
  u32 sw_if_index; 
} vapi_payload_nat64_interface_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat64_interface_details payload;
} vapi_msg_nat64_interface_details;

typedef struct __attribute__ ((__packed__)) {
  u8 proto; 
} vapi_payload_nat64_bib_dump;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_nat64_bib_dump payload;
} vapi_msg_nat64_bib_dump;

typedef struct __attribute__ ((__packed__)) {
  u8 start_addr[4];
  u8 end_addr[4];
  u32 vrf_id;
  u8 is_add; 
} vapi_payload_nat64_add_del_pool_addr_range;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_nat64_add_del_pool_addr_range payload;
} vapi_msg_nat64_add_del_pool_addr_range;

typedef struct __attribute__ ((__packed__)) {
  u8 i_addr[16];
  u8 o_addr[4];
  u16 i_port;
  u16 o_port;
  u32 vrf_id;
  u8 proto;
  u8 is_static;
  u32 ses_num; 
} vapi_payload_nat64_bib_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat64_bib_details payload;
} vapi_msg_nat64_bib_details;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u32 udp;
  u32 icmp;
  u32 tcp_trans;
  u32 tcp_est;
  u32 tcp_incoming_syn; 
} vapi_payload_nat64_get_timeouts_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat64_get_timeouts_reply payload;
} vapi_msg_nat64_get_timeouts_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_nat64_prefix_dump;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_nat_det_map_dump;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index; 
} vapi_payload_snat_interface_addr_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_snat_interface_addr_details payload;
} vapi_msg_snat_interface_addr_details;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_nat_det_close_session_in_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat_det_close_session_in_reply payload;
} vapi_msg_nat_det_close_session_in_reply;

typedef struct __attribute__ ((__packed__)) {
  u8 is_ip4;
  u8 in_addr[16];
  u8 in_plen;
  u8 out_addr[16];
  u8 out_plen;
  u32 sharing_ratio;
  u16 ports_per_host;
  u32 ses_num; 
} vapi_payload_snat_det_map_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_snat_det_map_details payload;
} vapi_msg_snat_det_map_details;

typedef struct __attribute__ ((__packed__)) {
  u64 worker_mask; 
} vapi_payload_nat_set_workers;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_nat_set_workers payload;
} vapi_msg_nat_set_workers;

typedef struct __attribute__ ((__packed__)) {
  u8 prefix[16];
  u8 prefix_len;
  u32 vrf_id;
  u8 is_add; 
} vapi_payload_nat64_add_del_prefix;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_nat64_add_del_prefix payload;
} vapi_msg_nat64_add_del_prefix;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_snat_add_address_range_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_snat_add_address_range_reply payload;
} vapi_msg_snat_add_address_range_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_nat_ipfix_enable_disable_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat_ipfix_enable_disable_reply payload;
} vapi_msg_nat_ipfix_enable_disable_reply;

typedef struct __attribute__ ((__packed__)) {
  u8 address[4];
  u32 vrf_id; 
} vapi_payload_nat64_pool_addr_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat64_pool_addr_details payload;
} vapi_msg_nat64_pool_addr_details;

typedef struct __attribute__ ((__packed__)) {
  u16 out_port;
  u8 is_ip4;
  u8 out_addr[16]; 
} vapi_payload_snat_det_reverse;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_snat_det_reverse payload;
} vapi_msg_snat_det_reverse;

typedef struct __attribute__ ((__packed__)) {
  u32 worker_index;
  u32 lcore_id;
  u8 name[64]; 
} vapi_payload_nat_worker_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat_worker_details payload;
} vapi_msg_nat_worker_details;

typedef struct __attribute__ ((__packed__)) {
  u8 is_add;
  u8 is_inside;
  u32 sw_if_index; 
} vapi_payload_nat44_interface_add_del_output_feature;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_nat44_interface_add_del_output_feature payload;
} vapi_msg_nat44_interface_add_del_output_feature;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_nat44_add_del_static_mapping_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat44_add_del_static_mapping_reply payload;
} vapi_msg_nat44_add_del_static_mapping_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_nat44_add_del_interface_addr_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat44_add_del_interface_addr_reply payload;
} vapi_msg_nat44_add_del_interface_addr_reply;

typedef struct __attribute__ ((__packed__)) {
  u8 is_ip4;
  u8 out_addr[16];
  u16 out_port;
  u8 ext_addr[16];
  u16 ext_port; 
} vapi_payload_snat_det_close_session_out;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_snat_det_close_session_out payload;
} vapi_msg_snat_det_close_session_out;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_snat_det_close_session_out_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_snat_det_close_session_out_reply payload;
} vapi_msg_snat_det_close_session_out_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_snat_det_set_timeouts_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_snat_det_set_timeouts_reply payload;
} vapi_msg_snat_det_set_timeouts_reply;

typedef struct __attribute__ ((__packed__)) {
  u8 is_add;
  u8 is_inside;
  u32 sw_if_index; 
} vapi_payload_nat44_add_del_interface_addr;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_nat44_add_del_interface_addr payload;
} vapi_msg_nat44_add_del_interface_addr;

typedef struct __attribute__ ((__packed__)) {
  u8 is_nat44;
  u8 in_addr[16];
  u8 in_plen;
  u8 out_addr[4];
  u8 out_plen;
  u32 sharing_ratio;
  u16 ports_per_host;
  u32 ses_num; 
} vapi_payload_nat_det_map_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat_det_map_details payload;
} vapi_msg_nat_det_map_details;

typedef struct __attribute__ ((__packed__)) {
  u8 proto; 
} vapi_payload_nat64_st_dump;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_nat64_st_dump payload;
} vapi_msg_nat64_st_dump;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_snat_show_config;

typedef struct __attribute__ ((__packed__)) {
  u8 external_addr[4];
  u16 external_port;
  u8 protocol;
  u32 vrf_id;
  u8 local_num;
  vapi_type_nat44_lb_addr_port locals[0]; 
} vapi_payload_nat44_lb_static_mapping_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat44_lb_static_mapping_details payload;
} vapi_msg_nat44_lb_static_mapping_details;

typedef struct __attribute__ ((__packed__)) {
  u8 is_ip4;
  u8 first_ip_address[16];
  u8 last_ip_address[16];
  u32 vrf_id;
  u8 is_add; 
} vapi_payload_snat_add_address_range;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_snat_add_address_range payload;
} vapi_msg_snat_add_address_range;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_snat_add_det_map_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_snat_add_det_map_reply payload;
} vapi_msg_snat_add_det_map_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_snat_static_mapping_dump;

typedef struct __attribute__ ((__packed__)) {
  u8 is_inside;
  u32 sw_if_index; 
} vapi_payload_nat44_interface_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat44_interface_details payload;
} vapi_msg_nat44_interface_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_snat_interface_dump;

typedef struct __attribute__ ((__packed__)) {
  u8 first_ip_address[4];
  u8 last_ip_address[4];
  u32 vrf_id;
  u8 is_add; 
} vapi_payload_nat44_add_del_address_range;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_nat44_add_del_address_range payload;
} vapi_msg_nat44_add_del_address_range;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_nat_det_set_timeouts_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat_det_set_timeouts_reply payload;
} vapi_msg_nat_det_set_timeouts_reply;

typedef struct __attribute__ ((__packed__)) {
  u8 is_ip4;
  u8 outside_ip_address[16];
  u16 outside_port;
  u8 inside_ip_address[16];
  u16 inside_port;
  u16 protocol;
  u8 is_static;
  u64 last_heard;
  u64 total_bytes;
  u32 total_pkts; 
} vapi_payload_snat_user_session_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_snat_user_session_details payload;
} vapi_msg_snat_user_session_details;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u32 client_index;
  u32 vpe_pid; 
} vapi_payload_snat_control_ping_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_snat_control_ping_reply payload;
} vapi_msg_snat_control_ping_reply;

typedef struct __attribute__ ((__packed__)) {
  u8 is_add;
  u8 is_inside;
  u32 sw_if_index; 
} vapi_payload_snat_interface_add_del_output_feature;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_snat_interface_add_del_output_feature payload;
} vapi_msg_snat_interface_add_del_output_feature;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_snat_worker_dump;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_nat_set_workers_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_nat_set_workers_reply payload;
} vapi_msg_nat_set_workers_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_snat_interface_output_feature_dump;

typedef struct __attribute__ ((__packed__)) {
  u8 is_add;
  u8 addr_only;
  u8 local_ip_address[4];
  u8 external_ip_address[4];
  u8 protocol;
  u16 local_port;
  u16 external_port;
  u32 external_sw_if_index;
  u32 vrf_id; 
} vapi_payload_nat44_add_del_static_mapping;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_nat44_add_del_static_mapping payload;
} vapi_msg_nat44_add_del_static_mapping;

typedef struct __attribute__ ((__packed__)) {
  u8 i_addr[16];
  u8 o_addr[4];
  u16 i_port;
  u16 o_port;
  u32 vrf_id;
  u8 proto;
  u8 is_add; 
} vapi_payload_nat64_add_del_static_bib;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_nat64_add_del_static_bib payload;
} vapi_msg_nat64_add_del_static_bib;

typedef struct __attribute__ ((__packed__)) {
  u8 is_ip4;
  u8 in_addr[16];
  u16 in_port;
  u8 ext_addr[16];
  u16 ext_port; 
} vapi_payload_snat_det_close_session_in;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_snat_det_close_session_in payload;
} vapi_msg_snat_det_close_session_in;

typedef struct __attribute__ ((__packed__)) {
  u8 is_inside;
  u32 sw_if_index; 
} vapi_payload_snat_interface_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_snat_interface_details payload;
} vapi_msg_snat_interface_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_snat_det_get_timeouts;


static inline void vapi_type_nat44_lb_addr_port_hton(vapi_type_nat44_lb_addr_port *msg)
{
  msg->port = htobe16(msg->port);
}

static inline void vapi_type_nat44_lb_addr_port_ntoh(vapi_type_nat44_lb_addr_port *msg)
{
  msg->port = be16toh(msg->port);
}

static inline void vapi_msg_snat_interface_add_del_feature_payload_hton(vapi_payload_snat_interface_add_del_feature *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_snat_interface_add_del_feature_payload_ntoh(vapi_payload_snat_interface_add_del_feature *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_snat_interface_add_del_feature_msg_size(vapi_msg_snat_interface_add_del_feature *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_interface_add_del_feature_hton(vapi_msg_snat_interface_add_del_feature *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_interface_add_del_feature'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_snat_interface_add_del_feature_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_interface_add_del_feature_ntoh(vapi_msg_snat_interface_add_del_feature *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_interface_add_del_feature'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_snat_interface_add_del_feature_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_snat_control_ping_msg_size(vapi_msg_snat_control_ping *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_control_ping_hton(vapi_msg_snat_control_ping *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_control_ping'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_snat_control_ping_ntoh(vapi_msg_snat_control_ping *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_control_ping'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_nat_ipfix_enable_disable_payload_hton(vapi_payload_nat_ipfix_enable_disable *payload)
{
  payload->domain_id = htobe32(payload->domain_id);
  payload->src_port = htobe16(payload->src_port);
}

static inline void vapi_msg_nat_ipfix_enable_disable_payload_ntoh(vapi_payload_nat_ipfix_enable_disable *payload)
{
  payload->domain_id = be32toh(payload->domain_id);
  payload->src_port = be16toh(payload->src_port);
}

static inline uword vapi_calc_nat_ipfix_enable_disable_msg_size(vapi_msg_nat_ipfix_enable_disable *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat_ipfix_enable_disable_hton(vapi_msg_nat_ipfix_enable_disable *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_ipfix_enable_disable'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_nat_ipfix_enable_disable_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat_ipfix_enable_disable_ntoh(vapi_msg_nat_ipfix_enable_disable *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_ipfix_enable_disable'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_nat_ipfix_enable_disable_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_snat_static_mapping_details_payload_hton(vapi_payload_snat_static_mapping_details *payload)
{
  payload->local_port = htobe16(payload->local_port);
  payload->external_port = htobe16(payload->external_port);
  payload->external_sw_if_index = htobe32(payload->external_sw_if_index);
  payload->vrf_id = htobe32(payload->vrf_id);
}

static inline void vapi_msg_snat_static_mapping_details_payload_ntoh(vapi_payload_snat_static_mapping_details *payload)
{
  payload->local_port = be16toh(payload->local_port);
  payload->external_port = be16toh(payload->external_port);
  payload->external_sw_if_index = be32toh(payload->external_sw_if_index);
  payload->vrf_id = be32toh(payload->vrf_id);
}

static inline uword vapi_calc_snat_static_mapping_details_msg_size(vapi_msg_snat_static_mapping_details *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_static_mapping_details_hton(vapi_msg_snat_static_mapping_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_static_mapping_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_snat_static_mapping_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_static_mapping_details_ntoh(vapi_msg_snat_static_mapping_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_static_mapping_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_snat_static_mapping_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat_control_ping_reply_payload_hton(vapi_payload_nat_control_ping_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->client_index = htobe32(payload->client_index);
  payload->vpe_pid = htobe32(payload->vpe_pid);
}

static inline void vapi_msg_nat_control_ping_reply_payload_ntoh(vapi_payload_nat_control_ping_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->client_index = be32toh(payload->client_index);
  payload->vpe_pid = be32toh(payload->vpe_pid);
}

static inline uword vapi_calc_nat_control_ping_reply_msg_size(vapi_msg_nat_control_ping_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat_control_ping_reply_hton(vapi_msg_nat_control_ping_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_control_ping_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat_control_ping_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat_control_ping_reply_ntoh(vapi_msg_nat_control_ping_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_control_ping_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat_control_ping_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_snat_interface_output_feature_details_payload_hton(vapi_payload_snat_interface_output_feature_details *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_snat_interface_output_feature_details_payload_ntoh(vapi_payload_snat_interface_output_feature_details *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_snat_interface_output_feature_details_msg_size(vapi_msg_snat_interface_output_feature_details *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_interface_output_feature_details_hton(vapi_msg_snat_interface_output_feature_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_interface_output_feature_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_snat_interface_output_feature_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_interface_output_feature_details_ntoh(vapi_msg_snat_interface_output_feature_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_interface_output_feature_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_snat_interface_output_feature_details_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_nat44_lb_static_mapping_dump_msg_size(vapi_msg_nat44_lb_static_mapping_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat44_lb_static_mapping_dump_hton(vapi_msg_nat44_lb_static_mapping_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_lb_static_mapping_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_nat44_lb_static_mapping_dump_ntoh(vapi_msg_nat44_lb_static_mapping_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_lb_static_mapping_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline uword vapi_calc_nat64_pool_addr_dump_msg_size(vapi_msg_nat64_pool_addr_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat64_pool_addr_dump_hton(vapi_msg_nat64_pool_addr_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_pool_addr_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_nat64_pool_addr_dump_ntoh(vapi_msg_nat64_pool_addr_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_pool_addr_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_snat_user_session_dump_payload_hton(vapi_payload_snat_user_session_dump *payload)
{
  payload->vrf_id = htobe32(payload->vrf_id);
}

static inline void vapi_msg_snat_user_session_dump_payload_ntoh(vapi_payload_snat_user_session_dump *payload)
{
  payload->vrf_id = be32toh(payload->vrf_id);
}

static inline uword vapi_calc_snat_user_session_dump_msg_size(vapi_msg_snat_user_session_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_user_session_dump_hton(vapi_msg_snat_user_session_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_user_session_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_snat_user_session_dump_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_user_session_dump_ntoh(vapi_msg_snat_user_session_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_user_session_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_snat_user_session_dump_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_nat64_interface_dump_msg_size(vapi_msg_nat64_interface_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat64_interface_dump_hton(vapi_msg_nat64_interface_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_interface_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_nat64_interface_dump_ntoh(vapi_msg_nat64_interface_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_interface_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_nat_det_add_del_map_payload_hton(vapi_payload_nat_det_add_del_map *payload)
{

}

static inline void vapi_msg_nat_det_add_del_map_payload_ntoh(vapi_payload_nat_det_add_del_map *payload)
{

}

static inline uword vapi_calc_nat_det_add_del_map_msg_size(vapi_msg_nat_det_add_del_map *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat_det_add_del_map_hton(vapi_msg_nat_det_add_del_map *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_add_del_map'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_nat_det_add_del_map_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat_det_add_del_map_ntoh(vapi_msg_nat_det_add_del_map *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_add_del_map'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_nat_det_add_del_map_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_snat_interface_add_del_feature_reply_payload_hton(vapi_payload_snat_interface_add_del_feature_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_snat_interface_add_del_feature_reply_payload_ntoh(vapi_payload_snat_interface_add_del_feature_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_snat_interface_add_del_feature_reply_msg_size(vapi_msg_snat_interface_add_del_feature_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_interface_add_del_feature_reply_hton(vapi_msg_snat_interface_add_del_feature_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_interface_add_del_feature_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_snat_interface_add_del_feature_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_interface_add_del_feature_reply_ntoh(vapi_msg_snat_interface_add_del_feature_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_interface_add_del_feature_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_snat_interface_add_del_feature_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat64_prefix_details_payload_hton(vapi_payload_nat64_prefix_details *payload)
{
  payload->vrf_id = htobe32(payload->vrf_id);
}

static inline void vapi_msg_nat64_prefix_details_payload_ntoh(vapi_payload_nat64_prefix_details *payload)
{
  payload->vrf_id = be32toh(payload->vrf_id);
}

static inline uword vapi_calc_nat64_prefix_details_msg_size(vapi_msg_nat64_prefix_details *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat64_prefix_details_hton(vapi_msg_nat64_prefix_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_prefix_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat64_prefix_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat64_prefix_details_ntoh(vapi_msg_nat64_prefix_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_prefix_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat64_prefix_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_snat_ipfix_enable_disable_payload_hton(vapi_payload_snat_ipfix_enable_disable *payload)
{
  payload->domain_id = htobe32(payload->domain_id);
  payload->src_port = htobe16(payload->src_port);
}

static inline void vapi_msg_snat_ipfix_enable_disable_payload_ntoh(vapi_payload_snat_ipfix_enable_disable *payload)
{
  payload->domain_id = be32toh(payload->domain_id);
  payload->src_port = be16toh(payload->src_port);
}

static inline uword vapi_calc_snat_ipfix_enable_disable_msg_size(vapi_msg_snat_ipfix_enable_disable *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_ipfix_enable_disable_hton(vapi_msg_snat_ipfix_enable_disable *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_ipfix_enable_disable'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_snat_ipfix_enable_disable_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_ipfix_enable_disable_ntoh(vapi_msg_snat_ipfix_enable_disable *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_ipfix_enable_disable'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_snat_ipfix_enable_disable_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat_det_get_timeouts_reply_payload_hton(vapi_payload_nat_det_get_timeouts_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->udp = htobe32(payload->udp);
  payload->tcp_established = htobe32(payload->tcp_established);
  payload->tcp_transitory = htobe32(payload->tcp_transitory);
  payload->icmp = htobe32(payload->icmp);
}

static inline void vapi_msg_nat_det_get_timeouts_reply_payload_ntoh(vapi_payload_nat_det_get_timeouts_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->udp = be32toh(payload->udp);
  payload->tcp_established = be32toh(payload->tcp_established);
  payload->tcp_transitory = be32toh(payload->tcp_transitory);
  payload->icmp = be32toh(payload->icmp);
}

static inline uword vapi_calc_nat_det_get_timeouts_reply_msg_size(vapi_msg_nat_det_get_timeouts_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat_det_get_timeouts_reply_hton(vapi_msg_nat_det_get_timeouts_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_get_timeouts_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat_det_get_timeouts_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat_det_get_timeouts_reply_ntoh(vapi_msg_nat_det_get_timeouts_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_get_timeouts_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat_det_get_timeouts_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat_det_reverse_reply_payload_hton(vapi_payload_nat_det_reverse_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_nat_det_reverse_reply_payload_ntoh(vapi_payload_nat_det_reverse_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_nat_det_reverse_reply_msg_size(vapi_msg_nat_det_reverse_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat_det_reverse_reply_hton(vapi_msg_nat_det_reverse_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_reverse_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat_det_reverse_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat_det_reverse_reply_ntoh(vapi_msg_nat_det_reverse_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_reverse_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat_det_reverse_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_nat44_user_dump_msg_size(vapi_msg_nat44_user_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat44_user_dump_hton(vapi_msg_nat44_user_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_user_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_nat44_user_dump_ntoh(vapi_msg_nat44_user_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_user_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_snat_det_set_timeouts_payload_hton(vapi_payload_snat_det_set_timeouts *payload)
{
  payload->udp = htobe32(payload->udp);
  payload->tcp_established = htobe32(payload->tcp_established);
  payload->tcp_transitory = htobe32(payload->tcp_transitory);
  payload->icmp = htobe32(payload->icmp);
}

static inline void vapi_msg_snat_det_set_timeouts_payload_ntoh(vapi_payload_snat_det_set_timeouts *payload)
{
  payload->udp = be32toh(payload->udp);
  payload->tcp_established = be32toh(payload->tcp_established);
  payload->tcp_transitory = be32toh(payload->tcp_transitory);
  payload->icmp = be32toh(payload->icmp);
}

static inline uword vapi_calc_snat_det_set_timeouts_msg_size(vapi_msg_snat_det_set_timeouts *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_det_set_timeouts_hton(vapi_msg_snat_det_set_timeouts *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_det_set_timeouts'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_snat_det_set_timeouts_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_det_set_timeouts_ntoh(vapi_msg_snat_det_set_timeouts *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_det_set_timeouts'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_snat_det_set_timeouts_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat44_static_mapping_details_payload_hton(vapi_payload_nat44_static_mapping_details *payload)
{
  payload->local_port = htobe16(payload->local_port);
  payload->external_port = htobe16(payload->external_port);
  payload->external_sw_if_index = htobe32(payload->external_sw_if_index);
  payload->vrf_id = htobe32(payload->vrf_id);
}

static inline void vapi_msg_nat44_static_mapping_details_payload_ntoh(vapi_payload_nat44_static_mapping_details *payload)
{
  payload->local_port = be16toh(payload->local_port);
  payload->external_port = be16toh(payload->external_port);
  payload->external_sw_if_index = be32toh(payload->external_sw_if_index);
  payload->vrf_id = be32toh(payload->vrf_id);
}

static inline uword vapi_calc_nat44_static_mapping_details_msg_size(vapi_msg_nat44_static_mapping_details *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat44_static_mapping_details_hton(vapi_msg_nat44_static_mapping_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_static_mapping_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat44_static_mapping_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat44_static_mapping_details_ntoh(vapi_msg_nat44_static_mapping_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_static_mapping_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat44_static_mapping_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat64_add_del_prefix_reply_payload_hton(vapi_payload_nat64_add_del_prefix_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_nat64_add_del_prefix_reply_payload_ntoh(vapi_payload_nat64_add_del_prefix_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_nat64_add_del_prefix_reply_msg_size(vapi_msg_nat64_add_del_prefix_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat64_add_del_prefix_reply_hton(vapi_msg_nat64_add_del_prefix_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_add_del_prefix_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat64_add_del_prefix_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat64_add_del_prefix_reply_ntoh(vapi_msg_nat64_add_del_prefix_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_add_del_prefix_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat64_add_del_prefix_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat64_st_details_payload_hton(vapi_payload_nat64_st_details *payload)
{
  payload->il_port = htobe16(payload->il_port);
  payload->ol_port = htobe16(payload->ol_port);
  payload->r_port = htobe16(payload->r_port);
  payload->vrf_id = htobe32(payload->vrf_id);
}

static inline void vapi_msg_nat64_st_details_payload_ntoh(vapi_payload_nat64_st_details *payload)
{
  payload->il_port = be16toh(payload->il_port);
  payload->ol_port = be16toh(payload->ol_port);
  payload->r_port = be16toh(payload->r_port);
  payload->vrf_id = be32toh(payload->vrf_id);
}

static inline uword vapi_calc_nat64_st_details_msg_size(vapi_msg_nat64_st_details *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat64_st_details_hton(vapi_msg_nat64_st_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_st_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat64_st_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat64_st_details_ntoh(vapi_msg_nat64_st_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_st_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat64_st_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_snat_show_config_reply_payload_hton(vapi_payload_snat_show_config_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->translation_buckets = htobe32(payload->translation_buckets);
  payload->translation_memory_size = htobe32(payload->translation_memory_size);
  payload->user_buckets = htobe32(payload->user_buckets);
  payload->user_memory_size = htobe32(payload->user_memory_size);
  payload->max_translations_per_user = htobe32(payload->max_translations_per_user);
  payload->outside_vrf_id = htobe32(payload->outside_vrf_id);
  payload->inside_vrf_id = htobe32(payload->inside_vrf_id);
}

static inline void vapi_msg_snat_show_config_reply_payload_ntoh(vapi_payload_snat_show_config_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->translation_buckets = be32toh(payload->translation_buckets);
  payload->translation_memory_size = be32toh(payload->translation_memory_size);
  payload->user_buckets = be32toh(payload->user_buckets);
  payload->user_memory_size = be32toh(payload->user_memory_size);
  payload->max_translations_per_user = be32toh(payload->max_translations_per_user);
  payload->outside_vrf_id = be32toh(payload->outside_vrf_id);
  payload->inside_vrf_id = be32toh(payload->inside_vrf_id);
}

static inline uword vapi_calc_snat_show_config_reply_msg_size(vapi_msg_snat_show_config_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_show_config_reply_hton(vapi_msg_snat_show_config_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_show_config_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_snat_show_config_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_show_config_reply_ntoh(vapi_msg_snat_show_config_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_show_config_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_snat_show_config_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_snat_add_static_mapping_payload_hton(vapi_payload_snat_add_static_mapping *payload)
{
  payload->local_port = htobe16(payload->local_port);
  payload->external_port = htobe16(payload->external_port);
  payload->external_sw_if_index = htobe32(payload->external_sw_if_index);
  payload->vrf_id = htobe32(payload->vrf_id);
}

static inline void vapi_msg_snat_add_static_mapping_payload_ntoh(vapi_payload_snat_add_static_mapping *payload)
{
  payload->local_port = be16toh(payload->local_port);
  payload->external_port = be16toh(payload->external_port);
  payload->external_sw_if_index = be32toh(payload->external_sw_if_index);
  payload->vrf_id = be32toh(payload->vrf_id);
}

static inline uword vapi_calc_snat_add_static_mapping_msg_size(vapi_msg_snat_add_static_mapping *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_add_static_mapping_hton(vapi_msg_snat_add_static_mapping *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_add_static_mapping'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_snat_add_static_mapping_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_add_static_mapping_ntoh(vapi_msg_snat_add_static_mapping *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_add_static_mapping'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_snat_add_static_mapping_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_nat_control_ping_msg_size(vapi_msg_nat_control_ping *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat_control_ping_hton(vapi_msg_nat_control_ping *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_control_ping'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_nat_control_ping_ntoh(vapi_msg_nat_control_ping *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_control_ping'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_nat44_interface_add_del_output_feature_reply_payload_hton(vapi_payload_nat44_interface_add_del_output_feature_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_nat44_interface_add_del_output_feature_reply_payload_ntoh(vapi_payload_nat44_interface_add_del_output_feature_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_nat44_interface_add_del_output_feature_reply_msg_size(vapi_msg_nat44_interface_add_del_output_feature_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat44_interface_add_del_output_feature_reply_hton(vapi_msg_nat44_interface_add_del_output_feature_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_interface_add_del_output_feature_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat44_interface_add_del_output_feature_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat44_interface_add_del_output_feature_reply_ntoh(vapi_msg_nat44_interface_add_del_output_feature_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_interface_add_del_output_feature_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat44_interface_add_del_output_feature_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_snat_add_static_mapping_reply_payload_hton(vapi_payload_snat_add_static_mapping_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_snat_add_static_mapping_reply_payload_ntoh(vapi_payload_snat_add_static_mapping_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_snat_add_static_mapping_reply_msg_size(vapi_msg_snat_add_static_mapping_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_add_static_mapping_reply_hton(vapi_msg_snat_add_static_mapping_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_add_static_mapping_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_snat_add_static_mapping_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_add_static_mapping_reply_ntoh(vapi_msg_snat_add_static_mapping_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_add_static_mapping_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_snat_add_static_mapping_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat64_add_del_interface_payload_hton(vapi_payload_nat64_add_del_interface *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_nat64_add_del_interface_payload_ntoh(vapi_payload_nat64_add_del_interface *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_nat64_add_del_interface_msg_size(vapi_msg_nat64_add_del_interface *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat64_add_del_interface_hton(vapi_msg_nat64_add_del_interface *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_add_del_interface'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_nat64_add_del_interface_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat64_add_del_interface_ntoh(vapi_msg_nat64_add_del_interface *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_add_del_interface'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_nat64_add_del_interface_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat_det_close_session_in_payload_hton(vapi_payload_nat_det_close_session_in *payload)
{
  payload->in_port = htobe16(payload->in_port);
  payload->ext_port = htobe16(payload->ext_port);
}

static inline void vapi_msg_nat_det_close_session_in_payload_ntoh(vapi_payload_nat_det_close_session_in *payload)
{
  payload->in_port = be16toh(payload->in_port);
  payload->ext_port = be16toh(payload->ext_port);
}

static inline uword vapi_calc_nat_det_close_session_in_msg_size(vapi_msg_nat_det_close_session_in *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat_det_close_session_in_hton(vapi_msg_nat_det_close_session_in *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_close_session_in'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_nat_det_close_session_in_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat_det_close_session_in_ntoh(vapi_msg_nat_det_close_session_in *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_close_session_in'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_nat_det_close_session_in_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat44_user_session_dump_payload_hton(vapi_payload_nat44_user_session_dump *payload)
{
  payload->vrf_id = htobe32(payload->vrf_id);
}

static inline void vapi_msg_nat44_user_session_dump_payload_ntoh(vapi_payload_nat44_user_session_dump *payload)
{
  payload->vrf_id = be32toh(payload->vrf_id);
}

static inline uword vapi_calc_nat44_user_session_dump_msg_size(vapi_msg_nat44_user_session_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat44_user_session_dump_hton(vapi_msg_nat44_user_session_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_user_session_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_nat44_user_session_dump_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat44_user_session_dump_ntoh(vapi_msg_nat44_user_session_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_user_session_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_nat44_user_session_dump_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_nat44_static_mapping_dump_msg_size(vapi_msg_nat44_static_mapping_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat44_static_mapping_dump_hton(vapi_msg_nat44_static_mapping_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_static_mapping_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_nat44_static_mapping_dump_ntoh(vapi_msg_nat44_static_mapping_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_static_mapping_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_snat_worker_details_payload_hton(vapi_payload_snat_worker_details *payload)
{
  payload->worker_index = htobe32(payload->worker_index);
  payload->lcore_id = htobe32(payload->lcore_id);
}

static inline void vapi_msg_snat_worker_details_payload_ntoh(vapi_payload_snat_worker_details *payload)
{
  payload->worker_index = be32toh(payload->worker_index);
  payload->lcore_id = be32toh(payload->lcore_id);
}

static inline uword vapi_calc_snat_worker_details_msg_size(vapi_msg_snat_worker_details *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_worker_details_hton(vapi_msg_snat_worker_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_worker_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_snat_worker_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_worker_details_ntoh(vapi_msg_snat_worker_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_worker_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_snat_worker_details_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_snat_det_map_dump_msg_size(vapi_msg_snat_det_map_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_det_map_dump_hton(vapi_msg_snat_det_map_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_det_map_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_snat_det_map_dump_ntoh(vapi_msg_snat_det_map_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_det_map_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_nat64_set_timeouts_reply_payload_hton(vapi_payload_nat64_set_timeouts_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_nat64_set_timeouts_reply_payload_ntoh(vapi_payload_nat64_set_timeouts_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_nat64_set_timeouts_reply_msg_size(vapi_msg_nat64_set_timeouts_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat64_set_timeouts_reply_hton(vapi_msg_nat64_set_timeouts_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_set_timeouts_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat64_set_timeouts_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat64_set_timeouts_reply_ntoh(vapi_msg_nat64_set_timeouts_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_set_timeouts_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat64_set_timeouts_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat44_user_session_details_payload_hton(vapi_payload_nat44_user_session_details *payload)
{
  payload->outside_port = htobe16(payload->outside_port);
  payload->inside_port = htobe16(payload->inside_port);
  payload->protocol = htobe16(payload->protocol);
  payload->last_heard = htobe64(payload->last_heard);
  payload->total_bytes = htobe64(payload->total_bytes);
  payload->total_pkts = htobe32(payload->total_pkts);
}

static inline void vapi_msg_nat44_user_session_details_payload_ntoh(vapi_payload_nat44_user_session_details *payload)
{
  payload->outside_port = be16toh(payload->outside_port);
  payload->inside_port = be16toh(payload->inside_port);
  payload->protocol = be16toh(payload->protocol);
  payload->last_heard = be64toh(payload->last_heard);
  payload->total_bytes = be64toh(payload->total_bytes);
  payload->total_pkts = be32toh(payload->total_pkts);
}

static inline uword vapi_calc_nat44_user_session_details_msg_size(vapi_msg_nat44_user_session_details *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat44_user_session_details_hton(vapi_msg_nat44_user_session_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_user_session_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat44_user_session_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat44_user_session_details_ntoh(vapi_msg_nat44_user_session_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_user_session_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat44_user_session_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_snat_add_del_interface_addr_payload_hton(vapi_payload_snat_add_del_interface_addr *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_snat_add_del_interface_addr_payload_ntoh(vapi_payload_snat_add_del_interface_addr *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_snat_add_del_interface_addr_msg_size(vapi_msg_snat_add_del_interface_addr *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_add_del_interface_addr_hton(vapi_msg_snat_add_del_interface_addr *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_add_del_interface_addr'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_snat_add_del_interface_addr_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_add_del_interface_addr_ntoh(vapi_msg_snat_add_del_interface_addr *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_add_del_interface_addr'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_snat_add_del_interface_addr_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_snat_ipfix_enable_disable_reply_payload_hton(vapi_payload_snat_ipfix_enable_disable_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_snat_ipfix_enable_disable_reply_payload_ntoh(vapi_payload_snat_ipfix_enable_disable_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_snat_ipfix_enable_disable_reply_msg_size(vapi_msg_snat_ipfix_enable_disable_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_ipfix_enable_disable_reply_hton(vapi_msg_snat_ipfix_enable_disable_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_ipfix_enable_disable_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_snat_ipfix_enable_disable_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_ipfix_enable_disable_reply_ntoh(vapi_msg_snat_ipfix_enable_disable_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_ipfix_enable_disable_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_snat_ipfix_enable_disable_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_snat_address_dump_msg_size(vapi_msg_snat_address_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_address_dump_hton(vapi_msg_snat_address_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_address_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_snat_address_dump_ntoh(vapi_msg_snat_address_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_address_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_snat_set_workers_payload_hton(vapi_payload_snat_set_workers *payload)
{
  payload->worker_mask = htobe64(payload->worker_mask);
}

static inline void vapi_msg_snat_set_workers_payload_ntoh(vapi_payload_snat_set_workers *payload)
{
  payload->worker_mask = be64toh(payload->worker_mask);
}

static inline uword vapi_calc_snat_set_workers_msg_size(vapi_msg_snat_set_workers *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_set_workers_hton(vapi_msg_snat_set_workers *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_set_workers'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_snat_set_workers_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_set_workers_ntoh(vapi_msg_snat_set_workers *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_set_workers'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_snat_set_workers_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_nat44_interface_output_feature_dump_msg_size(vapi_msg_nat44_interface_output_feature_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat44_interface_output_feature_dump_hton(vapi_msg_nat44_interface_output_feature_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_interface_output_feature_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_nat44_interface_output_feature_dump_ntoh(vapi_msg_nat44_interface_output_feature_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_interface_output_feature_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_nat44_interface_add_del_feature_payload_hton(vapi_payload_nat44_interface_add_del_feature *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_nat44_interface_add_del_feature_payload_ntoh(vapi_payload_nat44_interface_add_del_feature *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_nat44_interface_add_del_feature_msg_size(vapi_msg_nat44_interface_add_del_feature *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat44_interface_add_del_feature_hton(vapi_msg_nat44_interface_add_del_feature *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_interface_add_del_feature'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_nat44_interface_add_del_feature_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat44_interface_add_del_feature_ntoh(vapi_msg_nat44_interface_add_del_feature *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_interface_add_del_feature'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_nat44_interface_add_del_feature_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat44_interface_output_feature_details_payload_hton(vapi_payload_nat44_interface_output_feature_details *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_nat44_interface_output_feature_details_payload_ntoh(vapi_payload_nat44_interface_output_feature_details *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_nat44_interface_output_feature_details_msg_size(vapi_msg_nat44_interface_output_feature_details *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat44_interface_output_feature_details_hton(vapi_msg_nat44_interface_output_feature_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_interface_output_feature_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat44_interface_output_feature_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat44_interface_output_feature_details_ntoh(vapi_msg_nat44_interface_output_feature_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_interface_output_feature_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat44_interface_output_feature_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat_det_reverse_payload_hton(vapi_payload_nat_det_reverse *payload)
{
  payload->out_port = htobe16(payload->out_port);
}

static inline void vapi_msg_nat_det_reverse_payload_ntoh(vapi_payload_nat_det_reverse *payload)
{
  payload->out_port = be16toh(payload->out_port);
}

static inline uword vapi_calc_nat_det_reverse_msg_size(vapi_msg_nat_det_reverse *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat_det_reverse_hton(vapi_msg_nat_det_reverse *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_reverse'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_nat_det_reverse_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat_det_reverse_ntoh(vapi_msg_nat_det_reverse *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_reverse'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_nat_det_reverse_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat_det_session_details_payload_hton(vapi_payload_nat_det_session_details *payload)
{
  payload->in_port = htobe16(payload->in_port);
  payload->ext_port = htobe16(payload->ext_port);
  payload->out_port = htobe16(payload->out_port);
  payload->expire = htobe32(payload->expire);
}

static inline void vapi_msg_nat_det_session_details_payload_ntoh(vapi_payload_nat_det_session_details *payload)
{
  payload->in_port = be16toh(payload->in_port);
  payload->ext_port = be16toh(payload->ext_port);
  payload->out_port = be16toh(payload->out_port);
  payload->expire = be32toh(payload->expire);
}

static inline uword vapi_calc_nat_det_session_details_msg_size(vapi_msg_nat_det_session_details *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat_det_session_details_hton(vapi_msg_nat_det_session_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_session_details'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_nat_det_session_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat_det_session_details_ntoh(vapi_msg_nat_det_session_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_session_details'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_nat_det_session_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_snat_interface_add_del_output_feature_reply_payload_hton(vapi_payload_snat_interface_add_del_output_feature_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_snat_interface_add_del_output_feature_reply_payload_ntoh(vapi_payload_snat_interface_add_del_output_feature_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_snat_interface_add_del_output_feature_reply_msg_size(vapi_msg_snat_interface_add_del_output_feature_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_interface_add_del_output_feature_reply_hton(vapi_msg_snat_interface_add_del_output_feature_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_interface_add_del_output_feature_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_snat_interface_add_del_output_feature_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_interface_add_del_output_feature_reply_ntoh(vapi_msg_snat_interface_add_del_output_feature_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_interface_add_del_output_feature_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_snat_interface_add_del_output_feature_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat44_interface_add_del_feature_reply_payload_hton(vapi_payload_nat44_interface_add_del_feature_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_nat44_interface_add_del_feature_reply_payload_ntoh(vapi_payload_nat44_interface_add_del_feature_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_nat44_interface_add_del_feature_reply_msg_size(vapi_msg_nat44_interface_add_del_feature_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat44_interface_add_del_feature_reply_hton(vapi_msg_nat44_interface_add_del_feature_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_interface_add_del_feature_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat44_interface_add_del_feature_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat44_interface_add_del_feature_reply_ntoh(vapi_msg_nat44_interface_add_del_feature_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_interface_add_del_feature_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat44_interface_add_del_feature_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat44_add_del_address_range_reply_payload_hton(vapi_payload_nat44_add_del_address_range_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_nat44_add_del_address_range_reply_payload_ntoh(vapi_payload_nat44_add_del_address_range_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_nat44_add_del_address_range_reply_msg_size(vapi_msg_nat44_add_del_address_range_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat44_add_del_address_range_reply_hton(vapi_msg_nat44_add_del_address_range_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_add_del_address_range_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat44_add_del_address_range_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat44_add_del_address_range_reply_ntoh(vapi_msg_nat44_add_del_address_range_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_add_del_address_range_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat44_add_del_address_range_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat64_add_del_interface_reply_payload_hton(vapi_payload_nat64_add_del_interface_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_nat64_add_del_interface_reply_payload_ntoh(vapi_payload_nat64_add_del_interface_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_nat64_add_del_interface_reply_msg_size(vapi_msg_nat64_add_del_interface_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat64_add_del_interface_reply_hton(vapi_msg_nat64_add_del_interface_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_add_del_interface_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat64_add_del_interface_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat64_add_del_interface_reply_ntoh(vapi_msg_nat64_add_del_interface_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_add_del_interface_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat64_add_del_interface_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat_det_forward_payload_hton(vapi_payload_nat_det_forward *payload)
{

}

static inline void vapi_msg_nat_det_forward_payload_ntoh(vapi_payload_nat_det_forward *payload)
{

}

static inline uword vapi_calc_nat_det_forward_msg_size(vapi_msg_nat_det_forward *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat_det_forward_hton(vapi_msg_nat_det_forward *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_forward'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_nat_det_forward_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat_det_forward_ntoh(vapi_msg_nat_det_forward *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_forward'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_nat_det_forward_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_nat_worker_dump_msg_size(vapi_msg_nat_worker_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat_worker_dump_hton(vapi_msg_nat_worker_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_worker_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_nat_worker_dump_ntoh(vapi_msg_nat_worker_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_worker_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline uword vapi_calc_snat_interface_addr_dump_msg_size(vapi_msg_snat_interface_addr_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_interface_addr_dump_hton(vapi_msg_snat_interface_addr_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_interface_addr_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_snat_interface_addr_dump_ntoh(vapi_msg_snat_interface_addr_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_interface_addr_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline uword vapi_calc_nat_det_get_timeouts_msg_size(vapi_msg_nat_det_get_timeouts *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat_det_get_timeouts_hton(vapi_msg_nat_det_get_timeouts *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_get_timeouts'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_nat_det_get_timeouts_ntoh(vapi_msg_nat_det_get_timeouts *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_get_timeouts'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_nat_det_add_del_map_reply_payload_hton(vapi_payload_nat_det_add_del_map_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_nat_det_add_del_map_reply_payload_ntoh(vapi_payload_nat_det_add_del_map_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_nat_det_add_del_map_reply_msg_size(vapi_msg_nat_det_add_del_map_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat_det_add_del_map_reply_hton(vapi_msg_nat_det_add_del_map_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_add_del_map_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat_det_add_del_map_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat_det_add_del_map_reply_ntoh(vapi_msg_nat_det_add_del_map_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_add_del_map_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat_det_add_del_map_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_nat44_interface_addr_dump_msg_size(vapi_msg_nat44_interface_addr_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat44_interface_addr_dump_hton(vapi_msg_nat44_interface_addr_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_interface_addr_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_nat44_interface_addr_dump_ntoh(vapi_msg_nat44_interface_addr_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_interface_addr_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_nat_show_config_reply_payload_hton(vapi_payload_nat_show_config_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->translation_buckets = htobe32(payload->translation_buckets);
  payload->translation_memory_size = htobe32(payload->translation_memory_size);
  payload->user_buckets = htobe32(payload->user_buckets);
  payload->user_memory_size = htobe32(payload->user_memory_size);
  payload->max_translations_per_user = htobe32(payload->max_translations_per_user);
  payload->outside_vrf_id = htobe32(payload->outside_vrf_id);
  payload->inside_vrf_id = htobe32(payload->inside_vrf_id);
}

static inline void vapi_msg_nat_show_config_reply_payload_ntoh(vapi_payload_nat_show_config_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->translation_buckets = be32toh(payload->translation_buckets);
  payload->translation_memory_size = be32toh(payload->translation_memory_size);
  payload->user_buckets = be32toh(payload->user_buckets);
  payload->user_memory_size = be32toh(payload->user_memory_size);
  payload->max_translations_per_user = be32toh(payload->max_translations_per_user);
  payload->outside_vrf_id = be32toh(payload->outside_vrf_id);
  payload->inside_vrf_id = be32toh(payload->inside_vrf_id);
}

static inline uword vapi_calc_nat_show_config_reply_msg_size(vapi_msg_nat_show_config_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat_show_config_reply_hton(vapi_msg_nat_show_config_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_show_config_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat_show_config_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat_show_config_reply_ntoh(vapi_msg_nat_show_config_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_show_config_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat_show_config_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat44_add_del_lb_static_mapping_reply_payload_hton(vapi_payload_nat44_add_del_lb_static_mapping_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_nat44_add_del_lb_static_mapping_reply_payload_ntoh(vapi_payload_nat44_add_del_lb_static_mapping_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_nat44_add_del_lb_static_mapping_reply_msg_size(vapi_msg_nat44_add_del_lb_static_mapping_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat44_add_del_lb_static_mapping_reply_hton(vapi_msg_nat44_add_del_lb_static_mapping_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_add_del_lb_static_mapping_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat44_add_del_lb_static_mapping_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat44_add_del_lb_static_mapping_reply_ntoh(vapi_msg_nat44_add_del_lb_static_mapping_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_add_del_lb_static_mapping_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat44_add_del_lb_static_mapping_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_snat_det_get_timeouts_reply_payload_hton(vapi_payload_snat_det_get_timeouts_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->udp = htobe32(payload->udp);
  payload->tcp_established = htobe32(payload->tcp_established);
  payload->tcp_transitory = htobe32(payload->tcp_transitory);
  payload->icmp = htobe32(payload->icmp);
}

static inline void vapi_msg_snat_det_get_timeouts_reply_payload_ntoh(vapi_payload_snat_det_get_timeouts_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->udp = be32toh(payload->udp);
  payload->tcp_established = be32toh(payload->tcp_established);
  payload->tcp_transitory = be32toh(payload->tcp_transitory);
  payload->icmp = be32toh(payload->icmp);
}

static inline uword vapi_calc_snat_det_get_timeouts_reply_msg_size(vapi_msg_snat_det_get_timeouts_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_det_get_timeouts_reply_hton(vapi_msg_snat_det_get_timeouts_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_det_get_timeouts_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_snat_det_get_timeouts_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_det_get_timeouts_reply_ntoh(vapi_msg_snat_det_get_timeouts_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_det_get_timeouts_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_snat_det_get_timeouts_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_snat_user_details_payload_hton(vapi_payload_snat_user_details *payload)
{
  payload->vrf_id = htobe32(payload->vrf_id);
  payload->nsessions = htobe32(payload->nsessions);
  payload->nstaticsessions = htobe32(payload->nstaticsessions);
}

static inline void vapi_msg_snat_user_details_payload_ntoh(vapi_payload_snat_user_details *payload)
{
  payload->vrf_id = be32toh(payload->vrf_id);
  payload->nsessions = be32toh(payload->nsessions);
  payload->nstaticsessions = be32toh(payload->nstaticsessions);
}

static inline uword vapi_calc_snat_user_details_msg_size(vapi_msg_snat_user_details *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_user_details_hton(vapi_msg_snat_user_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_user_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_snat_user_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_user_details_ntoh(vapi_msg_snat_user_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_user_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_snat_user_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_snat_det_close_session_in_reply_payload_hton(vapi_payload_snat_det_close_session_in_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_snat_det_close_session_in_reply_payload_ntoh(vapi_payload_snat_det_close_session_in_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_snat_det_close_session_in_reply_msg_size(vapi_msg_snat_det_close_session_in_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_det_close_session_in_reply_hton(vapi_msg_snat_det_close_session_in_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_det_close_session_in_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_snat_det_close_session_in_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_det_close_session_in_reply_ntoh(vapi_msg_snat_det_close_session_in_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_det_close_session_in_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_snat_det_close_session_in_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat64_add_del_static_bib_reply_payload_hton(vapi_payload_nat64_add_del_static_bib_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_nat64_add_del_static_bib_reply_payload_ntoh(vapi_payload_nat64_add_del_static_bib_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_nat64_add_del_static_bib_reply_msg_size(vapi_msg_nat64_add_del_static_bib_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat64_add_del_static_bib_reply_hton(vapi_msg_nat64_add_del_static_bib_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_add_del_static_bib_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat64_add_del_static_bib_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat64_add_del_static_bib_reply_ntoh(vapi_msg_nat64_add_del_static_bib_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_add_del_static_bib_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat64_add_del_static_bib_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat44_address_details_payload_hton(vapi_payload_nat44_address_details *payload)
{
  payload->vrf_id = htobe32(payload->vrf_id);
}

static inline void vapi_msg_nat44_address_details_payload_ntoh(vapi_payload_nat44_address_details *payload)
{
  payload->vrf_id = be32toh(payload->vrf_id);
}

static inline uword vapi_calc_nat44_address_details_msg_size(vapi_msg_nat44_address_details *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat44_address_details_hton(vapi_msg_nat44_address_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_address_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat44_address_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat44_address_details_ntoh(vapi_msg_nat44_address_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_address_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat44_address_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat44_add_del_lb_static_mapping_payload_hton(vapi_payload_nat44_add_del_lb_static_mapping *payload)
{
  payload->external_port = htobe16(payload->external_port);
  payload->vrf_id = htobe32(payload->vrf_id);
  do { unsigned i; for (i = 0; i < payload->local_num; ++i) { vapi_type_nat44_lb_addr_port_hton(&payload->locals[i]); } } while(0);
}

static inline void vapi_msg_nat44_add_del_lb_static_mapping_payload_ntoh(vapi_payload_nat44_add_del_lb_static_mapping *payload)
{
  payload->external_port = be16toh(payload->external_port);
  payload->vrf_id = be32toh(payload->vrf_id);
  do { unsigned i; for (i = 0; i < payload->local_num; ++i) { vapi_type_nat44_lb_addr_port_ntoh(&payload->locals[i]); } } while(0);
}

static inline uword vapi_calc_nat44_add_del_lb_static_mapping_msg_size(vapi_msg_nat44_add_del_lb_static_mapping *msg)
{
  return sizeof(*msg)+ msg->payload.local_num * sizeof(msg->payload.locals[0]);
}

static inline void vapi_msg_nat44_add_del_lb_static_mapping_hton(vapi_msg_nat44_add_del_lb_static_mapping *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_add_del_lb_static_mapping'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_nat44_add_del_lb_static_mapping_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat44_add_del_lb_static_mapping_ntoh(vapi_msg_nat44_add_del_lb_static_mapping *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_add_del_lb_static_mapping'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_nat44_add_del_lb_static_mapping_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat_det_set_timeouts_payload_hton(vapi_payload_nat_det_set_timeouts *payload)
{
  payload->udp = htobe32(payload->udp);
  payload->tcp_established = htobe32(payload->tcp_established);
  payload->tcp_transitory = htobe32(payload->tcp_transitory);
  payload->icmp = htobe32(payload->icmp);
}

static inline void vapi_msg_nat_det_set_timeouts_payload_ntoh(vapi_payload_nat_det_set_timeouts *payload)
{
  payload->udp = be32toh(payload->udp);
  payload->tcp_established = be32toh(payload->tcp_established);
  payload->tcp_transitory = be32toh(payload->tcp_transitory);
  payload->icmp = be32toh(payload->icmp);
}

static inline uword vapi_calc_nat_det_set_timeouts_msg_size(vapi_msg_nat_det_set_timeouts *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat_det_set_timeouts_hton(vapi_msg_nat_det_set_timeouts *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_set_timeouts'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_nat_det_set_timeouts_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat_det_set_timeouts_ntoh(vapi_msg_nat_det_set_timeouts *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_set_timeouts'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_nat_det_set_timeouts_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_snat_user_dump_msg_size(vapi_msg_snat_user_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_user_dump_hton(vapi_msg_snat_user_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_user_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_snat_user_dump_ntoh(vapi_msg_snat_user_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_user_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_snat_add_del_interface_addr_reply_payload_hton(vapi_payload_snat_add_del_interface_addr_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_snat_add_del_interface_addr_reply_payload_ntoh(vapi_payload_snat_add_del_interface_addr_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_snat_add_del_interface_addr_reply_msg_size(vapi_msg_snat_add_del_interface_addr_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_add_del_interface_addr_reply_hton(vapi_msg_snat_add_del_interface_addr_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_add_del_interface_addr_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_snat_add_del_interface_addr_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_add_del_interface_addr_reply_ntoh(vapi_msg_snat_add_del_interface_addr_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_add_del_interface_addr_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_snat_add_del_interface_addr_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_snat_set_workers_reply_payload_hton(vapi_payload_snat_set_workers_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_snat_set_workers_reply_payload_ntoh(vapi_payload_snat_set_workers_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_snat_set_workers_reply_msg_size(vapi_msg_snat_set_workers_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_set_workers_reply_hton(vapi_msg_snat_set_workers_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_set_workers_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_snat_set_workers_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_set_workers_reply_ntoh(vapi_msg_snat_set_workers_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_set_workers_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_snat_set_workers_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_snat_det_forward_reply_payload_hton(vapi_payload_snat_det_forward_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->out_port_lo = htobe16(payload->out_port_lo);
  payload->out_port_hi = htobe16(payload->out_port_hi);
}

static inline void vapi_msg_snat_det_forward_reply_payload_ntoh(vapi_payload_snat_det_forward_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->out_port_lo = be16toh(payload->out_port_lo);
  payload->out_port_hi = be16toh(payload->out_port_hi);
}

static inline uword vapi_calc_snat_det_forward_reply_msg_size(vapi_msg_snat_det_forward_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_det_forward_reply_hton(vapi_msg_snat_det_forward_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_det_forward_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_snat_det_forward_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_det_forward_reply_ntoh(vapi_msg_snat_det_forward_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_det_forward_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_snat_det_forward_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat_det_close_session_out_payload_hton(vapi_payload_nat_det_close_session_out *payload)
{
  payload->out_port = htobe16(payload->out_port);
  payload->ext_port = htobe16(payload->ext_port);
}

static inline void vapi_msg_nat_det_close_session_out_payload_ntoh(vapi_payload_nat_det_close_session_out *payload)
{
  payload->out_port = be16toh(payload->out_port);
  payload->ext_port = be16toh(payload->ext_port);
}

static inline uword vapi_calc_nat_det_close_session_out_msg_size(vapi_msg_nat_det_close_session_out *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat_det_close_session_out_hton(vapi_msg_nat_det_close_session_out *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_close_session_out'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_nat_det_close_session_out_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat_det_close_session_out_ntoh(vapi_msg_nat_det_close_session_out *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_close_session_out'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_nat_det_close_session_out_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_snat_det_reverse_reply_payload_hton(vapi_payload_snat_det_reverse_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_snat_det_reverse_reply_payload_ntoh(vapi_payload_snat_det_reverse_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_snat_det_reverse_reply_msg_size(vapi_msg_snat_det_reverse_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_det_reverse_reply_hton(vapi_msg_snat_det_reverse_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_det_reverse_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_snat_det_reverse_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_det_reverse_reply_ntoh(vapi_msg_snat_det_reverse_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_det_reverse_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_snat_det_reverse_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat_det_session_dump_payload_hton(vapi_payload_nat_det_session_dump *payload)
{

}

static inline void vapi_msg_nat_det_session_dump_payload_ntoh(vapi_payload_nat_det_session_dump *payload)
{

}

static inline uword vapi_calc_nat_det_session_dump_msg_size(vapi_msg_nat_det_session_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat_det_session_dump_hton(vapi_msg_nat_det_session_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_session_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_nat_det_session_dump_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat_det_session_dump_ntoh(vapi_msg_nat_det_session_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_session_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_nat_det_session_dump_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat44_user_details_payload_hton(vapi_payload_nat44_user_details *payload)
{
  payload->vrf_id = htobe32(payload->vrf_id);
  payload->nsessions = htobe32(payload->nsessions);
  payload->nstaticsessions = htobe32(payload->nstaticsessions);
}

static inline void vapi_msg_nat44_user_details_payload_ntoh(vapi_payload_nat44_user_details *payload)
{
  payload->vrf_id = be32toh(payload->vrf_id);
  payload->nsessions = be32toh(payload->nsessions);
  payload->nstaticsessions = be32toh(payload->nstaticsessions);
}

static inline uword vapi_calc_nat44_user_details_msg_size(vapi_msg_nat44_user_details *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat44_user_details_hton(vapi_msg_nat44_user_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_user_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat44_user_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat44_user_details_ntoh(vapi_msg_nat44_user_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_user_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat44_user_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat_det_forward_reply_payload_hton(vapi_payload_nat_det_forward_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->out_port_lo = htobe16(payload->out_port_lo);
  payload->out_port_hi = htobe16(payload->out_port_hi);
}

static inline void vapi_msg_nat_det_forward_reply_payload_ntoh(vapi_payload_nat_det_forward_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->out_port_lo = be16toh(payload->out_port_lo);
  payload->out_port_hi = be16toh(payload->out_port_hi);
}

static inline uword vapi_calc_nat_det_forward_reply_msg_size(vapi_msg_nat_det_forward_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat_det_forward_reply_hton(vapi_msg_nat_det_forward_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_forward_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat_det_forward_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat_det_forward_reply_ntoh(vapi_msg_nat_det_forward_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_forward_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat_det_forward_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat64_set_timeouts_payload_hton(vapi_payload_nat64_set_timeouts *payload)
{
  payload->udp = htobe32(payload->udp);
  payload->icmp = htobe32(payload->icmp);
  payload->tcp_trans = htobe32(payload->tcp_trans);
  payload->tcp_est = htobe32(payload->tcp_est);
  payload->tcp_incoming_syn = htobe32(payload->tcp_incoming_syn);
}

static inline void vapi_msg_nat64_set_timeouts_payload_ntoh(vapi_payload_nat64_set_timeouts *payload)
{
  payload->udp = be32toh(payload->udp);
  payload->icmp = be32toh(payload->icmp);
  payload->tcp_trans = be32toh(payload->tcp_trans);
  payload->tcp_est = be32toh(payload->tcp_est);
  payload->tcp_incoming_syn = be32toh(payload->tcp_incoming_syn);
}

static inline uword vapi_calc_nat64_set_timeouts_msg_size(vapi_msg_nat64_set_timeouts *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat64_set_timeouts_hton(vapi_msg_nat64_set_timeouts *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_set_timeouts'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_nat64_set_timeouts_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat64_set_timeouts_ntoh(vapi_msg_nat64_set_timeouts *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_set_timeouts'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_nat64_set_timeouts_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat44_interface_addr_details_payload_hton(vapi_payload_nat44_interface_addr_details *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_nat44_interface_addr_details_payload_ntoh(vapi_payload_nat44_interface_addr_details *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_nat44_interface_addr_details_msg_size(vapi_msg_nat44_interface_addr_details *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat44_interface_addr_details_hton(vapi_msg_nat44_interface_addr_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_interface_addr_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat44_interface_addr_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat44_interface_addr_details_ntoh(vapi_msg_nat44_interface_addr_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_interface_addr_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat44_interface_addr_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_snat_address_details_payload_hton(vapi_payload_snat_address_details *payload)
{
  payload->vrf_id = htobe32(payload->vrf_id);
}

static inline void vapi_msg_snat_address_details_payload_ntoh(vapi_payload_snat_address_details *payload)
{
  payload->vrf_id = be32toh(payload->vrf_id);
}

static inline uword vapi_calc_snat_address_details_msg_size(vapi_msg_snat_address_details *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_address_details_hton(vapi_msg_snat_address_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_address_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_snat_address_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_address_details_ntoh(vapi_msg_snat_address_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_address_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_snat_address_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat64_add_del_pool_addr_range_reply_payload_hton(vapi_payload_nat64_add_del_pool_addr_range_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_nat64_add_del_pool_addr_range_reply_payload_ntoh(vapi_payload_nat64_add_del_pool_addr_range_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_nat64_add_del_pool_addr_range_reply_msg_size(vapi_msg_nat64_add_del_pool_addr_range_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat64_add_del_pool_addr_range_reply_hton(vapi_msg_nat64_add_del_pool_addr_range_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_add_del_pool_addr_range_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat64_add_del_pool_addr_range_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat64_add_del_pool_addr_range_reply_ntoh(vapi_msg_nat64_add_del_pool_addr_range_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_add_del_pool_addr_range_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat64_add_del_pool_addr_range_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_snat_det_session_dump_payload_hton(vapi_payload_snat_det_session_dump *payload)
{

}

static inline void vapi_msg_snat_det_session_dump_payload_ntoh(vapi_payload_snat_det_session_dump *payload)
{

}

static inline uword vapi_calc_snat_det_session_dump_msg_size(vapi_msg_snat_det_session_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_det_session_dump_hton(vapi_msg_snat_det_session_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_det_session_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_snat_det_session_dump_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_det_session_dump_ntoh(vapi_msg_snat_det_session_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_det_session_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_snat_det_session_dump_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_nat64_get_timeouts_msg_size(vapi_msg_nat64_get_timeouts *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat64_get_timeouts_hton(vapi_msg_nat64_get_timeouts *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_get_timeouts'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_nat64_get_timeouts_ntoh(vapi_msg_nat64_get_timeouts *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_get_timeouts'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_snat_add_det_map_payload_hton(vapi_payload_snat_add_det_map *payload)
{

}

static inline void vapi_msg_snat_add_det_map_payload_ntoh(vapi_payload_snat_add_det_map *payload)
{

}

static inline uword vapi_calc_snat_add_det_map_msg_size(vapi_msg_snat_add_det_map *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_add_det_map_hton(vapi_msg_snat_add_det_map *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_add_det_map'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_snat_add_det_map_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_add_det_map_ntoh(vapi_msg_snat_add_det_map *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_add_det_map'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_snat_add_det_map_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat_det_close_session_out_reply_payload_hton(vapi_payload_nat_det_close_session_out_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_nat_det_close_session_out_reply_payload_ntoh(vapi_payload_nat_det_close_session_out_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_nat_det_close_session_out_reply_msg_size(vapi_msg_nat_det_close_session_out_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat_det_close_session_out_reply_hton(vapi_msg_nat_det_close_session_out_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_close_session_out_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat_det_close_session_out_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat_det_close_session_out_reply_ntoh(vapi_msg_nat_det_close_session_out_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_close_session_out_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat_det_close_session_out_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_nat_show_config_msg_size(vapi_msg_nat_show_config *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat_show_config_hton(vapi_msg_nat_show_config *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_show_config'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_nat_show_config_ntoh(vapi_msg_nat_show_config *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_show_config'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_snat_det_session_details_payload_hton(vapi_payload_snat_det_session_details *payload)
{
  payload->in_port = htobe16(payload->in_port);
  payload->ext_port = htobe16(payload->ext_port);
  payload->out_port = htobe16(payload->out_port);
  payload->expire = htobe32(payload->expire);
}

static inline void vapi_msg_snat_det_session_details_payload_ntoh(vapi_payload_snat_det_session_details *payload)
{
  payload->in_port = be16toh(payload->in_port);
  payload->ext_port = be16toh(payload->ext_port);
  payload->out_port = be16toh(payload->out_port);
  payload->expire = be32toh(payload->expire);
}

static inline uword vapi_calc_snat_det_session_details_msg_size(vapi_msg_snat_det_session_details *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_det_session_details_hton(vapi_msg_snat_det_session_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_det_session_details'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_snat_det_session_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_det_session_details_ntoh(vapi_msg_snat_det_session_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_det_session_details'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_snat_det_session_details_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_nat44_address_dump_msg_size(vapi_msg_nat44_address_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat44_address_dump_hton(vapi_msg_nat44_address_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_address_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_nat44_address_dump_ntoh(vapi_msg_nat44_address_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_address_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_snat_det_forward_payload_hton(vapi_payload_snat_det_forward *payload)
{

}

static inline void vapi_msg_snat_det_forward_payload_ntoh(vapi_payload_snat_det_forward *payload)
{

}

static inline uword vapi_calc_snat_det_forward_msg_size(vapi_msg_snat_det_forward *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_det_forward_hton(vapi_msg_snat_det_forward *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_det_forward'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_snat_det_forward_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_det_forward_ntoh(vapi_msg_snat_det_forward *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_det_forward'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_snat_det_forward_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_nat44_interface_dump_msg_size(vapi_msg_nat44_interface_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat44_interface_dump_hton(vapi_msg_nat44_interface_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_interface_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_nat44_interface_dump_ntoh(vapi_msg_nat44_interface_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_interface_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_nat64_interface_details_payload_hton(vapi_payload_nat64_interface_details *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_nat64_interface_details_payload_ntoh(vapi_payload_nat64_interface_details *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_nat64_interface_details_msg_size(vapi_msg_nat64_interface_details *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat64_interface_details_hton(vapi_msg_nat64_interface_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_interface_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat64_interface_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat64_interface_details_ntoh(vapi_msg_nat64_interface_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_interface_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat64_interface_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat64_bib_dump_payload_hton(vapi_payload_nat64_bib_dump *payload)
{

}

static inline void vapi_msg_nat64_bib_dump_payload_ntoh(vapi_payload_nat64_bib_dump *payload)
{

}

static inline uword vapi_calc_nat64_bib_dump_msg_size(vapi_msg_nat64_bib_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat64_bib_dump_hton(vapi_msg_nat64_bib_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_bib_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_nat64_bib_dump_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat64_bib_dump_ntoh(vapi_msg_nat64_bib_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_bib_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_nat64_bib_dump_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat64_add_del_pool_addr_range_payload_hton(vapi_payload_nat64_add_del_pool_addr_range *payload)
{
  payload->vrf_id = htobe32(payload->vrf_id);
}

static inline void vapi_msg_nat64_add_del_pool_addr_range_payload_ntoh(vapi_payload_nat64_add_del_pool_addr_range *payload)
{
  payload->vrf_id = be32toh(payload->vrf_id);
}

static inline uword vapi_calc_nat64_add_del_pool_addr_range_msg_size(vapi_msg_nat64_add_del_pool_addr_range *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat64_add_del_pool_addr_range_hton(vapi_msg_nat64_add_del_pool_addr_range *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_add_del_pool_addr_range'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_nat64_add_del_pool_addr_range_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat64_add_del_pool_addr_range_ntoh(vapi_msg_nat64_add_del_pool_addr_range *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_add_del_pool_addr_range'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_nat64_add_del_pool_addr_range_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat64_bib_details_payload_hton(vapi_payload_nat64_bib_details *payload)
{
  payload->i_port = htobe16(payload->i_port);
  payload->o_port = htobe16(payload->o_port);
  payload->vrf_id = htobe32(payload->vrf_id);
  payload->ses_num = htobe32(payload->ses_num);
}

static inline void vapi_msg_nat64_bib_details_payload_ntoh(vapi_payload_nat64_bib_details *payload)
{
  payload->i_port = be16toh(payload->i_port);
  payload->o_port = be16toh(payload->o_port);
  payload->vrf_id = be32toh(payload->vrf_id);
  payload->ses_num = be32toh(payload->ses_num);
}

static inline uword vapi_calc_nat64_bib_details_msg_size(vapi_msg_nat64_bib_details *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat64_bib_details_hton(vapi_msg_nat64_bib_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_bib_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat64_bib_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat64_bib_details_ntoh(vapi_msg_nat64_bib_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_bib_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat64_bib_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat64_get_timeouts_reply_payload_hton(vapi_payload_nat64_get_timeouts_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->udp = htobe32(payload->udp);
  payload->icmp = htobe32(payload->icmp);
  payload->tcp_trans = htobe32(payload->tcp_trans);
  payload->tcp_est = htobe32(payload->tcp_est);
  payload->tcp_incoming_syn = htobe32(payload->tcp_incoming_syn);
}

static inline void vapi_msg_nat64_get_timeouts_reply_payload_ntoh(vapi_payload_nat64_get_timeouts_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->udp = be32toh(payload->udp);
  payload->icmp = be32toh(payload->icmp);
  payload->tcp_trans = be32toh(payload->tcp_trans);
  payload->tcp_est = be32toh(payload->tcp_est);
  payload->tcp_incoming_syn = be32toh(payload->tcp_incoming_syn);
}

static inline uword vapi_calc_nat64_get_timeouts_reply_msg_size(vapi_msg_nat64_get_timeouts_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat64_get_timeouts_reply_hton(vapi_msg_nat64_get_timeouts_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_get_timeouts_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat64_get_timeouts_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat64_get_timeouts_reply_ntoh(vapi_msg_nat64_get_timeouts_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_get_timeouts_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat64_get_timeouts_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_nat64_prefix_dump_msg_size(vapi_msg_nat64_prefix_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat64_prefix_dump_hton(vapi_msg_nat64_prefix_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_prefix_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_nat64_prefix_dump_ntoh(vapi_msg_nat64_prefix_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_prefix_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline uword vapi_calc_nat_det_map_dump_msg_size(vapi_msg_nat_det_map_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat_det_map_dump_hton(vapi_msg_nat_det_map_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_map_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_nat_det_map_dump_ntoh(vapi_msg_nat_det_map_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_map_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_snat_interface_addr_details_payload_hton(vapi_payload_snat_interface_addr_details *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_snat_interface_addr_details_payload_ntoh(vapi_payload_snat_interface_addr_details *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_snat_interface_addr_details_msg_size(vapi_msg_snat_interface_addr_details *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_interface_addr_details_hton(vapi_msg_snat_interface_addr_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_interface_addr_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_snat_interface_addr_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_interface_addr_details_ntoh(vapi_msg_snat_interface_addr_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_interface_addr_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_snat_interface_addr_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat_det_close_session_in_reply_payload_hton(vapi_payload_nat_det_close_session_in_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_nat_det_close_session_in_reply_payload_ntoh(vapi_payload_nat_det_close_session_in_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_nat_det_close_session_in_reply_msg_size(vapi_msg_nat_det_close_session_in_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat_det_close_session_in_reply_hton(vapi_msg_nat_det_close_session_in_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_close_session_in_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat_det_close_session_in_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat_det_close_session_in_reply_ntoh(vapi_msg_nat_det_close_session_in_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_close_session_in_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat_det_close_session_in_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_snat_det_map_details_payload_hton(vapi_payload_snat_det_map_details *payload)
{
  payload->sharing_ratio = htobe32(payload->sharing_ratio);
  payload->ports_per_host = htobe16(payload->ports_per_host);
  payload->ses_num = htobe32(payload->ses_num);
}

static inline void vapi_msg_snat_det_map_details_payload_ntoh(vapi_payload_snat_det_map_details *payload)
{
  payload->sharing_ratio = be32toh(payload->sharing_ratio);
  payload->ports_per_host = be16toh(payload->ports_per_host);
  payload->ses_num = be32toh(payload->ses_num);
}

static inline uword vapi_calc_snat_det_map_details_msg_size(vapi_msg_snat_det_map_details *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_det_map_details_hton(vapi_msg_snat_det_map_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_det_map_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_snat_det_map_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_det_map_details_ntoh(vapi_msg_snat_det_map_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_det_map_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_snat_det_map_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat_set_workers_payload_hton(vapi_payload_nat_set_workers *payload)
{
  payload->worker_mask = htobe64(payload->worker_mask);
}

static inline void vapi_msg_nat_set_workers_payload_ntoh(vapi_payload_nat_set_workers *payload)
{
  payload->worker_mask = be64toh(payload->worker_mask);
}

static inline uword vapi_calc_nat_set_workers_msg_size(vapi_msg_nat_set_workers *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat_set_workers_hton(vapi_msg_nat_set_workers *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_set_workers'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_nat_set_workers_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat_set_workers_ntoh(vapi_msg_nat_set_workers *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_set_workers'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_nat_set_workers_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat64_add_del_prefix_payload_hton(vapi_payload_nat64_add_del_prefix *payload)
{
  payload->vrf_id = htobe32(payload->vrf_id);
}

static inline void vapi_msg_nat64_add_del_prefix_payload_ntoh(vapi_payload_nat64_add_del_prefix *payload)
{
  payload->vrf_id = be32toh(payload->vrf_id);
}

static inline uword vapi_calc_nat64_add_del_prefix_msg_size(vapi_msg_nat64_add_del_prefix *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat64_add_del_prefix_hton(vapi_msg_nat64_add_del_prefix *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_add_del_prefix'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_nat64_add_del_prefix_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat64_add_del_prefix_ntoh(vapi_msg_nat64_add_del_prefix *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_add_del_prefix'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_nat64_add_del_prefix_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_snat_add_address_range_reply_payload_hton(vapi_payload_snat_add_address_range_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_snat_add_address_range_reply_payload_ntoh(vapi_payload_snat_add_address_range_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_snat_add_address_range_reply_msg_size(vapi_msg_snat_add_address_range_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_add_address_range_reply_hton(vapi_msg_snat_add_address_range_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_add_address_range_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_snat_add_address_range_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_add_address_range_reply_ntoh(vapi_msg_snat_add_address_range_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_add_address_range_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_snat_add_address_range_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat_ipfix_enable_disable_reply_payload_hton(vapi_payload_nat_ipfix_enable_disable_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_nat_ipfix_enable_disable_reply_payload_ntoh(vapi_payload_nat_ipfix_enable_disable_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_nat_ipfix_enable_disable_reply_msg_size(vapi_msg_nat_ipfix_enable_disable_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat_ipfix_enable_disable_reply_hton(vapi_msg_nat_ipfix_enable_disable_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_ipfix_enable_disable_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat_ipfix_enable_disable_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat_ipfix_enable_disable_reply_ntoh(vapi_msg_nat_ipfix_enable_disable_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_ipfix_enable_disable_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat_ipfix_enable_disable_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat64_pool_addr_details_payload_hton(vapi_payload_nat64_pool_addr_details *payload)
{
  payload->vrf_id = htobe32(payload->vrf_id);
}

static inline void vapi_msg_nat64_pool_addr_details_payload_ntoh(vapi_payload_nat64_pool_addr_details *payload)
{
  payload->vrf_id = be32toh(payload->vrf_id);
}

static inline uword vapi_calc_nat64_pool_addr_details_msg_size(vapi_msg_nat64_pool_addr_details *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat64_pool_addr_details_hton(vapi_msg_nat64_pool_addr_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_pool_addr_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat64_pool_addr_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat64_pool_addr_details_ntoh(vapi_msg_nat64_pool_addr_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_pool_addr_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat64_pool_addr_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_snat_det_reverse_payload_hton(vapi_payload_snat_det_reverse *payload)
{
  payload->out_port = htobe16(payload->out_port);
}

static inline void vapi_msg_snat_det_reverse_payload_ntoh(vapi_payload_snat_det_reverse *payload)
{
  payload->out_port = be16toh(payload->out_port);
}

static inline uword vapi_calc_snat_det_reverse_msg_size(vapi_msg_snat_det_reverse *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_det_reverse_hton(vapi_msg_snat_det_reverse *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_det_reverse'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_snat_det_reverse_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_det_reverse_ntoh(vapi_msg_snat_det_reverse *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_det_reverse'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_snat_det_reverse_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat_worker_details_payload_hton(vapi_payload_nat_worker_details *payload)
{
  payload->worker_index = htobe32(payload->worker_index);
  payload->lcore_id = htobe32(payload->lcore_id);
}

static inline void vapi_msg_nat_worker_details_payload_ntoh(vapi_payload_nat_worker_details *payload)
{
  payload->worker_index = be32toh(payload->worker_index);
  payload->lcore_id = be32toh(payload->lcore_id);
}

static inline uword vapi_calc_nat_worker_details_msg_size(vapi_msg_nat_worker_details *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat_worker_details_hton(vapi_msg_nat_worker_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_worker_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat_worker_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat_worker_details_ntoh(vapi_msg_nat_worker_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_worker_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat_worker_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat44_interface_add_del_output_feature_payload_hton(vapi_payload_nat44_interface_add_del_output_feature *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_nat44_interface_add_del_output_feature_payload_ntoh(vapi_payload_nat44_interface_add_del_output_feature *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_nat44_interface_add_del_output_feature_msg_size(vapi_msg_nat44_interface_add_del_output_feature *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat44_interface_add_del_output_feature_hton(vapi_msg_nat44_interface_add_del_output_feature *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_interface_add_del_output_feature'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_nat44_interface_add_del_output_feature_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat44_interface_add_del_output_feature_ntoh(vapi_msg_nat44_interface_add_del_output_feature *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_interface_add_del_output_feature'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_nat44_interface_add_del_output_feature_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat44_add_del_static_mapping_reply_payload_hton(vapi_payload_nat44_add_del_static_mapping_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_nat44_add_del_static_mapping_reply_payload_ntoh(vapi_payload_nat44_add_del_static_mapping_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_nat44_add_del_static_mapping_reply_msg_size(vapi_msg_nat44_add_del_static_mapping_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat44_add_del_static_mapping_reply_hton(vapi_msg_nat44_add_del_static_mapping_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_add_del_static_mapping_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat44_add_del_static_mapping_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat44_add_del_static_mapping_reply_ntoh(vapi_msg_nat44_add_del_static_mapping_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_add_del_static_mapping_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat44_add_del_static_mapping_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat44_add_del_interface_addr_reply_payload_hton(vapi_payload_nat44_add_del_interface_addr_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_nat44_add_del_interface_addr_reply_payload_ntoh(vapi_payload_nat44_add_del_interface_addr_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_nat44_add_del_interface_addr_reply_msg_size(vapi_msg_nat44_add_del_interface_addr_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat44_add_del_interface_addr_reply_hton(vapi_msg_nat44_add_del_interface_addr_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_add_del_interface_addr_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat44_add_del_interface_addr_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat44_add_del_interface_addr_reply_ntoh(vapi_msg_nat44_add_del_interface_addr_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_add_del_interface_addr_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat44_add_del_interface_addr_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_snat_det_close_session_out_payload_hton(vapi_payload_snat_det_close_session_out *payload)
{
  payload->out_port = htobe16(payload->out_port);
  payload->ext_port = htobe16(payload->ext_port);
}

static inline void vapi_msg_snat_det_close_session_out_payload_ntoh(vapi_payload_snat_det_close_session_out *payload)
{
  payload->out_port = be16toh(payload->out_port);
  payload->ext_port = be16toh(payload->ext_port);
}

static inline uword vapi_calc_snat_det_close_session_out_msg_size(vapi_msg_snat_det_close_session_out *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_det_close_session_out_hton(vapi_msg_snat_det_close_session_out *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_det_close_session_out'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_snat_det_close_session_out_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_det_close_session_out_ntoh(vapi_msg_snat_det_close_session_out *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_det_close_session_out'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_snat_det_close_session_out_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_snat_det_close_session_out_reply_payload_hton(vapi_payload_snat_det_close_session_out_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_snat_det_close_session_out_reply_payload_ntoh(vapi_payload_snat_det_close_session_out_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_snat_det_close_session_out_reply_msg_size(vapi_msg_snat_det_close_session_out_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_det_close_session_out_reply_hton(vapi_msg_snat_det_close_session_out_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_det_close_session_out_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_snat_det_close_session_out_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_det_close_session_out_reply_ntoh(vapi_msg_snat_det_close_session_out_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_det_close_session_out_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_snat_det_close_session_out_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_snat_det_set_timeouts_reply_payload_hton(vapi_payload_snat_det_set_timeouts_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_snat_det_set_timeouts_reply_payload_ntoh(vapi_payload_snat_det_set_timeouts_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_snat_det_set_timeouts_reply_msg_size(vapi_msg_snat_det_set_timeouts_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_det_set_timeouts_reply_hton(vapi_msg_snat_det_set_timeouts_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_det_set_timeouts_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_snat_det_set_timeouts_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_det_set_timeouts_reply_ntoh(vapi_msg_snat_det_set_timeouts_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_det_set_timeouts_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_snat_det_set_timeouts_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat44_add_del_interface_addr_payload_hton(vapi_payload_nat44_add_del_interface_addr *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_nat44_add_del_interface_addr_payload_ntoh(vapi_payload_nat44_add_del_interface_addr *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_nat44_add_del_interface_addr_msg_size(vapi_msg_nat44_add_del_interface_addr *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat44_add_del_interface_addr_hton(vapi_msg_nat44_add_del_interface_addr *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_add_del_interface_addr'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_nat44_add_del_interface_addr_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat44_add_del_interface_addr_ntoh(vapi_msg_nat44_add_del_interface_addr *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_add_del_interface_addr'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_nat44_add_del_interface_addr_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat_det_map_details_payload_hton(vapi_payload_nat_det_map_details *payload)
{
  payload->sharing_ratio = htobe32(payload->sharing_ratio);
  payload->ports_per_host = htobe16(payload->ports_per_host);
  payload->ses_num = htobe32(payload->ses_num);
}

static inline void vapi_msg_nat_det_map_details_payload_ntoh(vapi_payload_nat_det_map_details *payload)
{
  payload->sharing_ratio = be32toh(payload->sharing_ratio);
  payload->ports_per_host = be16toh(payload->ports_per_host);
  payload->ses_num = be32toh(payload->ses_num);
}

static inline uword vapi_calc_nat_det_map_details_msg_size(vapi_msg_nat_det_map_details *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat_det_map_details_hton(vapi_msg_nat_det_map_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_map_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat_det_map_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat_det_map_details_ntoh(vapi_msg_nat_det_map_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_map_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat_det_map_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat64_st_dump_payload_hton(vapi_payload_nat64_st_dump *payload)
{

}

static inline void vapi_msg_nat64_st_dump_payload_ntoh(vapi_payload_nat64_st_dump *payload)
{

}

static inline uword vapi_calc_nat64_st_dump_msg_size(vapi_msg_nat64_st_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat64_st_dump_hton(vapi_msg_nat64_st_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_st_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_nat64_st_dump_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat64_st_dump_ntoh(vapi_msg_nat64_st_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_st_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_nat64_st_dump_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_snat_show_config_msg_size(vapi_msg_snat_show_config *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_show_config_hton(vapi_msg_snat_show_config *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_show_config'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_snat_show_config_ntoh(vapi_msg_snat_show_config *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_show_config'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_nat44_lb_static_mapping_details_payload_hton(vapi_payload_nat44_lb_static_mapping_details *payload)
{
  payload->external_port = htobe16(payload->external_port);
  payload->vrf_id = htobe32(payload->vrf_id);
  do { unsigned i; for (i = 0; i < payload->local_num; ++i) { vapi_type_nat44_lb_addr_port_hton(&payload->locals[i]); } } while(0);
}

static inline void vapi_msg_nat44_lb_static_mapping_details_payload_ntoh(vapi_payload_nat44_lb_static_mapping_details *payload)
{
  payload->external_port = be16toh(payload->external_port);
  payload->vrf_id = be32toh(payload->vrf_id);
  do { unsigned i; for (i = 0; i < payload->local_num; ++i) { vapi_type_nat44_lb_addr_port_ntoh(&payload->locals[i]); } } while(0);
}

static inline uword vapi_calc_nat44_lb_static_mapping_details_msg_size(vapi_msg_nat44_lb_static_mapping_details *msg)
{
  return sizeof(*msg)+ msg->payload.local_num * sizeof(msg->payload.locals[0]);
}

static inline void vapi_msg_nat44_lb_static_mapping_details_hton(vapi_msg_nat44_lb_static_mapping_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_lb_static_mapping_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat44_lb_static_mapping_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat44_lb_static_mapping_details_ntoh(vapi_msg_nat44_lb_static_mapping_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_lb_static_mapping_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat44_lb_static_mapping_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_snat_add_address_range_payload_hton(vapi_payload_snat_add_address_range *payload)
{
  payload->vrf_id = htobe32(payload->vrf_id);
}

static inline void vapi_msg_snat_add_address_range_payload_ntoh(vapi_payload_snat_add_address_range *payload)
{
  payload->vrf_id = be32toh(payload->vrf_id);
}

static inline uword vapi_calc_snat_add_address_range_msg_size(vapi_msg_snat_add_address_range *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_add_address_range_hton(vapi_msg_snat_add_address_range *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_add_address_range'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_snat_add_address_range_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_add_address_range_ntoh(vapi_msg_snat_add_address_range *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_add_address_range'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_snat_add_address_range_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_snat_add_det_map_reply_payload_hton(vapi_payload_snat_add_det_map_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_snat_add_det_map_reply_payload_ntoh(vapi_payload_snat_add_det_map_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_snat_add_det_map_reply_msg_size(vapi_msg_snat_add_det_map_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_add_det_map_reply_hton(vapi_msg_snat_add_det_map_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_add_det_map_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_snat_add_det_map_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_add_det_map_reply_ntoh(vapi_msg_snat_add_det_map_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_add_det_map_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_snat_add_det_map_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_snat_static_mapping_dump_msg_size(vapi_msg_snat_static_mapping_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_static_mapping_dump_hton(vapi_msg_snat_static_mapping_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_static_mapping_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_snat_static_mapping_dump_ntoh(vapi_msg_snat_static_mapping_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_static_mapping_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_nat44_interface_details_payload_hton(vapi_payload_nat44_interface_details *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_nat44_interface_details_payload_ntoh(vapi_payload_nat44_interface_details *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_nat44_interface_details_msg_size(vapi_msg_nat44_interface_details *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat44_interface_details_hton(vapi_msg_nat44_interface_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_interface_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat44_interface_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat44_interface_details_ntoh(vapi_msg_nat44_interface_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_interface_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat44_interface_details_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_snat_interface_dump_msg_size(vapi_msg_snat_interface_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_interface_dump_hton(vapi_msg_snat_interface_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_interface_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_snat_interface_dump_ntoh(vapi_msg_snat_interface_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_interface_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_nat44_add_del_address_range_payload_hton(vapi_payload_nat44_add_del_address_range *payload)
{
  payload->vrf_id = htobe32(payload->vrf_id);
}

static inline void vapi_msg_nat44_add_del_address_range_payload_ntoh(vapi_payload_nat44_add_del_address_range *payload)
{
  payload->vrf_id = be32toh(payload->vrf_id);
}

static inline uword vapi_calc_nat44_add_del_address_range_msg_size(vapi_msg_nat44_add_del_address_range *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat44_add_del_address_range_hton(vapi_msg_nat44_add_del_address_range *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_add_del_address_range'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_nat44_add_del_address_range_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat44_add_del_address_range_ntoh(vapi_msg_nat44_add_del_address_range *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_add_del_address_range'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_nat44_add_del_address_range_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat_det_set_timeouts_reply_payload_hton(vapi_payload_nat_det_set_timeouts_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_nat_det_set_timeouts_reply_payload_ntoh(vapi_payload_nat_det_set_timeouts_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_nat_det_set_timeouts_reply_msg_size(vapi_msg_nat_det_set_timeouts_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat_det_set_timeouts_reply_hton(vapi_msg_nat_det_set_timeouts_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_set_timeouts_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat_det_set_timeouts_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat_det_set_timeouts_reply_ntoh(vapi_msg_nat_det_set_timeouts_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_det_set_timeouts_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat_det_set_timeouts_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_snat_user_session_details_payload_hton(vapi_payload_snat_user_session_details *payload)
{
  payload->outside_port = htobe16(payload->outside_port);
  payload->inside_port = htobe16(payload->inside_port);
  payload->protocol = htobe16(payload->protocol);
  payload->last_heard = htobe64(payload->last_heard);
  payload->total_bytes = htobe64(payload->total_bytes);
  payload->total_pkts = htobe32(payload->total_pkts);
}

static inline void vapi_msg_snat_user_session_details_payload_ntoh(vapi_payload_snat_user_session_details *payload)
{
  payload->outside_port = be16toh(payload->outside_port);
  payload->inside_port = be16toh(payload->inside_port);
  payload->protocol = be16toh(payload->protocol);
  payload->last_heard = be64toh(payload->last_heard);
  payload->total_bytes = be64toh(payload->total_bytes);
  payload->total_pkts = be32toh(payload->total_pkts);
}

static inline uword vapi_calc_snat_user_session_details_msg_size(vapi_msg_snat_user_session_details *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_user_session_details_hton(vapi_msg_snat_user_session_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_user_session_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_snat_user_session_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_user_session_details_ntoh(vapi_msg_snat_user_session_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_user_session_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_snat_user_session_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_snat_control_ping_reply_payload_hton(vapi_payload_snat_control_ping_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->client_index = htobe32(payload->client_index);
  payload->vpe_pid = htobe32(payload->vpe_pid);
}

static inline void vapi_msg_snat_control_ping_reply_payload_ntoh(vapi_payload_snat_control_ping_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->client_index = be32toh(payload->client_index);
  payload->vpe_pid = be32toh(payload->vpe_pid);
}

static inline uword vapi_calc_snat_control_ping_reply_msg_size(vapi_msg_snat_control_ping_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_control_ping_reply_hton(vapi_msg_snat_control_ping_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_control_ping_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_snat_control_ping_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_control_ping_reply_ntoh(vapi_msg_snat_control_ping_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_control_ping_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_snat_control_ping_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_snat_interface_add_del_output_feature_payload_hton(vapi_payload_snat_interface_add_del_output_feature *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_snat_interface_add_del_output_feature_payload_ntoh(vapi_payload_snat_interface_add_del_output_feature *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_snat_interface_add_del_output_feature_msg_size(vapi_msg_snat_interface_add_del_output_feature *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_interface_add_del_output_feature_hton(vapi_msg_snat_interface_add_del_output_feature *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_interface_add_del_output_feature'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_snat_interface_add_del_output_feature_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_interface_add_del_output_feature_ntoh(vapi_msg_snat_interface_add_del_output_feature *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_interface_add_del_output_feature'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_snat_interface_add_del_output_feature_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_snat_worker_dump_msg_size(vapi_msg_snat_worker_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_worker_dump_hton(vapi_msg_snat_worker_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_worker_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_snat_worker_dump_ntoh(vapi_msg_snat_worker_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_worker_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_nat_set_workers_reply_payload_hton(vapi_payload_nat_set_workers_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_nat_set_workers_reply_payload_ntoh(vapi_payload_nat_set_workers_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_nat_set_workers_reply_msg_size(vapi_msg_nat_set_workers_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat_set_workers_reply_hton(vapi_msg_nat_set_workers_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_set_workers_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_nat_set_workers_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat_set_workers_reply_ntoh(vapi_msg_nat_set_workers_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat_set_workers_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_nat_set_workers_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_snat_interface_output_feature_dump_msg_size(vapi_msg_snat_interface_output_feature_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_interface_output_feature_dump_hton(vapi_msg_snat_interface_output_feature_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_interface_output_feature_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_snat_interface_output_feature_dump_ntoh(vapi_msg_snat_interface_output_feature_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_interface_output_feature_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_nat44_add_del_static_mapping_payload_hton(vapi_payload_nat44_add_del_static_mapping *payload)
{
  payload->local_port = htobe16(payload->local_port);
  payload->external_port = htobe16(payload->external_port);
  payload->external_sw_if_index = htobe32(payload->external_sw_if_index);
  payload->vrf_id = htobe32(payload->vrf_id);
}

static inline void vapi_msg_nat44_add_del_static_mapping_payload_ntoh(vapi_payload_nat44_add_del_static_mapping *payload)
{
  payload->local_port = be16toh(payload->local_port);
  payload->external_port = be16toh(payload->external_port);
  payload->external_sw_if_index = be32toh(payload->external_sw_if_index);
  payload->vrf_id = be32toh(payload->vrf_id);
}

static inline uword vapi_calc_nat44_add_del_static_mapping_msg_size(vapi_msg_nat44_add_del_static_mapping *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat44_add_del_static_mapping_hton(vapi_msg_nat44_add_del_static_mapping *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_add_del_static_mapping'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_nat44_add_del_static_mapping_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat44_add_del_static_mapping_ntoh(vapi_msg_nat44_add_del_static_mapping *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat44_add_del_static_mapping'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_nat44_add_del_static_mapping_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_nat64_add_del_static_bib_payload_hton(vapi_payload_nat64_add_del_static_bib *payload)
{
  payload->i_port = htobe16(payload->i_port);
  payload->o_port = htobe16(payload->o_port);
  payload->vrf_id = htobe32(payload->vrf_id);
}

static inline void vapi_msg_nat64_add_del_static_bib_payload_ntoh(vapi_payload_nat64_add_del_static_bib *payload)
{
  payload->i_port = be16toh(payload->i_port);
  payload->o_port = be16toh(payload->o_port);
  payload->vrf_id = be32toh(payload->vrf_id);
}

static inline uword vapi_calc_nat64_add_del_static_bib_msg_size(vapi_msg_nat64_add_del_static_bib *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_nat64_add_del_static_bib_hton(vapi_msg_nat64_add_del_static_bib *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_add_del_static_bib'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_nat64_add_del_static_bib_payload_hton(&msg->payload);
}

static inline void vapi_msg_nat64_add_del_static_bib_ntoh(vapi_msg_nat64_add_del_static_bib *msg)
{
  VAPI_DBG("Swapping `vapi_msg_nat64_add_del_static_bib'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_nat64_add_del_static_bib_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_snat_det_close_session_in_payload_hton(vapi_payload_snat_det_close_session_in *payload)
{
  payload->in_port = htobe16(payload->in_port);
  payload->ext_port = htobe16(payload->ext_port);
}

static inline void vapi_msg_snat_det_close_session_in_payload_ntoh(vapi_payload_snat_det_close_session_in *payload)
{
  payload->in_port = be16toh(payload->in_port);
  payload->ext_port = be16toh(payload->ext_port);
}

static inline uword vapi_calc_snat_det_close_session_in_msg_size(vapi_msg_snat_det_close_session_in *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_det_close_session_in_hton(vapi_msg_snat_det_close_session_in *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_det_close_session_in'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_snat_det_close_session_in_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_det_close_session_in_ntoh(vapi_msg_snat_det_close_session_in *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_det_close_session_in'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_snat_det_close_session_in_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_snat_interface_details_payload_hton(vapi_payload_snat_interface_details *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_snat_interface_details_payload_ntoh(vapi_payload_snat_interface_details *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_snat_interface_details_msg_size(vapi_msg_snat_interface_details *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_interface_details_hton(vapi_msg_snat_interface_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_interface_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_snat_interface_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_snat_interface_details_ntoh(vapi_msg_snat_interface_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_interface_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_snat_interface_details_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_snat_det_get_timeouts_msg_size(vapi_msg_snat_det_get_timeouts *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_snat_det_get_timeouts_hton(vapi_msg_snat_det_get_timeouts *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_det_get_timeouts'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_snat_det_get_timeouts_ntoh(vapi_msg_snat_det_get_timeouts *msg)
{
  VAPI_DBG("Swapping `vapi_msg_snat_det_get_timeouts'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline vapi_msg_snat_interface_add_del_feature* vapi_alloc_snat_interface_add_del_feature(struct vapi_ctx_s *ctx)
{
  vapi_msg_snat_interface_add_del_feature *msg = NULL;
  const size_t size = sizeof(vapi_msg_snat_interface_add_del_feature);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_snat_interface_add_del_feature*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_snat_interface_add_del_feature);

  return msg;
}

static inline vapi_error_e vapi_snat_interface_add_del_feature(struct vapi_ctx_s *ctx,
  vapi_msg_snat_interface_add_del_feature *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_snat_interface_add_del_feature_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_snat_interface_add_del_feature_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_snat_interface_add_del_feature_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_snat_control_ping* vapi_alloc_snat_control_ping(struct vapi_ctx_s *ctx)
{
  vapi_msg_snat_control_ping *msg = NULL;
  const size_t size = sizeof(vapi_msg_snat_control_ping);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_snat_control_ping*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_snat_control_ping);

  return msg;
}

static inline vapi_error_e vapi_snat_control_ping(struct vapi_ctx_s *ctx,
  vapi_msg_snat_control_ping *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_snat_control_ping_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_snat_control_ping_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_snat_control_ping_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat_ipfix_enable_disable* vapi_alloc_nat_ipfix_enable_disable(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat_ipfix_enable_disable *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat_ipfix_enable_disable);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat_ipfix_enable_disable*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat_ipfix_enable_disable);

  return msg;
}

static inline vapi_error_e vapi_nat_ipfix_enable_disable(struct vapi_ctx_s *ctx,
  vapi_msg_nat_ipfix_enable_disable *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat_ipfix_enable_disable_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat_ipfix_enable_disable_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat_ipfix_enable_disable_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat44_lb_static_mapping_dump* vapi_alloc_nat44_lb_static_mapping_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat44_lb_static_mapping_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat44_lb_static_mapping_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat44_lb_static_mapping_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat44_lb_static_mapping_dump);

  return msg;
}

static inline vapi_error_e vapi_nat44_lb_static_mapping_dump(struct vapi_ctx_s *ctx,
  vapi_msg_nat44_lb_static_mapping_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat44_lb_static_mapping_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat44_lb_static_mapping_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat44_lb_static_mapping_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat64_pool_addr_dump* vapi_alloc_nat64_pool_addr_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat64_pool_addr_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat64_pool_addr_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat64_pool_addr_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat64_pool_addr_dump);

  return msg;
}

static inline vapi_error_e vapi_nat64_pool_addr_dump(struct vapi_ctx_s *ctx,
  vapi_msg_nat64_pool_addr_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat64_pool_addr_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat64_pool_addr_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat64_pool_addr_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_snat_user_session_dump* vapi_alloc_snat_user_session_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_snat_user_session_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_snat_user_session_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_snat_user_session_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_snat_user_session_dump);

  return msg;
}

static inline vapi_error_e vapi_snat_user_session_dump(struct vapi_ctx_s *ctx,
  vapi_msg_snat_user_session_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_snat_user_session_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_snat_user_session_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_snat_user_session_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat64_interface_dump* vapi_alloc_nat64_interface_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat64_interface_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat64_interface_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat64_interface_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat64_interface_dump);

  return msg;
}

static inline vapi_error_e vapi_nat64_interface_dump(struct vapi_ctx_s *ctx,
  vapi_msg_nat64_interface_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat64_interface_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat64_interface_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat64_interface_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat_det_add_del_map* vapi_alloc_nat_det_add_del_map(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat_det_add_del_map *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat_det_add_del_map);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat_det_add_del_map*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat_det_add_del_map);

  return msg;
}

static inline vapi_error_e vapi_nat_det_add_del_map(struct vapi_ctx_s *ctx,
  vapi_msg_nat_det_add_del_map *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat_det_add_del_map_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat_det_add_del_map_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat_det_add_del_map_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_snat_ipfix_enable_disable* vapi_alloc_snat_ipfix_enable_disable(struct vapi_ctx_s *ctx)
{
  vapi_msg_snat_ipfix_enable_disable *msg = NULL;
  const size_t size = sizeof(vapi_msg_snat_ipfix_enable_disable);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_snat_ipfix_enable_disable*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_snat_ipfix_enable_disable);

  return msg;
}

static inline vapi_error_e vapi_snat_ipfix_enable_disable(struct vapi_ctx_s *ctx,
  vapi_msg_snat_ipfix_enable_disable *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_snat_ipfix_enable_disable_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_snat_ipfix_enable_disable_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_snat_ipfix_enable_disable_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat44_user_dump* vapi_alloc_nat44_user_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat44_user_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat44_user_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat44_user_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat44_user_dump);

  return msg;
}

static inline vapi_error_e vapi_nat44_user_dump(struct vapi_ctx_s *ctx,
  vapi_msg_nat44_user_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat44_user_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat44_user_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat44_user_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_snat_det_set_timeouts* vapi_alloc_snat_det_set_timeouts(struct vapi_ctx_s *ctx)
{
  vapi_msg_snat_det_set_timeouts *msg = NULL;
  const size_t size = sizeof(vapi_msg_snat_det_set_timeouts);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_snat_det_set_timeouts*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_snat_det_set_timeouts);

  return msg;
}

static inline vapi_error_e vapi_snat_det_set_timeouts(struct vapi_ctx_s *ctx,
  vapi_msg_snat_det_set_timeouts *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_snat_det_set_timeouts_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_snat_det_set_timeouts_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_snat_det_set_timeouts_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_snat_add_static_mapping* vapi_alloc_snat_add_static_mapping(struct vapi_ctx_s *ctx)
{
  vapi_msg_snat_add_static_mapping *msg = NULL;
  const size_t size = sizeof(vapi_msg_snat_add_static_mapping);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_snat_add_static_mapping*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_snat_add_static_mapping);

  return msg;
}

static inline vapi_error_e vapi_snat_add_static_mapping(struct vapi_ctx_s *ctx,
  vapi_msg_snat_add_static_mapping *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_snat_add_static_mapping_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_snat_add_static_mapping_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_snat_add_static_mapping_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat_control_ping* vapi_alloc_nat_control_ping(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat_control_ping *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat_control_ping);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat_control_ping*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat_control_ping);

  return msg;
}

static inline vapi_error_e vapi_nat_control_ping(struct vapi_ctx_s *ctx,
  vapi_msg_nat_control_ping *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat_control_ping_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat_control_ping_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat_control_ping_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat64_add_del_interface* vapi_alloc_nat64_add_del_interface(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat64_add_del_interface *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat64_add_del_interface);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat64_add_del_interface*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat64_add_del_interface);

  return msg;
}

static inline vapi_error_e vapi_nat64_add_del_interface(struct vapi_ctx_s *ctx,
  vapi_msg_nat64_add_del_interface *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat64_add_del_interface_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat64_add_del_interface_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat64_add_del_interface_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat_det_close_session_in* vapi_alloc_nat_det_close_session_in(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat_det_close_session_in *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat_det_close_session_in);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat_det_close_session_in*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat_det_close_session_in);

  return msg;
}

static inline vapi_error_e vapi_nat_det_close_session_in(struct vapi_ctx_s *ctx,
  vapi_msg_nat_det_close_session_in *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat_det_close_session_in_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat_det_close_session_in_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat_det_close_session_in_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat44_user_session_dump* vapi_alloc_nat44_user_session_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat44_user_session_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat44_user_session_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat44_user_session_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat44_user_session_dump);

  return msg;
}

static inline vapi_error_e vapi_nat44_user_session_dump(struct vapi_ctx_s *ctx,
  vapi_msg_nat44_user_session_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat44_user_session_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat44_user_session_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat44_user_session_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat44_static_mapping_dump* vapi_alloc_nat44_static_mapping_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat44_static_mapping_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat44_static_mapping_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat44_static_mapping_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat44_static_mapping_dump);

  return msg;
}

static inline vapi_error_e vapi_nat44_static_mapping_dump(struct vapi_ctx_s *ctx,
  vapi_msg_nat44_static_mapping_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat44_static_mapping_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat44_static_mapping_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat44_static_mapping_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_snat_det_map_dump* vapi_alloc_snat_det_map_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_snat_det_map_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_snat_det_map_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_snat_det_map_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_snat_det_map_dump);

  return msg;
}

static inline vapi_error_e vapi_snat_det_map_dump(struct vapi_ctx_s *ctx,
  vapi_msg_snat_det_map_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_snat_det_map_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_snat_det_map_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_snat_det_map_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_snat_add_del_interface_addr* vapi_alloc_snat_add_del_interface_addr(struct vapi_ctx_s *ctx)
{
  vapi_msg_snat_add_del_interface_addr *msg = NULL;
  const size_t size = sizeof(vapi_msg_snat_add_del_interface_addr);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_snat_add_del_interface_addr*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_snat_add_del_interface_addr);

  return msg;
}

static inline vapi_error_e vapi_snat_add_del_interface_addr(struct vapi_ctx_s *ctx,
  vapi_msg_snat_add_del_interface_addr *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_snat_add_del_interface_addr_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_snat_add_del_interface_addr_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_snat_add_del_interface_addr_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_snat_address_dump* vapi_alloc_snat_address_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_snat_address_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_snat_address_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_snat_address_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_snat_address_dump);

  return msg;
}

static inline vapi_error_e vapi_snat_address_dump(struct vapi_ctx_s *ctx,
  vapi_msg_snat_address_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_snat_address_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_snat_address_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_snat_address_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_snat_set_workers* vapi_alloc_snat_set_workers(struct vapi_ctx_s *ctx)
{
  vapi_msg_snat_set_workers *msg = NULL;
  const size_t size = sizeof(vapi_msg_snat_set_workers);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_snat_set_workers*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_snat_set_workers);

  return msg;
}

static inline vapi_error_e vapi_snat_set_workers(struct vapi_ctx_s *ctx,
  vapi_msg_snat_set_workers *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_snat_set_workers_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_snat_set_workers_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_snat_set_workers_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat44_interface_output_feature_dump* vapi_alloc_nat44_interface_output_feature_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat44_interface_output_feature_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat44_interface_output_feature_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat44_interface_output_feature_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat44_interface_output_feature_dump);

  return msg;
}

static inline vapi_error_e vapi_nat44_interface_output_feature_dump(struct vapi_ctx_s *ctx,
  vapi_msg_nat44_interface_output_feature_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat44_interface_output_feature_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat44_interface_output_feature_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat44_interface_output_feature_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat44_interface_add_del_feature* vapi_alloc_nat44_interface_add_del_feature(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat44_interface_add_del_feature *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat44_interface_add_del_feature);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat44_interface_add_del_feature*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat44_interface_add_del_feature);

  return msg;
}

static inline vapi_error_e vapi_nat44_interface_add_del_feature(struct vapi_ctx_s *ctx,
  vapi_msg_nat44_interface_add_del_feature *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat44_interface_add_del_feature_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat44_interface_add_del_feature_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat44_interface_add_del_feature_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat_det_reverse* vapi_alloc_nat_det_reverse(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat_det_reverse *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat_det_reverse);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat_det_reverse*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat_det_reverse);

  return msg;
}

static inline vapi_error_e vapi_nat_det_reverse(struct vapi_ctx_s *ctx,
  vapi_msg_nat_det_reverse *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat_det_reverse_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat_det_reverse_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat_det_reverse_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat_det_forward* vapi_alloc_nat_det_forward(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat_det_forward *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat_det_forward);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat_det_forward*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat_det_forward);

  return msg;
}

static inline vapi_error_e vapi_nat_det_forward(struct vapi_ctx_s *ctx,
  vapi_msg_nat_det_forward *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat_det_forward_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat_det_forward_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat_det_forward_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat_worker_dump* vapi_alloc_nat_worker_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat_worker_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat_worker_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat_worker_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat_worker_dump);

  return msg;
}

static inline vapi_error_e vapi_nat_worker_dump(struct vapi_ctx_s *ctx,
  vapi_msg_nat_worker_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat_worker_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat_worker_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat_worker_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_snat_interface_addr_dump* vapi_alloc_snat_interface_addr_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_snat_interface_addr_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_snat_interface_addr_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_snat_interface_addr_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_snat_interface_addr_dump);

  return msg;
}

static inline vapi_error_e vapi_snat_interface_addr_dump(struct vapi_ctx_s *ctx,
  vapi_msg_snat_interface_addr_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_snat_interface_addr_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_snat_interface_addr_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_snat_interface_addr_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat_det_get_timeouts* vapi_alloc_nat_det_get_timeouts(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat_det_get_timeouts *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat_det_get_timeouts);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat_det_get_timeouts*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat_det_get_timeouts);

  return msg;
}

static inline vapi_error_e vapi_nat_det_get_timeouts(struct vapi_ctx_s *ctx,
  vapi_msg_nat_det_get_timeouts *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat_det_get_timeouts_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat_det_get_timeouts_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat_det_get_timeouts_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat44_interface_addr_dump* vapi_alloc_nat44_interface_addr_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat44_interface_addr_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat44_interface_addr_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat44_interface_addr_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat44_interface_addr_dump);

  return msg;
}

static inline vapi_error_e vapi_nat44_interface_addr_dump(struct vapi_ctx_s *ctx,
  vapi_msg_nat44_interface_addr_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat44_interface_addr_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat44_interface_addr_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat44_interface_addr_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat44_add_del_lb_static_mapping* vapi_alloc_nat44_add_del_lb_static_mapping(struct vapi_ctx_s *ctx, size_t locals_array_size)
{
  vapi_msg_nat44_add_del_lb_static_mapping *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat44_add_del_lb_static_mapping) + sizeof(msg->payload.locals[0]) * locals_array_size;
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat44_add_del_lb_static_mapping*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat44_add_del_lb_static_mapping);
  msg->payload.local_num = locals_array_size;
  return msg;
}

static inline vapi_error_e vapi_nat44_add_del_lb_static_mapping(struct vapi_ctx_s *ctx,
  vapi_msg_nat44_add_del_lb_static_mapping *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat44_add_del_lb_static_mapping_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat44_add_del_lb_static_mapping_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat44_add_del_lb_static_mapping_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat_det_set_timeouts* vapi_alloc_nat_det_set_timeouts(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat_det_set_timeouts *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat_det_set_timeouts);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat_det_set_timeouts*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat_det_set_timeouts);

  return msg;
}

static inline vapi_error_e vapi_nat_det_set_timeouts(struct vapi_ctx_s *ctx,
  vapi_msg_nat_det_set_timeouts *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat_det_set_timeouts_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat_det_set_timeouts_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat_det_set_timeouts_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_snat_user_dump* vapi_alloc_snat_user_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_snat_user_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_snat_user_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_snat_user_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_snat_user_dump);

  return msg;
}

static inline vapi_error_e vapi_snat_user_dump(struct vapi_ctx_s *ctx,
  vapi_msg_snat_user_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_snat_user_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_snat_user_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_snat_user_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat_det_close_session_out* vapi_alloc_nat_det_close_session_out(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat_det_close_session_out *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat_det_close_session_out);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat_det_close_session_out*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat_det_close_session_out);

  return msg;
}

static inline vapi_error_e vapi_nat_det_close_session_out(struct vapi_ctx_s *ctx,
  vapi_msg_nat_det_close_session_out *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat_det_close_session_out_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat_det_close_session_out_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat_det_close_session_out_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat_det_session_dump* vapi_alloc_nat_det_session_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat_det_session_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat_det_session_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat_det_session_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat_det_session_dump);

  return msg;
}

static inline vapi_error_e vapi_nat_det_session_dump(struct vapi_ctx_s *ctx,
  vapi_msg_nat_det_session_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat_det_session_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat_det_session_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat_det_session_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat64_set_timeouts* vapi_alloc_nat64_set_timeouts(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat64_set_timeouts *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat64_set_timeouts);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat64_set_timeouts*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat64_set_timeouts);

  return msg;
}

static inline vapi_error_e vapi_nat64_set_timeouts(struct vapi_ctx_s *ctx,
  vapi_msg_nat64_set_timeouts *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat64_set_timeouts_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat64_set_timeouts_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat64_set_timeouts_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_snat_det_session_dump* vapi_alloc_snat_det_session_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_snat_det_session_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_snat_det_session_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_snat_det_session_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_snat_det_session_dump);

  return msg;
}

static inline vapi_error_e vapi_snat_det_session_dump(struct vapi_ctx_s *ctx,
  vapi_msg_snat_det_session_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_snat_det_session_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_snat_det_session_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_snat_det_session_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat64_get_timeouts* vapi_alloc_nat64_get_timeouts(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat64_get_timeouts *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat64_get_timeouts);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat64_get_timeouts*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat64_get_timeouts);

  return msg;
}

static inline vapi_error_e vapi_nat64_get_timeouts(struct vapi_ctx_s *ctx,
  vapi_msg_nat64_get_timeouts *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat64_get_timeouts_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat64_get_timeouts_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat64_get_timeouts_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_snat_add_det_map* vapi_alloc_snat_add_det_map(struct vapi_ctx_s *ctx)
{
  vapi_msg_snat_add_det_map *msg = NULL;
  const size_t size = sizeof(vapi_msg_snat_add_det_map);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_snat_add_det_map*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_snat_add_det_map);

  return msg;
}

static inline vapi_error_e vapi_snat_add_det_map(struct vapi_ctx_s *ctx,
  vapi_msg_snat_add_det_map *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_snat_add_det_map_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_snat_add_det_map_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_snat_add_det_map_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat_show_config* vapi_alloc_nat_show_config(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat_show_config *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat_show_config);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat_show_config*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat_show_config);

  return msg;
}

static inline vapi_error_e vapi_nat_show_config(struct vapi_ctx_s *ctx,
  vapi_msg_nat_show_config *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat_show_config_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat_show_config_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat_show_config_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat44_address_dump* vapi_alloc_nat44_address_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat44_address_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat44_address_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat44_address_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat44_address_dump);

  return msg;
}

static inline vapi_error_e vapi_nat44_address_dump(struct vapi_ctx_s *ctx,
  vapi_msg_nat44_address_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat44_address_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat44_address_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat44_address_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_snat_det_forward* vapi_alloc_snat_det_forward(struct vapi_ctx_s *ctx)
{
  vapi_msg_snat_det_forward *msg = NULL;
  const size_t size = sizeof(vapi_msg_snat_det_forward);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_snat_det_forward*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_snat_det_forward);

  return msg;
}

static inline vapi_error_e vapi_snat_det_forward(struct vapi_ctx_s *ctx,
  vapi_msg_snat_det_forward *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_snat_det_forward_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_snat_det_forward_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_snat_det_forward_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat44_interface_dump* vapi_alloc_nat44_interface_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat44_interface_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat44_interface_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat44_interface_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat44_interface_dump);

  return msg;
}

static inline vapi_error_e vapi_nat44_interface_dump(struct vapi_ctx_s *ctx,
  vapi_msg_nat44_interface_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat44_interface_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat44_interface_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat44_interface_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat64_bib_dump* vapi_alloc_nat64_bib_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat64_bib_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat64_bib_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat64_bib_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat64_bib_dump);

  return msg;
}

static inline vapi_error_e vapi_nat64_bib_dump(struct vapi_ctx_s *ctx,
  vapi_msg_nat64_bib_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat64_bib_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat64_bib_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat64_bib_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat64_add_del_pool_addr_range* vapi_alloc_nat64_add_del_pool_addr_range(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat64_add_del_pool_addr_range *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat64_add_del_pool_addr_range);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat64_add_del_pool_addr_range*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat64_add_del_pool_addr_range);

  return msg;
}

static inline vapi_error_e vapi_nat64_add_del_pool_addr_range(struct vapi_ctx_s *ctx,
  vapi_msg_nat64_add_del_pool_addr_range *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat64_add_del_pool_addr_range_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat64_add_del_pool_addr_range_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat64_add_del_pool_addr_range_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat64_prefix_dump* vapi_alloc_nat64_prefix_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat64_prefix_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat64_prefix_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat64_prefix_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat64_prefix_dump);

  return msg;
}

static inline vapi_error_e vapi_nat64_prefix_dump(struct vapi_ctx_s *ctx,
  vapi_msg_nat64_prefix_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat64_prefix_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat64_prefix_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat64_prefix_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat_det_map_dump* vapi_alloc_nat_det_map_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat_det_map_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat_det_map_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat_det_map_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat_det_map_dump);

  return msg;
}

static inline vapi_error_e vapi_nat_det_map_dump(struct vapi_ctx_s *ctx,
  vapi_msg_nat_det_map_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat_det_map_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat_det_map_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat_det_map_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat_set_workers* vapi_alloc_nat_set_workers(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat_set_workers *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat_set_workers);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat_set_workers*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat_set_workers);

  return msg;
}

static inline vapi_error_e vapi_nat_set_workers(struct vapi_ctx_s *ctx,
  vapi_msg_nat_set_workers *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat_set_workers_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat_set_workers_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat_set_workers_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat64_add_del_prefix* vapi_alloc_nat64_add_del_prefix(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat64_add_del_prefix *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat64_add_del_prefix);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat64_add_del_prefix*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat64_add_del_prefix);

  return msg;
}

static inline vapi_error_e vapi_nat64_add_del_prefix(struct vapi_ctx_s *ctx,
  vapi_msg_nat64_add_del_prefix *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat64_add_del_prefix_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat64_add_del_prefix_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat64_add_del_prefix_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_snat_det_reverse* vapi_alloc_snat_det_reverse(struct vapi_ctx_s *ctx)
{
  vapi_msg_snat_det_reverse *msg = NULL;
  const size_t size = sizeof(vapi_msg_snat_det_reverse);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_snat_det_reverse*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_snat_det_reverse);

  return msg;
}

static inline vapi_error_e vapi_snat_det_reverse(struct vapi_ctx_s *ctx,
  vapi_msg_snat_det_reverse *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_snat_det_reverse_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_snat_det_reverse_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_snat_det_reverse_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat44_interface_add_del_output_feature* vapi_alloc_nat44_interface_add_del_output_feature(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat44_interface_add_del_output_feature *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat44_interface_add_del_output_feature);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat44_interface_add_del_output_feature*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat44_interface_add_del_output_feature);

  return msg;
}

static inline vapi_error_e vapi_nat44_interface_add_del_output_feature(struct vapi_ctx_s *ctx,
  vapi_msg_nat44_interface_add_del_output_feature *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat44_interface_add_del_output_feature_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat44_interface_add_del_output_feature_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat44_interface_add_del_output_feature_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_snat_det_close_session_out* vapi_alloc_snat_det_close_session_out(struct vapi_ctx_s *ctx)
{
  vapi_msg_snat_det_close_session_out *msg = NULL;
  const size_t size = sizeof(vapi_msg_snat_det_close_session_out);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_snat_det_close_session_out*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_snat_det_close_session_out);

  return msg;
}

static inline vapi_error_e vapi_snat_det_close_session_out(struct vapi_ctx_s *ctx,
  vapi_msg_snat_det_close_session_out *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_snat_det_close_session_out_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_snat_det_close_session_out_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_snat_det_close_session_out_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat44_add_del_interface_addr* vapi_alloc_nat44_add_del_interface_addr(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat44_add_del_interface_addr *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat44_add_del_interface_addr);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat44_add_del_interface_addr*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat44_add_del_interface_addr);

  return msg;
}

static inline vapi_error_e vapi_nat44_add_del_interface_addr(struct vapi_ctx_s *ctx,
  vapi_msg_nat44_add_del_interface_addr *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat44_add_del_interface_addr_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat44_add_del_interface_addr_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat44_add_del_interface_addr_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat64_st_dump* vapi_alloc_nat64_st_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat64_st_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat64_st_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat64_st_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat64_st_dump);

  return msg;
}

static inline vapi_error_e vapi_nat64_st_dump(struct vapi_ctx_s *ctx,
  vapi_msg_nat64_st_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat64_st_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat64_st_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat64_st_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_snat_show_config* vapi_alloc_snat_show_config(struct vapi_ctx_s *ctx)
{
  vapi_msg_snat_show_config *msg = NULL;
  const size_t size = sizeof(vapi_msg_snat_show_config);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_snat_show_config*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_snat_show_config);

  return msg;
}

static inline vapi_error_e vapi_snat_show_config(struct vapi_ctx_s *ctx,
  vapi_msg_snat_show_config *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_snat_show_config_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_snat_show_config_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_snat_show_config_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_snat_add_address_range* vapi_alloc_snat_add_address_range(struct vapi_ctx_s *ctx)
{
  vapi_msg_snat_add_address_range *msg = NULL;
  const size_t size = sizeof(vapi_msg_snat_add_address_range);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_snat_add_address_range*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_snat_add_address_range);

  return msg;
}

static inline vapi_error_e vapi_snat_add_address_range(struct vapi_ctx_s *ctx,
  vapi_msg_snat_add_address_range *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_snat_add_address_range_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_snat_add_address_range_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_snat_add_address_range_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_snat_static_mapping_dump* vapi_alloc_snat_static_mapping_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_snat_static_mapping_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_snat_static_mapping_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_snat_static_mapping_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_snat_static_mapping_dump);

  return msg;
}

static inline vapi_error_e vapi_snat_static_mapping_dump(struct vapi_ctx_s *ctx,
  vapi_msg_snat_static_mapping_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_snat_static_mapping_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_snat_static_mapping_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_snat_static_mapping_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_snat_interface_dump* vapi_alloc_snat_interface_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_snat_interface_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_snat_interface_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_snat_interface_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_snat_interface_dump);

  return msg;
}

static inline vapi_error_e vapi_snat_interface_dump(struct vapi_ctx_s *ctx,
  vapi_msg_snat_interface_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_snat_interface_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_snat_interface_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_snat_interface_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat44_add_del_address_range* vapi_alloc_nat44_add_del_address_range(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat44_add_del_address_range *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat44_add_del_address_range);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat44_add_del_address_range*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat44_add_del_address_range);

  return msg;
}

static inline vapi_error_e vapi_nat44_add_del_address_range(struct vapi_ctx_s *ctx,
  vapi_msg_nat44_add_del_address_range *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat44_add_del_address_range_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat44_add_del_address_range_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat44_add_del_address_range_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_snat_interface_add_del_output_feature* vapi_alloc_snat_interface_add_del_output_feature(struct vapi_ctx_s *ctx)
{
  vapi_msg_snat_interface_add_del_output_feature *msg = NULL;
  const size_t size = sizeof(vapi_msg_snat_interface_add_del_output_feature);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_snat_interface_add_del_output_feature*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_snat_interface_add_del_output_feature);

  return msg;
}

static inline vapi_error_e vapi_snat_interface_add_del_output_feature(struct vapi_ctx_s *ctx,
  vapi_msg_snat_interface_add_del_output_feature *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_snat_interface_add_del_output_feature_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_snat_interface_add_del_output_feature_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_snat_interface_add_del_output_feature_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_snat_worker_dump* vapi_alloc_snat_worker_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_snat_worker_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_snat_worker_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_snat_worker_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_snat_worker_dump);

  return msg;
}

static inline vapi_error_e vapi_snat_worker_dump(struct vapi_ctx_s *ctx,
  vapi_msg_snat_worker_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_snat_worker_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_snat_worker_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_snat_worker_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_snat_interface_output_feature_dump* vapi_alloc_snat_interface_output_feature_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_snat_interface_output_feature_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_snat_interface_output_feature_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_snat_interface_output_feature_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_snat_interface_output_feature_dump);

  return msg;
}

static inline vapi_error_e vapi_snat_interface_output_feature_dump(struct vapi_ctx_s *ctx,
  vapi_msg_snat_interface_output_feature_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_snat_interface_output_feature_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_snat_interface_output_feature_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_snat_interface_output_feature_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat44_add_del_static_mapping* vapi_alloc_nat44_add_del_static_mapping(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat44_add_del_static_mapping *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat44_add_del_static_mapping);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat44_add_del_static_mapping*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat44_add_del_static_mapping);

  return msg;
}

static inline vapi_error_e vapi_nat44_add_del_static_mapping(struct vapi_ctx_s *ctx,
  vapi_msg_nat44_add_del_static_mapping *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat44_add_del_static_mapping_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat44_add_del_static_mapping_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat44_add_del_static_mapping_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_nat64_add_del_static_bib* vapi_alloc_nat64_add_del_static_bib(struct vapi_ctx_s *ctx)
{
  vapi_msg_nat64_add_del_static_bib *msg = NULL;
  const size_t size = sizeof(vapi_msg_nat64_add_del_static_bib);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_nat64_add_del_static_bib*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_nat64_add_del_static_bib);

  return msg;
}

static inline vapi_error_e vapi_nat64_add_del_static_bib(struct vapi_ctx_s *ctx,
  vapi_msg_nat64_add_del_static_bib *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_nat64_add_del_static_bib_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_nat64_add_del_static_bib_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_nat64_add_del_static_bib_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_snat_det_close_session_in* vapi_alloc_snat_det_close_session_in(struct vapi_ctx_s *ctx)
{
  vapi_msg_snat_det_close_session_in *msg = NULL;
  const size_t size = sizeof(vapi_msg_snat_det_close_session_in);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_snat_det_close_session_in*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_snat_det_close_session_in);

  return msg;
}

static inline vapi_error_e vapi_snat_det_close_session_in(struct vapi_ctx_s *ctx,
  vapi_msg_snat_det_close_session_in *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_snat_det_close_session_in_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_snat_det_close_session_in_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_snat_det_close_session_in_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_snat_det_get_timeouts* vapi_alloc_snat_det_get_timeouts(struct vapi_ctx_s *ctx)
{
  vapi_msg_snat_det_get_timeouts *msg = NULL;
  const size_t size = sizeof(vapi_msg_snat_det_get_timeouts);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_snat_det_get_timeouts*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_snat_det_get_timeouts);

  return msg;
}

static inline vapi_error_e vapi_snat_det_get_timeouts(struct vapi_ctx_s *ctx,
  vapi_msg_snat_det_get_timeouts *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_snat_det_get_timeouts_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_snat_det_get_timeouts_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_snat_det_get_timeouts_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}



static void __attribute__((constructor)) __vapi_constructor_snat_interface_add_del_feature()
{
  static const char name[] = "snat_interface_add_del_feature";
  static const char name_with_crc[] = "snat_interface_add_del_feature_dd74ea24";
  static vapi_message_desc_t __vapi_metadata_snat_interface_add_del_feature = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_snat_interface_add_del_feature, payload),
    sizeof(vapi_msg_snat_interface_add_del_feature),
    (generic_swap_fn_t)vapi_msg_snat_interface_add_del_feature_hton,
    (generic_swap_fn_t)vapi_msg_snat_interface_add_del_feature_ntoh,
    ~0,
  };

  vapi_msg_id_snat_interface_add_del_feature = vapi_register_msg(&__vapi_metadata_snat_interface_add_del_feature);
  VAPI_DBG("Assigned msg id %d to snat_interface_add_del_feature", vapi_msg_id_snat_interface_add_del_feature);
}

static void __attribute__((constructor)) __vapi_constructor_snat_control_ping()
{
  static const char name[] = "snat_control_ping";
  static const char name_with_crc[] = "snat_control_ping_7a3d60f6";
  static vapi_message_desc_t __vapi_metadata_snat_control_ping = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_snat_control_ping),
    (generic_swap_fn_t)vapi_msg_snat_control_ping_hton,
    (generic_swap_fn_t)vapi_msg_snat_control_ping_ntoh,
    ~0,
  };

  vapi_msg_id_snat_control_ping = vapi_register_msg(&__vapi_metadata_snat_control_ping);
  VAPI_DBG("Assigned msg id %d to snat_control_ping", vapi_msg_id_snat_control_ping);
}

static void __attribute__((constructor)) __vapi_constructor_nat_ipfix_enable_disable()
{
  static const char name[] = "nat_ipfix_enable_disable";
  static const char name_with_crc[] = "nat_ipfix_enable_disable_c1b2fbba";
  static vapi_message_desc_t __vapi_metadata_nat_ipfix_enable_disable = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_nat_ipfix_enable_disable, payload),
    sizeof(vapi_msg_nat_ipfix_enable_disable),
    (generic_swap_fn_t)vapi_msg_nat_ipfix_enable_disable_hton,
    (generic_swap_fn_t)vapi_msg_nat_ipfix_enable_disable_ntoh,
    ~0,
  };

  vapi_msg_id_nat_ipfix_enable_disable = vapi_register_msg(&__vapi_metadata_nat_ipfix_enable_disable);
  VAPI_DBG("Assigned msg id %d to nat_ipfix_enable_disable", vapi_msg_id_nat_ipfix_enable_disable);
}

static void __attribute__((constructor)) __vapi_constructor_snat_static_mapping_details()
{
  static const char name[] = "snat_static_mapping_details";
  static const char name_with_crc[] = "snat_static_mapping_details_5e4d17bf";
  static vapi_message_desc_t __vapi_metadata_snat_static_mapping_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_snat_static_mapping_details, payload),
    sizeof(vapi_msg_snat_static_mapping_details),
    (generic_swap_fn_t)vapi_msg_snat_static_mapping_details_hton,
    (generic_swap_fn_t)vapi_msg_snat_static_mapping_details_ntoh,
    ~0,
  };

  vapi_msg_id_snat_static_mapping_details = vapi_register_msg(&__vapi_metadata_snat_static_mapping_details);
  VAPI_DBG("Assigned msg id %d to snat_static_mapping_details", vapi_msg_id_snat_static_mapping_details);
}

static void __attribute__((constructor)) __vapi_constructor_nat_control_ping_reply()
{
  static const char name[] = "nat_control_ping_reply";
  static const char name_with_crc[] = "nat_control_ping_reply_2d86a59b";
  static vapi_message_desc_t __vapi_metadata_nat_control_ping_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat_control_ping_reply, payload),
    sizeof(vapi_msg_nat_control_ping_reply),
    (generic_swap_fn_t)vapi_msg_nat_control_ping_reply_hton,
    (generic_swap_fn_t)vapi_msg_nat_control_ping_reply_ntoh,
    ~0,
  };

  vapi_msg_id_nat_control_ping_reply = vapi_register_msg(&__vapi_metadata_nat_control_ping_reply);
  VAPI_DBG("Assigned msg id %d to nat_control_ping_reply", vapi_msg_id_nat_control_ping_reply);
}

static void __attribute__((constructor)) __vapi_constructor_snat_interface_output_feature_details()
{
  static const char name[] = "snat_interface_output_feature_details";
  static const char name_with_crc[] = "snat_interface_output_feature_details_d47ddb87";
  static vapi_message_desc_t __vapi_metadata_snat_interface_output_feature_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_snat_interface_output_feature_details, payload),
    sizeof(vapi_msg_snat_interface_output_feature_details),
    (generic_swap_fn_t)vapi_msg_snat_interface_output_feature_details_hton,
    (generic_swap_fn_t)vapi_msg_snat_interface_output_feature_details_ntoh,
    ~0,
  };

  vapi_msg_id_snat_interface_output_feature_details = vapi_register_msg(&__vapi_metadata_snat_interface_output_feature_details);
  VAPI_DBG("Assigned msg id %d to snat_interface_output_feature_details", vapi_msg_id_snat_interface_output_feature_details);
}

static void __attribute__((constructor)) __vapi_constructor_nat44_lb_static_mapping_dump()
{
  static const char name[] = "nat44_lb_static_mapping_dump";
  static const char name_with_crc[] = "nat44_lb_static_mapping_dump_1ddda4c8";
  static vapi_message_desc_t __vapi_metadata_nat44_lb_static_mapping_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_nat44_lb_static_mapping_dump),
    (generic_swap_fn_t)vapi_msg_nat44_lb_static_mapping_dump_hton,
    (generic_swap_fn_t)vapi_msg_nat44_lb_static_mapping_dump_ntoh,
    ~0,
  };

  vapi_msg_id_nat44_lb_static_mapping_dump = vapi_register_msg(&__vapi_metadata_nat44_lb_static_mapping_dump);
  VAPI_DBG("Assigned msg id %d to nat44_lb_static_mapping_dump", vapi_msg_id_nat44_lb_static_mapping_dump);
}

static void __attribute__((constructor)) __vapi_constructor_nat64_pool_addr_dump()
{
  static const char name[] = "nat64_pool_addr_dump";
  static const char name_with_crc[] = "nat64_pool_addr_dump_4ab68b4e";
  static vapi_message_desc_t __vapi_metadata_nat64_pool_addr_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_nat64_pool_addr_dump),
    (generic_swap_fn_t)vapi_msg_nat64_pool_addr_dump_hton,
    (generic_swap_fn_t)vapi_msg_nat64_pool_addr_dump_ntoh,
    ~0,
  };

  vapi_msg_id_nat64_pool_addr_dump = vapi_register_msg(&__vapi_metadata_nat64_pool_addr_dump);
  VAPI_DBG("Assigned msg id %d to nat64_pool_addr_dump", vapi_msg_id_nat64_pool_addr_dump);
}

static void __attribute__((constructor)) __vapi_constructor_snat_user_session_dump()
{
  static const char name[] = "snat_user_session_dump";
  static const char name_with_crc[] = "snat_user_session_dump_98bd1a88";
  static vapi_message_desc_t __vapi_metadata_snat_user_session_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_snat_user_session_dump, payload),
    sizeof(vapi_msg_snat_user_session_dump),
    (generic_swap_fn_t)vapi_msg_snat_user_session_dump_hton,
    (generic_swap_fn_t)vapi_msg_snat_user_session_dump_ntoh,
    ~0,
  };

  vapi_msg_id_snat_user_session_dump = vapi_register_msg(&__vapi_metadata_snat_user_session_dump);
  VAPI_DBG("Assigned msg id %d to snat_user_session_dump", vapi_msg_id_snat_user_session_dump);
}

static void __attribute__((constructor)) __vapi_constructor_nat64_interface_dump()
{
  static const char name[] = "nat64_interface_dump";
  static const char name_with_crc[] = "nat64_interface_dump_039fac3f";
  static vapi_message_desc_t __vapi_metadata_nat64_interface_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_nat64_interface_dump),
    (generic_swap_fn_t)vapi_msg_nat64_interface_dump_hton,
    (generic_swap_fn_t)vapi_msg_nat64_interface_dump_ntoh,
    ~0,
  };

  vapi_msg_id_nat64_interface_dump = vapi_register_msg(&__vapi_metadata_nat64_interface_dump);
  VAPI_DBG("Assigned msg id %d to nat64_interface_dump", vapi_msg_id_nat64_interface_dump);
}

static void __attribute__((constructor)) __vapi_constructor_nat_det_add_del_map()
{
  static const char name[] = "nat_det_add_del_map";
  static const char name_with_crc[] = "nat_det_add_del_map_477b07ed";
  static vapi_message_desc_t __vapi_metadata_nat_det_add_del_map = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_nat_det_add_del_map, payload),
    sizeof(vapi_msg_nat_det_add_del_map),
    (generic_swap_fn_t)vapi_msg_nat_det_add_del_map_hton,
    (generic_swap_fn_t)vapi_msg_nat_det_add_del_map_ntoh,
    ~0,
  };

  vapi_msg_id_nat_det_add_del_map = vapi_register_msg(&__vapi_metadata_nat_det_add_del_map);
  VAPI_DBG("Assigned msg id %d to nat_det_add_del_map", vapi_msg_id_nat_det_add_del_map);
}

static void __attribute__((constructor)) __vapi_constructor_snat_interface_add_del_feature_reply()
{
  static const char name[] = "snat_interface_add_del_feature_reply";
  static const char name_with_crc[] = "snat_interface_add_del_feature_reply_abd1e17f";
  static vapi_message_desc_t __vapi_metadata_snat_interface_add_del_feature_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_snat_interface_add_del_feature_reply, payload),
    sizeof(vapi_msg_snat_interface_add_del_feature_reply),
    (generic_swap_fn_t)vapi_msg_snat_interface_add_del_feature_reply_hton,
    (generic_swap_fn_t)vapi_msg_snat_interface_add_del_feature_reply_ntoh,
    ~0,
  };

  vapi_msg_id_snat_interface_add_del_feature_reply = vapi_register_msg(&__vapi_metadata_snat_interface_add_del_feature_reply);
  VAPI_DBG("Assigned msg id %d to snat_interface_add_del_feature_reply", vapi_msg_id_snat_interface_add_del_feature_reply);
}

static void __attribute__((constructor)) __vapi_constructor_nat64_prefix_details()
{
  static const char name[] = "nat64_prefix_details";
  static const char name_with_crc[] = "nat64_prefix_details_521be2eb";
  static vapi_message_desc_t __vapi_metadata_nat64_prefix_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat64_prefix_details, payload),
    sizeof(vapi_msg_nat64_prefix_details),
    (generic_swap_fn_t)vapi_msg_nat64_prefix_details_hton,
    (generic_swap_fn_t)vapi_msg_nat64_prefix_details_ntoh,
    ~0,
  };

  vapi_msg_id_nat64_prefix_details = vapi_register_msg(&__vapi_metadata_nat64_prefix_details);
  VAPI_DBG("Assigned msg id %d to nat64_prefix_details", vapi_msg_id_nat64_prefix_details);
}

static void __attribute__((constructor)) __vapi_constructor_snat_ipfix_enable_disable()
{
  static const char name[] = "snat_ipfix_enable_disable";
  static const char name_with_crc[] = "snat_ipfix_enable_disable_88f422c2";
  static vapi_message_desc_t __vapi_metadata_snat_ipfix_enable_disable = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_snat_ipfix_enable_disable, payload),
    sizeof(vapi_msg_snat_ipfix_enable_disable),
    (generic_swap_fn_t)vapi_msg_snat_ipfix_enable_disable_hton,
    (generic_swap_fn_t)vapi_msg_snat_ipfix_enable_disable_ntoh,
    ~0,
  };

  vapi_msg_id_snat_ipfix_enable_disable = vapi_register_msg(&__vapi_metadata_snat_ipfix_enable_disable);
  VAPI_DBG("Assigned msg id %d to snat_ipfix_enable_disable", vapi_msg_id_snat_ipfix_enable_disable);
}

static void __attribute__((constructor)) __vapi_constructor_nat_det_get_timeouts_reply()
{
  static const char name[] = "nat_det_get_timeouts_reply";
  static const char name_with_crc[] = "nat_det_get_timeouts_reply_4a25be37";
  static vapi_message_desc_t __vapi_metadata_nat_det_get_timeouts_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat_det_get_timeouts_reply, payload),
    sizeof(vapi_msg_nat_det_get_timeouts_reply),
    (generic_swap_fn_t)vapi_msg_nat_det_get_timeouts_reply_hton,
    (generic_swap_fn_t)vapi_msg_nat_det_get_timeouts_reply_ntoh,
    ~0,
  };

  vapi_msg_id_nat_det_get_timeouts_reply = vapi_register_msg(&__vapi_metadata_nat_det_get_timeouts_reply);
  VAPI_DBG("Assigned msg id %d to nat_det_get_timeouts_reply", vapi_msg_id_nat_det_get_timeouts_reply);
}

static void __attribute__((constructor)) __vapi_constructor_nat_det_reverse_reply()
{
  static const char name[] = "nat_det_reverse_reply";
  static const char name_with_crc[] = "nat_det_reverse_reply_61420be4";
  static vapi_message_desc_t __vapi_metadata_nat_det_reverse_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat_det_reverse_reply, payload),
    sizeof(vapi_msg_nat_det_reverse_reply),
    (generic_swap_fn_t)vapi_msg_nat_det_reverse_reply_hton,
    (generic_swap_fn_t)vapi_msg_nat_det_reverse_reply_ntoh,
    ~0,
  };

  vapi_msg_id_nat_det_reverse_reply = vapi_register_msg(&__vapi_metadata_nat_det_reverse_reply);
  VAPI_DBG("Assigned msg id %d to nat_det_reverse_reply", vapi_msg_id_nat_det_reverse_reply);
}

static void __attribute__((constructor)) __vapi_constructor_nat44_user_dump()
{
  static const char name[] = "nat44_user_dump";
  static const char name_with_crc[] = "nat44_user_dump_bf92f8eb";
  static vapi_message_desc_t __vapi_metadata_nat44_user_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_nat44_user_dump),
    (generic_swap_fn_t)vapi_msg_nat44_user_dump_hton,
    (generic_swap_fn_t)vapi_msg_nat44_user_dump_ntoh,
    ~0,
  };

  vapi_msg_id_nat44_user_dump = vapi_register_msg(&__vapi_metadata_nat44_user_dump);
  VAPI_DBG("Assigned msg id %d to nat44_user_dump", vapi_msg_id_nat44_user_dump);
}

static void __attribute__((constructor)) __vapi_constructor_snat_det_set_timeouts()
{
  static const char name[] = "snat_det_set_timeouts";
  static const char name_with_crc[] = "snat_det_set_timeouts_fe713877";
  static vapi_message_desc_t __vapi_metadata_snat_det_set_timeouts = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_snat_det_set_timeouts, payload),
    sizeof(vapi_msg_snat_det_set_timeouts),
    (generic_swap_fn_t)vapi_msg_snat_det_set_timeouts_hton,
    (generic_swap_fn_t)vapi_msg_snat_det_set_timeouts_ntoh,
    ~0,
  };

  vapi_msg_id_snat_det_set_timeouts = vapi_register_msg(&__vapi_metadata_snat_det_set_timeouts);
  VAPI_DBG("Assigned msg id %d to snat_det_set_timeouts", vapi_msg_id_snat_det_set_timeouts);
}

static void __attribute__((constructor)) __vapi_constructor_nat44_static_mapping_details()
{
  static const char name[] = "nat44_static_mapping_details";
  static const char name_with_crc[] = "nat44_static_mapping_details_fd6c218f";
  static vapi_message_desc_t __vapi_metadata_nat44_static_mapping_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat44_static_mapping_details, payload),
    sizeof(vapi_msg_nat44_static_mapping_details),
    (generic_swap_fn_t)vapi_msg_nat44_static_mapping_details_hton,
    (generic_swap_fn_t)vapi_msg_nat44_static_mapping_details_ntoh,
    ~0,
  };

  vapi_msg_id_nat44_static_mapping_details = vapi_register_msg(&__vapi_metadata_nat44_static_mapping_details);
  VAPI_DBG("Assigned msg id %d to nat44_static_mapping_details", vapi_msg_id_nat44_static_mapping_details);
}

static void __attribute__((constructor)) __vapi_constructor_nat64_add_del_prefix_reply()
{
  static const char name[] = "nat64_add_del_prefix_reply";
  static const char name_with_crc[] = "nat64_add_del_prefix_reply_098c2c7a";
  static vapi_message_desc_t __vapi_metadata_nat64_add_del_prefix_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat64_add_del_prefix_reply, payload),
    sizeof(vapi_msg_nat64_add_del_prefix_reply),
    (generic_swap_fn_t)vapi_msg_nat64_add_del_prefix_reply_hton,
    (generic_swap_fn_t)vapi_msg_nat64_add_del_prefix_reply_ntoh,
    ~0,
  };

  vapi_msg_id_nat64_add_del_prefix_reply = vapi_register_msg(&__vapi_metadata_nat64_add_del_prefix_reply);
  VAPI_DBG("Assigned msg id %d to nat64_add_del_prefix_reply", vapi_msg_id_nat64_add_del_prefix_reply);
}

static void __attribute__((constructor)) __vapi_constructor_nat64_st_details()
{
  static const char name[] = "nat64_st_details";
  static const char name_with_crc[] = "nat64_st_details_5ac62548";
  static vapi_message_desc_t __vapi_metadata_nat64_st_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat64_st_details, payload),
    sizeof(vapi_msg_nat64_st_details),
    (generic_swap_fn_t)vapi_msg_nat64_st_details_hton,
    (generic_swap_fn_t)vapi_msg_nat64_st_details_ntoh,
    ~0,
  };

  vapi_msg_id_nat64_st_details = vapi_register_msg(&__vapi_metadata_nat64_st_details);
  VAPI_DBG("Assigned msg id %d to nat64_st_details", vapi_msg_id_nat64_st_details);
}

static void __attribute__((constructor)) __vapi_constructor_snat_show_config_reply()
{
  static const char name[] = "snat_show_config_reply";
  static const char name_with_crc[] = "snat_show_config_reply_bf9c4060";
  static vapi_message_desc_t __vapi_metadata_snat_show_config_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_snat_show_config_reply, payload),
    sizeof(vapi_msg_snat_show_config_reply),
    (generic_swap_fn_t)vapi_msg_snat_show_config_reply_hton,
    (generic_swap_fn_t)vapi_msg_snat_show_config_reply_ntoh,
    ~0,
  };

  vapi_msg_id_snat_show_config_reply = vapi_register_msg(&__vapi_metadata_snat_show_config_reply);
  VAPI_DBG("Assigned msg id %d to snat_show_config_reply", vapi_msg_id_snat_show_config_reply);
}

static void __attribute__((constructor)) __vapi_constructor_snat_add_static_mapping()
{
  static const char name[] = "snat_add_static_mapping";
  static const char name_with_crc[] = "snat_add_static_mapping_d478ee49";
  static vapi_message_desc_t __vapi_metadata_snat_add_static_mapping = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_snat_add_static_mapping, payload),
    sizeof(vapi_msg_snat_add_static_mapping),
    (generic_swap_fn_t)vapi_msg_snat_add_static_mapping_hton,
    (generic_swap_fn_t)vapi_msg_snat_add_static_mapping_ntoh,
    ~0,
  };

  vapi_msg_id_snat_add_static_mapping = vapi_register_msg(&__vapi_metadata_snat_add_static_mapping);
  VAPI_DBG("Assigned msg id %d to snat_add_static_mapping", vapi_msg_id_snat_add_static_mapping);
}

static void __attribute__((constructor)) __vapi_constructor_nat_control_ping()
{
  static const char name[] = "nat_control_ping";
  static const char name_with_crc[] = "nat_control_ping_96e6a834";
  static vapi_message_desc_t __vapi_metadata_nat_control_ping = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_nat_control_ping),
    (generic_swap_fn_t)vapi_msg_nat_control_ping_hton,
    (generic_swap_fn_t)vapi_msg_nat_control_ping_ntoh,
    ~0,
  };

  vapi_msg_id_nat_control_ping = vapi_register_msg(&__vapi_metadata_nat_control_ping);
  VAPI_DBG("Assigned msg id %d to nat_control_ping", vapi_msg_id_nat_control_ping);
}

static void __attribute__((constructor)) __vapi_constructor_nat44_interface_add_del_output_feature_reply()
{
  static const char name[] = "nat44_interface_add_del_output_feature_reply";
  static const char name_with_crc[] = "nat44_interface_add_del_output_feature_reply_afb362f5";
  static vapi_message_desc_t __vapi_metadata_nat44_interface_add_del_output_feature_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat44_interface_add_del_output_feature_reply, payload),
    sizeof(vapi_msg_nat44_interface_add_del_output_feature_reply),
    (generic_swap_fn_t)vapi_msg_nat44_interface_add_del_output_feature_reply_hton,
    (generic_swap_fn_t)vapi_msg_nat44_interface_add_del_output_feature_reply_ntoh,
    ~0,
  };

  vapi_msg_id_nat44_interface_add_del_output_feature_reply = vapi_register_msg(&__vapi_metadata_nat44_interface_add_del_output_feature_reply);
  VAPI_DBG("Assigned msg id %d to nat44_interface_add_del_output_feature_reply", vapi_msg_id_nat44_interface_add_del_output_feature_reply);
}

static void __attribute__((constructor)) __vapi_constructor_snat_add_static_mapping_reply()
{
  static const char name[] = "snat_add_static_mapping_reply";
  static const char name_with_crc[] = "snat_add_static_mapping_reply_c9db5568";
  static vapi_message_desc_t __vapi_metadata_snat_add_static_mapping_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_snat_add_static_mapping_reply, payload),
    sizeof(vapi_msg_snat_add_static_mapping_reply),
    (generic_swap_fn_t)vapi_msg_snat_add_static_mapping_reply_hton,
    (generic_swap_fn_t)vapi_msg_snat_add_static_mapping_reply_ntoh,
    ~0,
  };

  vapi_msg_id_snat_add_static_mapping_reply = vapi_register_msg(&__vapi_metadata_snat_add_static_mapping_reply);
  VAPI_DBG("Assigned msg id %d to snat_add_static_mapping_reply", vapi_msg_id_snat_add_static_mapping_reply);
}

static void __attribute__((constructor)) __vapi_constructor_nat64_add_del_interface()
{
  static const char name[] = "nat64_add_del_interface";
  static const char name_with_crc[] = "nat64_add_del_interface_df24a879";
  static vapi_message_desc_t __vapi_metadata_nat64_add_del_interface = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_nat64_add_del_interface, payload),
    sizeof(vapi_msg_nat64_add_del_interface),
    (generic_swap_fn_t)vapi_msg_nat64_add_del_interface_hton,
    (generic_swap_fn_t)vapi_msg_nat64_add_del_interface_ntoh,
    ~0,
  };

  vapi_msg_id_nat64_add_del_interface = vapi_register_msg(&__vapi_metadata_nat64_add_del_interface);
  VAPI_DBG("Assigned msg id %d to nat64_add_del_interface", vapi_msg_id_nat64_add_del_interface);
}

static void __attribute__((constructor)) __vapi_constructor_nat_det_close_session_in()
{
  static const char name[] = "nat_det_close_session_in";
  static const char name_with_crc[] = "nat_det_close_session_in_ff933811";
  static vapi_message_desc_t __vapi_metadata_nat_det_close_session_in = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_nat_det_close_session_in, payload),
    sizeof(vapi_msg_nat_det_close_session_in),
    (generic_swap_fn_t)vapi_msg_nat_det_close_session_in_hton,
    (generic_swap_fn_t)vapi_msg_nat_det_close_session_in_ntoh,
    ~0,
  };

  vapi_msg_id_nat_det_close_session_in = vapi_register_msg(&__vapi_metadata_nat_det_close_session_in);
  VAPI_DBG("Assigned msg id %d to nat_det_close_session_in", vapi_msg_id_nat_det_close_session_in);
}

static void __attribute__((constructor)) __vapi_constructor_nat44_user_session_dump()
{
  static const char name[] = "nat44_user_session_dump";
  static const char name_with_crc[] = "nat44_user_session_dump_597cec3f";
  static vapi_message_desc_t __vapi_metadata_nat44_user_session_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_nat44_user_session_dump, payload),
    sizeof(vapi_msg_nat44_user_session_dump),
    (generic_swap_fn_t)vapi_msg_nat44_user_session_dump_hton,
    (generic_swap_fn_t)vapi_msg_nat44_user_session_dump_ntoh,
    ~0,
  };

  vapi_msg_id_nat44_user_session_dump = vapi_register_msg(&__vapi_metadata_nat44_user_session_dump);
  VAPI_DBG("Assigned msg id %d to nat44_user_session_dump", vapi_msg_id_nat44_user_session_dump);
}

static void __attribute__((constructor)) __vapi_constructor_nat44_static_mapping_dump()
{
  static const char name[] = "nat44_static_mapping_dump";
  static const char name_with_crc[] = "nat44_static_mapping_dump_df3b078e";
  static vapi_message_desc_t __vapi_metadata_nat44_static_mapping_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_nat44_static_mapping_dump),
    (generic_swap_fn_t)vapi_msg_nat44_static_mapping_dump_hton,
    (generic_swap_fn_t)vapi_msg_nat44_static_mapping_dump_ntoh,
    ~0,
  };

  vapi_msg_id_nat44_static_mapping_dump = vapi_register_msg(&__vapi_metadata_nat44_static_mapping_dump);
  VAPI_DBG("Assigned msg id %d to nat44_static_mapping_dump", vapi_msg_id_nat44_static_mapping_dump);
}

static void __attribute__((constructor)) __vapi_constructor_snat_worker_details()
{
  static const char name[] = "snat_worker_details";
  static const char name_with_crc[] = "snat_worker_details_6a1d1344";
  static vapi_message_desc_t __vapi_metadata_snat_worker_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_snat_worker_details, payload),
    sizeof(vapi_msg_snat_worker_details),
    (generic_swap_fn_t)vapi_msg_snat_worker_details_hton,
    (generic_swap_fn_t)vapi_msg_snat_worker_details_ntoh,
    ~0,
  };

  vapi_msg_id_snat_worker_details = vapi_register_msg(&__vapi_metadata_snat_worker_details);
  VAPI_DBG("Assigned msg id %d to snat_worker_details", vapi_msg_id_snat_worker_details);
}

static void __attribute__((constructor)) __vapi_constructor_snat_det_map_dump()
{
  static const char name[] = "snat_det_map_dump";
  static const char name_with_crc[] = "snat_det_map_dump_9da7fd51";
  static vapi_message_desc_t __vapi_metadata_snat_det_map_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_snat_det_map_dump),
    (generic_swap_fn_t)vapi_msg_snat_det_map_dump_hton,
    (generic_swap_fn_t)vapi_msg_snat_det_map_dump_ntoh,
    ~0,
  };

  vapi_msg_id_snat_det_map_dump = vapi_register_msg(&__vapi_metadata_snat_det_map_dump);
  VAPI_DBG("Assigned msg id %d to snat_det_map_dump", vapi_msg_id_snat_det_map_dump);
}

static void __attribute__((constructor)) __vapi_constructor_nat64_set_timeouts_reply()
{
  static const char name[] = "nat64_set_timeouts_reply";
  static const char name_with_crc[] = "nat64_set_timeouts_reply_f8de0c6d";
  static vapi_message_desc_t __vapi_metadata_nat64_set_timeouts_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat64_set_timeouts_reply, payload),
    sizeof(vapi_msg_nat64_set_timeouts_reply),
    (generic_swap_fn_t)vapi_msg_nat64_set_timeouts_reply_hton,
    (generic_swap_fn_t)vapi_msg_nat64_set_timeouts_reply_ntoh,
    ~0,
  };

  vapi_msg_id_nat64_set_timeouts_reply = vapi_register_msg(&__vapi_metadata_nat64_set_timeouts_reply);
  VAPI_DBG("Assigned msg id %d to nat64_set_timeouts_reply", vapi_msg_id_nat64_set_timeouts_reply);
}

static void __attribute__((constructor)) __vapi_constructor_nat44_user_session_details()
{
  static const char name[] = "nat44_user_session_details";
  static const char name_with_crc[] = "nat44_user_session_details_9abeddd4";
  static vapi_message_desc_t __vapi_metadata_nat44_user_session_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat44_user_session_details, payload),
    sizeof(vapi_msg_nat44_user_session_details),
    (generic_swap_fn_t)vapi_msg_nat44_user_session_details_hton,
    (generic_swap_fn_t)vapi_msg_nat44_user_session_details_ntoh,
    ~0,
  };

  vapi_msg_id_nat44_user_session_details = vapi_register_msg(&__vapi_metadata_nat44_user_session_details);
  VAPI_DBG("Assigned msg id %d to nat44_user_session_details", vapi_msg_id_nat44_user_session_details);
}

static void __attribute__((constructor)) __vapi_constructor_snat_add_del_interface_addr()
{
  static const char name[] = "snat_add_del_interface_addr";
  static const char name_with_crc[] = "snat_add_del_interface_addr_42b97914";
  static vapi_message_desc_t __vapi_metadata_snat_add_del_interface_addr = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_snat_add_del_interface_addr, payload),
    sizeof(vapi_msg_snat_add_del_interface_addr),
    (generic_swap_fn_t)vapi_msg_snat_add_del_interface_addr_hton,
    (generic_swap_fn_t)vapi_msg_snat_add_del_interface_addr_ntoh,
    ~0,
  };

  vapi_msg_id_snat_add_del_interface_addr = vapi_register_msg(&__vapi_metadata_snat_add_del_interface_addr);
  VAPI_DBG("Assigned msg id %d to snat_add_del_interface_addr", vapi_msg_id_snat_add_del_interface_addr);
}

static void __attribute__((constructor)) __vapi_constructor_snat_ipfix_enable_disable_reply()
{
  static const char name[] = "snat_ipfix_enable_disable_reply";
  static const char name_with_crc[] = "snat_ipfix_enable_disable_reply_a7f6c343";
  static vapi_message_desc_t __vapi_metadata_snat_ipfix_enable_disable_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_snat_ipfix_enable_disable_reply, payload),
    sizeof(vapi_msg_snat_ipfix_enable_disable_reply),
    (generic_swap_fn_t)vapi_msg_snat_ipfix_enable_disable_reply_hton,
    (generic_swap_fn_t)vapi_msg_snat_ipfix_enable_disable_reply_ntoh,
    ~0,
  };

  vapi_msg_id_snat_ipfix_enable_disable_reply = vapi_register_msg(&__vapi_metadata_snat_ipfix_enable_disable_reply);
  VAPI_DBG("Assigned msg id %d to snat_ipfix_enable_disable_reply", vapi_msg_id_snat_ipfix_enable_disable_reply);
}

static void __attribute__((constructor)) __vapi_constructor_snat_address_dump()
{
  static const char name[] = "snat_address_dump";
  static const char name_with_crc[] = "snat_address_dump_27c92402";
  static vapi_message_desc_t __vapi_metadata_snat_address_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_snat_address_dump),
    (generic_swap_fn_t)vapi_msg_snat_address_dump_hton,
    (generic_swap_fn_t)vapi_msg_snat_address_dump_ntoh,
    ~0,
  };

  vapi_msg_id_snat_address_dump = vapi_register_msg(&__vapi_metadata_snat_address_dump);
  VAPI_DBG("Assigned msg id %d to snat_address_dump", vapi_msg_id_snat_address_dump);
}

static void __attribute__((constructor)) __vapi_constructor_snat_set_workers()
{
  static const char name[] = "snat_set_workers";
  static const char name_with_crc[] = "snat_set_workers_e884f45e";
  static vapi_message_desc_t __vapi_metadata_snat_set_workers = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_snat_set_workers, payload),
    sizeof(vapi_msg_snat_set_workers),
    (generic_swap_fn_t)vapi_msg_snat_set_workers_hton,
    (generic_swap_fn_t)vapi_msg_snat_set_workers_ntoh,
    ~0,
  };

  vapi_msg_id_snat_set_workers = vapi_register_msg(&__vapi_metadata_snat_set_workers);
  VAPI_DBG("Assigned msg id %d to snat_set_workers", vapi_msg_id_snat_set_workers);
}

static void __attribute__((constructor)) __vapi_constructor_nat44_interface_output_feature_dump()
{
  static const char name[] = "nat44_interface_output_feature_dump";
  static const char name_with_crc[] = "nat44_interface_output_feature_dump_e7245137";
  static vapi_message_desc_t __vapi_metadata_nat44_interface_output_feature_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_nat44_interface_output_feature_dump),
    (generic_swap_fn_t)vapi_msg_nat44_interface_output_feature_dump_hton,
    (generic_swap_fn_t)vapi_msg_nat44_interface_output_feature_dump_ntoh,
    ~0,
  };

  vapi_msg_id_nat44_interface_output_feature_dump = vapi_register_msg(&__vapi_metadata_nat44_interface_output_feature_dump);
  VAPI_DBG("Assigned msg id %d to nat44_interface_output_feature_dump", vapi_msg_id_nat44_interface_output_feature_dump);
}

static void __attribute__((constructor)) __vapi_constructor_nat44_interface_add_del_feature()
{
  static const char name[] = "nat44_interface_add_del_feature";
  static const char name_with_crc[] = "nat44_interface_add_del_feature_c5aa4c6e";
  static vapi_message_desc_t __vapi_metadata_nat44_interface_add_del_feature = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_nat44_interface_add_del_feature, payload),
    sizeof(vapi_msg_nat44_interface_add_del_feature),
    (generic_swap_fn_t)vapi_msg_nat44_interface_add_del_feature_hton,
    (generic_swap_fn_t)vapi_msg_nat44_interface_add_del_feature_ntoh,
    ~0,
  };

  vapi_msg_id_nat44_interface_add_del_feature = vapi_register_msg(&__vapi_metadata_nat44_interface_add_del_feature);
  VAPI_DBG("Assigned msg id %d to nat44_interface_add_del_feature", vapi_msg_id_nat44_interface_add_del_feature);
}

static void __attribute__((constructor)) __vapi_constructor_nat44_interface_output_feature_details()
{
  static const char name[] = "nat44_interface_output_feature_details";
  static const char name_with_crc[] = "nat44_interface_output_feature_details_119c7053";
  static vapi_message_desc_t __vapi_metadata_nat44_interface_output_feature_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat44_interface_output_feature_details, payload),
    sizeof(vapi_msg_nat44_interface_output_feature_details),
    (generic_swap_fn_t)vapi_msg_nat44_interface_output_feature_details_hton,
    (generic_swap_fn_t)vapi_msg_nat44_interface_output_feature_details_ntoh,
    ~0,
  };

  vapi_msg_id_nat44_interface_output_feature_details = vapi_register_msg(&__vapi_metadata_nat44_interface_output_feature_details);
  VAPI_DBG("Assigned msg id %d to nat44_interface_output_feature_details", vapi_msg_id_nat44_interface_output_feature_details);
}

static void __attribute__((constructor)) __vapi_constructor_nat_det_reverse()
{
  static const char name[] = "nat_det_reverse";
  static const char name_with_crc[] = "nat_det_reverse_bb55c1d1";
  static vapi_message_desc_t __vapi_metadata_nat_det_reverse = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_nat_det_reverse, payload),
    sizeof(vapi_msg_nat_det_reverse),
    (generic_swap_fn_t)vapi_msg_nat_det_reverse_hton,
    (generic_swap_fn_t)vapi_msg_nat_det_reverse_ntoh,
    ~0,
  };

  vapi_msg_id_nat_det_reverse = vapi_register_msg(&__vapi_metadata_nat_det_reverse);
  VAPI_DBG("Assigned msg id %d to nat_det_reverse", vapi_msg_id_nat_det_reverse);
}

static void __attribute__((constructor)) __vapi_constructor_nat_det_session_details()
{
  static const char name[] = "nat_det_session_details";
  static const char name_with_crc[] = "nat_det_session_details_7e7399c3";
  static vapi_message_desc_t __vapi_metadata_nat_det_session_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_nat_det_session_details, payload),
    sizeof(vapi_msg_nat_det_session_details),
    (generic_swap_fn_t)vapi_msg_nat_det_session_details_hton,
    (generic_swap_fn_t)vapi_msg_nat_det_session_details_ntoh,
    ~0,
  };

  vapi_msg_id_nat_det_session_details = vapi_register_msg(&__vapi_metadata_nat_det_session_details);
  VAPI_DBG("Assigned msg id %d to nat_det_session_details", vapi_msg_id_nat_det_session_details);
}

static void __attribute__((constructor)) __vapi_constructor_snat_interface_add_del_output_feature_reply()
{
  static const char name[] = "snat_interface_add_del_output_feature_reply";
  static const char name_with_crc[] = "snat_interface_add_del_output_feature_reply_731bfbcb";
  static vapi_message_desc_t __vapi_metadata_snat_interface_add_del_output_feature_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_snat_interface_add_del_output_feature_reply, payload),
    sizeof(vapi_msg_snat_interface_add_del_output_feature_reply),
    (generic_swap_fn_t)vapi_msg_snat_interface_add_del_output_feature_reply_hton,
    (generic_swap_fn_t)vapi_msg_snat_interface_add_del_output_feature_reply_ntoh,
    ~0,
  };

  vapi_msg_id_snat_interface_add_del_output_feature_reply = vapi_register_msg(&__vapi_metadata_snat_interface_add_del_output_feature_reply);
  VAPI_DBG("Assigned msg id %d to snat_interface_add_del_output_feature_reply", vapi_msg_id_snat_interface_add_del_output_feature_reply);
}

static void __attribute__((constructor)) __vapi_constructor_nat44_interface_add_del_feature_reply()
{
  static const char name[] = "nat44_interface_add_del_feature_reply";
  static const char name_with_crc[] = "nat44_interface_add_del_feature_reply_fefe38af";
  static vapi_message_desc_t __vapi_metadata_nat44_interface_add_del_feature_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat44_interface_add_del_feature_reply, payload),
    sizeof(vapi_msg_nat44_interface_add_del_feature_reply),
    (generic_swap_fn_t)vapi_msg_nat44_interface_add_del_feature_reply_hton,
    (generic_swap_fn_t)vapi_msg_nat44_interface_add_del_feature_reply_ntoh,
    ~0,
  };

  vapi_msg_id_nat44_interface_add_del_feature_reply = vapi_register_msg(&__vapi_metadata_nat44_interface_add_del_feature_reply);
  VAPI_DBG("Assigned msg id %d to nat44_interface_add_del_feature_reply", vapi_msg_id_nat44_interface_add_del_feature_reply);
}

static void __attribute__((constructor)) __vapi_constructor_nat44_add_del_address_range_reply()
{
  static const char name[] = "nat44_add_del_address_range_reply";
  static const char name_with_crc[] = "nat44_add_del_address_range_reply_4e9b159d";
  static vapi_message_desc_t __vapi_metadata_nat44_add_del_address_range_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat44_add_del_address_range_reply, payload),
    sizeof(vapi_msg_nat44_add_del_address_range_reply),
    (generic_swap_fn_t)vapi_msg_nat44_add_del_address_range_reply_hton,
    (generic_swap_fn_t)vapi_msg_nat44_add_del_address_range_reply_ntoh,
    ~0,
  };

  vapi_msg_id_nat44_add_del_address_range_reply = vapi_register_msg(&__vapi_metadata_nat44_add_del_address_range_reply);
  VAPI_DBG("Assigned msg id %d to nat44_add_del_address_range_reply", vapi_msg_id_nat44_add_del_address_range_reply);
}

static void __attribute__((constructor)) __vapi_constructor_nat64_add_del_interface_reply()
{
  static const char name[] = "nat64_add_del_interface_reply";
  static const char name_with_crc[] = "nat64_add_del_interface_reply_cfbb3de6";
  static vapi_message_desc_t __vapi_metadata_nat64_add_del_interface_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat64_add_del_interface_reply, payload),
    sizeof(vapi_msg_nat64_add_del_interface_reply),
    (generic_swap_fn_t)vapi_msg_nat64_add_del_interface_reply_hton,
    (generic_swap_fn_t)vapi_msg_nat64_add_del_interface_reply_ntoh,
    ~0,
  };

  vapi_msg_id_nat64_add_del_interface_reply = vapi_register_msg(&__vapi_metadata_nat64_add_del_interface_reply);
  VAPI_DBG("Assigned msg id %d to nat64_add_del_interface_reply", vapi_msg_id_nat64_add_del_interface_reply);
}

static void __attribute__((constructor)) __vapi_constructor_nat_det_forward()
{
  static const char name[] = "nat_det_forward";
  static const char name_with_crc[] = "nat_det_forward_85b74d31";
  static vapi_message_desc_t __vapi_metadata_nat_det_forward = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_nat_det_forward, payload),
    sizeof(vapi_msg_nat_det_forward),
    (generic_swap_fn_t)vapi_msg_nat_det_forward_hton,
    (generic_swap_fn_t)vapi_msg_nat_det_forward_ntoh,
    ~0,
  };

  vapi_msg_id_nat_det_forward = vapi_register_msg(&__vapi_metadata_nat_det_forward);
  VAPI_DBG("Assigned msg id %d to nat_det_forward", vapi_msg_id_nat_det_forward);
}

static void __attribute__((constructor)) __vapi_constructor_nat_worker_dump()
{
  static const char name[] = "nat_worker_dump";
  static const char name_with_crc[] = "nat_worker_dump_6adf1d97";
  static vapi_message_desc_t __vapi_metadata_nat_worker_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_nat_worker_dump),
    (generic_swap_fn_t)vapi_msg_nat_worker_dump_hton,
    (generic_swap_fn_t)vapi_msg_nat_worker_dump_ntoh,
    ~0,
  };

  vapi_msg_id_nat_worker_dump = vapi_register_msg(&__vapi_metadata_nat_worker_dump);
  VAPI_DBG("Assigned msg id %d to nat_worker_dump", vapi_msg_id_nat_worker_dump);
}

static void __attribute__((constructor)) __vapi_constructor_snat_interface_addr_dump()
{
  static const char name[] = "snat_interface_addr_dump";
  static const char name_with_crc[] = "snat_interface_addr_dump_3e801286";
  static vapi_message_desc_t __vapi_metadata_snat_interface_addr_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_snat_interface_addr_dump),
    (generic_swap_fn_t)vapi_msg_snat_interface_addr_dump_hton,
    (generic_swap_fn_t)vapi_msg_snat_interface_addr_dump_ntoh,
    ~0,
  };

  vapi_msg_id_snat_interface_addr_dump = vapi_register_msg(&__vapi_metadata_snat_interface_addr_dump);
  VAPI_DBG("Assigned msg id %d to snat_interface_addr_dump", vapi_msg_id_snat_interface_addr_dump);
}

static void __attribute__((constructor)) __vapi_constructor_nat_det_get_timeouts()
{
  static const char name[] = "nat_det_get_timeouts";
  static const char name_with_crc[] = "nat_det_get_timeouts_8dac1e2d";
  static vapi_message_desc_t __vapi_metadata_nat_det_get_timeouts = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_nat_det_get_timeouts),
    (generic_swap_fn_t)vapi_msg_nat_det_get_timeouts_hton,
    (generic_swap_fn_t)vapi_msg_nat_det_get_timeouts_ntoh,
    ~0,
  };

  vapi_msg_id_nat_det_get_timeouts = vapi_register_msg(&__vapi_metadata_nat_det_get_timeouts);
  VAPI_DBG("Assigned msg id %d to nat_det_get_timeouts", vapi_msg_id_nat_det_get_timeouts);
}

static void __attribute__((constructor)) __vapi_constructor_nat_det_add_del_map_reply()
{
  static const char name[] = "nat_det_add_del_map_reply";
  static const char name_with_crc[] = "nat_det_add_del_map_reply_2fa49765";
  static vapi_message_desc_t __vapi_metadata_nat_det_add_del_map_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat_det_add_del_map_reply, payload),
    sizeof(vapi_msg_nat_det_add_del_map_reply),
    (generic_swap_fn_t)vapi_msg_nat_det_add_del_map_reply_hton,
    (generic_swap_fn_t)vapi_msg_nat_det_add_del_map_reply_ntoh,
    ~0,
  };

  vapi_msg_id_nat_det_add_del_map_reply = vapi_register_msg(&__vapi_metadata_nat_det_add_del_map_reply);
  VAPI_DBG("Assigned msg id %d to nat_det_add_del_map_reply", vapi_msg_id_nat_det_add_del_map_reply);
}

static void __attribute__((constructor)) __vapi_constructor_nat44_interface_addr_dump()
{
  static const char name[] = "nat44_interface_addr_dump";
  static const char name_with_crc[] = "nat44_interface_addr_dump_65ac3823";
  static vapi_message_desc_t __vapi_metadata_nat44_interface_addr_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_nat44_interface_addr_dump),
    (generic_swap_fn_t)vapi_msg_nat44_interface_addr_dump_hton,
    (generic_swap_fn_t)vapi_msg_nat44_interface_addr_dump_ntoh,
    ~0,
  };

  vapi_msg_id_nat44_interface_addr_dump = vapi_register_msg(&__vapi_metadata_nat44_interface_addr_dump);
  VAPI_DBG("Assigned msg id %d to nat44_interface_addr_dump", vapi_msg_id_nat44_interface_addr_dump);
}

static void __attribute__((constructor)) __vapi_constructor_nat_show_config_reply()
{
  static const char name[] = "nat_show_config_reply";
  static const char name_with_crc[] = "nat_show_config_reply_4a456e3a";
  static vapi_message_desc_t __vapi_metadata_nat_show_config_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat_show_config_reply, payload),
    sizeof(vapi_msg_nat_show_config_reply),
    (generic_swap_fn_t)vapi_msg_nat_show_config_reply_hton,
    (generic_swap_fn_t)vapi_msg_nat_show_config_reply_ntoh,
    ~0,
  };

  vapi_msg_id_nat_show_config_reply = vapi_register_msg(&__vapi_metadata_nat_show_config_reply);
  VAPI_DBG("Assigned msg id %d to nat_show_config_reply", vapi_msg_id_nat_show_config_reply);
}

static void __attribute__((constructor)) __vapi_constructor_nat44_add_del_lb_static_mapping_reply()
{
  static const char name[] = "nat44_add_del_lb_static_mapping_reply";
  static const char name_with_crc[] = "nat44_add_del_lb_static_mapping_reply_c24bab18";
  static vapi_message_desc_t __vapi_metadata_nat44_add_del_lb_static_mapping_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat44_add_del_lb_static_mapping_reply, payload),
    sizeof(vapi_msg_nat44_add_del_lb_static_mapping_reply),
    (generic_swap_fn_t)vapi_msg_nat44_add_del_lb_static_mapping_reply_hton,
    (generic_swap_fn_t)vapi_msg_nat44_add_del_lb_static_mapping_reply_ntoh,
    ~0,
  };

  vapi_msg_id_nat44_add_del_lb_static_mapping_reply = vapi_register_msg(&__vapi_metadata_nat44_add_del_lb_static_mapping_reply);
  VAPI_DBG("Assigned msg id %d to nat44_add_del_lb_static_mapping_reply", vapi_msg_id_nat44_add_del_lb_static_mapping_reply);
}

static void __attribute__((constructor)) __vapi_constructor_snat_det_get_timeouts_reply()
{
  static const char name[] = "snat_det_get_timeouts_reply";
  static const char name_with_crc[] = "snat_det_get_timeouts_reply_4d03d12e";
  static vapi_message_desc_t __vapi_metadata_snat_det_get_timeouts_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_snat_det_get_timeouts_reply, payload),
    sizeof(vapi_msg_snat_det_get_timeouts_reply),
    (generic_swap_fn_t)vapi_msg_snat_det_get_timeouts_reply_hton,
    (generic_swap_fn_t)vapi_msg_snat_det_get_timeouts_reply_ntoh,
    ~0,
  };

  vapi_msg_id_snat_det_get_timeouts_reply = vapi_register_msg(&__vapi_metadata_snat_det_get_timeouts_reply);
  VAPI_DBG("Assigned msg id %d to snat_det_get_timeouts_reply", vapi_msg_id_snat_det_get_timeouts_reply);
}

static void __attribute__((constructor)) __vapi_constructor_snat_user_details()
{
  static const char name[] = "snat_user_details";
  static const char name_with_crc[] = "snat_user_details_fe7dad8e";
  static vapi_message_desc_t __vapi_metadata_snat_user_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_snat_user_details, payload),
    sizeof(vapi_msg_snat_user_details),
    (generic_swap_fn_t)vapi_msg_snat_user_details_hton,
    (generic_swap_fn_t)vapi_msg_snat_user_details_ntoh,
    ~0,
  };

  vapi_msg_id_snat_user_details = vapi_register_msg(&__vapi_metadata_snat_user_details);
  VAPI_DBG("Assigned msg id %d to snat_user_details", vapi_msg_id_snat_user_details);
}

static void __attribute__((constructor)) __vapi_constructor_snat_det_close_session_in_reply()
{
  static const char name[] = "snat_det_close_session_in_reply";
  static const char name_with_crc[] = "snat_det_close_session_in_reply_1150e58b";
  static vapi_message_desc_t __vapi_metadata_snat_det_close_session_in_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_snat_det_close_session_in_reply, payload),
    sizeof(vapi_msg_snat_det_close_session_in_reply),
    (generic_swap_fn_t)vapi_msg_snat_det_close_session_in_reply_hton,
    (generic_swap_fn_t)vapi_msg_snat_det_close_session_in_reply_ntoh,
    ~0,
  };

  vapi_msg_id_snat_det_close_session_in_reply = vapi_register_msg(&__vapi_metadata_snat_det_close_session_in_reply);
  VAPI_DBG("Assigned msg id %d to snat_det_close_session_in_reply", vapi_msg_id_snat_det_close_session_in_reply);
}

static void __attribute__((constructor)) __vapi_constructor_nat64_add_del_static_bib_reply()
{
  static const char name[] = "nat64_add_del_static_bib_reply";
  static const char name_with_crc[] = "nat64_add_del_static_bib_reply_7045bd17";
  static vapi_message_desc_t __vapi_metadata_nat64_add_del_static_bib_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat64_add_del_static_bib_reply, payload),
    sizeof(vapi_msg_nat64_add_del_static_bib_reply),
    (generic_swap_fn_t)vapi_msg_nat64_add_del_static_bib_reply_hton,
    (generic_swap_fn_t)vapi_msg_nat64_add_del_static_bib_reply_ntoh,
    ~0,
  };

  vapi_msg_id_nat64_add_del_static_bib_reply = vapi_register_msg(&__vapi_metadata_nat64_add_del_static_bib_reply);
  VAPI_DBG("Assigned msg id %d to nat64_add_del_static_bib_reply", vapi_msg_id_nat64_add_del_static_bib_reply);
}

static void __attribute__((constructor)) __vapi_constructor_nat44_address_details()
{
  static const char name[] = "nat44_address_details";
  static const char name_with_crc[] = "nat44_address_details_f4b08b70";
  static vapi_message_desc_t __vapi_metadata_nat44_address_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat44_address_details, payload),
    sizeof(vapi_msg_nat44_address_details),
    (generic_swap_fn_t)vapi_msg_nat44_address_details_hton,
    (generic_swap_fn_t)vapi_msg_nat44_address_details_ntoh,
    ~0,
  };

  vapi_msg_id_nat44_address_details = vapi_register_msg(&__vapi_metadata_nat44_address_details);
  VAPI_DBG("Assigned msg id %d to nat44_address_details", vapi_msg_id_nat44_address_details);
}

static void __attribute__((constructor)) __vapi_constructor_nat44_add_del_lb_static_mapping()
{
  static const char name[] = "nat44_add_del_lb_static_mapping";
  static const char name_with_crc[] = "nat44_add_del_lb_static_mapping_e8ad23b1";
  static vapi_message_desc_t __vapi_metadata_nat44_add_del_lb_static_mapping = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_nat44_add_del_lb_static_mapping, payload),
    sizeof(vapi_msg_nat44_add_del_lb_static_mapping),
    (generic_swap_fn_t)vapi_msg_nat44_add_del_lb_static_mapping_hton,
    (generic_swap_fn_t)vapi_msg_nat44_add_del_lb_static_mapping_ntoh,
    ~0,
  };

  vapi_msg_id_nat44_add_del_lb_static_mapping = vapi_register_msg(&__vapi_metadata_nat44_add_del_lb_static_mapping);
  VAPI_DBG("Assigned msg id %d to nat44_add_del_lb_static_mapping", vapi_msg_id_nat44_add_del_lb_static_mapping);
}

static void __attribute__((constructor)) __vapi_constructor_nat_det_set_timeouts()
{
  static const char name[] = "nat_det_set_timeouts";
  static const char name_with_crc[] = "nat_det_set_timeouts_f957576e";
  static vapi_message_desc_t __vapi_metadata_nat_det_set_timeouts = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_nat_det_set_timeouts, payload),
    sizeof(vapi_msg_nat_det_set_timeouts),
    (generic_swap_fn_t)vapi_msg_nat_det_set_timeouts_hton,
    (generic_swap_fn_t)vapi_msg_nat_det_set_timeouts_ntoh,
    ~0,
  };

  vapi_msg_id_nat_det_set_timeouts = vapi_register_msg(&__vapi_metadata_nat_det_set_timeouts);
  VAPI_DBG("Assigned msg id %d to nat_det_set_timeouts", vapi_msg_id_nat_det_set_timeouts);
}

static void __attribute__((constructor)) __vapi_constructor_snat_user_dump()
{
  static const char name[] = "snat_user_dump";
  static const char name_with_crc[] = "snat_user_dump_062dc900";
  static vapi_message_desc_t __vapi_metadata_snat_user_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_snat_user_dump),
    (generic_swap_fn_t)vapi_msg_snat_user_dump_hton,
    (generic_swap_fn_t)vapi_msg_snat_user_dump_ntoh,
    ~0,
  };

  vapi_msg_id_snat_user_dump = vapi_register_msg(&__vapi_metadata_snat_user_dump);
  VAPI_DBG("Assigned msg id %d to snat_user_dump", vapi_msg_id_snat_user_dump);
}

static void __attribute__((constructor)) __vapi_constructor_snat_add_del_interface_addr_reply()
{
  static const char name[] = "snat_add_del_interface_addr_reply";
  static const char name_with_crc[] = "snat_add_del_interface_addr_reply_8d0be39e";
  static vapi_message_desc_t __vapi_metadata_snat_add_del_interface_addr_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_snat_add_del_interface_addr_reply, payload),
    sizeof(vapi_msg_snat_add_del_interface_addr_reply),
    (generic_swap_fn_t)vapi_msg_snat_add_del_interface_addr_reply_hton,
    (generic_swap_fn_t)vapi_msg_snat_add_del_interface_addr_reply_ntoh,
    ~0,
  };

  vapi_msg_id_snat_add_del_interface_addr_reply = vapi_register_msg(&__vapi_metadata_snat_add_del_interface_addr_reply);
  VAPI_DBG("Assigned msg id %d to snat_add_del_interface_addr_reply", vapi_msg_id_snat_add_del_interface_addr_reply);
}

static void __attribute__((constructor)) __vapi_constructor_snat_set_workers_reply()
{
  static const char name[] = "snat_set_workers_reply";
  static const char name_with_crc[] = "snat_set_workers_reply_47fb5f11";
  static vapi_message_desc_t __vapi_metadata_snat_set_workers_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_snat_set_workers_reply, payload),
    sizeof(vapi_msg_snat_set_workers_reply),
    (generic_swap_fn_t)vapi_msg_snat_set_workers_reply_hton,
    (generic_swap_fn_t)vapi_msg_snat_set_workers_reply_ntoh,
    ~0,
  };

  vapi_msg_id_snat_set_workers_reply = vapi_register_msg(&__vapi_metadata_snat_set_workers_reply);
  VAPI_DBG("Assigned msg id %d to snat_set_workers_reply", vapi_msg_id_snat_set_workers_reply);
}

static void __attribute__((constructor)) __vapi_constructor_snat_det_forward_reply()
{
  static const char name[] = "snat_det_forward_reply";
  static const char name_with_crc[] = "snat_det_forward_reply_c04ce963";
  static vapi_message_desc_t __vapi_metadata_snat_det_forward_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_snat_det_forward_reply, payload),
    sizeof(vapi_msg_snat_det_forward_reply),
    (generic_swap_fn_t)vapi_msg_snat_det_forward_reply_hton,
    (generic_swap_fn_t)vapi_msg_snat_det_forward_reply_ntoh,
    ~0,
  };

  vapi_msg_id_snat_det_forward_reply = vapi_register_msg(&__vapi_metadata_snat_det_forward_reply);
  VAPI_DBG("Assigned msg id %d to snat_det_forward_reply", vapi_msg_id_snat_det_forward_reply);
}

static void __attribute__((constructor)) __vapi_constructor_nat_det_close_session_out()
{
  static const char name[] = "nat_det_close_session_out";
  static const char name_with_crc[] = "nat_det_close_session_out_fa5c6cc6";
  static vapi_message_desc_t __vapi_metadata_nat_det_close_session_out = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_nat_det_close_session_out, payload),
    sizeof(vapi_msg_nat_det_close_session_out),
    (generic_swap_fn_t)vapi_msg_nat_det_close_session_out_hton,
    (generic_swap_fn_t)vapi_msg_nat_det_close_session_out_ntoh,
    ~0,
  };

  vapi_msg_id_nat_det_close_session_out = vapi_register_msg(&__vapi_metadata_nat_det_close_session_out);
  VAPI_DBG("Assigned msg id %d to nat_det_close_session_out", vapi_msg_id_nat_det_close_session_out);
}

static void __attribute__((constructor)) __vapi_constructor_snat_det_reverse_reply()
{
  static const char name[] = "snat_det_reverse_reply";
  static const char name_with_crc[] = "snat_det_reverse_reply_0b0c08d5";
  static vapi_message_desc_t __vapi_metadata_snat_det_reverse_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_snat_det_reverse_reply, payload),
    sizeof(vapi_msg_snat_det_reverse_reply),
    (generic_swap_fn_t)vapi_msg_snat_det_reverse_reply_hton,
    (generic_swap_fn_t)vapi_msg_snat_det_reverse_reply_ntoh,
    ~0,
  };

  vapi_msg_id_snat_det_reverse_reply = vapi_register_msg(&__vapi_metadata_snat_det_reverse_reply);
  VAPI_DBG("Assigned msg id %d to snat_det_reverse_reply", vapi_msg_id_snat_det_reverse_reply);
}

static void __attribute__((constructor)) __vapi_constructor_nat_det_session_dump()
{
  static const char name[] = "nat_det_session_dump";
  static const char name_with_crc[] = "nat_det_session_dump_e265f99d";
  static vapi_message_desc_t __vapi_metadata_nat_det_session_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_nat_det_session_dump, payload),
    sizeof(vapi_msg_nat_det_session_dump),
    (generic_swap_fn_t)vapi_msg_nat_det_session_dump_hton,
    (generic_swap_fn_t)vapi_msg_nat_det_session_dump_ntoh,
    ~0,
  };

  vapi_msg_id_nat_det_session_dump = vapi_register_msg(&__vapi_metadata_nat_det_session_dump);
  VAPI_DBG("Assigned msg id %d to nat_det_session_dump", vapi_msg_id_nat_det_session_dump);
}

static void __attribute__((constructor)) __vapi_constructor_nat44_user_details()
{
  static const char name[] = "nat44_user_details";
  static const char name_with_crc[] = "nat44_user_details_77ce783b";
  static vapi_message_desc_t __vapi_metadata_nat44_user_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat44_user_details, payload),
    sizeof(vapi_msg_nat44_user_details),
    (generic_swap_fn_t)vapi_msg_nat44_user_details_hton,
    (generic_swap_fn_t)vapi_msg_nat44_user_details_ntoh,
    ~0,
  };

  vapi_msg_id_nat44_user_details = vapi_register_msg(&__vapi_metadata_nat44_user_details);
  VAPI_DBG("Assigned msg id %d to nat44_user_details", vapi_msg_id_nat44_user_details);
}

static void __attribute__((constructor)) __vapi_constructor_nat_det_forward_reply()
{
  static const char name[] = "nat_det_forward_reply";
  static const char name_with_crc[] = "nat_det_forward_reply_037762b9";
  static vapi_message_desc_t __vapi_metadata_nat_det_forward_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat_det_forward_reply, payload),
    sizeof(vapi_msg_nat_det_forward_reply),
    (generic_swap_fn_t)vapi_msg_nat_det_forward_reply_hton,
    (generic_swap_fn_t)vapi_msg_nat_det_forward_reply_ntoh,
    ~0,
  };

  vapi_msg_id_nat_det_forward_reply = vapi_register_msg(&__vapi_metadata_nat_det_forward_reply);
  VAPI_DBG("Assigned msg id %d to nat_det_forward_reply", vapi_msg_id_nat_det_forward_reply);
}

static void __attribute__((constructor)) __vapi_constructor_nat64_set_timeouts()
{
  static const char name[] = "nat64_set_timeouts";
  static const char name_with_crc[] = "nat64_set_timeouts_1b9f767e";
  static vapi_message_desc_t __vapi_metadata_nat64_set_timeouts = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_nat64_set_timeouts, payload),
    sizeof(vapi_msg_nat64_set_timeouts),
    (generic_swap_fn_t)vapi_msg_nat64_set_timeouts_hton,
    (generic_swap_fn_t)vapi_msg_nat64_set_timeouts_ntoh,
    ~0,
  };

  vapi_msg_id_nat64_set_timeouts = vapi_register_msg(&__vapi_metadata_nat64_set_timeouts);
  VAPI_DBG("Assigned msg id %d to nat64_set_timeouts", vapi_msg_id_nat64_set_timeouts);
}

static void __attribute__((constructor)) __vapi_constructor_nat44_interface_addr_details()
{
  static const char name[] = "nat44_interface_addr_details";
  static const char name_with_crc[] = "nat44_interface_addr_details_446b9c77";
  static vapi_message_desc_t __vapi_metadata_nat44_interface_addr_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat44_interface_addr_details, payload),
    sizeof(vapi_msg_nat44_interface_addr_details),
    (generic_swap_fn_t)vapi_msg_nat44_interface_addr_details_hton,
    (generic_swap_fn_t)vapi_msg_nat44_interface_addr_details_ntoh,
    ~0,
  };

  vapi_msg_id_nat44_interface_addr_details = vapi_register_msg(&__vapi_metadata_nat44_interface_addr_details);
  VAPI_DBG("Assigned msg id %d to nat44_interface_addr_details", vapi_msg_id_nat44_interface_addr_details);
}

static void __attribute__((constructor)) __vapi_constructor_snat_address_details()
{
  static const char name[] = "snat_address_details";
  static const char name_with_crc[] = "snat_address_details_f4e07104";
  static vapi_message_desc_t __vapi_metadata_snat_address_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_snat_address_details, payload),
    sizeof(vapi_msg_snat_address_details),
    (generic_swap_fn_t)vapi_msg_snat_address_details_hton,
    (generic_swap_fn_t)vapi_msg_snat_address_details_ntoh,
    ~0,
  };

  vapi_msg_id_snat_address_details = vapi_register_msg(&__vapi_metadata_snat_address_details);
  VAPI_DBG("Assigned msg id %d to snat_address_details", vapi_msg_id_snat_address_details);
}

static void __attribute__((constructor)) __vapi_constructor_nat64_add_del_pool_addr_range_reply()
{
  static const char name[] = "nat64_add_del_pool_addr_range_reply";
  static const char name_with_crc[] = "nat64_add_del_pool_addr_range_reply_9c968408";
  static vapi_message_desc_t __vapi_metadata_nat64_add_del_pool_addr_range_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat64_add_del_pool_addr_range_reply, payload),
    sizeof(vapi_msg_nat64_add_del_pool_addr_range_reply),
    (generic_swap_fn_t)vapi_msg_nat64_add_del_pool_addr_range_reply_hton,
    (generic_swap_fn_t)vapi_msg_nat64_add_del_pool_addr_range_reply_ntoh,
    ~0,
  };

  vapi_msg_id_nat64_add_del_pool_addr_range_reply = vapi_register_msg(&__vapi_metadata_nat64_add_del_pool_addr_range_reply);
  VAPI_DBG("Assigned msg id %d to nat64_add_del_pool_addr_range_reply", vapi_msg_id_nat64_add_del_pool_addr_range_reply);
}

static void __attribute__((constructor)) __vapi_constructor_snat_det_session_dump()
{
  static const char name[] = "snat_det_session_dump";
  static const char name_with_crc[] = "snat_det_session_dump_e412e169";
  static vapi_message_desc_t __vapi_metadata_snat_det_session_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_snat_det_session_dump, payload),
    sizeof(vapi_msg_snat_det_session_dump),
    (generic_swap_fn_t)vapi_msg_snat_det_session_dump_hton,
    (generic_swap_fn_t)vapi_msg_snat_det_session_dump_ntoh,
    ~0,
  };

  vapi_msg_id_snat_det_session_dump = vapi_register_msg(&__vapi_metadata_snat_det_session_dump);
  VAPI_DBG("Assigned msg id %d to snat_det_session_dump", vapi_msg_id_snat_det_session_dump);
}

static void __attribute__((constructor)) __vapi_constructor_nat64_get_timeouts()
{
  static const char name[] = "nat64_get_timeouts";
  static const char name_with_crc[] = "nat64_get_timeouts_62da1833";
  static vapi_message_desc_t __vapi_metadata_nat64_get_timeouts = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_nat64_get_timeouts),
    (generic_swap_fn_t)vapi_msg_nat64_get_timeouts_hton,
    (generic_swap_fn_t)vapi_msg_nat64_get_timeouts_ntoh,
    ~0,
  };

  vapi_msg_id_nat64_get_timeouts = vapi_register_msg(&__vapi_metadata_nat64_get_timeouts);
  VAPI_DBG("Assigned msg id %d to nat64_get_timeouts", vapi_msg_id_nat64_get_timeouts);
}

static void __attribute__((constructor)) __vapi_constructor_snat_add_det_map()
{
  static const char name[] = "snat_add_det_map";
  static const char name_with_crc[] = "snat_add_det_map_b62c5cfd";
  static vapi_message_desc_t __vapi_metadata_snat_add_det_map = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_snat_add_det_map, payload),
    sizeof(vapi_msg_snat_add_det_map),
    (generic_swap_fn_t)vapi_msg_snat_add_det_map_hton,
    (generic_swap_fn_t)vapi_msg_snat_add_det_map_ntoh,
    ~0,
  };

  vapi_msg_id_snat_add_det_map = vapi_register_msg(&__vapi_metadata_snat_add_det_map);
  VAPI_DBG("Assigned msg id %d to snat_add_det_map", vapi_msg_id_snat_add_det_map);
}

static void __attribute__((constructor)) __vapi_constructor_nat_det_close_session_out_reply()
{
  static const char name[] = "nat_det_close_session_out_reply";
  static const char name_with_crc[] = "nat_det_close_session_out_reply_ff3961f2";
  static vapi_message_desc_t __vapi_metadata_nat_det_close_session_out_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat_det_close_session_out_reply, payload),
    sizeof(vapi_msg_nat_det_close_session_out_reply),
    (generic_swap_fn_t)vapi_msg_nat_det_close_session_out_reply_hton,
    (generic_swap_fn_t)vapi_msg_nat_det_close_session_out_reply_ntoh,
    ~0,
  };

  vapi_msg_id_nat_det_close_session_out_reply = vapi_register_msg(&__vapi_metadata_nat_det_close_session_out_reply);
  VAPI_DBG("Assigned msg id %d to nat_det_close_session_out_reply", vapi_msg_id_nat_det_close_session_out_reply);
}

static void __attribute__((constructor)) __vapi_constructor_nat_show_config()
{
  static const char name[] = "nat_show_config";
  static const char name_with_crc[] = "nat_show_config_f1e6587b";
  static vapi_message_desc_t __vapi_metadata_nat_show_config = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_nat_show_config),
    (generic_swap_fn_t)vapi_msg_nat_show_config_hton,
    (generic_swap_fn_t)vapi_msg_nat_show_config_ntoh,
    ~0,
  };

  vapi_msg_id_nat_show_config = vapi_register_msg(&__vapi_metadata_nat_show_config);
  VAPI_DBG("Assigned msg id %d to nat_show_config", vapi_msg_id_nat_show_config);
}

static void __attribute__((constructor)) __vapi_constructor_snat_det_session_details()
{
  static const char name[] = "snat_det_session_details";
  static const char name_with_crc[] = "snat_det_session_details_6e9cddb1";
  static vapi_message_desc_t __vapi_metadata_snat_det_session_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_snat_det_session_details, payload),
    sizeof(vapi_msg_snat_det_session_details),
    (generic_swap_fn_t)vapi_msg_snat_det_session_details_hton,
    (generic_swap_fn_t)vapi_msg_snat_det_session_details_ntoh,
    ~0,
  };

  vapi_msg_id_snat_det_session_details = vapi_register_msg(&__vapi_metadata_snat_det_session_details);
  VAPI_DBG("Assigned msg id %d to snat_det_session_details", vapi_msg_id_snat_det_session_details);
}

static void __attribute__((constructor)) __vapi_constructor_nat44_address_dump()
{
  static const char name[] = "nat44_address_dump";
  static const char name_with_crc[] = "nat44_address_dump_e75a129a";
  static vapi_message_desc_t __vapi_metadata_nat44_address_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_nat44_address_dump),
    (generic_swap_fn_t)vapi_msg_nat44_address_dump_hton,
    (generic_swap_fn_t)vapi_msg_nat44_address_dump_ntoh,
    ~0,
  };

  vapi_msg_id_nat44_address_dump = vapi_register_msg(&__vapi_metadata_nat44_address_dump);
  VAPI_DBG("Assigned msg id %d to nat44_address_dump", vapi_msg_id_nat44_address_dump);
}

static void __attribute__((constructor)) __vapi_constructor_snat_det_forward()
{
  static const char name[] = "snat_det_forward";
  static const char name_with_crc[] = "snat_det_forward_8584635a";
  static vapi_message_desc_t __vapi_metadata_snat_det_forward = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_snat_det_forward, payload),
    sizeof(vapi_msg_snat_det_forward),
    (generic_swap_fn_t)vapi_msg_snat_det_forward_hton,
    (generic_swap_fn_t)vapi_msg_snat_det_forward_ntoh,
    ~0,
  };

  vapi_msg_id_snat_det_forward = vapi_register_msg(&__vapi_metadata_snat_det_forward);
  VAPI_DBG("Assigned msg id %d to snat_det_forward", vapi_msg_id_snat_det_forward);
}

static void __attribute__((constructor)) __vapi_constructor_nat44_interface_dump()
{
  static const char name[] = "nat44_interface_dump";
  static const char name_with_crc[] = "nat44_interface_dump_4eae339a";
  static vapi_message_desc_t __vapi_metadata_nat44_interface_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_nat44_interface_dump),
    (generic_swap_fn_t)vapi_msg_nat44_interface_dump_hton,
    (generic_swap_fn_t)vapi_msg_nat44_interface_dump_ntoh,
    ~0,
  };

  vapi_msg_id_nat44_interface_dump = vapi_register_msg(&__vapi_metadata_nat44_interface_dump);
  VAPI_DBG("Assigned msg id %d to nat44_interface_dump", vapi_msg_id_nat44_interface_dump);
}

static void __attribute__((constructor)) __vapi_constructor_nat64_interface_details()
{
  static const char name[] = "nat64_interface_details";
  static const char name_with_crc[] = "nat64_interface_details_3d95fdbc";
  static vapi_message_desc_t __vapi_metadata_nat64_interface_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat64_interface_details, payload),
    sizeof(vapi_msg_nat64_interface_details),
    (generic_swap_fn_t)vapi_msg_nat64_interface_details_hton,
    (generic_swap_fn_t)vapi_msg_nat64_interface_details_ntoh,
    ~0,
  };

  vapi_msg_id_nat64_interface_details = vapi_register_msg(&__vapi_metadata_nat64_interface_details);
  VAPI_DBG("Assigned msg id %d to nat64_interface_details", vapi_msg_id_nat64_interface_details);
}

static void __attribute__((constructor)) __vapi_constructor_nat64_bib_dump()
{
  static const char name[] = "nat64_bib_dump";
  static const char name_with_crc[] = "nat64_bib_dump_d48143dd";
  static vapi_message_desc_t __vapi_metadata_nat64_bib_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_nat64_bib_dump, payload),
    sizeof(vapi_msg_nat64_bib_dump),
    (generic_swap_fn_t)vapi_msg_nat64_bib_dump_hton,
    (generic_swap_fn_t)vapi_msg_nat64_bib_dump_ntoh,
    ~0,
  };

  vapi_msg_id_nat64_bib_dump = vapi_register_msg(&__vapi_metadata_nat64_bib_dump);
  VAPI_DBG("Assigned msg id %d to nat64_bib_dump", vapi_msg_id_nat64_bib_dump);
}

static void __attribute__((constructor)) __vapi_constructor_nat64_add_del_pool_addr_range()
{
  static const char name[] = "nat64_add_del_pool_addr_range";
  static const char name_with_crc[] = "nat64_add_del_pool_addr_range_669df3f0";
  static vapi_message_desc_t __vapi_metadata_nat64_add_del_pool_addr_range = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_nat64_add_del_pool_addr_range, payload),
    sizeof(vapi_msg_nat64_add_del_pool_addr_range),
    (generic_swap_fn_t)vapi_msg_nat64_add_del_pool_addr_range_hton,
    (generic_swap_fn_t)vapi_msg_nat64_add_del_pool_addr_range_ntoh,
    ~0,
  };

  vapi_msg_id_nat64_add_del_pool_addr_range = vapi_register_msg(&__vapi_metadata_nat64_add_del_pool_addr_range);
  VAPI_DBG("Assigned msg id %d to nat64_add_del_pool_addr_range", vapi_msg_id_nat64_add_del_pool_addr_range);
}

static void __attribute__((constructor)) __vapi_constructor_nat64_bib_details()
{
  static const char name[] = "nat64_bib_details";
  static const char name_with_crc[] = "nat64_bib_details_dc57f1a9";
  static vapi_message_desc_t __vapi_metadata_nat64_bib_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat64_bib_details, payload),
    sizeof(vapi_msg_nat64_bib_details),
    (generic_swap_fn_t)vapi_msg_nat64_bib_details_hton,
    (generic_swap_fn_t)vapi_msg_nat64_bib_details_ntoh,
    ~0,
  };

  vapi_msg_id_nat64_bib_details = vapi_register_msg(&__vapi_metadata_nat64_bib_details);
  VAPI_DBG("Assigned msg id %d to nat64_bib_details", vapi_msg_id_nat64_bib_details);
}

static void __attribute__((constructor)) __vapi_constructor_nat64_get_timeouts_reply()
{
  static const char name[] = "nat64_get_timeouts_reply";
  static const char name_with_crc[] = "nat64_get_timeouts_reply_3829fa1a";
  static vapi_message_desc_t __vapi_metadata_nat64_get_timeouts_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat64_get_timeouts_reply, payload),
    sizeof(vapi_msg_nat64_get_timeouts_reply),
    (generic_swap_fn_t)vapi_msg_nat64_get_timeouts_reply_hton,
    (generic_swap_fn_t)vapi_msg_nat64_get_timeouts_reply_ntoh,
    ~0,
  };

  vapi_msg_id_nat64_get_timeouts_reply = vapi_register_msg(&__vapi_metadata_nat64_get_timeouts_reply);
  VAPI_DBG("Assigned msg id %d to nat64_get_timeouts_reply", vapi_msg_id_nat64_get_timeouts_reply);
}

static void __attribute__((constructor)) __vapi_constructor_nat64_prefix_dump()
{
  static const char name[] = "nat64_prefix_dump";
  static const char name_with_crc[] = "nat64_prefix_dump_333a751d";
  static vapi_message_desc_t __vapi_metadata_nat64_prefix_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_nat64_prefix_dump),
    (generic_swap_fn_t)vapi_msg_nat64_prefix_dump_hton,
    (generic_swap_fn_t)vapi_msg_nat64_prefix_dump_ntoh,
    ~0,
  };

  vapi_msg_id_nat64_prefix_dump = vapi_register_msg(&__vapi_metadata_nat64_prefix_dump);
  VAPI_DBG("Assigned msg id %d to nat64_prefix_dump", vapi_msg_id_nat64_prefix_dump);
}

static void __attribute__((constructor)) __vapi_constructor_nat_det_map_dump()
{
  static const char name[] = "nat_det_map_dump";
  static const char name_with_crc[] = "nat_det_map_dump_717c3593";
  static vapi_message_desc_t __vapi_metadata_nat_det_map_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_nat_det_map_dump),
    (generic_swap_fn_t)vapi_msg_nat_det_map_dump_hton,
    (generic_swap_fn_t)vapi_msg_nat_det_map_dump_ntoh,
    ~0,
  };

  vapi_msg_id_nat_det_map_dump = vapi_register_msg(&__vapi_metadata_nat_det_map_dump);
  VAPI_DBG("Assigned msg id %d to nat_det_map_dump", vapi_msg_id_nat_det_map_dump);
}

static void __attribute__((constructor)) __vapi_constructor_snat_interface_addr_details()
{
  static const char name[] = "snat_interface_addr_details";
  static const char name_with_crc[] = "snat_interface_addr_details_d65481ed";
  static vapi_message_desc_t __vapi_metadata_snat_interface_addr_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_snat_interface_addr_details, payload),
    sizeof(vapi_msg_snat_interface_addr_details),
    (generic_swap_fn_t)vapi_msg_snat_interface_addr_details_hton,
    (generic_swap_fn_t)vapi_msg_snat_interface_addr_details_ntoh,
    ~0,
  };

  vapi_msg_id_snat_interface_addr_details = vapi_register_msg(&__vapi_metadata_snat_interface_addr_details);
  VAPI_DBG("Assigned msg id %d to snat_interface_addr_details", vapi_msg_id_snat_interface_addr_details);
}

static void __attribute__((constructor)) __vapi_constructor_nat_det_close_session_in_reply()
{
  static const char name[] = "nat_det_close_session_in_reply";
  static const char name_with_crc[] = "nat_det_close_session_in_reply_8d1e060c";
  static vapi_message_desc_t __vapi_metadata_nat_det_close_session_in_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat_det_close_session_in_reply, payload),
    sizeof(vapi_msg_nat_det_close_session_in_reply),
    (generic_swap_fn_t)vapi_msg_nat_det_close_session_in_reply_hton,
    (generic_swap_fn_t)vapi_msg_nat_det_close_session_in_reply_ntoh,
    ~0,
  };

  vapi_msg_id_nat_det_close_session_in_reply = vapi_register_msg(&__vapi_metadata_nat_det_close_session_in_reply);
  VAPI_DBG("Assigned msg id %d to nat_det_close_session_in_reply", vapi_msg_id_nat_det_close_session_in_reply);
}

static void __attribute__((constructor)) __vapi_constructor_snat_det_map_details()
{
  static const char name[] = "snat_det_map_details";
  static const char name_with_crc[] = "snat_det_map_details_0b0ddd08";
  static vapi_message_desc_t __vapi_metadata_snat_det_map_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_snat_det_map_details, payload),
    sizeof(vapi_msg_snat_det_map_details),
    (generic_swap_fn_t)vapi_msg_snat_det_map_details_hton,
    (generic_swap_fn_t)vapi_msg_snat_det_map_details_ntoh,
    ~0,
  };

  vapi_msg_id_snat_det_map_details = vapi_register_msg(&__vapi_metadata_snat_det_map_details);
  VAPI_DBG("Assigned msg id %d to snat_det_map_details", vapi_msg_id_snat_det_map_details);
}

static void __attribute__((constructor)) __vapi_constructor_nat_set_workers()
{
  static const char name[] = "nat_set_workers";
  static const char name_with_crc[] = "nat_set_workers_f7b85189";
  static vapi_message_desc_t __vapi_metadata_nat_set_workers = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_nat_set_workers, payload),
    sizeof(vapi_msg_nat_set_workers),
    (generic_swap_fn_t)vapi_msg_nat_set_workers_hton,
    (generic_swap_fn_t)vapi_msg_nat_set_workers_ntoh,
    ~0,
  };

  vapi_msg_id_nat_set_workers = vapi_register_msg(&__vapi_metadata_nat_set_workers);
  VAPI_DBG("Assigned msg id %d to nat_set_workers", vapi_msg_id_nat_set_workers);
}

static void __attribute__((constructor)) __vapi_constructor_nat64_add_del_prefix()
{
  static const char name[] = "nat64_add_del_prefix";
  static const char name_with_crc[] = "nat64_add_del_prefix_1e126638";
  static vapi_message_desc_t __vapi_metadata_nat64_add_del_prefix = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_nat64_add_del_prefix, payload),
    sizeof(vapi_msg_nat64_add_del_prefix),
    (generic_swap_fn_t)vapi_msg_nat64_add_del_prefix_hton,
    (generic_swap_fn_t)vapi_msg_nat64_add_del_prefix_ntoh,
    ~0,
  };

  vapi_msg_id_nat64_add_del_prefix = vapi_register_msg(&__vapi_metadata_nat64_add_del_prefix);
  VAPI_DBG("Assigned msg id %d to nat64_add_del_prefix", vapi_msg_id_nat64_add_del_prefix);
}

static void __attribute__((constructor)) __vapi_constructor_snat_add_address_range_reply()
{
  static const char name[] = "snat_add_address_range_reply";
  static const char name_with_crc[] = "snat_add_address_range_reply_7d360766";
  static vapi_message_desc_t __vapi_metadata_snat_add_address_range_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_snat_add_address_range_reply, payload),
    sizeof(vapi_msg_snat_add_address_range_reply),
    (generic_swap_fn_t)vapi_msg_snat_add_address_range_reply_hton,
    (generic_swap_fn_t)vapi_msg_snat_add_address_range_reply_ntoh,
    ~0,
  };

  vapi_msg_id_snat_add_address_range_reply = vapi_register_msg(&__vapi_metadata_snat_add_address_range_reply);
  VAPI_DBG("Assigned msg id %d to snat_add_address_range_reply", vapi_msg_id_snat_add_address_range_reply);
}

static void __attribute__((constructor)) __vapi_constructor_nat_ipfix_enable_disable_reply()
{
  static const char name[] = "nat_ipfix_enable_disable_reply";
  static const char name_with_crc[] = "nat_ipfix_enable_disable_reply_3bb820c4";
  static vapi_message_desc_t __vapi_metadata_nat_ipfix_enable_disable_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat_ipfix_enable_disable_reply, payload),
    sizeof(vapi_msg_nat_ipfix_enable_disable_reply),
    (generic_swap_fn_t)vapi_msg_nat_ipfix_enable_disable_reply_hton,
    (generic_swap_fn_t)vapi_msg_nat_ipfix_enable_disable_reply_ntoh,
    ~0,
  };

  vapi_msg_id_nat_ipfix_enable_disable_reply = vapi_register_msg(&__vapi_metadata_nat_ipfix_enable_disable_reply);
  VAPI_DBG("Assigned msg id %d to nat_ipfix_enable_disable_reply", vapi_msg_id_nat_ipfix_enable_disable_reply);
}

static void __attribute__((constructor)) __vapi_constructor_nat64_pool_addr_details()
{
  static const char name[] = "nat64_pool_addr_details";
  static const char name_with_crc[] = "nat64_pool_addr_details_235db4a3";
  static vapi_message_desc_t __vapi_metadata_nat64_pool_addr_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat64_pool_addr_details, payload),
    sizeof(vapi_msg_nat64_pool_addr_details),
    (generic_swap_fn_t)vapi_msg_nat64_pool_addr_details_hton,
    (generic_swap_fn_t)vapi_msg_nat64_pool_addr_details_ntoh,
    ~0,
  };

  vapi_msg_id_nat64_pool_addr_details = vapi_register_msg(&__vapi_metadata_nat64_pool_addr_details);
  VAPI_DBG("Assigned msg id %d to nat64_pool_addr_details", vapi_msg_id_nat64_pool_addr_details);
}

static void __attribute__((constructor)) __vapi_constructor_snat_det_reverse()
{
  static const char name[] = "snat_det_reverse";
  static const char name_with_crc[] = "snat_det_reverse_f6c78383";
  static vapi_message_desc_t __vapi_metadata_snat_det_reverse = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_snat_det_reverse, payload),
    sizeof(vapi_msg_snat_det_reverse),
    (generic_swap_fn_t)vapi_msg_snat_det_reverse_hton,
    (generic_swap_fn_t)vapi_msg_snat_det_reverse_ntoh,
    ~0,
  };

  vapi_msg_id_snat_det_reverse = vapi_register_msg(&__vapi_metadata_snat_det_reverse);
  VAPI_DBG("Assigned msg id %d to snat_det_reverse", vapi_msg_id_snat_det_reverse);
}

static void __attribute__((constructor)) __vapi_constructor_nat_worker_details()
{
  static const char name[] = "nat_worker_details";
  static const char name_with_crc[] = "nat_worker_details_d001e0c7";
  static vapi_message_desc_t __vapi_metadata_nat_worker_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat_worker_details, payload),
    sizeof(vapi_msg_nat_worker_details),
    (generic_swap_fn_t)vapi_msg_nat_worker_details_hton,
    (generic_swap_fn_t)vapi_msg_nat_worker_details_ntoh,
    ~0,
  };

  vapi_msg_id_nat_worker_details = vapi_register_msg(&__vapi_metadata_nat_worker_details);
  VAPI_DBG("Assigned msg id %d to nat_worker_details", vapi_msg_id_nat_worker_details);
}

static void __attribute__((constructor)) __vapi_constructor_nat44_interface_add_del_output_feature()
{
  static const char name[] = "nat44_interface_add_del_output_feature";
  static const char name_with_crc[] = "nat44_interface_add_del_output_feature_b819e4dd";
  static vapi_message_desc_t __vapi_metadata_nat44_interface_add_del_output_feature = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_nat44_interface_add_del_output_feature, payload),
    sizeof(vapi_msg_nat44_interface_add_del_output_feature),
    (generic_swap_fn_t)vapi_msg_nat44_interface_add_del_output_feature_hton,
    (generic_swap_fn_t)vapi_msg_nat44_interface_add_del_output_feature_ntoh,
    ~0,
  };

  vapi_msg_id_nat44_interface_add_del_output_feature = vapi_register_msg(&__vapi_metadata_nat44_interface_add_del_output_feature);
  VAPI_DBG("Assigned msg id %d to nat44_interface_add_del_output_feature", vapi_msg_id_nat44_interface_add_del_output_feature);
}

static void __attribute__((constructor)) __vapi_constructor_nat44_add_del_static_mapping_reply()
{
  static const char name[] = "nat44_add_del_static_mapping_reply";
  static const char name_with_crc[] = "nat44_add_del_static_mapping_reply_a30f3c34";
  static vapi_message_desc_t __vapi_metadata_nat44_add_del_static_mapping_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat44_add_del_static_mapping_reply, payload),
    sizeof(vapi_msg_nat44_add_del_static_mapping_reply),
    (generic_swap_fn_t)vapi_msg_nat44_add_del_static_mapping_reply_hton,
    (generic_swap_fn_t)vapi_msg_nat44_add_del_static_mapping_reply_ntoh,
    ~0,
  };

  vapi_msg_id_nat44_add_del_static_mapping_reply = vapi_register_msg(&__vapi_metadata_nat44_add_del_static_mapping_reply);
  VAPI_DBG("Assigned msg id %d to nat44_add_del_static_mapping_reply", vapi_msg_id_nat44_add_del_static_mapping_reply);
}

static void __attribute__((constructor)) __vapi_constructor_nat44_add_del_interface_addr_reply()
{
  static const char name[] = "nat44_add_del_interface_addr_reply";
  static const char name_with_crc[] = "nat44_add_del_interface_addr_reply_74d308ac";
  static vapi_message_desc_t __vapi_metadata_nat44_add_del_interface_addr_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat44_add_del_interface_addr_reply, payload),
    sizeof(vapi_msg_nat44_add_del_interface_addr_reply),
    (generic_swap_fn_t)vapi_msg_nat44_add_del_interface_addr_reply_hton,
    (generic_swap_fn_t)vapi_msg_nat44_add_del_interface_addr_reply_ntoh,
    ~0,
  };

  vapi_msg_id_nat44_add_del_interface_addr_reply = vapi_register_msg(&__vapi_metadata_nat44_add_del_interface_addr_reply);
  VAPI_DBG("Assigned msg id %d to nat44_add_del_interface_addr_reply", vapi_msg_id_nat44_add_del_interface_addr_reply);
}

static void __attribute__((constructor)) __vapi_constructor_snat_det_close_session_out()
{
  static const char name[] = "snat_det_close_session_out";
  static const char name_with_crc[] = "snat_det_close_session_out_aacd5d95";
  static vapi_message_desc_t __vapi_metadata_snat_det_close_session_out = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_snat_det_close_session_out, payload),
    sizeof(vapi_msg_snat_det_close_session_out),
    (generic_swap_fn_t)vapi_msg_snat_det_close_session_out_hton,
    (generic_swap_fn_t)vapi_msg_snat_det_close_session_out_ntoh,
    ~0,
  };

  vapi_msg_id_snat_det_close_session_out = vapi_register_msg(&__vapi_metadata_snat_det_close_session_out);
  VAPI_DBG("Assigned msg id %d to snat_det_close_session_out", vapi_msg_id_snat_det_close_session_out);
}

static void __attribute__((constructor)) __vapi_constructor_snat_det_close_session_out_reply()
{
  static const char name[] = "snat_det_close_session_out_reply";
  static const char name_with_crc[] = "snat_det_close_session_out_reply_a9997082";
  static vapi_message_desc_t __vapi_metadata_snat_det_close_session_out_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_snat_det_close_session_out_reply, payload),
    sizeof(vapi_msg_snat_det_close_session_out_reply),
    (generic_swap_fn_t)vapi_msg_snat_det_close_session_out_reply_hton,
    (generic_swap_fn_t)vapi_msg_snat_det_close_session_out_reply_ntoh,
    ~0,
  };

  vapi_msg_id_snat_det_close_session_out_reply = vapi_register_msg(&__vapi_metadata_snat_det_close_session_out_reply);
  VAPI_DBG("Assigned msg id %d to snat_det_close_session_out_reply", vapi_msg_id_snat_det_close_session_out_reply);
}

static void __attribute__((constructor)) __vapi_constructor_snat_det_set_timeouts_reply()
{
  static const char name[] = "snat_det_set_timeouts_reply";
  static const char name_with_crc[] = "snat_det_set_timeouts_reply_194bb7e2";
  static vapi_message_desc_t __vapi_metadata_snat_det_set_timeouts_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_snat_det_set_timeouts_reply, payload),
    sizeof(vapi_msg_snat_det_set_timeouts_reply),
    (generic_swap_fn_t)vapi_msg_snat_det_set_timeouts_reply_hton,
    (generic_swap_fn_t)vapi_msg_snat_det_set_timeouts_reply_ntoh,
    ~0,
  };

  vapi_msg_id_snat_det_set_timeouts_reply = vapi_register_msg(&__vapi_metadata_snat_det_set_timeouts_reply);
  VAPI_DBG("Assigned msg id %d to snat_det_set_timeouts_reply", vapi_msg_id_snat_det_set_timeouts_reply);
}

static void __attribute__((constructor)) __vapi_constructor_nat44_add_del_interface_addr()
{
  static const char name[] = "nat44_add_del_interface_addr";
  static const char name_with_crc[] = "nat44_add_del_interface_addr_d194c451";
  static vapi_message_desc_t __vapi_metadata_nat44_add_del_interface_addr = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_nat44_add_del_interface_addr, payload),
    sizeof(vapi_msg_nat44_add_del_interface_addr),
    (generic_swap_fn_t)vapi_msg_nat44_add_del_interface_addr_hton,
    (generic_swap_fn_t)vapi_msg_nat44_add_del_interface_addr_ntoh,
    ~0,
  };

  vapi_msg_id_nat44_add_del_interface_addr = vapi_register_msg(&__vapi_metadata_nat44_add_del_interface_addr);
  VAPI_DBG("Assigned msg id %d to nat44_add_del_interface_addr", vapi_msg_id_nat44_add_del_interface_addr);
}

static void __attribute__((constructor)) __vapi_constructor_nat_det_map_details()
{
  static const char name[] = "nat_det_map_details";
  static const char name_with_crc[] = "nat_det_map_details_c403648b";
  static vapi_message_desc_t __vapi_metadata_nat_det_map_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat_det_map_details, payload),
    sizeof(vapi_msg_nat_det_map_details),
    (generic_swap_fn_t)vapi_msg_nat_det_map_details_hton,
    (generic_swap_fn_t)vapi_msg_nat_det_map_details_ntoh,
    ~0,
  };

  vapi_msg_id_nat_det_map_details = vapi_register_msg(&__vapi_metadata_nat_det_map_details);
  VAPI_DBG("Assigned msg id %d to nat_det_map_details", vapi_msg_id_nat_det_map_details);
}

static void __attribute__((constructor)) __vapi_constructor_nat64_st_dump()
{
  static const char name[] = "nat64_st_dump";
  static const char name_with_crc[] = "nat64_st_dump_df3cd00f";
  static vapi_message_desc_t __vapi_metadata_nat64_st_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_nat64_st_dump, payload),
    sizeof(vapi_msg_nat64_st_dump),
    (generic_swap_fn_t)vapi_msg_nat64_st_dump_hton,
    (generic_swap_fn_t)vapi_msg_nat64_st_dump_ntoh,
    ~0,
  };

  vapi_msg_id_nat64_st_dump = vapi_register_msg(&__vapi_metadata_nat64_st_dump);
  VAPI_DBG("Assigned msg id %d to nat64_st_dump", vapi_msg_id_nat64_st_dump);
}

static void __attribute__((constructor)) __vapi_constructor_snat_show_config()
{
  static const char name[] = "snat_show_config";
  static const char name_with_crc[] = "snat_show_config_2c6077c4";
  static vapi_message_desc_t __vapi_metadata_snat_show_config = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_snat_show_config),
    (generic_swap_fn_t)vapi_msg_snat_show_config_hton,
    (generic_swap_fn_t)vapi_msg_snat_show_config_ntoh,
    ~0,
  };

  vapi_msg_id_snat_show_config = vapi_register_msg(&__vapi_metadata_snat_show_config);
  VAPI_DBG("Assigned msg id %d to snat_show_config", vapi_msg_id_snat_show_config);
}

static void __attribute__((constructor)) __vapi_constructor_nat44_lb_static_mapping_details()
{
  static const char name[] = "nat44_lb_static_mapping_details";
  static const char name_with_crc[] = "nat44_lb_static_mapping_details_4663e4a4";
  static vapi_message_desc_t __vapi_metadata_nat44_lb_static_mapping_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat44_lb_static_mapping_details, payload),
    sizeof(vapi_msg_nat44_lb_static_mapping_details),
    (generic_swap_fn_t)vapi_msg_nat44_lb_static_mapping_details_hton,
    (generic_swap_fn_t)vapi_msg_nat44_lb_static_mapping_details_ntoh,
    ~0,
  };

  vapi_msg_id_nat44_lb_static_mapping_details = vapi_register_msg(&__vapi_metadata_nat44_lb_static_mapping_details);
  VAPI_DBG("Assigned msg id %d to nat44_lb_static_mapping_details", vapi_msg_id_nat44_lb_static_mapping_details);
}

static void __attribute__((constructor)) __vapi_constructor_snat_add_address_range()
{
  static const char name[] = "snat_add_address_range";
  static const char name_with_crc[] = "snat_add_address_range_d45f0a85";
  static vapi_message_desc_t __vapi_metadata_snat_add_address_range = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_snat_add_address_range, payload),
    sizeof(vapi_msg_snat_add_address_range),
    (generic_swap_fn_t)vapi_msg_snat_add_address_range_hton,
    (generic_swap_fn_t)vapi_msg_snat_add_address_range_ntoh,
    ~0,
  };

  vapi_msg_id_snat_add_address_range = vapi_register_msg(&__vapi_metadata_snat_add_address_range);
  VAPI_DBG("Assigned msg id %d to snat_add_address_range", vapi_msg_id_snat_add_address_range);
}

static void __attribute__((constructor)) __vapi_constructor_snat_add_det_map_reply()
{
  static const char name[] = "snat_add_det_map_reply";
  static const char name_with_crc[] = "snat_add_det_map_reply_d84be59c";
  static vapi_message_desc_t __vapi_metadata_snat_add_det_map_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_snat_add_det_map_reply, payload),
    sizeof(vapi_msg_snat_add_det_map_reply),
    (generic_swap_fn_t)vapi_msg_snat_add_det_map_reply_hton,
    (generic_swap_fn_t)vapi_msg_snat_add_det_map_reply_ntoh,
    ~0,
  };

  vapi_msg_id_snat_add_det_map_reply = vapi_register_msg(&__vapi_metadata_snat_add_det_map_reply);
  VAPI_DBG("Assigned msg id %d to snat_add_det_map_reply", vapi_msg_id_snat_add_det_map_reply);
}

static void __attribute__((constructor)) __vapi_constructor_snat_static_mapping_dump()
{
  static const char name[] = "snat_static_mapping_dump";
  static const char name_with_crc[] = "snat_static_mapping_dump_84172d2b";
  static vapi_message_desc_t __vapi_metadata_snat_static_mapping_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_snat_static_mapping_dump),
    (generic_swap_fn_t)vapi_msg_snat_static_mapping_dump_hton,
    (generic_swap_fn_t)vapi_msg_snat_static_mapping_dump_ntoh,
    ~0,
  };

  vapi_msg_id_snat_static_mapping_dump = vapi_register_msg(&__vapi_metadata_snat_static_mapping_dump);
  VAPI_DBG("Assigned msg id %d to snat_static_mapping_dump", vapi_msg_id_snat_static_mapping_dump);
}

static void __attribute__((constructor)) __vapi_constructor_nat44_interface_details()
{
  static const char name[] = "nat44_interface_details";
  static const char name_with_crc[] = "nat44_interface_details_c3f78d04";
  static vapi_message_desc_t __vapi_metadata_nat44_interface_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat44_interface_details, payload),
    sizeof(vapi_msg_nat44_interface_details),
    (generic_swap_fn_t)vapi_msg_nat44_interface_details_hton,
    (generic_swap_fn_t)vapi_msg_nat44_interface_details_ntoh,
    ~0,
  };

  vapi_msg_id_nat44_interface_details = vapi_register_msg(&__vapi_metadata_nat44_interface_details);
  VAPI_DBG("Assigned msg id %d to nat44_interface_details", vapi_msg_id_nat44_interface_details);
}

static void __attribute__((constructor)) __vapi_constructor_snat_interface_dump()
{
  static const char name[] = "snat_interface_dump";
  static const char name_with_crc[] = "snat_interface_dump_01fe9590";
  static vapi_message_desc_t __vapi_metadata_snat_interface_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_snat_interface_dump),
    (generic_swap_fn_t)vapi_msg_snat_interface_dump_hton,
    (generic_swap_fn_t)vapi_msg_snat_interface_dump_ntoh,
    ~0,
  };

  vapi_msg_id_snat_interface_dump = vapi_register_msg(&__vapi_metadata_snat_interface_dump);
  VAPI_DBG("Assigned msg id %d to snat_interface_dump", vapi_msg_id_snat_interface_dump);
}

static void __attribute__((constructor)) __vapi_constructor_nat44_add_del_address_range()
{
  static const char name[] = "nat44_add_del_address_range";
  static const char name_with_crc[] = "nat44_add_del_address_range_1ca67820";
  static vapi_message_desc_t __vapi_metadata_nat44_add_del_address_range = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_nat44_add_del_address_range, payload),
    sizeof(vapi_msg_nat44_add_del_address_range),
    (generic_swap_fn_t)vapi_msg_nat44_add_del_address_range_hton,
    (generic_swap_fn_t)vapi_msg_nat44_add_del_address_range_ntoh,
    ~0,
  };

  vapi_msg_id_nat44_add_del_address_range = vapi_register_msg(&__vapi_metadata_nat44_add_del_address_range);
  VAPI_DBG("Assigned msg id %d to nat44_add_del_address_range", vapi_msg_id_nat44_add_del_address_range);
}

static void __attribute__((constructor)) __vapi_constructor_nat_det_set_timeouts_reply()
{
  static const char name[] = "nat_det_set_timeouts_reply";
  static const char name_with_crc[] = "nat_det_set_timeouts_reply_17a80a73";
  static vapi_message_desc_t __vapi_metadata_nat_det_set_timeouts_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat_det_set_timeouts_reply, payload),
    sizeof(vapi_msg_nat_det_set_timeouts_reply),
    (generic_swap_fn_t)vapi_msg_nat_det_set_timeouts_reply_hton,
    (generic_swap_fn_t)vapi_msg_nat_det_set_timeouts_reply_ntoh,
    ~0,
  };

  vapi_msg_id_nat_det_set_timeouts_reply = vapi_register_msg(&__vapi_metadata_nat_det_set_timeouts_reply);
  VAPI_DBG("Assigned msg id %d to nat_det_set_timeouts_reply", vapi_msg_id_nat_det_set_timeouts_reply);
}

static void __attribute__((constructor)) __vapi_constructor_snat_user_session_details()
{
  static const char name[] = "snat_user_session_details";
  static const char name_with_crc[] = "snat_user_session_details_1a632582";
  static vapi_message_desc_t __vapi_metadata_snat_user_session_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_snat_user_session_details, payload),
    sizeof(vapi_msg_snat_user_session_details),
    (generic_swap_fn_t)vapi_msg_snat_user_session_details_hton,
    (generic_swap_fn_t)vapi_msg_snat_user_session_details_ntoh,
    ~0,
  };

  vapi_msg_id_snat_user_session_details = vapi_register_msg(&__vapi_metadata_snat_user_session_details);
  VAPI_DBG("Assigned msg id %d to snat_user_session_details", vapi_msg_id_snat_user_session_details);
}

static void __attribute__((constructor)) __vapi_constructor_snat_control_ping_reply()
{
  static const char name[] = "snat_control_ping_reply";
  static const char name_with_crc[] = "snat_control_ping_reply_979a5618";
  static vapi_message_desc_t __vapi_metadata_snat_control_ping_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_snat_control_ping_reply, payload),
    sizeof(vapi_msg_snat_control_ping_reply),
    (generic_swap_fn_t)vapi_msg_snat_control_ping_reply_hton,
    (generic_swap_fn_t)vapi_msg_snat_control_ping_reply_ntoh,
    ~0,
  };

  vapi_msg_id_snat_control_ping_reply = vapi_register_msg(&__vapi_metadata_snat_control_ping_reply);
  VAPI_DBG("Assigned msg id %d to snat_control_ping_reply", vapi_msg_id_snat_control_ping_reply);
}

static void __attribute__((constructor)) __vapi_constructor_snat_interface_add_del_output_feature()
{
  static const char name[] = "snat_interface_add_del_output_feature";
  static const char name_with_crc[] = "snat_interface_add_del_output_feature_30f11708";
  static vapi_message_desc_t __vapi_metadata_snat_interface_add_del_output_feature = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_snat_interface_add_del_output_feature, payload),
    sizeof(vapi_msg_snat_interface_add_del_output_feature),
    (generic_swap_fn_t)vapi_msg_snat_interface_add_del_output_feature_hton,
    (generic_swap_fn_t)vapi_msg_snat_interface_add_del_output_feature_ntoh,
    ~0,
  };

  vapi_msg_id_snat_interface_add_del_output_feature = vapi_register_msg(&__vapi_metadata_snat_interface_add_del_output_feature);
  VAPI_DBG("Assigned msg id %d to snat_interface_add_del_output_feature", vapi_msg_id_snat_interface_add_del_output_feature);
}

static void __attribute__((constructor)) __vapi_constructor_snat_worker_dump()
{
  static const char name[] = "snat_worker_dump";
  static const char name_with_crc[] = "snat_worker_dump_b7593228";
  static vapi_message_desc_t __vapi_metadata_snat_worker_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_snat_worker_dump),
    (generic_swap_fn_t)vapi_msg_snat_worker_dump_hton,
    (generic_swap_fn_t)vapi_msg_snat_worker_dump_ntoh,
    ~0,
  };

  vapi_msg_id_snat_worker_dump = vapi_register_msg(&__vapi_metadata_snat_worker_dump);
  VAPI_DBG("Assigned msg id %d to snat_worker_dump", vapi_msg_id_snat_worker_dump);
}

static void __attribute__((constructor)) __vapi_constructor_nat_set_workers_reply()
{
  static const char name[] = "nat_set_workers_reply";
  static const char name_with_crc[] = "nat_set_workers_reply_9a7d70ae";
  static vapi_message_desc_t __vapi_metadata_nat_set_workers_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_nat_set_workers_reply, payload),
    sizeof(vapi_msg_nat_set_workers_reply),
    (generic_swap_fn_t)vapi_msg_nat_set_workers_reply_hton,
    (generic_swap_fn_t)vapi_msg_nat_set_workers_reply_ntoh,
    ~0,
  };

  vapi_msg_id_nat_set_workers_reply = vapi_register_msg(&__vapi_metadata_nat_set_workers_reply);
  VAPI_DBG("Assigned msg id %d to nat_set_workers_reply", vapi_msg_id_nat_set_workers_reply);
}

static void __attribute__((constructor)) __vapi_constructor_snat_interface_output_feature_dump()
{
  static const char name[] = "snat_interface_output_feature_dump";
  static const char name_with_crc[] = "snat_interface_output_feature_dump_aa907749";
  static vapi_message_desc_t __vapi_metadata_snat_interface_output_feature_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_snat_interface_output_feature_dump),
    (generic_swap_fn_t)vapi_msg_snat_interface_output_feature_dump_hton,
    (generic_swap_fn_t)vapi_msg_snat_interface_output_feature_dump_ntoh,
    ~0,
  };

  vapi_msg_id_snat_interface_output_feature_dump = vapi_register_msg(&__vapi_metadata_snat_interface_output_feature_dump);
  VAPI_DBG("Assigned msg id %d to snat_interface_output_feature_dump", vapi_msg_id_snat_interface_output_feature_dump);
}

static void __attribute__((constructor)) __vapi_constructor_nat44_add_del_static_mapping()
{
  static const char name[] = "nat44_add_del_static_mapping";
  static const char name_with_crc[] = "nat44_add_del_static_mapping_6e24fd82";
  static vapi_message_desc_t __vapi_metadata_nat44_add_del_static_mapping = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_nat44_add_del_static_mapping, payload),
    sizeof(vapi_msg_nat44_add_del_static_mapping),
    (generic_swap_fn_t)vapi_msg_nat44_add_del_static_mapping_hton,
    (generic_swap_fn_t)vapi_msg_nat44_add_del_static_mapping_ntoh,
    ~0,
  };

  vapi_msg_id_nat44_add_del_static_mapping = vapi_register_msg(&__vapi_metadata_nat44_add_del_static_mapping);
  VAPI_DBG("Assigned msg id %d to nat44_add_del_static_mapping", vapi_msg_id_nat44_add_del_static_mapping);
}

static void __attribute__((constructor)) __vapi_constructor_nat64_add_del_static_bib()
{
  static const char name[] = "nat64_add_del_static_bib";
  static const char name_with_crc[] = "nat64_add_del_static_bib_cb5fb6e9";
  static vapi_message_desc_t __vapi_metadata_nat64_add_del_static_bib = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_nat64_add_del_static_bib, payload),
    sizeof(vapi_msg_nat64_add_del_static_bib),
    (generic_swap_fn_t)vapi_msg_nat64_add_del_static_bib_hton,
    (generic_swap_fn_t)vapi_msg_nat64_add_del_static_bib_ntoh,
    ~0,
  };

  vapi_msg_id_nat64_add_del_static_bib = vapi_register_msg(&__vapi_metadata_nat64_add_del_static_bib);
  VAPI_DBG("Assigned msg id %d to nat64_add_del_static_bib", vapi_msg_id_nat64_add_del_static_bib);
}

static void __attribute__((constructor)) __vapi_constructor_snat_det_close_session_in()
{
  static const char name[] = "snat_det_close_session_in";
  static const char name_with_crc[] = "snat_det_close_session_in_170dc301";
  static vapi_message_desc_t __vapi_metadata_snat_det_close_session_in = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_snat_det_close_session_in, payload),
    sizeof(vapi_msg_snat_det_close_session_in),
    (generic_swap_fn_t)vapi_msg_snat_det_close_session_in_hton,
    (generic_swap_fn_t)vapi_msg_snat_det_close_session_in_ntoh,
    ~0,
  };

  vapi_msg_id_snat_det_close_session_in = vapi_register_msg(&__vapi_metadata_snat_det_close_session_in);
  VAPI_DBG("Assigned msg id %d to snat_det_close_session_in", vapi_msg_id_snat_det_close_session_in);
}

static void __attribute__((constructor)) __vapi_constructor_snat_interface_details()
{
  static const char name[] = "snat_interface_details";
  static const char name_with_crc[] = "snat_interface_details_8e43ab7a";
  static vapi_message_desc_t __vapi_metadata_snat_interface_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_snat_interface_details, payload),
    sizeof(vapi_msg_snat_interface_details),
    (generic_swap_fn_t)vapi_msg_snat_interface_details_hton,
    (generic_swap_fn_t)vapi_msg_snat_interface_details_ntoh,
    ~0,
  };

  vapi_msg_id_snat_interface_details = vapi_register_msg(&__vapi_metadata_snat_interface_details);
  VAPI_DBG("Assigned msg id %d to snat_interface_details", vapi_msg_id_snat_interface_details);
}

static void __attribute__((constructor)) __vapi_constructor_snat_det_get_timeouts()
{
  static const char name[] = "snat_det_get_timeouts";
  static const char name_with_crc[] = "snat_det_get_timeouts_834fa3bc";
  static vapi_message_desc_t __vapi_metadata_snat_det_get_timeouts = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_snat_det_get_timeouts),
    (generic_swap_fn_t)vapi_msg_snat_det_get_timeouts_hton,
    (generic_swap_fn_t)vapi_msg_snat_det_get_timeouts_ntoh,
    ~0,
  };

  vapi_msg_id_snat_det_get_timeouts = vapi_register_msg(&__vapi_metadata_snat_det_get_timeouts);
  VAPI_DBG("Assigned msg id %d to snat_det_get_timeouts", vapi_msg_id_snat_det_get_timeouts);
}


static inline void vapi_set_vapi_msg_snat_static_mapping_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_snat_static_mapping_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_snat_static_mapping_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat_control_ping_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat_control_ping_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat_control_ping_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_snat_interface_output_feature_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_snat_interface_output_feature_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_snat_interface_output_feature_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_snat_interface_add_del_feature_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_snat_interface_add_del_feature_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_snat_interface_add_del_feature_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat64_prefix_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat64_prefix_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat64_prefix_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat_det_get_timeouts_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat_det_get_timeouts_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat_det_get_timeouts_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat_det_reverse_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat_det_reverse_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat_det_reverse_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat44_static_mapping_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat44_static_mapping_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat44_static_mapping_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat64_add_del_prefix_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat64_add_del_prefix_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat64_add_del_prefix_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat64_st_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat64_st_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat64_st_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_snat_show_config_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_snat_show_config_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_snat_show_config_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat44_interface_add_del_output_feature_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat44_interface_add_del_output_feature_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat44_interface_add_del_output_feature_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_snat_add_static_mapping_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_snat_add_static_mapping_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_snat_add_static_mapping_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_snat_worker_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_snat_worker_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_snat_worker_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat64_set_timeouts_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat64_set_timeouts_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat64_set_timeouts_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat44_user_session_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat44_user_session_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat44_user_session_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_snat_ipfix_enable_disable_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_snat_ipfix_enable_disable_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_snat_ipfix_enable_disable_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat44_interface_output_feature_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat44_interface_output_feature_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat44_interface_output_feature_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat_det_session_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat_det_session_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat_det_session_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_snat_interface_add_del_output_feature_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_snat_interface_add_del_output_feature_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_snat_interface_add_del_output_feature_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat44_interface_add_del_feature_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat44_interface_add_del_feature_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat44_interface_add_del_feature_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat44_add_del_address_range_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat44_add_del_address_range_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat44_add_del_address_range_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat64_add_del_interface_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat64_add_del_interface_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat64_add_del_interface_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat_det_add_del_map_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat_det_add_del_map_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat_det_add_del_map_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat_show_config_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat_show_config_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat_show_config_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat44_add_del_lb_static_mapping_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat44_add_del_lb_static_mapping_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat44_add_del_lb_static_mapping_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_snat_det_get_timeouts_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_snat_det_get_timeouts_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_snat_det_get_timeouts_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_snat_user_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_snat_user_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_snat_user_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_snat_det_close_session_in_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_snat_det_close_session_in_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_snat_det_close_session_in_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat64_add_del_static_bib_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat64_add_del_static_bib_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat64_add_del_static_bib_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat44_address_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat44_address_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat44_address_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_snat_add_del_interface_addr_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_snat_add_del_interface_addr_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_snat_add_del_interface_addr_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_snat_set_workers_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_snat_set_workers_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_snat_set_workers_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_snat_det_forward_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_snat_det_forward_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_snat_det_forward_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_snat_det_reverse_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_snat_det_reverse_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_snat_det_reverse_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat44_user_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat44_user_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat44_user_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat_det_forward_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat_det_forward_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat_det_forward_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat44_interface_addr_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat44_interface_addr_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat44_interface_addr_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_snat_address_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_snat_address_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_snat_address_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat64_add_del_pool_addr_range_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat64_add_del_pool_addr_range_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat64_add_del_pool_addr_range_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat_det_close_session_out_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat_det_close_session_out_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat_det_close_session_out_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_snat_det_session_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_snat_det_session_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_snat_det_session_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat64_interface_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat64_interface_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat64_interface_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat64_bib_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat64_bib_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat64_bib_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat64_get_timeouts_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat64_get_timeouts_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat64_get_timeouts_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_snat_interface_addr_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_snat_interface_addr_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_snat_interface_addr_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat_det_close_session_in_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat_det_close_session_in_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat_det_close_session_in_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_snat_det_map_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_snat_det_map_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_snat_det_map_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_snat_add_address_range_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_snat_add_address_range_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_snat_add_address_range_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat_ipfix_enable_disable_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat_ipfix_enable_disable_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat_ipfix_enable_disable_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat64_pool_addr_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat64_pool_addr_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat64_pool_addr_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat_worker_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat_worker_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat_worker_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat44_add_del_static_mapping_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat44_add_del_static_mapping_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat44_add_del_static_mapping_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat44_add_del_interface_addr_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat44_add_del_interface_addr_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat44_add_del_interface_addr_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_snat_det_close_session_out_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_snat_det_close_session_out_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_snat_det_close_session_out_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_snat_det_set_timeouts_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_snat_det_set_timeouts_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_snat_det_set_timeouts_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat_det_map_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat_det_map_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat_det_map_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat44_lb_static_mapping_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat44_lb_static_mapping_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat44_lb_static_mapping_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_snat_add_det_map_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_snat_add_det_map_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_snat_add_det_map_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat44_interface_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat44_interface_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat44_interface_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat_det_set_timeouts_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat_det_set_timeouts_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat_det_set_timeouts_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_snat_user_session_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_snat_user_session_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_snat_user_session_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_snat_control_ping_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_snat_control_ping_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_snat_control_ping_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_nat_set_workers_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_nat_set_workers_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_nat_set_workers_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_snat_interface_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_snat_interface_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_snat_interface_details, (vapi_event_cb)callback, callback_ctx);
};


#ifdef __cplusplus
}
#endif

#endif
