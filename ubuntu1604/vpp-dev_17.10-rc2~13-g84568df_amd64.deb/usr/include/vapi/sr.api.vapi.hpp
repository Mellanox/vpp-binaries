#ifndef __included_hpp_sr_api_json
#define __included_hpp_sr_api_json

#include <vapi/vapi.hpp>
#include <vapi/sr.api.vapi.h>

namespace vapi {

template <> inline void vapi_swap_to_be<vapi_msg_sr_policy_mod_reply>(vapi_msg_sr_policy_mod_reply *msg)
{
  vapi_msg_sr_policy_mod_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sr_policy_mod_reply>(vapi_msg_sr_policy_mod_reply *msg)
{
  vapi_msg_sr_policy_mod_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sr_policy_mod_reply>()
{
  return ::vapi_msg_id_sr_policy_mod_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sr_policy_mod_reply>>()
{
  return ::vapi_msg_id_sr_policy_mod_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sr_policy_mod_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sr_policy_mod_reply>(vapi_msg_id_sr_policy_mod_reply);
}

template class Msg<vapi_msg_sr_policy_mod_reply>;

using Sr_policy_mod_reply = Msg<vapi_msg_sr_policy_mod_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_sr_steering_add_del>(vapi_msg_sr_steering_add_del *msg)
{
  vapi_msg_sr_steering_add_del_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sr_steering_add_del>(vapi_msg_sr_steering_add_del *msg)
{
  vapi_msg_sr_steering_add_del_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sr_steering_add_del>()
{
  return ::vapi_msg_id_sr_steering_add_del; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sr_steering_add_del>>()
{
  return ::vapi_msg_id_sr_steering_add_del; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sr_steering_add_del()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sr_steering_add_del>(vapi_msg_id_sr_steering_add_del);
}

template <> inline vapi_msg_sr_steering_add_del* vapi_alloc<vapi_msg_sr_steering_add_del>(Connection &con)
{
  vapi_msg_sr_steering_add_del* result = vapi_alloc_sr_steering_add_del(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sr_steering_add_del>;

template class Request<vapi_msg_sr_steering_add_del, vapi_msg_sr_steering_add_del_reply>;

using Sr_steering_add_del = Request<vapi_msg_sr_steering_add_del, vapi_msg_sr_steering_add_del_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_sr_policy_del>(vapi_msg_sr_policy_del *msg)
{
  vapi_msg_sr_policy_del_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sr_policy_del>(vapi_msg_sr_policy_del *msg)
{
  vapi_msg_sr_policy_del_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sr_policy_del>()
{
  return ::vapi_msg_id_sr_policy_del; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sr_policy_del>>()
{
  return ::vapi_msg_id_sr_policy_del; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sr_policy_del()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sr_policy_del>(vapi_msg_id_sr_policy_del);
}

template <> inline vapi_msg_sr_policy_del* vapi_alloc<vapi_msg_sr_policy_del>(Connection &con)
{
  vapi_msg_sr_policy_del* result = vapi_alloc_sr_policy_del(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sr_policy_del>;

template class Request<vapi_msg_sr_policy_del, vapi_msg_sr_policy_del_reply>;

using Sr_policy_del = Request<vapi_msg_sr_policy_del, vapi_msg_sr_policy_del_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_sr_localsid_add_del>(vapi_msg_sr_localsid_add_del *msg)
{
  vapi_msg_sr_localsid_add_del_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sr_localsid_add_del>(vapi_msg_sr_localsid_add_del *msg)
{
  vapi_msg_sr_localsid_add_del_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sr_localsid_add_del>()
{
  return ::vapi_msg_id_sr_localsid_add_del; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sr_localsid_add_del>>()
{
  return ::vapi_msg_id_sr_localsid_add_del; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sr_localsid_add_del()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sr_localsid_add_del>(vapi_msg_id_sr_localsid_add_del);
}

template <> inline vapi_msg_sr_localsid_add_del* vapi_alloc<vapi_msg_sr_localsid_add_del>(Connection &con)
{
  vapi_msg_sr_localsid_add_del* result = vapi_alloc_sr_localsid_add_del(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sr_localsid_add_del>;

template class Request<vapi_msg_sr_localsid_add_del, vapi_msg_sr_localsid_add_del_reply>;

using Sr_localsid_add_del = Request<vapi_msg_sr_localsid_add_del, vapi_msg_sr_localsid_add_del_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_sr_steering_add_del_reply>(vapi_msg_sr_steering_add_del_reply *msg)
{
  vapi_msg_sr_steering_add_del_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sr_steering_add_del_reply>(vapi_msg_sr_steering_add_del_reply *msg)
{
  vapi_msg_sr_steering_add_del_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sr_steering_add_del_reply>()
{
  return ::vapi_msg_id_sr_steering_add_del_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sr_steering_add_del_reply>>()
{
  return ::vapi_msg_id_sr_steering_add_del_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sr_steering_add_del_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sr_steering_add_del_reply>(vapi_msg_id_sr_steering_add_del_reply);
}

template class Msg<vapi_msg_sr_steering_add_del_reply>;

using Sr_steering_add_del_reply = Msg<vapi_msg_sr_steering_add_del_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_sr_policy_del_reply>(vapi_msg_sr_policy_del_reply *msg)
{
  vapi_msg_sr_policy_del_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sr_policy_del_reply>(vapi_msg_sr_policy_del_reply *msg)
{
  vapi_msg_sr_policy_del_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sr_policy_del_reply>()
{
  return ::vapi_msg_id_sr_policy_del_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sr_policy_del_reply>>()
{
  return ::vapi_msg_id_sr_policy_del_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sr_policy_del_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sr_policy_del_reply>(vapi_msg_id_sr_policy_del_reply);
}

template class Msg<vapi_msg_sr_policy_del_reply>;

using Sr_policy_del_reply = Msg<vapi_msg_sr_policy_del_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_sr_policy_add_reply>(vapi_msg_sr_policy_add_reply *msg)
{
  vapi_msg_sr_policy_add_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sr_policy_add_reply>(vapi_msg_sr_policy_add_reply *msg)
{
  vapi_msg_sr_policy_add_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sr_policy_add_reply>()
{
  return ::vapi_msg_id_sr_policy_add_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sr_policy_add_reply>>()
{
  return ::vapi_msg_id_sr_policy_add_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sr_policy_add_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sr_policy_add_reply>(vapi_msg_id_sr_policy_add_reply);
}

template class Msg<vapi_msg_sr_policy_add_reply>;

using Sr_policy_add_reply = Msg<vapi_msg_sr_policy_add_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_sr_localsid_add_del_reply>(vapi_msg_sr_localsid_add_del_reply *msg)
{
  vapi_msg_sr_localsid_add_del_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sr_localsid_add_del_reply>(vapi_msg_sr_localsid_add_del_reply *msg)
{
  vapi_msg_sr_localsid_add_del_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sr_localsid_add_del_reply>()
{
  return ::vapi_msg_id_sr_localsid_add_del_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sr_localsid_add_del_reply>>()
{
  return ::vapi_msg_id_sr_localsid_add_del_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sr_localsid_add_del_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sr_localsid_add_del_reply>(vapi_msg_id_sr_localsid_add_del_reply);
}

template class Msg<vapi_msg_sr_localsid_add_del_reply>;

using Sr_localsid_add_del_reply = Msg<vapi_msg_sr_localsid_add_del_reply>;
}
#endif
