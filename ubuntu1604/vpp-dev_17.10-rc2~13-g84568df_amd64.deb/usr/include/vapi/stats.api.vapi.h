#ifndef __included_stats_api_json
#define __included_stats_api_json

#include <stdlib.h>
#include <stddef.h>
#include <arpa/inet.h>
#include <vapi/vapi_internal.h>
#include <vapi/vapi.h>
#include <vapi/vapi_dbg.h>

#ifdef __cplusplus
extern "C" {
#endif
#include <vapi/vpe.api.vapi.h>

extern vapi_msg_id_t vapi_msg_id_want_ip4_fib_stats;
extern vapi_msg_id_t vapi_msg_id_want_interface_combined_stats_reply;
extern vapi_msg_id_t vapi_msg_id_vnet_get_summary_stats;
extern vapi_msg_id_t vapi_msg_id_vnet_get_summary_stats_reply;
extern vapi_msg_id_t vapi_msg_id_want_ip4_nbr_stats_reply;
extern vapi_msg_id_t vapi_msg_id_want_interface_combined_stats;
extern vapi_msg_id_t vapi_msg_id_want_ip6_nbr_stats_reply;
extern vapi_msg_id_t vapi_msg_id_want_ip6_fib_stats;
extern vapi_msg_id_t vapi_msg_id_want_interface_simple_stats_reply;
extern vapi_msg_id_t vapi_msg_id_want_stats;
extern vapi_msg_id_t vapi_msg_id_want_interface_simple_stats;
extern vapi_msg_id_t vapi_msg_id_want_per_interface_combined_stats;
extern vapi_msg_id_t vapi_msg_id_want_stats_reply;
extern vapi_msg_id_t vapi_msg_id_vnet_ip4_nbr_counters;
extern vapi_msg_id_t vapi_msg_id_vnet_ip4_fib_counters;
extern vapi_msg_id_t vapi_msg_id_want_per_interface_combined_stats_reply;
extern vapi_msg_id_t vapi_msg_id_want_per_interface_simple_stats;
extern vapi_msg_id_t vapi_msg_id_want_ip4_nbr_stats;
extern vapi_msg_id_t vapi_msg_id_vnet_ip6_nbr_counters;
extern vapi_msg_id_t vapi_msg_id_want_ip4_fib_stats_reply;
extern vapi_msg_id_t vapi_msg_id_want_ip6_fib_stats_reply;
extern vapi_msg_id_t vapi_msg_id_vnet_ip6_fib_counters;
extern vapi_msg_id_t vapi_msg_id_want_per_interface_simple_stats_reply;
extern vapi_msg_id_t vapi_msg_id_want_ip6_nbr_stats;

#define DEFINE_VAPI_MSG_IDS_STATS_API_JSON\
  vapi_msg_id_t vapi_msg_id_want_ip4_fib_stats;\
  vapi_msg_id_t vapi_msg_id_want_interface_combined_stats_reply;\
  vapi_msg_id_t vapi_msg_id_vnet_get_summary_stats;\
  vapi_msg_id_t vapi_msg_id_vnet_get_summary_stats_reply;\
  vapi_msg_id_t vapi_msg_id_want_ip4_nbr_stats_reply;\
  vapi_msg_id_t vapi_msg_id_want_interface_combined_stats;\
  vapi_msg_id_t vapi_msg_id_want_ip6_nbr_stats_reply;\
  vapi_msg_id_t vapi_msg_id_want_ip6_fib_stats;\
  vapi_msg_id_t vapi_msg_id_want_interface_simple_stats_reply;\
  vapi_msg_id_t vapi_msg_id_want_stats;\
  vapi_msg_id_t vapi_msg_id_want_interface_simple_stats;\
  vapi_msg_id_t vapi_msg_id_want_per_interface_combined_stats;\
  vapi_msg_id_t vapi_msg_id_want_stats_reply;\
  vapi_msg_id_t vapi_msg_id_vnet_ip4_nbr_counters;\
  vapi_msg_id_t vapi_msg_id_vnet_ip4_fib_counters;\
  vapi_msg_id_t vapi_msg_id_want_per_interface_combined_stats_reply;\
  vapi_msg_id_t vapi_msg_id_want_per_interface_simple_stats;\
  vapi_msg_id_t vapi_msg_id_want_ip4_nbr_stats;\
  vapi_msg_id_t vapi_msg_id_vnet_ip6_nbr_counters;\
  vapi_msg_id_t vapi_msg_id_want_ip4_fib_stats_reply;\
  vapi_msg_id_t vapi_msg_id_want_ip6_fib_stats_reply;\
  vapi_msg_id_t vapi_msg_id_vnet_ip6_fib_counters;\
  vapi_msg_id_t vapi_msg_id_want_per_interface_simple_stats_reply;\
  vapi_msg_id_t vapi_msg_id_want_ip6_nbr_stats;


typedef struct __attribute__((__packed__)) {
  u32 address;
  u8 link_type;
  u64 packets;
  u64 bytes;
} vapi_type_ip4_nbr_counter;

typedef struct __attribute__((__packed__)) {
  u32 address;
  u8 address_length;
  u64 packets;
  u64 bytes;
} vapi_type_ip4_fib_counter;

typedef struct __attribute__((__packed__)) {
  u64 address[2];
  u8 link_type;
  u64 packets;
  u64 bytes;
} vapi_type_ip6_nbr_counter;

typedef struct __attribute__((__packed__)) {
  u64 address[2];
  u8 address_length;
  u64 packets;
  u64 bytes;
} vapi_type_ip6_fib_counter;

typedef struct __attribute__ ((__packed__)) {
  u32 enable_disable;
  u32 pid; 
} vapi_payload_want_ip4_fib_stats;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_want_ip4_fib_stats payload;
} vapi_msg_want_ip4_fib_stats;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_want_interface_combined_stats_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_want_interface_combined_stats_reply payload;
} vapi_msg_want_interface_combined_stats_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_vnet_get_summary_stats;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u64 total_pkts[2];
  u64 total_bytes[2];
  f64 vector_rate; 
} vapi_payload_vnet_get_summary_stats_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_vnet_get_summary_stats_reply payload;
} vapi_msg_vnet_get_summary_stats_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_want_ip4_nbr_stats_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_want_ip4_nbr_stats_reply payload;
} vapi_msg_want_ip4_nbr_stats_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 enable_disable;
  u32 pid; 
} vapi_payload_want_interface_combined_stats;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_want_interface_combined_stats payload;
} vapi_msg_want_interface_combined_stats;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_want_ip6_nbr_stats_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_want_ip6_nbr_stats_reply payload;
} vapi_msg_want_ip6_nbr_stats_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 enable_disable;
  u32 pid; 
} vapi_payload_want_ip6_fib_stats;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_want_ip6_fib_stats payload;
} vapi_msg_want_ip6_fib_stats;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_want_interface_simple_stats_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_want_interface_simple_stats_reply payload;
} vapi_msg_want_interface_simple_stats_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 enable_disable;
  u32 pid; 
} vapi_payload_want_stats;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_want_stats payload;
} vapi_msg_want_stats;

typedef struct __attribute__ ((__packed__)) {
  u32 enable_disable;
  u32 pid; 
} vapi_payload_want_interface_simple_stats;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_want_interface_simple_stats payload;
} vapi_msg_want_interface_simple_stats;

typedef struct __attribute__ ((__packed__)) {
  u32 enable_disable;
  u32 pid;
  u32 num;
  u32 sw_ifs[0]; 
} vapi_payload_want_per_interface_combined_stats;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_want_per_interface_combined_stats payload;
} vapi_msg_want_per_interface_combined_stats;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_want_stats_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_want_stats_reply payload;
} vapi_msg_want_stats_reply;

typedef struct __attribute__ ((__packed__)) {
  u16 _vl_msg_id;
  u32 count;
  u32 sw_if_index;
  u8 begin;
  vapi_type_ip4_nbr_counter c[0]; 
} vapi_payload_vnet_ip4_nbr_counters;

typedef struct __attribute__ ((__packed__)) {

  vapi_payload_vnet_ip4_nbr_counters payload;
} vapi_msg_vnet_ip4_nbr_counters;

typedef struct __attribute__ ((__packed__)) {
  u16 _vl_msg_id;
  u32 vrf_id;
  u32 count;
  vapi_type_ip4_fib_counter c[0]; 
} vapi_payload_vnet_ip4_fib_counters;

typedef struct __attribute__ ((__packed__)) {

  vapi_payload_vnet_ip4_fib_counters payload;
} vapi_msg_vnet_ip4_fib_counters;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_want_per_interface_combined_stats_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_want_per_interface_combined_stats_reply payload;
} vapi_msg_want_per_interface_combined_stats_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 enable_disable;
  u32 pid;
  u32 num;
  u32 sw_ifs[0]; 
} vapi_payload_want_per_interface_simple_stats;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_want_per_interface_simple_stats payload;
} vapi_msg_want_per_interface_simple_stats;

typedef struct __attribute__ ((__packed__)) {
  u32 enable_disable;
  u32 pid; 
} vapi_payload_want_ip4_nbr_stats;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_want_ip4_nbr_stats payload;
} vapi_msg_want_ip4_nbr_stats;

typedef struct __attribute__ ((__packed__)) {
  u16 _vl_msg_id;
  u32 count;
  u32 sw_if_index;
  u8 begin;
  vapi_type_ip6_nbr_counter c[0]; 
} vapi_payload_vnet_ip6_nbr_counters;

typedef struct __attribute__ ((__packed__)) {

  vapi_payload_vnet_ip6_nbr_counters payload;
} vapi_msg_vnet_ip6_nbr_counters;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_want_ip4_fib_stats_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_want_ip4_fib_stats_reply payload;
} vapi_msg_want_ip4_fib_stats_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_want_ip6_fib_stats_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_want_ip6_fib_stats_reply payload;
} vapi_msg_want_ip6_fib_stats_reply;

typedef struct __attribute__ ((__packed__)) {
  u16 _vl_msg_id;
  u32 vrf_id;
  u32 count;
  vapi_type_ip6_fib_counter c[0]; 
} vapi_payload_vnet_ip6_fib_counters;

typedef struct __attribute__ ((__packed__)) {

  vapi_payload_vnet_ip6_fib_counters payload;
} vapi_msg_vnet_ip6_fib_counters;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_want_per_interface_simple_stats_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_want_per_interface_simple_stats_reply payload;
} vapi_msg_want_per_interface_simple_stats_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 enable_disable;
  u32 pid; 
} vapi_payload_want_ip6_nbr_stats;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_want_ip6_nbr_stats payload;
} vapi_msg_want_ip6_nbr_stats;


static inline void vapi_type_ip4_nbr_counter_hton(vapi_type_ip4_nbr_counter *msg)
{
  msg->address = htobe32(msg->address);
  msg->packets = htobe64(msg->packets);
  msg->bytes = htobe64(msg->bytes);
}

static inline void vapi_type_ip4_nbr_counter_ntoh(vapi_type_ip4_nbr_counter *msg)
{
  msg->address = be32toh(msg->address);
  msg->packets = be64toh(msg->packets);
  msg->bytes = be64toh(msg->bytes);
}

static inline void vapi_type_ip4_fib_counter_hton(vapi_type_ip4_fib_counter *msg)
{
  msg->address = htobe32(msg->address);
  msg->packets = htobe64(msg->packets);
  msg->bytes = htobe64(msg->bytes);
}

static inline void vapi_type_ip4_fib_counter_ntoh(vapi_type_ip4_fib_counter *msg)
{
  msg->address = be32toh(msg->address);
  msg->packets = be64toh(msg->packets);
  msg->bytes = be64toh(msg->bytes);
}

static inline void vapi_type_ip6_nbr_counter_hton(vapi_type_ip6_nbr_counter *msg)
{
  do { unsigned i; for (i = 0; i < 2; ++i) { msg->address[i] = htobe64(msg->address[i]); } } while(0);
  msg->packets = htobe64(msg->packets);
  msg->bytes = htobe64(msg->bytes);
}

static inline void vapi_type_ip6_nbr_counter_ntoh(vapi_type_ip6_nbr_counter *msg)
{
  do { unsigned i; for (i = 0; i < 2; ++i) { msg->address[i] = be64toh(msg->address[i]); } } while(0);
  msg->packets = be64toh(msg->packets);
  msg->bytes = be64toh(msg->bytes);
}

static inline void vapi_type_ip6_fib_counter_hton(vapi_type_ip6_fib_counter *msg)
{
  do { unsigned i; for (i = 0; i < 2; ++i) { msg->address[i] = htobe64(msg->address[i]); } } while(0);
  msg->packets = htobe64(msg->packets);
  msg->bytes = htobe64(msg->bytes);
}

static inline void vapi_type_ip6_fib_counter_ntoh(vapi_type_ip6_fib_counter *msg)
{
  do { unsigned i; for (i = 0; i < 2; ++i) { msg->address[i] = be64toh(msg->address[i]); } } while(0);
  msg->packets = be64toh(msg->packets);
  msg->bytes = be64toh(msg->bytes);
}

static inline void vapi_msg_want_ip4_fib_stats_payload_hton(vapi_payload_want_ip4_fib_stats *payload)
{
  payload->enable_disable = htobe32(payload->enable_disable);
  payload->pid = htobe32(payload->pid);
}

static inline void vapi_msg_want_ip4_fib_stats_payload_ntoh(vapi_payload_want_ip4_fib_stats *payload)
{
  payload->enable_disable = be32toh(payload->enable_disable);
  payload->pid = be32toh(payload->pid);
}

static inline uword vapi_calc_want_ip4_fib_stats_msg_size(vapi_msg_want_ip4_fib_stats *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_want_ip4_fib_stats_hton(vapi_msg_want_ip4_fib_stats *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_ip4_fib_stats'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_want_ip4_fib_stats_payload_hton(&msg->payload);
}

static inline void vapi_msg_want_ip4_fib_stats_ntoh(vapi_msg_want_ip4_fib_stats *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_ip4_fib_stats'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_want_ip4_fib_stats_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_want_interface_combined_stats_reply_payload_hton(vapi_payload_want_interface_combined_stats_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_want_interface_combined_stats_reply_payload_ntoh(vapi_payload_want_interface_combined_stats_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_want_interface_combined_stats_reply_msg_size(vapi_msg_want_interface_combined_stats_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_want_interface_combined_stats_reply_hton(vapi_msg_want_interface_combined_stats_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_interface_combined_stats_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_want_interface_combined_stats_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_want_interface_combined_stats_reply_ntoh(vapi_msg_want_interface_combined_stats_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_interface_combined_stats_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_want_interface_combined_stats_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_vnet_get_summary_stats_msg_size(vapi_msg_vnet_get_summary_stats *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_vnet_get_summary_stats_hton(vapi_msg_vnet_get_summary_stats *msg)
{
  VAPI_DBG("Swapping `vapi_msg_vnet_get_summary_stats'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_vnet_get_summary_stats_ntoh(vapi_msg_vnet_get_summary_stats *msg)
{
  VAPI_DBG("Swapping `vapi_msg_vnet_get_summary_stats'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_vnet_get_summary_stats_reply_payload_hton(vapi_payload_vnet_get_summary_stats_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  do { unsigned i; for (i = 0; i < 2; ++i) { payload->total_pkts[i] = htobe64(payload->total_pkts[i]); } } while(0);
  do { unsigned i; for (i = 0; i < 2; ++i) { payload->total_bytes[i] = htobe64(payload->total_bytes[i]); } } while(0);
}

static inline void vapi_msg_vnet_get_summary_stats_reply_payload_ntoh(vapi_payload_vnet_get_summary_stats_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  do { unsigned i; for (i = 0; i < 2; ++i) { payload->total_pkts[i] = be64toh(payload->total_pkts[i]); } } while(0);
  do { unsigned i; for (i = 0; i < 2; ++i) { payload->total_bytes[i] = be64toh(payload->total_bytes[i]); } } while(0);
}

static inline uword vapi_calc_vnet_get_summary_stats_reply_msg_size(vapi_msg_vnet_get_summary_stats_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_vnet_get_summary_stats_reply_hton(vapi_msg_vnet_get_summary_stats_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_vnet_get_summary_stats_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_vnet_get_summary_stats_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_vnet_get_summary_stats_reply_ntoh(vapi_msg_vnet_get_summary_stats_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_vnet_get_summary_stats_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_vnet_get_summary_stats_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_want_ip4_nbr_stats_reply_payload_hton(vapi_payload_want_ip4_nbr_stats_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_want_ip4_nbr_stats_reply_payload_ntoh(vapi_payload_want_ip4_nbr_stats_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_want_ip4_nbr_stats_reply_msg_size(vapi_msg_want_ip4_nbr_stats_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_want_ip4_nbr_stats_reply_hton(vapi_msg_want_ip4_nbr_stats_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_ip4_nbr_stats_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_want_ip4_nbr_stats_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_want_ip4_nbr_stats_reply_ntoh(vapi_msg_want_ip4_nbr_stats_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_ip4_nbr_stats_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_want_ip4_nbr_stats_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_want_interface_combined_stats_payload_hton(vapi_payload_want_interface_combined_stats *payload)
{
  payload->enable_disable = htobe32(payload->enable_disable);
  payload->pid = htobe32(payload->pid);
}

static inline void vapi_msg_want_interface_combined_stats_payload_ntoh(vapi_payload_want_interface_combined_stats *payload)
{
  payload->enable_disable = be32toh(payload->enable_disable);
  payload->pid = be32toh(payload->pid);
}

static inline uword vapi_calc_want_interface_combined_stats_msg_size(vapi_msg_want_interface_combined_stats *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_want_interface_combined_stats_hton(vapi_msg_want_interface_combined_stats *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_interface_combined_stats'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_want_interface_combined_stats_payload_hton(&msg->payload);
}

static inline void vapi_msg_want_interface_combined_stats_ntoh(vapi_msg_want_interface_combined_stats *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_interface_combined_stats'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_want_interface_combined_stats_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_want_ip6_nbr_stats_reply_payload_hton(vapi_payload_want_ip6_nbr_stats_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_want_ip6_nbr_stats_reply_payload_ntoh(vapi_payload_want_ip6_nbr_stats_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_want_ip6_nbr_stats_reply_msg_size(vapi_msg_want_ip6_nbr_stats_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_want_ip6_nbr_stats_reply_hton(vapi_msg_want_ip6_nbr_stats_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_ip6_nbr_stats_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_want_ip6_nbr_stats_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_want_ip6_nbr_stats_reply_ntoh(vapi_msg_want_ip6_nbr_stats_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_ip6_nbr_stats_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_want_ip6_nbr_stats_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_want_ip6_fib_stats_payload_hton(vapi_payload_want_ip6_fib_stats *payload)
{
  payload->enable_disable = htobe32(payload->enable_disable);
  payload->pid = htobe32(payload->pid);
}

static inline void vapi_msg_want_ip6_fib_stats_payload_ntoh(vapi_payload_want_ip6_fib_stats *payload)
{
  payload->enable_disable = be32toh(payload->enable_disable);
  payload->pid = be32toh(payload->pid);
}

static inline uword vapi_calc_want_ip6_fib_stats_msg_size(vapi_msg_want_ip6_fib_stats *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_want_ip6_fib_stats_hton(vapi_msg_want_ip6_fib_stats *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_ip6_fib_stats'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_want_ip6_fib_stats_payload_hton(&msg->payload);
}

static inline void vapi_msg_want_ip6_fib_stats_ntoh(vapi_msg_want_ip6_fib_stats *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_ip6_fib_stats'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_want_ip6_fib_stats_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_want_interface_simple_stats_reply_payload_hton(vapi_payload_want_interface_simple_stats_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_want_interface_simple_stats_reply_payload_ntoh(vapi_payload_want_interface_simple_stats_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_want_interface_simple_stats_reply_msg_size(vapi_msg_want_interface_simple_stats_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_want_interface_simple_stats_reply_hton(vapi_msg_want_interface_simple_stats_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_interface_simple_stats_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_want_interface_simple_stats_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_want_interface_simple_stats_reply_ntoh(vapi_msg_want_interface_simple_stats_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_interface_simple_stats_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_want_interface_simple_stats_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_want_stats_payload_hton(vapi_payload_want_stats *payload)
{
  payload->enable_disable = htobe32(payload->enable_disable);
  payload->pid = htobe32(payload->pid);
}

static inline void vapi_msg_want_stats_payload_ntoh(vapi_payload_want_stats *payload)
{
  payload->enable_disable = be32toh(payload->enable_disable);
  payload->pid = be32toh(payload->pid);
}

static inline uword vapi_calc_want_stats_msg_size(vapi_msg_want_stats *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_want_stats_hton(vapi_msg_want_stats *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_stats'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_want_stats_payload_hton(&msg->payload);
}

static inline void vapi_msg_want_stats_ntoh(vapi_msg_want_stats *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_stats'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_want_stats_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_want_interface_simple_stats_payload_hton(vapi_payload_want_interface_simple_stats *payload)
{
  payload->enable_disable = htobe32(payload->enable_disable);
  payload->pid = htobe32(payload->pid);
}

static inline void vapi_msg_want_interface_simple_stats_payload_ntoh(vapi_payload_want_interface_simple_stats *payload)
{
  payload->enable_disable = be32toh(payload->enable_disable);
  payload->pid = be32toh(payload->pid);
}

static inline uword vapi_calc_want_interface_simple_stats_msg_size(vapi_msg_want_interface_simple_stats *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_want_interface_simple_stats_hton(vapi_msg_want_interface_simple_stats *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_interface_simple_stats'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_want_interface_simple_stats_payload_hton(&msg->payload);
}

static inline void vapi_msg_want_interface_simple_stats_ntoh(vapi_msg_want_interface_simple_stats *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_interface_simple_stats'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_want_interface_simple_stats_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_want_per_interface_combined_stats_payload_hton(vapi_payload_want_per_interface_combined_stats *payload)
{
  payload->enable_disable = htobe32(payload->enable_disable);
  payload->pid = htobe32(payload->pid);
  payload->num = htobe32(payload->num);
  do { unsigned i; for (i = 0; i < be32toh(payload->num); ++i) { payload->sw_ifs[i] = htobe32(payload->sw_ifs[i]); } } while(0);
}

static inline void vapi_msg_want_per_interface_combined_stats_payload_ntoh(vapi_payload_want_per_interface_combined_stats *payload)
{
  payload->enable_disable = be32toh(payload->enable_disable);
  payload->pid = be32toh(payload->pid);
  payload->num = be32toh(payload->num);
  do { unsigned i; for (i = 0; i < payload->num; ++i) { payload->sw_ifs[i] = be32toh(payload->sw_ifs[i]); } } while(0);
}

static inline uword vapi_calc_want_per_interface_combined_stats_msg_size(vapi_msg_want_per_interface_combined_stats *msg)
{
  return sizeof(*msg)+ msg->payload.num * sizeof(msg->payload.sw_ifs[0]);
}

static inline void vapi_msg_want_per_interface_combined_stats_hton(vapi_msg_want_per_interface_combined_stats *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_per_interface_combined_stats'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_want_per_interface_combined_stats_payload_hton(&msg->payload);
}

static inline void vapi_msg_want_per_interface_combined_stats_ntoh(vapi_msg_want_per_interface_combined_stats *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_per_interface_combined_stats'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_want_per_interface_combined_stats_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_want_stats_reply_payload_hton(vapi_payload_want_stats_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_want_stats_reply_payload_ntoh(vapi_payload_want_stats_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_want_stats_reply_msg_size(vapi_msg_want_stats_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_want_stats_reply_hton(vapi_msg_want_stats_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_stats_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_want_stats_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_want_stats_reply_ntoh(vapi_msg_want_stats_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_stats_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_want_stats_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_vnet_ip4_nbr_counters_payload_hton(vapi_payload_vnet_ip4_nbr_counters *payload)
{
  payload->_vl_msg_id = htobe16(payload->_vl_msg_id);
  payload->count = htobe32(payload->count);
  payload->sw_if_index = htobe32(payload->sw_if_index);
  do { unsigned i; for (i = 0; i < be32toh(payload->count); ++i) { vapi_type_ip4_nbr_counter_hton(&payload->c[i]); } } while(0);
}

static inline void vapi_msg_vnet_ip4_nbr_counters_payload_ntoh(vapi_payload_vnet_ip4_nbr_counters *payload)
{
  payload->_vl_msg_id = be16toh(payload->_vl_msg_id);
  payload->count = be32toh(payload->count);
  payload->sw_if_index = be32toh(payload->sw_if_index);
  do { unsigned i; for (i = 0; i < payload->count; ++i) { vapi_type_ip4_nbr_counter_ntoh(&payload->c[i]); } } while(0);
}

static inline uword vapi_calc_vnet_ip4_nbr_counters_msg_size(vapi_msg_vnet_ip4_nbr_counters *msg)
{
  return sizeof(*msg)+ msg->payload.count * sizeof(msg->payload.c[0]);
}

static inline void vapi_msg_vnet_ip4_nbr_counters_hton(vapi_msg_vnet_ip4_nbr_counters *msg)
{
  VAPI_DBG("Swapping `vapi_msg_vnet_ip4_nbr_counters'@%p to big endian", msg);

  vapi_msg_vnet_ip4_nbr_counters_payload_hton(&msg->payload);
}

static inline void vapi_msg_vnet_ip4_nbr_counters_ntoh(vapi_msg_vnet_ip4_nbr_counters *msg)
{
  VAPI_DBG("Swapping `vapi_msg_vnet_ip4_nbr_counters'@%p to host byte order", msg);

  vapi_msg_vnet_ip4_nbr_counters_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_vnet_ip4_fib_counters_payload_hton(vapi_payload_vnet_ip4_fib_counters *payload)
{
  payload->_vl_msg_id = htobe16(payload->_vl_msg_id);
  payload->vrf_id = htobe32(payload->vrf_id);
  payload->count = htobe32(payload->count);
  do { unsigned i; for (i = 0; i < be32toh(payload->count); ++i) { vapi_type_ip4_fib_counter_hton(&payload->c[i]); } } while(0);
}

static inline void vapi_msg_vnet_ip4_fib_counters_payload_ntoh(vapi_payload_vnet_ip4_fib_counters *payload)
{
  payload->_vl_msg_id = be16toh(payload->_vl_msg_id);
  payload->vrf_id = be32toh(payload->vrf_id);
  payload->count = be32toh(payload->count);
  do { unsigned i; for (i = 0; i < payload->count; ++i) { vapi_type_ip4_fib_counter_ntoh(&payload->c[i]); } } while(0);
}

static inline uword vapi_calc_vnet_ip4_fib_counters_msg_size(vapi_msg_vnet_ip4_fib_counters *msg)
{
  return sizeof(*msg)+ msg->payload.count * sizeof(msg->payload.c[0]);
}

static inline void vapi_msg_vnet_ip4_fib_counters_hton(vapi_msg_vnet_ip4_fib_counters *msg)
{
  VAPI_DBG("Swapping `vapi_msg_vnet_ip4_fib_counters'@%p to big endian", msg);

  vapi_msg_vnet_ip4_fib_counters_payload_hton(&msg->payload);
}

static inline void vapi_msg_vnet_ip4_fib_counters_ntoh(vapi_msg_vnet_ip4_fib_counters *msg)
{
  VAPI_DBG("Swapping `vapi_msg_vnet_ip4_fib_counters'@%p to host byte order", msg);

  vapi_msg_vnet_ip4_fib_counters_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_want_per_interface_combined_stats_reply_payload_hton(vapi_payload_want_per_interface_combined_stats_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_want_per_interface_combined_stats_reply_payload_ntoh(vapi_payload_want_per_interface_combined_stats_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_want_per_interface_combined_stats_reply_msg_size(vapi_msg_want_per_interface_combined_stats_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_want_per_interface_combined_stats_reply_hton(vapi_msg_want_per_interface_combined_stats_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_per_interface_combined_stats_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_want_per_interface_combined_stats_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_want_per_interface_combined_stats_reply_ntoh(vapi_msg_want_per_interface_combined_stats_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_per_interface_combined_stats_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_want_per_interface_combined_stats_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_want_per_interface_simple_stats_payload_hton(vapi_payload_want_per_interface_simple_stats *payload)
{
  payload->enable_disable = htobe32(payload->enable_disable);
  payload->pid = htobe32(payload->pid);
  payload->num = htobe32(payload->num);
  do { unsigned i; for (i = 0; i < be32toh(payload->num); ++i) { payload->sw_ifs[i] = htobe32(payload->sw_ifs[i]); } } while(0);
}

static inline void vapi_msg_want_per_interface_simple_stats_payload_ntoh(vapi_payload_want_per_interface_simple_stats *payload)
{
  payload->enable_disable = be32toh(payload->enable_disable);
  payload->pid = be32toh(payload->pid);
  payload->num = be32toh(payload->num);
  do { unsigned i; for (i = 0; i < payload->num; ++i) { payload->sw_ifs[i] = be32toh(payload->sw_ifs[i]); } } while(0);
}

static inline uword vapi_calc_want_per_interface_simple_stats_msg_size(vapi_msg_want_per_interface_simple_stats *msg)
{
  return sizeof(*msg)+ msg->payload.num * sizeof(msg->payload.sw_ifs[0]);
}

static inline void vapi_msg_want_per_interface_simple_stats_hton(vapi_msg_want_per_interface_simple_stats *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_per_interface_simple_stats'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_want_per_interface_simple_stats_payload_hton(&msg->payload);
}

static inline void vapi_msg_want_per_interface_simple_stats_ntoh(vapi_msg_want_per_interface_simple_stats *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_per_interface_simple_stats'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_want_per_interface_simple_stats_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_want_ip4_nbr_stats_payload_hton(vapi_payload_want_ip4_nbr_stats *payload)
{
  payload->enable_disable = htobe32(payload->enable_disable);
  payload->pid = htobe32(payload->pid);
}

static inline void vapi_msg_want_ip4_nbr_stats_payload_ntoh(vapi_payload_want_ip4_nbr_stats *payload)
{
  payload->enable_disable = be32toh(payload->enable_disable);
  payload->pid = be32toh(payload->pid);
}

static inline uword vapi_calc_want_ip4_nbr_stats_msg_size(vapi_msg_want_ip4_nbr_stats *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_want_ip4_nbr_stats_hton(vapi_msg_want_ip4_nbr_stats *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_ip4_nbr_stats'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_want_ip4_nbr_stats_payload_hton(&msg->payload);
}

static inline void vapi_msg_want_ip4_nbr_stats_ntoh(vapi_msg_want_ip4_nbr_stats *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_ip4_nbr_stats'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_want_ip4_nbr_stats_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_vnet_ip6_nbr_counters_payload_hton(vapi_payload_vnet_ip6_nbr_counters *payload)
{
  payload->_vl_msg_id = htobe16(payload->_vl_msg_id);
  payload->count = htobe32(payload->count);
  payload->sw_if_index = htobe32(payload->sw_if_index);
  do { unsigned i; for (i = 0; i < be32toh(payload->count); ++i) { vapi_type_ip6_nbr_counter_hton(&payload->c[i]); } } while(0);
}

static inline void vapi_msg_vnet_ip6_nbr_counters_payload_ntoh(vapi_payload_vnet_ip6_nbr_counters *payload)
{
  payload->_vl_msg_id = be16toh(payload->_vl_msg_id);
  payload->count = be32toh(payload->count);
  payload->sw_if_index = be32toh(payload->sw_if_index);
  do { unsigned i; for (i = 0; i < payload->count; ++i) { vapi_type_ip6_nbr_counter_ntoh(&payload->c[i]); } } while(0);
}

static inline uword vapi_calc_vnet_ip6_nbr_counters_msg_size(vapi_msg_vnet_ip6_nbr_counters *msg)
{
  return sizeof(*msg)+ msg->payload.count * sizeof(msg->payload.c[0]);
}

static inline void vapi_msg_vnet_ip6_nbr_counters_hton(vapi_msg_vnet_ip6_nbr_counters *msg)
{
  VAPI_DBG("Swapping `vapi_msg_vnet_ip6_nbr_counters'@%p to big endian", msg);

  vapi_msg_vnet_ip6_nbr_counters_payload_hton(&msg->payload);
}

static inline void vapi_msg_vnet_ip6_nbr_counters_ntoh(vapi_msg_vnet_ip6_nbr_counters *msg)
{
  VAPI_DBG("Swapping `vapi_msg_vnet_ip6_nbr_counters'@%p to host byte order", msg);

  vapi_msg_vnet_ip6_nbr_counters_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_want_ip4_fib_stats_reply_payload_hton(vapi_payload_want_ip4_fib_stats_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_want_ip4_fib_stats_reply_payload_ntoh(vapi_payload_want_ip4_fib_stats_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_want_ip4_fib_stats_reply_msg_size(vapi_msg_want_ip4_fib_stats_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_want_ip4_fib_stats_reply_hton(vapi_msg_want_ip4_fib_stats_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_ip4_fib_stats_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_want_ip4_fib_stats_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_want_ip4_fib_stats_reply_ntoh(vapi_msg_want_ip4_fib_stats_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_ip4_fib_stats_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_want_ip4_fib_stats_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_want_ip6_fib_stats_reply_payload_hton(vapi_payload_want_ip6_fib_stats_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_want_ip6_fib_stats_reply_payload_ntoh(vapi_payload_want_ip6_fib_stats_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_want_ip6_fib_stats_reply_msg_size(vapi_msg_want_ip6_fib_stats_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_want_ip6_fib_stats_reply_hton(vapi_msg_want_ip6_fib_stats_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_ip6_fib_stats_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_want_ip6_fib_stats_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_want_ip6_fib_stats_reply_ntoh(vapi_msg_want_ip6_fib_stats_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_ip6_fib_stats_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_want_ip6_fib_stats_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_vnet_ip6_fib_counters_payload_hton(vapi_payload_vnet_ip6_fib_counters *payload)
{
  payload->_vl_msg_id = htobe16(payload->_vl_msg_id);
  payload->vrf_id = htobe32(payload->vrf_id);
  payload->count = htobe32(payload->count);
  do { unsigned i; for (i = 0; i < be32toh(payload->count); ++i) { vapi_type_ip6_fib_counter_hton(&payload->c[i]); } } while(0);
}

static inline void vapi_msg_vnet_ip6_fib_counters_payload_ntoh(vapi_payload_vnet_ip6_fib_counters *payload)
{
  payload->_vl_msg_id = be16toh(payload->_vl_msg_id);
  payload->vrf_id = be32toh(payload->vrf_id);
  payload->count = be32toh(payload->count);
  do { unsigned i; for (i = 0; i < payload->count; ++i) { vapi_type_ip6_fib_counter_ntoh(&payload->c[i]); } } while(0);
}

static inline uword vapi_calc_vnet_ip6_fib_counters_msg_size(vapi_msg_vnet_ip6_fib_counters *msg)
{
  return sizeof(*msg)+ msg->payload.count * sizeof(msg->payload.c[0]);
}

static inline void vapi_msg_vnet_ip6_fib_counters_hton(vapi_msg_vnet_ip6_fib_counters *msg)
{
  VAPI_DBG("Swapping `vapi_msg_vnet_ip6_fib_counters'@%p to big endian", msg);

  vapi_msg_vnet_ip6_fib_counters_payload_hton(&msg->payload);
}

static inline void vapi_msg_vnet_ip6_fib_counters_ntoh(vapi_msg_vnet_ip6_fib_counters *msg)
{
  VAPI_DBG("Swapping `vapi_msg_vnet_ip6_fib_counters'@%p to host byte order", msg);

  vapi_msg_vnet_ip6_fib_counters_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_want_per_interface_simple_stats_reply_payload_hton(vapi_payload_want_per_interface_simple_stats_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_want_per_interface_simple_stats_reply_payload_ntoh(vapi_payload_want_per_interface_simple_stats_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_want_per_interface_simple_stats_reply_msg_size(vapi_msg_want_per_interface_simple_stats_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_want_per_interface_simple_stats_reply_hton(vapi_msg_want_per_interface_simple_stats_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_per_interface_simple_stats_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_want_per_interface_simple_stats_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_want_per_interface_simple_stats_reply_ntoh(vapi_msg_want_per_interface_simple_stats_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_per_interface_simple_stats_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_want_per_interface_simple_stats_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_want_ip6_nbr_stats_payload_hton(vapi_payload_want_ip6_nbr_stats *payload)
{
  payload->enable_disable = htobe32(payload->enable_disable);
  payload->pid = htobe32(payload->pid);
}

static inline void vapi_msg_want_ip6_nbr_stats_payload_ntoh(vapi_payload_want_ip6_nbr_stats *payload)
{
  payload->enable_disable = be32toh(payload->enable_disable);
  payload->pid = be32toh(payload->pid);
}

static inline uword vapi_calc_want_ip6_nbr_stats_msg_size(vapi_msg_want_ip6_nbr_stats *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_want_ip6_nbr_stats_hton(vapi_msg_want_ip6_nbr_stats *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_ip6_nbr_stats'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_want_ip6_nbr_stats_payload_hton(&msg->payload);
}

static inline void vapi_msg_want_ip6_nbr_stats_ntoh(vapi_msg_want_ip6_nbr_stats *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_ip6_nbr_stats'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_want_ip6_nbr_stats_payload_ntoh(&msg->payload);
}

static inline vapi_msg_want_ip4_fib_stats* vapi_alloc_want_ip4_fib_stats(struct vapi_ctx_s *ctx)
{
  vapi_msg_want_ip4_fib_stats *msg = NULL;
  const size_t size = sizeof(vapi_msg_want_ip4_fib_stats);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_want_ip4_fib_stats*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_want_ip4_fib_stats);

  return msg;
}

static inline vapi_error_e vapi_want_ip4_fib_stats(struct vapi_ctx_s *ctx,
  vapi_msg_want_ip4_fib_stats *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_want_ip4_fib_stats_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_want_ip4_fib_stats_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_want_ip4_fib_stats_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_vnet_get_summary_stats* vapi_alloc_vnet_get_summary_stats(struct vapi_ctx_s *ctx)
{
  vapi_msg_vnet_get_summary_stats *msg = NULL;
  const size_t size = sizeof(vapi_msg_vnet_get_summary_stats);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_vnet_get_summary_stats*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_vnet_get_summary_stats);

  return msg;
}

static inline vapi_error_e vapi_vnet_get_summary_stats(struct vapi_ctx_s *ctx,
  vapi_msg_vnet_get_summary_stats *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_vnet_get_summary_stats_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_vnet_get_summary_stats_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_vnet_get_summary_stats_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_want_interface_combined_stats* vapi_alloc_want_interface_combined_stats(struct vapi_ctx_s *ctx)
{
  vapi_msg_want_interface_combined_stats *msg = NULL;
  const size_t size = sizeof(vapi_msg_want_interface_combined_stats);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_want_interface_combined_stats*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_want_interface_combined_stats);

  return msg;
}

static inline vapi_error_e vapi_want_interface_combined_stats(struct vapi_ctx_s *ctx,
  vapi_msg_want_interface_combined_stats *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_want_interface_combined_stats_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_want_interface_combined_stats_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_want_interface_combined_stats_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_want_ip6_fib_stats* vapi_alloc_want_ip6_fib_stats(struct vapi_ctx_s *ctx)
{
  vapi_msg_want_ip6_fib_stats *msg = NULL;
  const size_t size = sizeof(vapi_msg_want_ip6_fib_stats);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_want_ip6_fib_stats*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_want_ip6_fib_stats);

  return msg;
}

static inline vapi_error_e vapi_want_ip6_fib_stats(struct vapi_ctx_s *ctx,
  vapi_msg_want_ip6_fib_stats *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_want_ip6_fib_stats_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_want_ip6_fib_stats_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_want_ip6_fib_stats_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_want_stats* vapi_alloc_want_stats(struct vapi_ctx_s *ctx)
{
  vapi_msg_want_stats *msg = NULL;
  const size_t size = sizeof(vapi_msg_want_stats);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_want_stats*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_want_stats);

  return msg;
}

static inline vapi_error_e vapi_want_stats(struct vapi_ctx_s *ctx,
  vapi_msg_want_stats *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_want_stats_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_want_stats_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_want_stats_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_want_interface_simple_stats* vapi_alloc_want_interface_simple_stats(struct vapi_ctx_s *ctx)
{
  vapi_msg_want_interface_simple_stats *msg = NULL;
  const size_t size = sizeof(vapi_msg_want_interface_simple_stats);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_want_interface_simple_stats*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_want_interface_simple_stats);

  return msg;
}

static inline vapi_error_e vapi_want_interface_simple_stats(struct vapi_ctx_s *ctx,
  vapi_msg_want_interface_simple_stats *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_want_interface_simple_stats_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_want_interface_simple_stats_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_want_interface_simple_stats_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_want_per_interface_combined_stats* vapi_alloc_want_per_interface_combined_stats(struct vapi_ctx_s *ctx, size_t sw_ifs_array_size)
{
  vapi_msg_want_per_interface_combined_stats *msg = NULL;
  const size_t size = sizeof(vapi_msg_want_per_interface_combined_stats) + sizeof(msg->payload.sw_ifs[0]) * sw_ifs_array_size;
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_want_per_interface_combined_stats*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_want_per_interface_combined_stats);
  msg->payload.num = sw_ifs_array_size;
  return msg;
}

static inline vapi_error_e vapi_want_per_interface_combined_stats(struct vapi_ctx_s *ctx,
  vapi_msg_want_per_interface_combined_stats *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_want_per_interface_combined_stats_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_want_per_interface_combined_stats_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_want_per_interface_combined_stats_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_want_per_interface_simple_stats* vapi_alloc_want_per_interface_simple_stats(struct vapi_ctx_s *ctx, size_t sw_ifs_array_size)
{
  vapi_msg_want_per_interface_simple_stats *msg = NULL;
  const size_t size = sizeof(vapi_msg_want_per_interface_simple_stats) + sizeof(msg->payload.sw_ifs[0]) * sw_ifs_array_size;
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_want_per_interface_simple_stats*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_want_per_interface_simple_stats);
  msg->payload.num = sw_ifs_array_size;
  return msg;
}

static inline vapi_error_e vapi_want_per_interface_simple_stats(struct vapi_ctx_s *ctx,
  vapi_msg_want_per_interface_simple_stats *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_want_per_interface_simple_stats_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_want_per_interface_simple_stats_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_want_per_interface_simple_stats_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_want_ip4_nbr_stats* vapi_alloc_want_ip4_nbr_stats(struct vapi_ctx_s *ctx)
{
  vapi_msg_want_ip4_nbr_stats *msg = NULL;
  const size_t size = sizeof(vapi_msg_want_ip4_nbr_stats);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_want_ip4_nbr_stats*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_want_ip4_nbr_stats);

  return msg;
}

static inline vapi_error_e vapi_want_ip4_nbr_stats(struct vapi_ctx_s *ctx,
  vapi_msg_want_ip4_nbr_stats *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_want_ip4_nbr_stats_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_want_ip4_nbr_stats_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_want_ip4_nbr_stats_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_want_ip6_nbr_stats* vapi_alloc_want_ip6_nbr_stats(struct vapi_ctx_s *ctx)
{
  vapi_msg_want_ip6_nbr_stats *msg = NULL;
  const size_t size = sizeof(vapi_msg_want_ip6_nbr_stats);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_want_ip6_nbr_stats*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_want_ip6_nbr_stats);

  return msg;
}

static inline vapi_error_e vapi_want_ip6_nbr_stats(struct vapi_ctx_s *ctx,
  vapi_msg_want_ip6_nbr_stats *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_want_ip6_nbr_stats_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_want_ip6_nbr_stats_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_want_ip6_nbr_stats_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}



static void __attribute__((constructor)) __vapi_constructor_want_ip4_fib_stats()
{
  static const char name[] = "want_ip4_fib_stats";
  static const char name_with_crc[] = "want_ip4_fib_stats_6ce4937d";
  static vapi_message_desc_t __vapi_metadata_want_ip4_fib_stats = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_want_ip4_fib_stats, payload),
    sizeof(vapi_msg_want_ip4_fib_stats),
    (generic_swap_fn_t)vapi_msg_want_ip4_fib_stats_hton,
    (generic_swap_fn_t)vapi_msg_want_ip4_fib_stats_ntoh,
    ~0,
  };

  vapi_msg_id_want_ip4_fib_stats = vapi_register_msg(&__vapi_metadata_want_ip4_fib_stats);
  VAPI_DBG("Assigned msg id %d to want_ip4_fib_stats", vapi_msg_id_want_ip4_fib_stats);
}

static void __attribute__((constructor)) __vapi_constructor_want_interface_combined_stats_reply()
{
  static const char name[] = "want_interface_combined_stats_reply";
  static const char name_with_crc[] = "want_interface_combined_stats_reply_b260196d";
  static vapi_message_desc_t __vapi_metadata_want_interface_combined_stats_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_want_interface_combined_stats_reply, payload),
    sizeof(vapi_msg_want_interface_combined_stats_reply),
    (generic_swap_fn_t)vapi_msg_want_interface_combined_stats_reply_hton,
    (generic_swap_fn_t)vapi_msg_want_interface_combined_stats_reply_ntoh,
    ~0,
  };

  vapi_msg_id_want_interface_combined_stats_reply = vapi_register_msg(&__vapi_metadata_want_interface_combined_stats_reply);
  VAPI_DBG("Assigned msg id %d to want_interface_combined_stats_reply", vapi_msg_id_want_interface_combined_stats_reply);
}

static void __attribute__((constructor)) __vapi_constructor_vnet_get_summary_stats()
{
  static const char name[] = "vnet_get_summary_stats";
  static const char name_with_crc[] = "vnet_get_summary_stats_16435c20";
  static vapi_message_desc_t __vapi_metadata_vnet_get_summary_stats = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_vnet_get_summary_stats),
    (generic_swap_fn_t)vapi_msg_vnet_get_summary_stats_hton,
    (generic_swap_fn_t)vapi_msg_vnet_get_summary_stats_ntoh,
    ~0,
  };

  vapi_msg_id_vnet_get_summary_stats = vapi_register_msg(&__vapi_metadata_vnet_get_summary_stats);
  VAPI_DBG("Assigned msg id %d to vnet_get_summary_stats", vapi_msg_id_vnet_get_summary_stats);
}

static void __attribute__((constructor)) __vapi_constructor_vnet_get_summary_stats_reply()
{
  static const char name[] = "vnet_get_summary_stats_reply";
  static const char name_with_crc[] = "vnet_get_summary_stats_reply_675ce280";
  static vapi_message_desc_t __vapi_metadata_vnet_get_summary_stats_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_vnet_get_summary_stats_reply, payload),
    sizeof(vapi_msg_vnet_get_summary_stats_reply),
    (generic_swap_fn_t)vapi_msg_vnet_get_summary_stats_reply_hton,
    (generic_swap_fn_t)vapi_msg_vnet_get_summary_stats_reply_ntoh,
    ~0,
  };

  vapi_msg_id_vnet_get_summary_stats_reply = vapi_register_msg(&__vapi_metadata_vnet_get_summary_stats_reply);
  VAPI_DBG("Assigned msg id %d to vnet_get_summary_stats_reply", vapi_msg_id_vnet_get_summary_stats_reply);
}

static void __attribute__((constructor)) __vapi_constructor_want_ip4_nbr_stats_reply()
{
  static const char name[] = "want_ip4_nbr_stats_reply";
  static const char name_with_crc[] = "want_ip4_nbr_stats_reply_e27d62cd";
  static vapi_message_desc_t __vapi_metadata_want_ip4_nbr_stats_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_want_ip4_nbr_stats_reply, payload),
    sizeof(vapi_msg_want_ip4_nbr_stats_reply),
    (generic_swap_fn_t)vapi_msg_want_ip4_nbr_stats_reply_hton,
    (generic_swap_fn_t)vapi_msg_want_ip4_nbr_stats_reply_ntoh,
    ~0,
  };

  vapi_msg_id_want_ip4_nbr_stats_reply = vapi_register_msg(&__vapi_metadata_want_ip4_nbr_stats_reply);
  VAPI_DBG("Assigned msg id %d to want_ip4_nbr_stats_reply", vapi_msg_id_want_ip4_nbr_stats_reply);
}

static void __attribute__((constructor)) __vapi_constructor_want_interface_combined_stats()
{
  static const char name[] = "want_interface_combined_stats";
  static const char name_with_crc[] = "want_interface_combined_stats_a98830b6";
  static vapi_message_desc_t __vapi_metadata_want_interface_combined_stats = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_want_interface_combined_stats, payload),
    sizeof(vapi_msg_want_interface_combined_stats),
    (generic_swap_fn_t)vapi_msg_want_interface_combined_stats_hton,
    (generic_swap_fn_t)vapi_msg_want_interface_combined_stats_ntoh,
    ~0,
  };

  vapi_msg_id_want_interface_combined_stats = vapi_register_msg(&__vapi_metadata_want_interface_combined_stats);
  VAPI_DBG("Assigned msg id %d to want_interface_combined_stats", vapi_msg_id_want_interface_combined_stats);
}

static void __attribute__((constructor)) __vapi_constructor_want_ip6_nbr_stats_reply()
{
  static const char name[] = "want_ip6_nbr_stats_reply";
  static const char name_with_crc[] = "want_ip6_nbr_stats_reply_625da111";
  static vapi_message_desc_t __vapi_metadata_want_ip6_nbr_stats_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_want_ip6_nbr_stats_reply, payload),
    sizeof(vapi_msg_want_ip6_nbr_stats_reply),
    (generic_swap_fn_t)vapi_msg_want_ip6_nbr_stats_reply_hton,
    (generic_swap_fn_t)vapi_msg_want_ip6_nbr_stats_reply_ntoh,
    ~0,
  };

  vapi_msg_id_want_ip6_nbr_stats_reply = vapi_register_msg(&__vapi_metadata_want_ip6_nbr_stats_reply);
  VAPI_DBG("Assigned msg id %d to want_ip6_nbr_stats_reply", vapi_msg_id_want_ip6_nbr_stats_reply);
}

static void __attribute__((constructor)) __vapi_constructor_want_ip6_fib_stats()
{
  static const char name[] = "want_ip6_fib_stats";
  static const char name_with_crc[] = "want_ip6_fib_stats_01697516";
  static vapi_message_desc_t __vapi_metadata_want_ip6_fib_stats = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_want_ip6_fib_stats, payload),
    sizeof(vapi_msg_want_ip6_fib_stats),
    (generic_swap_fn_t)vapi_msg_want_ip6_fib_stats_hton,
    (generic_swap_fn_t)vapi_msg_want_ip6_fib_stats_ntoh,
    ~0,
  };

  vapi_msg_id_want_ip6_fib_stats = vapi_register_msg(&__vapi_metadata_want_ip6_fib_stats);
  VAPI_DBG("Assigned msg id %d to want_ip6_fib_stats", vapi_msg_id_want_ip6_fib_stats);
}

static void __attribute__((constructor)) __vapi_constructor_want_interface_simple_stats_reply()
{
  static const char name[] = "want_interface_simple_stats_reply";
  static const char name_with_crc[] = "want_interface_simple_stats_reply_5163615b";
  static vapi_message_desc_t __vapi_metadata_want_interface_simple_stats_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_want_interface_simple_stats_reply, payload),
    sizeof(vapi_msg_want_interface_simple_stats_reply),
    (generic_swap_fn_t)vapi_msg_want_interface_simple_stats_reply_hton,
    (generic_swap_fn_t)vapi_msg_want_interface_simple_stats_reply_ntoh,
    ~0,
  };

  vapi_msg_id_want_interface_simple_stats_reply = vapi_register_msg(&__vapi_metadata_want_interface_simple_stats_reply);
  VAPI_DBG("Assigned msg id %d to want_interface_simple_stats_reply", vapi_msg_id_want_interface_simple_stats_reply);
}

static void __attribute__((constructor)) __vapi_constructor_want_stats()
{
  static const char name[] = "want_stats";
  static const char name_with_crc[] = "want_stats_4f2effb4";
  static vapi_message_desc_t __vapi_metadata_want_stats = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_want_stats, payload),
    sizeof(vapi_msg_want_stats),
    (generic_swap_fn_t)vapi_msg_want_stats_hton,
    (generic_swap_fn_t)vapi_msg_want_stats_ntoh,
    ~0,
  };

  vapi_msg_id_want_stats = vapi_register_msg(&__vapi_metadata_want_stats);
  VAPI_DBG("Assigned msg id %d to want_stats", vapi_msg_id_want_stats);
}

static void __attribute__((constructor)) __vapi_constructor_want_interface_simple_stats()
{
  static const char name[] = "want_interface_simple_stats";
  static const char name_with_crc[] = "want_interface_simple_stats_bb4739ed";
  static vapi_message_desc_t __vapi_metadata_want_interface_simple_stats = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_want_interface_simple_stats, payload),
    sizeof(vapi_msg_want_interface_simple_stats),
    (generic_swap_fn_t)vapi_msg_want_interface_simple_stats_hton,
    (generic_swap_fn_t)vapi_msg_want_interface_simple_stats_ntoh,
    ~0,
  };

  vapi_msg_id_want_interface_simple_stats = vapi_register_msg(&__vapi_metadata_want_interface_simple_stats);
  VAPI_DBG("Assigned msg id %d to want_interface_simple_stats", vapi_msg_id_want_interface_simple_stats);
}

static void __attribute__((constructor)) __vapi_constructor_want_per_interface_combined_stats()
{
  static const char name[] = "want_per_interface_combined_stats";
  static const char name_with_crc[] = "want_per_interface_combined_stats_d914890f";
  static vapi_message_desc_t __vapi_metadata_want_per_interface_combined_stats = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_want_per_interface_combined_stats, payload),
    sizeof(vapi_msg_want_per_interface_combined_stats),
    (generic_swap_fn_t)vapi_msg_want_per_interface_combined_stats_hton,
    (generic_swap_fn_t)vapi_msg_want_per_interface_combined_stats_ntoh,
    ~0,
  };

  vapi_msg_id_want_per_interface_combined_stats = vapi_register_msg(&__vapi_metadata_want_per_interface_combined_stats);
  VAPI_DBG("Assigned msg id %d to want_per_interface_combined_stats", vapi_msg_id_want_per_interface_combined_stats);
}

static void __attribute__((constructor)) __vapi_constructor_want_stats_reply()
{
  static const char name[] = "want_stats_reply";
  static const char name_with_crc[] = "want_stats_reply_b36abf5f";
  static vapi_message_desc_t __vapi_metadata_want_stats_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_want_stats_reply, payload),
    sizeof(vapi_msg_want_stats_reply),
    (generic_swap_fn_t)vapi_msg_want_stats_reply_hton,
    (generic_swap_fn_t)vapi_msg_want_stats_reply_ntoh,
    ~0,
  };

  vapi_msg_id_want_stats_reply = vapi_register_msg(&__vapi_metadata_want_stats_reply);
  VAPI_DBG("Assigned msg id %d to want_stats_reply", vapi_msg_id_want_stats_reply);
}

static void __attribute__((constructor)) __vapi_constructor_vnet_ip4_nbr_counters()
{
  static const char name[] = "vnet_ip4_nbr_counters";
  static const char name_with_crc[] = "vnet_ip4_nbr_counters_fc2b5092";
  static vapi_message_desc_t __vapi_metadata_vnet_ip4_nbr_counters = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    false,
    0,
    offsetof(vapi_msg_vnet_ip4_nbr_counters, payload),
    sizeof(vapi_msg_vnet_ip4_nbr_counters),
    (generic_swap_fn_t)vapi_msg_vnet_ip4_nbr_counters_hton,
    (generic_swap_fn_t)vapi_msg_vnet_ip4_nbr_counters_ntoh,
    ~0,
  };

  vapi_msg_id_vnet_ip4_nbr_counters = vapi_register_msg(&__vapi_metadata_vnet_ip4_nbr_counters);
  VAPI_DBG("Assigned msg id %d to vnet_ip4_nbr_counters", vapi_msg_id_vnet_ip4_nbr_counters);
}

static void __attribute__((constructor)) __vapi_constructor_vnet_ip4_fib_counters()
{
  static const char name[] = "vnet_ip4_fib_counters";
  static const char name_with_crc[] = "vnet_ip4_fib_counters_1ab9d6c5";
  static vapi_message_desc_t __vapi_metadata_vnet_ip4_fib_counters = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    false,
    0,
    offsetof(vapi_msg_vnet_ip4_fib_counters, payload),
    sizeof(vapi_msg_vnet_ip4_fib_counters),
    (generic_swap_fn_t)vapi_msg_vnet_ip4_fib_counters_hton,
    (generic_swap_fn_t)vapi_msg_vnet_ip4_fib_counters_ntoh,
    ~0,
  };

  vapi_msg_id_vnet_ip4_fib_counters = vapi_register_msg(&__vapi_metadata_vnet_ip4_fib_counters);
  VAPI_DBG("Assigned msg id %d to vnet_ip4_fib_counters", vapi_msg_id_vnet_ip4_fib_counters);
}

static void __attribute__((constructor)) __vapi_constructor_want_per_interface_combined_stats_reply()
{
  static const char name[] = "want_per_interface_combined_stats_reply";
  static const char name_with_crc[] = "want_per_interface_combined_stats_reply_06158495";
  static vapi_message_desc_t __vapi_metadata_want_per_interface_combined_stats_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_want_per_interface_combined_stats_reply, payload),
    sizeof(vapi_msg_want_per_interface_combined_stats_reply),
    (generic_swap_fn_t)vapi_msg_want_per_interface_combined_stats_reply_hton,
    (generic_swap_fn_t)vapi_msg_want_per_interface_combined_stats_reply_ntoh,
    ~0,
  };

  vapi_msg_id_want_per_interface_combined_stats_reply = vapi_register_msg(&__vapi_metadata_want_per_interface_combined_stats_reply);
  VAPI_DBG("Assigned msg id %d to want_per_interface_combined_stats_reply", vapi_msg_id_want_per_interface_combined_stats_reply);
}

static void __attribute__((constructor)) __vapi_constructor_want_per_interface_simple_stats()
{
  static const char name[] = "want_per_interface_simple_stats";
  static const char name_with_crc[] = "want_per_interface_simple_stats_0165e6f2";
  static vapi_message_desc_t __vapi_metadata_want_per_interface_simple_stats = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_want_per_interface_simple_stats, payload),
    sizeof(vapi_msg_want_per_interface_simple_stats),
    (generic_swap_fn_t)vapi_msg_want_per_interface_simple_stats_hton,
    (generic_swap_fn_t)vapi_msg_want_per_interface_simple_stats_ntoh,
    ~0,
  };

  vapi_msg_id_want_per_interface_simple_stats = vapi_register_msg(&__vapi_metadata_want_per_interface_simple_stats);
  VAPI_DBG("Assigned msg id %d to want_per_interface_simple_stats", vapi_msg_id_want_per_interface_simple_stats);
}

static void __attribute__((constructor)) __vapi_constructor_want_ip4_nbr_stats()
{
  static const char name[] = "want_ip4_nbr_stats";
  static const char name_with_crc[] = "want_ip4_nbr_stats_6bea26e1";
  static vapi_message_desc_t __vapi_metadata_want_ip4_nbr_stats = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_want_ip4_nbr_stats, payload),
    sizeof(vapi_msg_want_ip4_nbr_stats),
    (generic_swap_fn_t)vapi_msg_want_ip4_nbr_stats_hton,
    (generic_swap_fn_t)vapi_msg_want_ip4_nbr_stats_ntoh,
    ~0,
  };

  vapi_msg_id_want_ip4_nbr_stats = vapi_register_msg(&__vapi_metadata_want_ip4_nbr_stats);
  VAPI_DBG("Assigned msg id %d to want_ip4_nbr_stats", vapi_msg_id_want_ip4_nbr_stats);
}

static void __attribute__((constructor)) __vapi_constructor_vnet_ip6_nbr_counters()
{
  static const char name[] = "vnet_ip6_nbr_counters";
  static const char name_with_crc[] = "vnet_ip6_nbr_counters_181b673f";
  static vapi_message_desc_t __vapi_metadata_vnet_ip6_nbr_counters = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    false,
    0,
    offsetof(vapi_msg_vnet_ip6_nbr_counters, payload),
    sizeof(vapi_msg_vnet_ip6_nbr_counters),
    (generic_swap_fn_t)vapi_msg_vnet_ip6_nbr_counters_hton,
    (generic_swap_fn_t)vapi_msg_vnet_ip6_nbr_counters_ntoh,
    ~0,
  };

  vapi_msg_id_vnet_ip6_nbr_counters = vapi_register_msg(&__vapi_metadata_vnet_ip6_nbr_counters);
  VAPI_DBG("Assigned msg id %d to vnet_ip6_nbr_counters", vapi_msg_id_vnet_ip6_nbr_counters);
}

static void __attribute__((constructor)) __vapi_constructor_want_ip4_fib_stats_reply()
{
  static const char name[] = "want_ip4_fib_stats_reply";
  static const char name_with_crc[] = "want_ip4_fib_stats_reply_d337cb77";
  static vapi_message_desc_t __vapi_metadata_want_ip4_fib_stats_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_want_ip4_fib_stats_reply, payload),
    sizeof(vapi_msg_want_ip4_fib_stats_reply),
    (generic_swap_fn_t)vapi_msg_want_ip4_fib_stats_reply_hton,
    (generic_swap_fn_t)vapi_msg_want_ip4_fib_stats_reply_ntoh,
    ~0,
  };

  vapi_msg_id_want_ip4_fib_stats_reply = vapi_register_msg(&__vapi_metadata_want_ip4_fib_stats_reply);
  VAPI_DBG("Assigned msg id %d to want_ip4_fib_stats_reply", vapi_msg_id_want_ip4_fib_stats_reply);
}

static void __attribute__((constructor)) __vapi_constructor_want_ip6_fib_stats_reply()
{
  static const char name[] = "want_ip6_fib_stats_reply";
  static const char name_with_crc[] = "want_ip6_fib_stats_reply_531708ab";
  static vapi_message_desc_t __vapi_metadata_want_ip6_fib_stats_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_want_ip6_fib_stats_reply, payload),
    sizeof(vapi_msg_want_ip6_fib_stats_reply),
    (generic_swap_fn_t)vapi_msg_want_ip6_fib_stats_reply_hton,
    (generic_swap_fn_t)vapi_msg_want_ip6_fib_stats_reply_ntoh,
    ~0,
  };

  vapi_msg_id_want_ip6_fib_stats_reply = vapi_register_msg(&__vapi_metadata_want_ip6_fib_stats_reply);
  VAPI_DBG("Assigned msg id %d to want_ip6_fib_stats_reply", vapi_msg_id_want_ip6_fib_stats_reply);
}

static void __attribute__((constructor)) __vapi_constructor_vnet_ip6_fib_counters()
{
  static const char name[] = "vnet_ip6_fib_counters";
  static const char name_with_crc[] = "vnet_ip6_fib_counters_9ab453ae";
  static vapi_message_desc_t __vapi_metadata_vnet_ip6_fib_counters = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    false,
    0,
    offsetof(vapi_msg_vnet_ip6_fib_counters, payload),
    sizeof(vapi_msg_vnet_ip6_fib_counters),
    (generic_swap_fn_t)vapi_msg_vnet_ip6_fib_counters_hton,
    (generic_swap_fn_t)vapi_msg_vnet_ip6_fib_counters_ntoh,
    ~0,
  };

  vapi_msg_id_vnet_ip6_fib_counters = vapi_register_msg(&__vapi_metadata_vnet_ip6_fib_counters);
  VAPI_DBG("Assigned msg id %d to vnet_ip6_fib_counters", vapi_msg_id_vnet_ip6_fib_counters);
}

static void __attribute__((constructor)) __vapi_constructor_want_per_interface_simple_stats_reply()
{
  static const char name[] = "want_per_interface_simple_stats_reply";
  static const char name_with_crc[] = "want_per_interface_simple_stats_reply_720ee096";
  static vapi_message_desc_t __vapi_metadata_want_per_interface_simple_stats_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_want_per_interface_simple_stats_reply, payload),
    sizeof(vapi_msg_want_per_interface_simple_stats_reply),
    (generic_swap_fn_t)vapi_msg_want_per_interface_simple_stats_reply_hton,
    (generic_swap_fn_t)vapi_msg_want_per_interface_simple_stats_reply_ntoh,
    ~0,
  };

  vapi_msg_id_want_per_interface_simple_stats_reply = vapi_register_msg(&__vapi_metadata_want_per_interface_simple_stats_reply);
  VAPI_DBG("Assigned msg id %d to want_per_interface_simple_stats_reply", vapi_msg_id_want_per_interface_simple_stats_reply);
}

static void __attribute__((constructor)) __vapi_constructor_want_ip6_nbr_stats()
{
  static const char name[] = "want_ip6_nbr_stats";
  static const char name_with_crc[] = "want_ip6_nbr_stats_0667c08a";
  static vapi_message_desc_t __vapi_metadata_want_ip6_nbr_stats = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_want_ip6_nbr_stats, payload),
    sizeof(vapi_msg_want_ip6_nbr_stats),
    (generic_swap_fn_t)vapi_msg_want_ip6_nbr_stats_hton,
    (generic_swap_fn_t)vapi_msg_want_ip6_nbr_stats_ntoh,
    ~0,
  };

  vapi_msg_id_want_ip6_nbr_stats = vapi_register_msg(&__vapi_metadata_want_ip6_nbr_stats);
  VAPI_DBG("Assigned msg id %d to want_ip6_nbr_stats", vapi_msg_id_want_ip6_nbr_stats);
}


static inline void vapi_set_vapi_msg_want_interface_combined_stats_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_want_interface_combined_stats_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_want_interface_combined_stats_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_vnet_get_summary_stats_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_vnet_get_summary_stats_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_vnet_get_summary_stats_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_want_ip4_nbr_stats_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_want_ip4_nbr_stats_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_want_ip4_nbr_stats_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_want_ip6_nbr_stats_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_want_ip6_nbr_stats_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_want_ip6_nbr_stats_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_want_interface_simple_stats_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_want_interface_simple_stats_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_want_interface_simple_stats_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_want_stats_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_want_stats_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_want_stats_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_vnet_ip4_nbr_counters_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_vnet_ip4_nbr_counters *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_vnet_ip4_nbr_counters, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_vnet_ip4_fib_counters_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_vnet_ip4_fib_counters *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_vnet_ip4_fib_counters, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_want_per_interface_combined_stats_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_want_per_interface_combined_stats_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_want_per_interface_combined_stats_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_vnet_ip6_nbr_counters_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_vnet_ip6_nbr_counters *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_vnet_ip6_nbr_counters, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_want_ip4_fib_stats_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_want_ip4_fib_stats_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_want_ip4_fib_stats_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_want_ip6_fib_stats_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_want_ip6_fib_stats_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_want_ip6_fib_stats_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_vnet_ip6_fib_counters_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_vnet_ip6_fib_counters *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_vnet_ip6_fib_counters, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_want_per_interface_simple_stats_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_want_per_interface_simple_stats_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_want_per_interface_simple_stats_reply, (vapi_event_cb)callback, callback_ctx);
};


#ifdef __cplusplus
}
#endif

#endif
