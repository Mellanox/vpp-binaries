#ifndef __included_hpp_stats_api_json
#define __included_hpp_stats_api_json

#include <vapi/vapi.hpp>
#include <vapi/stats.api.vapi.h>

namespace vapi {

template <> inline void vapi_swap_to_be<vapi_msg_want_ip4_fib_stats>(vapi_msg_want_ip4_fib_stats *msg)
{
  vapi_msg_want_ip4_fib_stats_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_want_ip4_fib_stats>(vapi_msg_want_ip4_fib_stats *msg)
{
  vapi_msg_want_ip4_fib_stats_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_want_ip4_fib_stats>()
{
  return ::vapi_msg_id_want_ip4_fib_stats; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_want_ip4_fib_stats>>()
{
  return ::vapi_msg_id_want_ip4_fib_stats; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_want_ip4_fib_stats()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_want_ip4_fib_stats>(vapi_msg_id_want_ip4_fib_stats);
}

template <> inline vapi_msg_want_ip4_fib_stats* vapi_alloc<vapi_msg_want_ip4_fib_stats>(Connection &con)
{
  vapi_msg_want_ip4_fib_stats* result = vapi_alloc_want_ip4_fib_stats(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_want_ip4_fib_stats>;

template class Request<vapi_msg_want_ip4_fib_stats, vapi_msg_want_ip4_fib_stats_reply>;

using Want_ip4_fib_stats = Request<vapi_msg_want_ip4_fib_stats, vapi_msg_want_ip4_fib_stats_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_want_interface_combined_stats_reply>(vapi_msg_want_interface_combined_stats_reply *msg)
{
  vapi_msg_want_interface_combined_stats_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_want_interface_combined_stats_reply>(vapi_msg_want_interface_combined_stats_reply *msg)
{
  vapi_msg_want_interface_combined_stats_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_want_interface_combined_stats_reply>()
{
  return ::vapi_msg_id_want_interface_combined_stats_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_want_interface_combined_stats_reply>>()
{
  return ::vapi_msg_id_want_interface_combined_stats_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_want_interface_combined_stats_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_want_interface_combined_stats_reply>(vapi_msg_id_want_interface_combined_stats_reply);
}

template class Msg<vapi_msg_want_interface_combined_stats_reply>;

using Want_interface_combined_stats_reply = Msg<vapi_msg_want_interface_combined_stats_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_vnet_get_summary_stats>(vapi_msg_vnet_get_summary_stats *msg)
{
  vapi_msg_vnet_get_summary_stats_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_vnet_get_summary_stats>(vapi_msg_vnet_get_summary_stats *msg)
{
  vapi_msg_vnet_get_summary_stats_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_vnet_get_summary_stats>()
{
  return ::vapi_msg_id_vnet_get_summary_stats; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_vnet_get_summary_stats>>()
{
  return ::vapi_msg_id_vnet_get_summary_stats; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_vnet_get_summary_stats()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_vnet_get_summary_stats>(vapi_msg_id_vnet_get_summary_stats);
}

template <> inline vapi_msg_vnet_get_summary_stats* vapi_alloc<vapi_msg_vnet_get_summary_stats>(Connection &con)
{
  vapi_msg_vnet_get_summary_stats* result = vapi_alloc_vnet_get_summary_stats(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_vnet_get_summary_stats>;

template class Request<vapi_msg_vnet_get_summary_stats, vapi_msg_vnet_get_summary_stats_reply>;

using Vnet_get_summary_stats = Request<vapi_msg_vnet_get_summary_stats, vapi_msg_vnet_get_summary_stats_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_vnet_get_summary_stats_reply>(vapi_msg_vnet_get_summary_stats_reply *msg)
{
  vapi_msg_vnet_get_summary_stats_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_vnet_get_summary_stats_reply>(vapi_msg_vnet_get_summary_stats_reply *msg)
{
  vapi_msg_vnet_get_summary_stats_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_vnet_get_summary_stats_reply>()
{
  return ::vapi_msg_id_vnet_get_summary_stats_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_vnet_get_summary_stats_reply>>()
{
  return ::vapi_msg_id_vnet_get_summary_stats_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_vnet_get_summary_stats_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_vnet_get_summary_stats_reply>(vapi_msg_id_vnet_get_summary_stats_reply);
}

template class Msg<vapi_msg_vnet_get_summary_stats_reply>;

using Vnet_get_summary_stats_reply = Msg<vapi_msg_vnet_get_summary_stats_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_want_ip4_nbr_stats_reply>(vapi_msg_want_ip4_nbr_stats_reply *msg)
{
  vapi_msg_want_ip4_nbr_stats_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_want_ip4_nbr_stats_reply>(vapi_msg_want_ip4_nbr_stats_reply *msg)
{
  vapi_msg_want_ip4_nbr_stats_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_want_ip4_nbr_stats_reply>()
{
  return ::vapi_msg_id_want_ip4_nbr_stats_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_want_ip4_nbr_stats_reply>>()
{
  return ::vapi_msg_id_want_ip4_nbr_stats_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_want_ip4_nbr_stats_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_want_ip4_nbr_stats_reply>(vapi_msg_id_want_ip4_nbr_stats_reply);
}

template class Msg<vapi_msg_want_ip4_nbr_stats_reply>;

using Want_ip4_nbr_stats_reply = Msg<vapi_msg_want_ip4_nbr_stats_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_want_interface_combined_stats>(vapi_msg_want_interface_combined_stats *msg)
{
  vapi_msg_want_interface_combined_stats_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_want_interface_combined_stats>(vapi_msg_want_interface_combined_stats *msg)
{
  vapi_msg_want_interface_combined_stats_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_want_interface_combined_stats>()
{
  return ::vapi_msg_id_want_interface_combined_stats; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_want_interface_combined_stats>>()
{
  return ::vapi_msg_id_want_interface_combined_stats; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_want_interface_combined_stats()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_want_interface_combined_stats>(vapi_msg_id_want_interface_combined_stats);
}

template <> inline vapi_msg_want_interface_combined_stats* vapi_alloc<vapi_msg_want_interface_combined_stats>(Connection &con)
{
  vapi_msg_want_interface_combined_stats* result = vapi_alloc_want_interface_combined_stats(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_want_interface_combined_stats>;

template class Request<vapi_msg_want_interface_combined_stats, vapi_msg_want_interface_combined_stats_reply>;

using Want_interface_combined_stats = Request<vapi_msg_want_interface_combined_stats, vapi_msg_want_interface_combined_stats_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_want_ip6_nbr_stats_reply>(vapi_msg_want_ip6_nbr_stats_reply *msg)
{
  vapi_msg_want_ip6_nbr_stats_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_want_ip6_nbr_stats_reply>(vapi_msg_want_ip6_nbr_stats_reply *msg)
{
  vapi_msg_want_ip6_nbr_stats_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_want_ip6_nbr_stats_reply>()
{
  return ::vapi_msg_id_want_ip6_nbr_stats_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_want_ip6_nbr_stats_reply>>()
{
  return ::vapi_msg_id_want_ip6_nbr_stats_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_want_ip6_nbr_stats_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_want_ip6_nbr_stats_reply>(vapi_msg_id_want_ip6_nbr_stats_reply);
}

template class Msg<vapi_msg_want_ip6_nbr_stats_reply>;

using Want_ip6_nbr_stats_reply = Msg<vapi_msg_want_ip6_nbr_stats_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_want_ip6_fib_stats>(vapi_msg_want_ip6_fib_stats *msg)
{
  vapi_msg_want_ip6_fib_stats_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_want_ip6_fib_stats>(vapi_msg_want_ip6_fib_stats *msg)
{
  vapi_msg_want_ip6_fib_stats_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_want_ip6_fib_stats>()
{
  return ::vapi_msg_id_want_ip6_fib_stats; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_want_ip6_fib_stats>>()
{
  return ::vapi_msg_id_want_ip6_fib_stats; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_want_ip6_fib_stats()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_want_ip6_fib_stats>(vapi_msg_id_want_ip6_fib_stats);
}

template <> inline vapi_msg_want_ip6_fib_stats* vapi_alloc<vapi_msg_want_ip6_fib_stats>(Connection &con)
{
  vapi_msg_want_ip6_fib_stats* result = vapi_alloc_want_ip6_fib_stats(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_want_ip6_fib_stats>;

template class Request<vapi_msg_want_ip6_fib_stats, vapi_msg_want_ip6_fib_stats_reply>;

using Want_ip6_fib_stats = Request<vapi_msg_want_ip6_fib_stats, vapi_msg_want_ip6_fib_stats_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_want_interface_simple_stats_reply>(vapi_msg_want_interface_simple_stats_reply *msg)
{
  vapi_msg_want_interface_simple_stats_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_want_interface_simple_stats_reply>(vapi_msg_want_interface_simple_stats_reply *msg)
{
  vapi_msg_want_interface_simple_stats_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_want_interface_simple_stats_reply>()
{
  return ::vapi_msg_id_want_interface_simple_stats_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_want_interface_simple_stats_reply>>()
{
  return ::vapi_msg_id_want_interface_simple_stats_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_want_interface_simple_stats_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_want_interface_simple_stats_reply>(vapi_msg_id_want_interface_simple_stats_reply);
}

template class Msg<vapi_msg_want_interface_simple_stats_reply>;

using Want_interface_simple_stats_reply = Msg<vapi_msg_want_interface_simple_stats_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_want_stats>(vapi_msg_want_stats *msg)
{
  vapi_msg_want_stats_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_want_stats>(vapi_msg_want_stats *msg)
{
  vapi_msg_want_stats_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_want_stats>()
{
  return ::vapi_msg_id_want_stats; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_want_stats>>()
{
  return ::vapi_msg_id_want_stats; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_want_stats()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_want_stats>(vapi_msg_id_want_stats);
}

template <> inline vapi_msg_want_stats* vapi_alloc<vapi_msg_want_stats>(Connection &con)
{
  vapi_msg_want_stats* result = vapi_alloc_want_stats(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_want_stats>;

template class Request<vapi_msg_want_stats, vapi_msg_want_stats_reply>;

using Want_stats = Request<vapi_msg_want_stats, vapi_msg_want_stats_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_want_interface_simple_stats>(vapi_msg_want_interface_simple_stats *msg)
{
  vapi_msg_want_interface_simple_stats_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_want_interface_simple_stats>(vapi_msg_want_interface_simple_stats *msg)
{
  vapi_msg_want_interface_simple_stats_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_want_interface_simple_stats>()
{
  return ::vapi_msg_id_want_interface_simple_stats; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_want_interface_simple_stats>>()
{
  return ::vapi_msg_id_want_interface_simple_stats; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_want_interface_simple_stats()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_want_interface_simple_stats>(vapi_msg_id_want_interface_simple_stats);
}

template <> inline vapi_msg_want_interface_simple_stats* vapi_alloc<vapi_msg_want_interface_simple_stats>(Connection &con)
{
  vapi_msg_want_interface_simple_stats* result = vapi_alloc_want_interface_simple_stats(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_want_interface_simple_stats>;

template class Request<vapi_msg_want_interface_simple_stats, vapi_msg_want_interface_simple_stats_reply>;

using Want_interface_simple_stats = Request<vapi_msg_want_interface_simple_stats, vapi_msg_want_interface_simple_stats_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_want_per_interface_combined_stats>(vapi_msg_want_per_interface_combined_stats *msg)
{
  vapi_msg_want_per_interface_combined_stats_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_want_per_interface_combined_stats>(vapi_msg_want_per_interface_combined_stats *msg)
{
  vapi_msg_want_per_interface_combined_stats_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_want_per_interface_combined_stats>()
{
  return ::vapi_msg_id_want_per_interface_combined_stats; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_want_per_interface_combined_stats>>()
{
  return ::vapi_msg_id_want_per_interface_combined_stats; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_want_per_interface_combined_stats()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_want_per_interface_combined_stats>(vapi_msg_id_want_per_interface_combined_stats);
}

template <> inline vapi_msg_want_per_interface_combined_stats* vapi_alloc<vapi_msg_want_per_interface_combined_stats, size_t>(Connection &con, size_t sw_ifs_array_size)
{
  vapi_msg_want_per_interface_combined_stats* result = vapi_alloc_want_per_interface_combined_stats(con.vapi_ctx, sw_ifs_array_size);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_want_per_interface_combined_stats>;

template class Request<vapi_msg_want_per_interface_combined_stats, vapi_msg_want_per_interface_combined_stats_reply, size_t>;

using Want_per_interface_combined_stats = Request<vapi_msg_want_per_interface_combined_stats, vapi_msg_want_per_interface_combined_stats_reply, size_t>;

template <> inline void vapi_swap_to_be<vapi_msg_want_stats_reply>(vapi_msg_want_stats_reply *msg)
{
  vapi_msg_want_stats_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_want_stats_reply>(vapi_msg_want_stats_reply *msg)
{
  vapi_msg_want_stats_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_want_stats_reply>()
{
  return ::vapi_msg_id_want_stats_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_want_stats_reply>>()
{
  return ::vapi_msg_id_want_stats_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_want_stats_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_want_stats_reply>(vapi_msg_id_want_stats_reply);
}

template class Msg<vapi_msg_want_stats_reply>;

using Want_stats_reply = Msg<vapi_msg_want_stats_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_vnet_ip4_nbr_counters>(vapi_msg_vnet_ip4_nbr_counters *msg)
{
  vapi_msg_vnet_ip4_nbr_counters_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_vnet_ip4_nbr_counters>(vapi_msg_vnet_ip4_nbr_counters *msg)
{
  vapi_msg_vnet_ip4_nbr_counters_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_vnet_ip4_nbr_counters>()
{
  return ::vapi_msg_id_vnet_ip4_nbr_counters; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_vnet_ip4_nbr_counters>>()
{
  return ::vapi_msg_id_vnet_ip4_nbr_counters; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_vnet_ip4_nbr_counters()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_vnet_ip4_nbr_counters>(vapi_msg_id_vnet_ip4_nbr_counters);
}

template class Msg<vapi_msg_vnet_ip4_nbr_counters>;

using Vnet_ip4_nbr_counters = Msg<vapi_msg_vnet_ip4_nbr_counters>;
template <> inline void vapi_swap_to_be<vapi_msg_vnet_ip4_fib_counters>(vapi_msg_vnet_ip4_fib_counters *msg)
{
  vapi_msg_vnet_ip4_fib_counters_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_vnet_ip4_fib_counters>(vapi_msg_vnet_ip4_fib_counters *msg)
{
  vapi_msg_vnet_ip4_fib_counters_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_vnet_ip4_fib_counters>()
{
  return ::vapi_msg_id_vnet_ip4_fib_counters; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_vnet_ip4_fib_counters>>()
{
  return ::vapi_msg_id_vnet_ip4_fib_counters; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_vnet_ip4_fib_counters()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_vnet_ip4_fib_counters>(vapi_msg_id_vnet_ip4_fib_counters);
}

template class Msg<vapi_msg_vnet_ip4_fib_counters>;

using Vnet_ip4_fib_counters = Msg<vapi_msg_vnet_ip4_fib_counters>;
template <> inline void vapi_swap_to_be<vapi_msg_want_per_interface_combined_stats_reply>(vapi_msg_want_per_interface_combined_stats_reply *msg)
{
  vapi_msg_want_per_interface_combined_stats_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_want_per_interface_combined_stats_reply>(vapi_msg_want_per_interface_combined_stats_reply *msg)
{
  vapi_msg_want_per_interface_combined_stats_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_want_per_interface_combined_stats_reply>()
{
  return ::vapi_msg_id_want_per_interface_combined_stats_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_want_per_interface_combined_stats_reply>>()
{
  return ::vapi_msg_id_want_per_interface_combined_stats_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_want_per_interface_combined_stats_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_want_per_interface_combined_stats_reply>(vapi_msg_id_want_per_interface_combined_stats_reply);
}

template class Msg<vapi_msg_want_per_interface_combined_stats_reply>;

using Want_per_interface_combined_stats_reply = Msg<vapi_msg_want_per_interface_combined_stats_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_want_per_interface_simple_stats>(vapi_msg_want_per_interface_simple_stats *msg)
{
  vapi_msg_want_per_interface_simple_stats_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_want_per_interface_simple_stats>(vapi_msg_want_per_interface_simple_stats *msg)
{
  vapi_msg_want_per_interface_simple_stats_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_want_per_interface_simple_stats>()
{
  return ::vapi_msg_id_want_per_interface_simple_stats; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_want_per_interface_simple_stats>>()
{
  return ::vapi_msg_id_want_per_interface_simple_stats; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_want_per_interface_simple_stats()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_want_per_interface_simple_stats>(vapi_msg_id_want_per_interface_simple_stats);
}

template <> inline vapi_msg_want_per_interface_simple_stats* vapi_alloc<vapi_msg_want_per_interface_simple_stats, size_t>(Connection &con, size_t sw_ifs_array_size)
{
  vapi_msg_want_per_interface_simple_stats* result = vapi_alloc_want_per_interface_simple_stats(con.vapi_ctx, sw_ifs_array_size);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_want_per_interface_simple_stats>;

template class Request<vapi_msg_want_per_interface_simple_stats, vapi_msg_want_per_interface_simple_stats_reply, size_t>;

using Want_per_interface_simple_stats = Request<vapi_msg_want_per_interface_simple_stats, vapi_msg_want_per_interface_simple_stats_reply, size_t>;

template <> inline void vapi_swap_to_be<vapi_msg_want_ip4_nbr_stats>(vapi_msg_want_ip4_nbr_stats *msg)
{
  vapi_msg_want_ip4_nbr_stats_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_want_ip4_nbr_stats>(vapi_msg_want_ip4_nbr_stats *msg)
{
  vapi_msg_want_ip4_nbr_stats_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_want_ip4_nbr_stats>()
{
  return ::vapi_msg_id_want_ip4_nbr_stats; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_want_ip4_nbr_stats>>()
{
  return ::vapi_msg_id_want_ip4_nbr_stats; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_want_ip4_nbr_stats()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_want_ip4_nbr_stats>(vapi_msg_id_want_ip4_nbr_stats);
}

template <> inline vapi_msg_want_ip4_nbr_stats* vapi_alloc<vapi_msg_want_ip4_nbr_stats>(Connection &con)
{
  vapi_msg_want_ip4_nbr_stats* result = vapi_alloc_want_ip4_nbr_stats(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_want_ip4_nbr_stats>;

template class Request<vapi_msg_want_ip4_nbr_stats, vapi_msg_want_ip4_nbr_stats_reply>;

using Want_ip4_nbr_stats = Request<vapi_msg_want_ip4_nbr_stats, vapi_msg_want_ip4_nbr_stats_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_vnet_ip6_nbr_counters>(vapi_msg_vnet_ip6_nbr_counters *msg)
{
  vapi_msg_vnet_ip6_nbr_counters_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_vnet_ip6_nbr_counters>(vapi_msg_vnet_ip6_nbr_counters *msg)
{
  vapi_msg_vnet_ip6_nbr_counters_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_vnet_ip6_nbr_counters>()
{
  return ::vapi_msg_id_vnet_ip6_nbr_counters; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_vnet_ip6_nbr_counters>>()
{
  return ::vapi_msg_id_vnet_ip6_nbr_counters; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_vnet_ip6_nbr_counters()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_vnet_ip6_nbr_counters>(vapi_msg_id_vnet_ip6_nbr_counters);
}

template class Msg<vapi_msg_vnet_ip6_nbr_counters>;

using Vnet_ip6_nbr_counters = Msg<vapi_msg_vnet_ip6_nbr_counters>;
template <> inline void vapi_swap_to_be<vapi_msg_want_ip4_fib_stats_reply>(vapi_msg_want_ip4_fib_stats_reply *msg)
{
  vapi_msg_want_ip4_fib_stats_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_want_ip4_fib_stats_reply>(vapi_msg_want_ip4_fib_stats_reply *msg)
{
  vapi_msg_want_ip4_fib_stats_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_want_ip4_fib_stats_reply>()
{
  return ::vapi_msg_id_want_ip4_fib_stats_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_want_ip4_fib_stats_reply>>()
{
  return ::vapi_msg_id_want_ip4_fib_stats_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_want_ip4_fib_stats_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_want_ip4_fib_stats_reply>(vapi_msg_id_want_ip4_fib_stats_reply);
}

template class Msg<vapi_msg_want_ip4_fib_stats_reply>;

using Want_ip4_fib_stats_reply = Msg<vapi_msg_want_ip4_fib_stats_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_want_ip6_fib_stats_reply>(vapi_msg_want_ip6_fib_stats_reply *msg)
{
  vapi_msg_want_ip6_fib_stats_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_want_ip6_fib_stats_reply>(vapi_msg_want_ip6_fib_stats_reply *msg)
{
  vapi_msg_want_ip6_fib_stats_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_want_ip6_fib_stats_reply>()
{
  return ::vapi_msg_id_want_ip6_fib_stats_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_want_ip6_fib_stats_reply>>()
{
  return ::vapi_msg_id_want_ip6_fib_stats_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_want_ip6_fib_stats_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_want_ip6_fib_stats_reply>(vapi_msg_id_want_ip6_fib_stats_reply);
}

template class Msg<vapi_msg_want_ip6_fib_stats_reply>;

using Want_ip6_fib_stats_reply = Msg<vapi_msg_want_ip6_fib_stats_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_vnet_ip6_fib_counters>(vapi_msg_vnet_ip6_fib_counters *msg)
{
  vapi_msg_vnet_ip6_fib_counters_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_vnet_ip6_fib_counters>(vapi_msg_vnet_ip6_fib_counters *msg)
{
  vapi_msg_vnet_ip6_fib_counters_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_vnet_ip6_fib_counters>()
{
  return ::vapi_msg_id_vnet_ip6_fib_counters; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_vnet_ip6_fib_counters>>()
{
  return ::vapi_msg_id_vnet_ip6_fib_counters; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_vnet_ip6_fib_counters()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_vnet_ip6_fib_counters>(vapi_msg_id_vnet_ip6_fib_counters);
}

template class Msg<vapi_msg_vnet_ip6_fib_counters>;

using Vnet_ip6_fib_counters = Msg<vapi_msg_vnet_ip6_fib_counters>;
template <> inline void vapi_swap_to_be<vapi_msg_want_per_interface_simple_stats_reply>(vapi_msg_want_per_interface_simple_stats_reply *msg)
{
  vapi_msg_want_per_interface_simple_stats_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_want_per_interface_simple_stats_reply>(vapi_msg_want_per_interface_simple_stats_reply *msg)
{
  vapi_msg_want_per_interface_simple_stats_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_want_per_interface_simple_stats_reply>()
{
  return ::vapi_msg_id_want_per_interface_simple_stats_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_want_per_interface_simple_stats_reply>>()
{
  return ::vapi_msg_id_want_per_interface_simple_stats_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_want_per_interface_simple_stats_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_want_per_interface_simple_stats_reply>(vapi_msg_id_want_per_interface_simple_stats_reply);
}

template class Msg<vapi_msg_want_per_interface_simple_stats_reply>;

using Want_per_interface_simple_stats_reply = Msg<vapi_msg_want_per_interface_simple_stats_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_want_ip6_nbr_stats>(vapi_msg_want_ip6_nbr_stats *msg)
{
  vapi_msg_want_ip6_nbr_stats_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_want_ip6_nbr_stats>(vapi_msg_want_ip6_nbr_stats *msg)
{
  vapi_msg_want_ip6_nbr_stats_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_want_ip6_nbr_stats>()
{
  return ::vapi_msg_id_want_ip6_nbr_stats; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_want_ip6_nbr_stats>>()
{
  return ::vapi_msg_id_want_ip6_nbr_stats; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_want_ip6_nbr_stats()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_want_ip6_nbr_stats>(vapi_msg_id_want_ip6_nbr_stats);
}

template <> inline vapi_msg_want_ip6_nbr_stats* vapi_alloc<vapi_msg_want_ip6_nbr_stats>(Connection &con)
{
  vapi_msg_want_ip6_nbr_stats* result = vapi_alloc_want_ip6_nbr_stats(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_want_ip6_nbr_stats>;

template class Request<vapi_msg_want_ip6_nbr_stats, vapi_msg_want_ip6_nbr_stats_reply>;

using Want_ip6_nbr_stats = Request<vapi_msg_want_ip6_nbr_stats, vapi_msg_want_ip6_nbr_stats_reply>;

}
#endif
