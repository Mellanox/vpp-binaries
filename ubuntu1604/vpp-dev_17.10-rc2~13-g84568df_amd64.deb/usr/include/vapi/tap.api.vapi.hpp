#ifndef __included_hpp_tap_api_json
#define __included_hpp_tap_api_json

#include <vapi/vapi.hpp>
#include <vapi/tap.api.vapi.h>

namespace vapi {

template <> inline void vapi_swap_to_be<vapi_msg_tap_connect_reply>(vapi_msg_tap_connect_reply *msg)
{
  vapi_msg_tap_connect_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_tap_connect_reply>(vapi_msg_tap_connect_reply *msg)
{
  vapi_msg_tap_connect_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_tap_connect_reply>()
{
  return ::vapi_msg_id_tap_connect_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_tap_connect_reply>>()
{
  return ::vapi_msg_id_tap_connect_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_tap_connect_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_tap_connect_reply>(vapi_msg_id_tap_connect_reply);
}

template class Msg<vapi_msg_tap_connect_reply>;

using Tap_connect_reply = Msg<vapi_msg_tap_connect_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_tap_modify_reply>(vapi_msg_tap_modify_reply *msg)
{
  vapi_msg_tap_modify_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_tap_modify_reply>(vapi_msg_tap_modify_reply *msg)
{
  vapi_msg_tap_modify_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_tap_modify_reply>()
{
  return ::vapi_msg_id_tap_modify_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_tap_modify_reply>>()
{
  return ::vapi_msg_id_tap_modify_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_tap_modify_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_tap_modify_reply>(vapi_msg_id_tap_modify_reply);
}

template class Msg<vapi_msg_tap_modify_reply>;

using Tap_modify_reply = Msg<vapi_msg_tap_modify_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_tap_dump>(vapi_msg_sw_interface_tap_dump *msg)
{
  vapi_msg_sw_interface_tap_dump_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_tap_dump>(vapi_msg_sw_interface_tap_dump *msg)
{
  vapi_msg_sw_interface_tap_dump_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_tap_dump>()
{
  return ::vapi_msg_id_sw_interface_tap_dump; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_tap_dump>>()
{
  return ::vapi_msg_id_sw_interface_tap_dump; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_tap_dump()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_tap_dump>(vapi_msg_id_sw_interface_tap_dump);
}

template <> inline vapi_msg_sw_interface_tap_dump* vapi_alloc<vapi_msg_sw_interface_tap_dump>(Connection &con)
{
  vapi_msg_sw_interface_tap_dump* result = vapi_alloc_sw_interface_tap_dump(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sw_interface_tap_dump>;

template class Dump<vapi_msg_sw_interface_tap_dump, vapi_msg_sw_interface_tap_details>;

using Sw_interface_tap_dump = Dump<vapi_msg_sw_interface_tap_dump, vapi_msg_sw_interface_tap_details>;

template <> inline void vapi_swap_to_be<vapi_msg_tap_connect>(vapi_msg_tap_connect *msg)
{
  vapi_msg_tap_connect_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_tap_connect>(vapi_msg_tap_connect *msg)
{
  vapi_msg_tap_connect_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_tap_connect>()
{
  return ::vapi_msg_id_tap_connect; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_tap_connect>>()
{
  return ::vapi_msg_id_tap_connect; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_tap_connect()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_tap_connect>(vapi_msg_id_tap_connect);
}

template <> inline vapi_msg_tap_connect* vapi_alloc<vapi_msg_tap_connect>(Connection &con)
{
  vapi_msg_tap_connect* result = vapi_alloc_tap_connect(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_tap_connect>;

template class Request<vapi_msg_tap_connect, vapi_msg_tap_connect_reply>;

using Tap_connect = Request<vapi_msg_tap_connect, vapi_msg_tap_connect_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_tap_modify>(vapi_msg_tap_modify *msg)
{
  vapi_msg_tap_modify_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_tap_modify>(vapi_msg_tap_modify *msg)
{
  vapi_msg_tap_modify_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_tap_modify>()
{
  return ::vapi_msg_id_tap_modify; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_tap_modify>>()
{
  return ::vapi_msg_id_tap_modify; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_tap_modify()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_tap_modify>(vapi_msg_id_tap_modify);
}

template <> inline vapi_msg_tap_modify* vapi_alloc<vapi_msg_tap_modify>(Connection &con)
{
  vapi_msg_tap_modify* result = vapi_alloc_tap_modify(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_tap_modify>;

template class Request<vapi_msg_tap_modify, vapi_msg_tap_modify_reply>;

using Tap_modify = Request<vapi_msg_tap_modify, vapi_msg_tap_modify_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_tap_delete>(vapi_msg_tap_delete *msg)
{
  vapi_msg_tap_delete_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_tap_delete>(vapi_msg_tap_delete *msg)
{
  vapi_msg_tap_delete_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_tap_delete>()
{
  return ::vapi_msg_id_tap_delete; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_tap_delete>>()
{
  return ::vapi_msg_id_tap_delete; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_tap_delete()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_tap_delete>(vapi_msg_id_tap_delete);
}

template <> inline vapi_msg_tap_delete* vapi_alloc<vapi_msg_tap_delete>(Connection &con)
{
  vapi_msg_tap_delete* result = vapi_alloc_tap_delete(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_tap_delete>;

template class Request<vapi_msg_tap_delete, vapi_msg_tap_delete_reply>;

using Tap_delete = Request<vapi_msg_tap_delete, vapi_msg_tap_delete_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_tap_delete_reply>(vapi_msg_tap_delete_reply *msg)
{
  vapi_msg_tap_delete_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_tap_delete_reply>(vapi_msg_tap_delete_reply *msg)
{
  vapi_msg_tap_delete_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_tap_delete_reply>()
{
  return ::vapi_msg_id_tap_delete_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_tap_delete_reply>>()
{
  return ::vapi_msg_id_tap_delete_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_tap_delete_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_tap_delete_reply>(vapi_msg_id_tap_delete_reply);
}

template class Msg<vapi_msg_tap_delete_reply>;

using Tap_delete_reply = Msg<vapi_msg_tap_delete_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_tap_details>(vapi_msg_sw_interface_tap_details *msg)
{
  vapi_msg_sw_interface_tap_details_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_tap_details>(vapi_msg_sw_interface_tap_details *msg)
{
  vapi_msg_sw_interface_tap_details_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_tap_details>()
{
  return ::vapi_msg_id_sw_interface_tap_details; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_tap_details>>()
{
  return ::vapi_msg_id_sw_interface_tap_details; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_tap_details()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_tap_details>(vapi_msg_id_sw_interface_tap_details);
}

template class Msg<vapi_msg_sw_interface_tap_details>;

using Sw_interface_tap_details = Msg<vapi_msg_sw_interface_tap_details>;
}
#endif
