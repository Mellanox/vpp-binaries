#ifndef __included_vpe_api_json
#define __included_vpe_api_json

#include <stdlib.h>
#include <stddef.h>
#include <arpa/inet.h>
#include <vapi/vapi_internal.h>
#include <vapi/vapi.h>
#include <vapi/vapi_dbg.h>

#ifdef __cplusplus
extern "C" {
#endif

static inline vapi_error_e vapi_send_with_control_ping (vapi_ctx_t ctx, void * msg, u32 context);

extern vapi_msg_id_t vapi_msg_id_delete_subif_reply;
extern vapi_msg_id_t vapi_msg_id_ip6_nd_event;
extern vapi_msg_id_t vapi_msg_id_pg_create_interface_reply;
extern vapi_msg_id_t vapi_msg_id_pg_capture_reply;
extern vapi_msg_id_t vapi_msg_id_sw_interface_set_vpath_reply;
extern vapi_msg_id_t vapi_msg_id_get_node_index_reply;
extern vapi_msg_id_t vapi_msg_id_interface_name_renumber_reply;
extern vapi_msg_id_t vapi_msg_id_cli;
extern vapi_msg_id_t vapi_msg_id_ip4_arp_event;
extern vapi_msg_id_t vapi_msg_id_oam_add_del_reply;
extern vapi_msg_id_t vapi_msg_id_ip_source_and_port_range_check_add_del;
extern vapi_msg_id_t vapi_msg_id_get_node_index;
extern vapi_msg_id_t vapi_msg_id_l2_interface_efp_filter;
extern vapi_msg_id_t vapi_msg_id_l2_interface_efp_filter_reply;
extern vapi_msg_id_t vapi_msg_id_proxy_arp_intfc_enable_disable;
extern vapi_msg_id_t vapi_msg_id_feature_enable_disable;
extern vapi_msg_id_t vapi_msg_id_proxy_arp_add_del;
extern vapi_msg_id_t vapi_msg_id_ioam_disable_reply;
extern vapi_msg_id_t vapi_msg_id_classify_set_interface_ip_table;
extern vapi_msg_id_t vapi_msg_id_ioam_enable;
extern vapi_msg_id_t vapi_msg_id_get_next_index;
extern vapi_msg_id_t vapi_msg_id_sw_interface_set_vpath;
extern vapi_msg_id_t vapi_msg_id_punt_socket_deregister_reply;
extern vapi_msg_id_t vapi_msg_id_sw_interface_set_l2_xconnect;
extern vapi_msg_id_t vapi_msg_id_bd_ip_mac_add_del_reply;
extern vapi_msg_id_t vapi_msg_id_reset_fib_reply;
extern vapi_msg_id_t vapi_msg_id_want_ip6_nd_events_reply;
extern vapi_msg_id_t vapi_msg_id_l2_patch_add_del_reply;
extern vapi_msg_id_t vapi_msg_id_set_arp_neighbor_limit;
extern vapi_msg_id_t vapi_msg_id_add_node_next;
extern vapi_msg_id_t vapi_msg_id_get_next_index_reply;
extern vapi_msg_id_t vapi_msg_id_sw_interface_set_mpls_enable_reply;
extern vapi_msg_id_t vapi_msg_id_show_version_reply;
extern vapi_msg_id_t vapi_msg_id_want_ip4_arp_events;
extern vapi_msg_id_t vapi_msg_id_ip_source_and_port_range_check_interface_add_del_reply;
extern vapi_msg_id_t vapi_msg_id_punt_socket_register_reply;
extern vapi_msg_id_t vapi_msg_id_create_loopback_instance_reply;
extern vapi_msg_id_t vapi_msg_id_delete_loopback_reply;
extern vapi_msg_id_t vapi_msg_id_classify_set_interface_l2_tables_reply;
extern vapi_msg_id_t vapi_msg_id_pg_capture;
extern vapi_msg_id_t vapi_msg_id_create_vlan_subif;
extern vapi_msg_id_t vapi_msg_id_get_node_graph_reply;
extern vapi_msg_id_t vapi_msg_id_sw_interface_set_l2_bridge;
extern vapi_msg_id_t vapi_msg_id_punt;
extern vapi_msg_id_t vapi_msg_id_delete_loopback;
extern vapi_msg_id_t vapi_msg_id_pg_create_interface;
extern vapi_msg_id_t vapi_msg_id_ioam_enable_reply;
extern vapi_msg_id_t vapi_msg_id_create_subif;
extern vapi_msg_id_t vapi_msg_id_cli_inband;
extern vapi_msg_id_t vapi_msg_id_want_ip4_arp_events_reply;
extern vapi_msg_id_t vapi_msg_id_delete_subif;
extern vapi_msg_id_t vapi_msg_id_reset_vrf_reply;
extern vapi_msg_id_t vapi_msg_id_feature_enable_disable_reply;
extern vapi_msg_id_t vapi_msg_id_create_subif_reply;
extern vapi_msg_id_t vapi_msg_id_punt_socket_register;
extern vapi_msg_id_t vapi_msg_id_want_oam_events_reply;
extern vapi_msg_id_t vapi_msg_id_want_oam_events;
extern vapi_msg_id_t vapi_msg_id_ip_source_and_port_range_check_add_del_reply;
extern vapi_msg_id_t vapi_msg_id_classify_set_interface_ip_table_reply;
extern vapi_msg_id_t vapi_msg_id_create_loopback_instance;
extern vapi_msg_id_t vapi_msg_id_sw_interface_set_l2_xconnect_reply;
extern vapi_msg_id_t vapi_msg_id_cli_inband_reply;
extern vapi_msg_id_t vapi_msg_id_input_acl_set_interface;
extern vapi_msg_id_t vapi_msg_id_ioam_disable;
extern vapi_msg_id_t vapi_msg_id_proxy_arp_add_del_reply;
extern vapi_msg_id_t vapi_msg_id_create_vlan_subif_reply;
extern vapi_msg_id_t vapi_msg_id_reset_fib;
extern vapi_msg_id_t vapi_msg_id_pg_enable_disable;
extern vapi_msg_id_t vapi_msg_id_want_ip6_nd_events;
extern vapi_msg_id_t vapi_msg_id_l2_patch_add_del;
extern vapi_msg_id_t vapi_msg_id_cli_reply;
extern vapi_msg_id_t vapi_msg_id_proxy_arp_intfc_enable_disable_reply;
extern vapi_msg_id_t vapi_msg_id_control_ping_reply;
extern vapi_msg_id_t vapi_msg_id_oam_event;
extern vapi_msg_id_t vapi_msg_id_show_version;
extern vapi_msg_id_t vapi_msg_id_classify_set_interface_l2_tables;
extern vapi_msg_id_t vapi_msg_id_reset_vrf;
extern vapi_msg_id_t vapi_msg_id_input_acl_set_interface_reply;
extern vapi_msg_id_t vapi_msg_id_bd_ip_mac_add_del;
extern vapi_msg_id_t vapi_msg_id_sw_interface_set_l2_bridge_reply;
extern vapi_msg_id_t vapi_msg_id_oam_add_del;
extern vapi_msg_id_t vapi_msg_id_get_node_graph;
extern vapi_msg_id_t vapi_msg_id_interface_name_renumber;
extern vapi_msg_id_t vapi_msg_id_pg_enable_disable_reply;
extern vapi_msg_id_t vapi_msg_id_create_loopback;
extern vapi_msg_id_t vapi_msg_id_create_loopback_reply;
extern vapi_msg_id_t vapi_msg_id_set_arp_neighbor_limit_reply;
extern vapi_msg_id_t vapi_msg_id_add_node_next_reply;
extern vapi_msg_id_t vapi_msg_id_sw_interface_set_mpls_enable;
extern vapi_msg_id_t vapi_msg_id_punt_socket_deregister;
extern vapi_msg_id_t vapi_msg_id_ip_source_and_port_range_check_interface_add_del;
extern vapi_msg_id_t vapi_msg_id_punt_reply;
extern vapi_msg_id_t vapi_msg_id_control_ping;

#define DEFINE_VAPI_MSG_IDS_VPE_API_JSON\
  vapi_msg_id_t vapi_msg_id_delete_subif_reply;\
  vapi_msg_id_t vapi_msg_id_ip6_nd_event;\
  vapi_msg_id_t vapi_msg_id_pg_create_interface_reply;\
  vapi_msg_id_t vapi_msg_id_pg_capture_reply;\
  vapi_msg_id_t vapi_msg_id_sw_interface_set_vpath_reply;\
  vapi_msg_id_t vapi_msg_id_get_node_index_reply;\
  vapi_msg_id_t vapi_msg_id_interface_name_renumber_reply;\
  vapi_msg_id_t vapi_msg_id_cli;\
  vapi_msg_id_t vapi_msg_id_ip4_arp_event;\
  vapi_msg_id_t vapi_msg_id_oam_add_del_reply;\
  vapi_msg_id_t vapi_msg_id_ip_source_and_port_range_check_add_del;\
  vapi_msg_id_t vapi_msg_id_get_node_index;\
  vapi_msg_id_t vapi_msg_id_l2_interface_efp_filter;\
  vapi_msg_id_t vapi_msg_id_l2_interface_efp_filter_reply;\
  vapi_msg_id_t vapi_msg_id_proxy_arp_intfc_enable_disable;\
  vapi_msg_id_t vapi_msg_id_feature_enable_disable;\
  vapi_msg_id_t vapi_msg_id_proxy_arp_add_del;\
  vapi_msg_id_t vapi_msg_id_ioam_disable_reply;\
  vapi_msg_id_t vapi_msg_id_classify_set_interface_ip_table;\
  vapi_msg_id_t vapi_msg_id_ioam_enable;\
  vapi_msg_id_t vapi_msg_id_get_next_index;\
  vapi_msg_id_t vapi_msg_id_sw_interface_set_vpath;\
  vapi_msg_id_t vapi_msg_id_punt_socket_deregister_reply;\
  vapi_msg_id_t vapi_msg_id_sw_interface_set_l2_xconnect;\
  vapi_msg_id_t vapi_msg_id_bd_ip_mac_add_del_reply;\
  vapi_msg_id_t vapi_msg_id_reset_fib_reply;\
  vapi_msg_id_t vapi_msg_id_want_ip6_nd_events_reply;\
  vapi_msg_id_t vapi_msg_id_l2_patch_add_del_reply;\
  vapi_msg_id_t vapi_msg_id_set_arp_neighbor_limit;\
  vapi_msg_id_t vapi_msg_id_add_node_next;\
  vapi_msg_id_t vapi_msg_id_get_next_index_reply;\
  vapi_msg_id_t vapi_msg_id_sw_interface_set_mpls_enable_reply;\
  vapi_msg_id_t vapi_msg_id_show_version_reply;\
  vapi_msg_id_t vapi_msg_id_want_ip4_arp_events;\
  vapi_msg_id_t vapi_msg_id_ip_source_and_port_range_check_interface_add_del_reply;\
  vapi_msg_id_t vapi_msg_id_punt_socket_register_reply;\
  vapi_msg_id_t vapi_msg_id_create_loopback_instance_reply;\
  vapi_msg_id_t vapi_msg_id_delete_loopback_reply;\
  vapi_msg_id_t vapi_msg_id_classify_set_interface_l2_tables_reply;\
  vapi_msg_id_t vapi_msg_id_pg_capture;\
  vapi_msg_id_t vapi_msg_id_create_vlan_subif;\
  vapi_msg_id_t vapi_msg_id_get_node_graph_reply;\
  vapi_msg_id_t vapi_msg_id_sw_interface_set_l2_bridge;\
  vapi_msg_id_t vapi_msg_id_punt;\
  vapi_msg_id_t vapi_msg_id_delete_loopback;\
  vapi_msg_id_t vapi_msg_id_pg_create_interface;\
  vapi_msg_id_t vapi_msg_id_ioam_enable_reply;\
  vapi_msg_id_t vapi_msg_id_create_subif;\
  vapi_msg_id_t vapi_msg_id_cli_inband;\
  vapi_msg_id_t vapi_msg_id_want_ip4_arp_events_reply;\
  vapi_msg_id_t vapi_msg_id_delete_subif;\
  vapi_msg_id_t vapi_msg_id_reset_vrf_reply;\
  vapi_msg_id_t vapi_msg_id_feature_enable_disable_reply;\
  vapi_msg_id_t vapi_msg_id_create_subif_reply;\
  vapi_msg_id_t vapi_msg_id_punt_socket_register;\
  vapi_msg_id_t vapi_msg_id_want_oam_events_reply;\
  vapi_msg_id_t vapi_msg_id_want_oam_events;\
  vapi_msg_id_t vapi_msg_id_ip_source_and_port_range_check_add_del_reply;\
  vapi_msg_id_t vapi_msg_id_classify_set_interface_ip_table_reply;\
  vapi_msg_id_t vapi_msg_id_create_loopback_instance;\
  vapi_msg_id_t vapi_msg_id_sw_interface_set_l2_xconnect_reply;\
  vapi_msg_id_t vapi_msg_id_cli_inband_reply;\
  vapi_msg_id_t vapi_msg_id_input_acl_set_interface;\
  vapi_msg_id_t vapi_msg_id_ioam_disable;\
  vapi_msg_id_t vapi_msg_id_proxy_arp_add_del_reply;\
  vapi_msg_id_t vapi_msg_id_create_vlan_subif_reply;\
  vapi_msg_id_t vapi_msg_id_reset_fib;\
  vapi_msg_id_t vapi_msg_id_pg_enable_disable;\
  vapi_msg_id_t vapi_msg_id_want_ip6_nd_events;\
  vapi_msg_id_t vapi_msg_id_l2_patch_add_del;\
  vapi_msg_id_t vapi_msg_id_cli_reply;\
  vapi_msg_id_t vapi_msg_id_proxy_arp_intfc_enable_disable_reply;\
  vapi_msg_id_t vapi_msg_id_control_ping_reply;\
  vapi_msg_id_t vapi_msg_id_oam_event;\
  vapi_msg_id_t vapi_msg_id_show_version;\
  vapi_msg_id_t vapi_msg_id_classify_set_interface_l2_tables;\
  vapi_msg_id_t vapi_msg_id_reset_vrf;\
  vapi_msg_id_t vapi_msg_id_input_acl_set_interface_reply;\
  vapi_msg_id_t vapi_msg_id_bd_ip_mac_add_del;\
  vapi_msg_id_t vapi_msg_id_sw_interface_set_l2_bridge_reply;\
  vapi_msg_id_t vapi_msg_id_oam_add_del;\
  vapi_msg_id_t vapi_msg_id_get_node_graph;\
  vapi_msg_id_t vapi_msg_id_interface_name_renumber;\
  vapi_msg_id_t vapi_msg_id_pg_enable_disable_reply;\
  vapi_msg_id_t vapi_msg_id_create_loopback;\
  vapi_msg_id_t vapi_msg_id_create_loopback_reply;\
  vapi_msg_id_t vapi_msg_id_set_arp_neighbor_limit_reply;\
  vapi_msg_id_t vapi_msg_id_add_node_next_reply;\
  vapi_msg_id_t vapi_msg_id_sw_interface_set_mpls_enable;\
  vapi_msg_id_t vapi_msg_id_punt_socket_deregister;\
  vapi_msg_id_t vapi_msg_id_ip_source_and_port_range_check_interface_add_del;\
  vapi_msg_id_t vapi_msg_id_punt_reply;\
  vapi_msg_id_t vapi_msg_id_control_ping;


typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_delete_subif_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_delete_subif_reply payload;
} vapi_msg_delete_subif_reply;

typedef struct __attribute__ ((__packed__)) {
  u16 _vl_msg_id;
  u32 client_index;
  u32 pid;
  u32 sw_if_index;
  u8 address[16];
  u8 new_mac[6];
  u8 mac_ip; 
} vapi_payload_ip6_nd_event;

typedef struct __attribute__ ((__packed__)) {

  vapi_payload_ip6_nd_event payload;
} vapi_msg_ip6_nd_event;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u32 sw_if_index; 
} vapi_payload_pg_create_interface_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_pg_create_interface_reply payload;
} vapi_msg_pg_create_interface_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_pg_capture_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_pg_capture_reply payload;
} vapi_msg_pg_capture_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_sw_interface_set_vpath_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_sw_interface_set_vpath_reply payload;
} vapi_msg_sw_interface_set_vpath_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u32 node_index; 
} vapi_payload_get_node_index_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_get_node_index_reply payload;
} vapi_msg_get_node_index_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_interface_name_renumber_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_interface_name_renumber_reply payload;
} vapi_msg_interface_name_renumber_reply;

typedef struct __attribute__ ((__packed__)) {
  u64 cmd_in_shmem; 
} vapi_payload_cli;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_cli payload;
} vapi_msg_cli;

typedef struct __attribute__ ((__packed__)) {
  u16 _vl_msg_id;
  u32 client_index;
  u32 address;
  u32 pid;
  u32 sw_if_index;
  u8 new_mac[6];
  u8 mac_ip; 
} vapi_payload_ip4_arp_event;

typedef struct __attribute__ ((__packed__)) {

  vapi_payload_ip4_arp_event payload;
} vapi_msg_ip4_arp_event;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_oam_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_oam_add_del_reply payload;
} vapi_msg_oam_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  u8 is_ipv6;
  u8 is_add;
  u8 mask_length;
  u8 address[16];
  u8 number_of_ranges;
  u16 low_ports[32];
  u16 high_ports[32];
  u32 vrf_id; 
} vapi_payload_ip_source_and_port_range_check_add_del;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_ip_source_and_port_range_check_add_del payload;
} vapi_msg_ip_source_and_port_range_check_add_del;

typedef struct __attribute__ ((__packed__)) {
  u8 node_name[64]; 
} vapi_payload_get_node_index;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_get_node_index payload;
} vapi_msg_get_node_index;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u32 enable_disable; 
} vapi_payload_l2_interface_efp_filter;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_l2_interface_efp_filter payload;
} vapi_msg_l2_interface_efp_filter;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_l2_interface_efp_filter_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_l2_interface_efp_filter_reply payload;
} vapi_msg_l2_interface_efp_filter_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u8 enable_disable; 
} vapi_payload_proxy_arp_intfc_enable_disable;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_proxy_arp_intfc_enable_disable payload;
} vapi_msg_proxy_arp_intfc_enable_disable;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u8 enable;
  u8 arc_name[64];
  u8 feature_name[64]; 
} vapi_payload_feature_enable_disable;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_feature_enable_disable payload;
} vapi_msg_feature_enable_disable;

typedef struct __attribute__ ((__packed__)) {
  u32 vrf_id;
  u8 is_add;
  u8 low_address[4];
  u8 hi_address[4]; 
} vapi_payload_proxy_arp_add_del;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_proxy_arp_add_del payload;
} vapi_msg_proxy_arp_add_del;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_ioam_disable_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_ioam_disable_reply payload;
} vapi_msg_ioam_disable_reply;

typedef struct __attribute__ ((__packed__)) {
  u8 is_ipv6;
  u32 sw_if_index;
  u32 table_index; 
} vapi_payload_classify_set_interface_ip_table;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_classify_set_interface_ip_table payload;
} vapi_msg_classify_set_interface_ip_table;

typedef struct __attribute__ ((__packed__)) {
  u16 id;
  u8 seqno;
  u8 analyse;
  u8 pot_enable;
  u8 trace_enable;
  u32 node_id; 
} vapi_payload_ioam_enable;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_ioam_enable payload;
} vapi_msg_ioam_enable;

typedef struct __attribute__ ((__packed__)) {
  u8 node_name[64];
  u8 next_name[64]; 
} vapi_payload_get_next_index;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_get_next_index payload;
} vapi_msg_get_next_index;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u8 enable; 
} vapi_payload_sw_interface_set_vpath;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_sw_interface_set_vpath payload;
} vapi_msg_sw_interface_set_vpath;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_punt_socket_deregister_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_punt_socket_deregister_reply payload;
} vapi_msg_punt_socket_deregister_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 rx_sw_if_index;
  u32 tx_sw_if_index;
  u8 enable; 
} vapi_payload_sw_interface_set_l2_xconnect;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_sw_interface_set_l2_xconnect payload;
} vapi_msg_sw_interface_set_l2_xconnect;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_bd_ip_mac_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_bd_ip_mac_add_del_reply payload;
} vapi_msg_bd_ip_mac_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_reset_fib_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_reset_fib_reply payload;
} vapi_msg_reset_fib_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_want_ip6_nd_events_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_want_ip6_nd_events_reply payload;
} vapi_msg_want_ip6_nd_events_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_l2_patch_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_l2_patch_add_del_reply payload;
} vapi_msg_l2_patch_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  u8 is_ipv6;
  u32 arp_neighbor_limit; 
} vapi_payload_set_arp_neighbor_limit;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_set_arp_neighbor_limit payload;
} vapi_msg_set_arp_neighbor_limit;

typedef struct __attribute__ ((__packed__)) {
  u8 node_name[64];
  u8 next_name[64]; 
} vapi_payload_add_node_next;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_add_node_next payload;
} vapi_msg_add_node_next;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u32 next_index; 
} vapi_payload_get_next_index_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_get_next_index_reply payload;
} vapi_msg_get_next_index_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_sw_interface_set_mpls_enable_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_sw_interface_set_mpls_enable_reply payload;
} vapi_msg_sw_interface_set_mpls_enable_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u8 program[32];
  u8 version[32];
  u8 build_date[32];
  u8 build_directory[256]; 
} vapi_payload_show_version_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_show_version_reply payload;
} vapi_msg_show_version_reply;

typedef struct __attribute__ ((__packed__)) {
  u8 enable_disable;
  u32 pid;
  u32 address; 
} vapi_payload_want_ip4_arp_events;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_want_ip4_arp_events payload;
} vapi_msg_want_ip4_arp_events;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_ip_source_and_port_range_check_interface_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_ip_source_and_port_range_check_interface_add_del_reply payload;
} vapi_msg_ip_source_and_port_range_check_interface_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u8 pathname[64]; 
} vapi_payload_punt_socket_register_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_punt_socket_register_reply payload;
} vapi_msg_punt_socket_register_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u32 sw_if_index; 
} vapi_payload_create_loopback_instance_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_create_loopback_instance_reply payload;
} vapi_msg_create_loopback_instance_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_delete_loopback_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_delete_loopback_reply payload;
} vapi_msg_delete_loopback_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_classify_set_interface_l2_tables_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_classify_set_interface_l2_tables_reply payload;
} vapi_msg_classify_set_interface_l2_tables_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 interface_id;
  u8 is_enabled;
  u32 count;
  u32 pcap_name_length;
  u8 pcap_file_name[0]; 
} vapi_payload_pg_capture;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_pg_capture payload;
} vapi_msg_pg_capture;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u32 vlan_id; 
} vapi_payload_create_vlan_subif;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_create_vlan_subif payload;
} vapi_msg_create_vlan_subif;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u64 reply_in_shmem; 
} vapi_payload_get_node_graph_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_get_node_graph_reply payload;
} vapi_msg_get_node_graph_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 rx_sw_if_index;
  u32 bd_id;
  u8 shg;
  u8 bvi;
  u8 enable; 
} vapi_payload_sw_interface_set_l2_bridge;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_sw_interface_set_l2_bridge payload;
} vapi_msg_sw_interface_set_l2_bridge;

typedef struct __attribute__ ((__packed__)) {
  u8 is_add;
  u8 ipv;
  u8 l4_protocol;
  u16 l4_port; 
} vapi_payload_punt;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_punt payload;
} vapi_msg_punt;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index; 
} vapi_payload_delete_loopback;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_delete_loopback payload;
} vapi_msg_delete_loopback;

typedef struct __attribute__ ((__packed__)) {
  u32 interface_id; 
} vapi_payload_pg_create_interface;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_pg_create_interface payload;
} vapi_msg_pg_create_interface;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_ioam_enable_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_ioam_enable_reply payload;
} vapi_msg_ioam_enable_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u32 sub_id;
  u8 no_tags;
  u8 one_tag;
  u8 two_tags;
  u8 dot1ad;
  u8 exact_match;
  u8 default_sub;
  u8 outer_vlan_id_any;
  u8 inner_vlan_id_any;
  u16 outer_vlan_id;
  u16 inner_vlan_id; 
} vapi_payload_create_subif;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_create_subif payload;
} vapi_msg_create_subif;

typedef struct __attribute__ ((__packed__)) {
  u32 length;
  u8 cmd[0]; 
} vapi_payload_cli_inband;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_cli_inband payload;
} vapi_msg_cli_inband;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_want_ip4_arp_events_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_want_ip4_arp_events_reply payload;
} vapi_msg_want_ip4_arp_events_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index; 
} vapi_payload_delete_subif;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_delete_subif payload;
} vapi_msg_delete_subif;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_reset_vrf_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_reset_vrf_reply payload;
} vapi_msg_reset_vrf_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_feature_enable_disable_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_feature_enable_disable_reply payload;
} vapi_msg_feature_enable_disable_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u32 sw_if_index; 
} vapi_payload_create_subif_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_create_subif_reply payload;
} vapi_msg_create_subif_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 header_version;
  u8 is_ip4;
  u8 l4_protocol;
  u16 l4_port;
  u8 pathname[108]; 
} vapi_payload_punt_socket_register;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_punt_socket_register payload;
} vapi_msg_punt_socket_register;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_want_oam_events_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_want_oam_events_reply payload;
} vapi_msg_want_oam_events_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 enable_disable;
  u32 pid; 
} vapi_payload_want_oam_events;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_want_oam_events payload;
} vapi_msg_want_oam_events;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_ip_source_and_port_range_check_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_ip_source_and_port_range_check_add_del_reply payload;
} vapi_msg_ip_source_and_port_range_check_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_classify_set_interface_ip_table_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_classify_set_interface_ip_table_reply payload;
} vapi_msg_classify_set_interface_ip_table_reply;

typedef struct __attribute__ ((__packed__)) {
  u8 mac_address[6];
  u8 is_specified;
  u32 user_instance; 
} vapi_payload_create_loopback_instance;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_create_loopback_instance payload;
} vapi_msg_create_loopback_instance;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_sw_interface_set_l2_xconnect_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_sw_interface_set_l2_xconnect_reply payload;
} vapi_msg_sw_interface_set_l2_xconnect_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u32 length;
  u8 reply[0]; 
} vapi_payload_cli_inband_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_cli_inband_reply payload;
} vapi_msg_cli_inband_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u32 ip4_table_index;
  u32 ip6_table_index;
  u32 l2_table_index;
  u8 is_add; 
} vapi_payload_input_acl_set_interface;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_input_acl_set_interface payload;
} vapi_msg_input_acl_set_interface;

typedef struct __attribute__ ((__packed__)) {
  u16 id; 
} vapi_payload_ioam_disable;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_ioam_disable payload;
} vapi_msg_ioam_disable;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_proxy_arp_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_proxy_arp_add_del_reply payload;
} vapi_msg_proxy_arp_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u32 sw_if_index; 
} vapi_payload_create_vlan_subif_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_create_vlan_subif_reply payload;
} vapi_msg_create_vlan_subif_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 vrf_id;
  u8 is_ipv6; 
} vapi_payload_reset_fib;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_reset_fib payload;
} vapi_msg_reset_fib;

typedef struct __attribute__ ((__packed__)) {
  u8 is_enabled;
  u32 stream_name_length;
  u8 stream_name[0]; 
} vapi_payload_pg_enable_disable;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_pg_enable_disable payload;
} vapi_msg_pg_enable_disable;

typedef struct __attribute__ ((__packed__)) {
  u8 enable_disable;
  u32 pid;
  u8 address[16]; 
} vapi_payload_want_ip6_nd_events;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_want_ip6_nd_events payload;
} vapi_msg_want_ip6_nd_events;

typedef struct __attribute__ ((__packed__)) {
  u32 rx_sw_if_index;
  u32 tx_sw_if_index;
  u8 is_add; 
} vapi_payload_l2_patch_add_del;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_l2_patch_add_del payload;
} vapi_msg_l2_patch_add_del;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u64 reply_in_shmem; 
} vapi_payload_cli_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_cli_reply payload;
} vapi_msg_cli_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_proxy_arp_intfc_enable_disable_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_proxy_arp_intfc_enable_disable_reply payload;
} vapi_msg_proxy_arp_intfc_enable_disable_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u32 client_index;
  u32 vpe_pid; 
} vapi_payload_control_ping_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_control_ping_reply payload;
} vapi_msg_control_ping_reply;

typedef struct __attribute__ ((__packed__)) {
  u16 _vl_msg_id;
  u8 dst_address[4];
  u8 state; 
} vapi_payload_oam_event;

typedef struct __attribute__ ((__packed__)) {

  vapi_payload_oam_event payload;
} vapi_msg_oam_event;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_show_version;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u32 ip4_table_index;
  u32 ip6_table_index;
  u32 other_table_index;
  u8 is_input; 
} vapi_payload_classify_set_interface_l2_tables;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_classify_set_interface_l2_tables payload;
} vapi_msg_classify_set_interface_l2_tables;

typedef struct __attribute__ ((__packed__)) {
  u8 is_ipv6;
  u32 vrf_id; 
} vapi_payload_reset_vrf;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_reset_vrf payload;
} vapi_msg_reset_vrf;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_input_acl_set_interface_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_input_acl_set_interface_reply payload;
} vapi_msg_input_acl_set_interface_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 bd_id;
  u8 is_add;
  u8 is_ipv6;
  u8 ip_address[16];
  u8 mac_address[6]; 
} vapi_payload_bd_ip_mac_add_del;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_bd_ip_mac_add_del payload;
} vapi_msg_bd_ip_mac_add_del;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_sw_interface_set_l2_bridge_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_sw_interface_set_l2_bridge_reply payload;
} vapi_msg_sw_interface_set_l2_bridge_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 vrf_id;
  u8 src_address[4];
  u8 dst_address[4];
  u8 is_add; 
} vapi_payload_oam_add_del;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_oam_add_del payload;
} vapi_msg_oam_add_del;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_get_node_graph;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u32 new_show_dev_instance; 
} vapi_payload_interface_name_renumber;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_interface_name_renumber payload;
} vapi_msg_interface_name_renumber;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_pg_enable_disable_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_pg_enable_disable_reply payload;
} vapi_msg_pg_enable_disable_reply;

typedef struct __attribute__ ((__packed__)) {
  u8 mac_address[6]; 
} vapi_payload_create_loopback;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_create_loopback payload;
} vapi_msg_create_loopback;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u32 sw_if_index; 
} vapi_payload_create_loopback_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_create_loopback_reply payload;
} vapi_msg_create_loopback_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_set_arp_neighbor_limit_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_set_arp_neighbor_limit_reply payload;
} vapi_msg_set_arp_neighbor_limit_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u32 next_index; 
} vapi_payload_add_node_next_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_add_node_next_reply payload;
} vapi_msg_add_node_next_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u8 enable; 
} vapi_payload_sw_interface_set_mpls_enable;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_sw_interface_set_mpls_enable payload;
} vapi_msg_sw_interface_set_mpls_enable;

typedef struct __attribute__ ((__packed__)) {
  u8 is_ip4;
  u8 l4_protocol;
  u16 l4_port; 
} vapi_payload_punt_socket_deregister;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_punt_socket_deregister payload;
} vapi_msg_punt_socket_deregister;

typedef struct __attribute__ ((__packed__)) {
  u8 is_add;
  u32 sw_if_index;
  u32 tcp_in_vrf_id;
  u32 tcp_out_vrf_id;
  u32 udp_in_vrf_id;
  u32 udp_out_vrf_id; 
} vapi_payload_ip_source_and_port_range_check_interface_add_del;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_ip_source_and_port_range_check_interface_add_del payload;
} vapi_msg_ip_source_and_port_range_check_interface_add_del;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_punt_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_punt_reply payload;
} vapi_msg_punt_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_control_ping;


static inline void vapi_msg_delete_subif_reply_payload_hton(vapi_payload_delete_subif_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_delete_subif_reply_payload_ntoh(vapi_payload_delete_subif_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_delete_subif_reply_msg_size(vapi_msg_delete_subif_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_delete_subif_reply_hton(vapi_msg_delete_subif_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_delete_subif_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_delete_subif_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_delete_subif_reply_ntoh(vapi_msg_delete_subif_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_delete_subif_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_delete_subif_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ip6_nd_event_payload_hton(vapi_payload_ip6_nd_event *payload)
{
  payload->_vl_msg_id = htobe16(payload->_vl_msg_id);
  payload->client_index = htobe32(payload->client_index);
  payload->pid = htobe32(payload->pid);
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_ip6_nd_event_payload_ntoh(vapi_payload_ip6_nd_event *payload)
{
  payload->_vl_msg_id = be16toh(payload->_vl_msg_id);
  payload->client_index = be32toh(payload->client_index);
  payload->pid = be32toh(payload->pid);
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_ip6_nd_event_msg_size(vapi_msg_ip6_nd_event *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ip6_nd_event_hton(vapi_msg_ip6_nd_event *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip6_nd_event'@%p to big endian", msg);

  vapi_msg_ip6_nd_event_payload_hton(&msg->payload);
}

static inline void vapi_msg_ip6_nd_event_ntoh(vapi_msg_ip6_nd_event *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip6_nd_event'@%p to host byte order", msg);

  vapi_msg_ip6_nd_event_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_pg_create_interface_reply_payload_hton(vapi_payload_pg_create_interface_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_pg_create_interface_reply_payload_ntoh(vapi_payload_pg_create_interface_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_pg_create_interface_reply_msg_size(vapi_msg_pg_create_interface_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_pg_create_interface_reply_hton(vapi_msg_pg_create_interface_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_pg_create_interface_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_pg_create_interface_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_pg_create_interface_reply_ntoh(vapi_msg_pg_create_interface_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_pg_create_interface_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_pg_create_interface_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_pg_capture_reply_payload_hton(vapi_payload_pg_capture_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_pg_capture_reply_payload_ntoh(vapi_payload_pg_capture_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_pg_capture_reply_msg_size(vapi_msg_pg_capture_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_pg_capture_reply_hton(vapi_msg_pg_capture_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_pg_capture_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_pg_capture_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_pg_capture_reply_ntoh(vapi_msg_pg_capture_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_pg_capture_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_pg_capture_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_vpath_reply_payload_hton(vapi_payload_sw_interface_set_vpath_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_sw_interface_set_vpath_reply_payload_ntoh(vapi_payload_sw_interface_set_vpath_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_sw_interface_set_vpath_reply_msg_size(vapi_msg_sw_interface_set_vpath_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_set_vpath_reply_hton(vapi_msg_sw_interface_set_vpath_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_vpath_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_sw_interface_set_vpath_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_vpath_reply_ntoh(vapi_msg_sw_interface_set_vpath_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_vpath_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_sw_interface_set_vpath_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_get_node_index_reply_payload_hton(vapi_payload_get_node_index_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->node_index = htobe32(payload->node_index);
}

static inline void vapi_msg_get_node_index_reply_payload_ntoh(vapi_payload_get_node_index_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->node_index = be32toh(payload->node_index);
}

static inline uword vapi_calc_get_node_index_reply_msg_size(vapi_msg_get_node_index_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_get_node_index_reply_hton(vapi_msg_get_node_index_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_get_node_index_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_get_node_index_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_get_node_index_reply_ntoh(vapi_msg_get_node_index_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_get_node_index_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_get_node_index_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_interface_name_renumber_reply_payload_hton(vapi_payload_interface_name_renumber_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_interface_name_renumber_reply_payload_ntoh(vapi_payload_interface_name_renumber_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_interface_name_renumber_reply_msg_size(vapi_msg_interface_name_renumber_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_interface_name_renumber_reply_hton(vapi_msg_interface_name_renumber_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_interface_name_renumber_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_interface_name_renumber_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_interface_name_renumber_reply_ntoh(vapi_msg_interface_name_renumber_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_interface_name_renumber_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_interface_name_renumber_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_cli_payload_hton(vapi_payload_cli *payload)
{
  payload->cmd_in_shmem = htobe64(payload->cmd_in_shmem);
}

static inline void vapi_msg_cli_payload_ntoh(vapi_payload_cli *payload)
{
  payload->cmd_in_shmem = be64toh(payload->cmd_in_shmem);
}

static inline uword vapi_calc_cli_msg_size(vapi_msg_cli *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_cli_hton(vapi_msg_cli *msg)
{
  VAPI_DBG("Swapping `vapi_msg_cli'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_cli_payload_hton(&msg->payload);
}

static inline void vapi_msg_cli_ntoh(vapi_msg_cli *msg)
{
  VAPI_DBG("Swapping `vapi_msg_cli'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_cli_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ip4_arp_event_payload_hton(vapi_payload_ip4_arp_event *payload)
{
  payload->_vl_msg_id = htobe16(payload->_vl_msg_id);
  payload->client_index = htobe32(payload->client_index);
  payload->address = htobe32(payload->address);
  payload->pid = htobe32(payload->pid);
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_ip4_arp_event_payload_ntoh(vapi_payload_ip4_arp_event *payload)
{
  payload->_vl_msg_id = be16toh(payload->_vl_msg_id);
  payload->client_index = be32toh(payload->client_index);
  payload->address = be32toh(payload->address);
  payload->pid = be32toh(payload->pid);
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_ip4_arp_event_msg_size(vapi_msg_ip4_arp_event *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ip4_arp_event_hton(vapi_msg_ip4_arp_event *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip4_arp_event'@%p to big endian", msg);

  vapi_msg_ip4_arp_event_payload_hton(&msg->payload);
}

static inline void vapi_msg_ip4_arp_event_ntoh(vapi_msg_ip4_arp_event *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip4_arp_event'@%p to host byte order", msg);

  vapi_msg_ip4_arp_event_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_oam_add_del_reply_payload_hton(vapi_payload_oam_add_del_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_oam_add_del_reply_payload_ntoh(vapi_payload_oam_add_del_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_oam_add_del_reply_msg_size(vapi_msg_oam_add_del_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_oam_add_del_reply_hton(vapi_msg_oam_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_oam_add_del_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_oam_add_del_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_oam_add_del_reply_ntoh(vapi_msg_oam_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_oam_add_del_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_oam_add_del_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ip_source_and_port_range_check_add_del_payload_hton(vapi_payload_ip_source_and_port_range_check_add_del *payload)
{
  do { unsigned i; for (i = 0; i < 32; ++i) { payload->low_ports[i] = htobe16(payload->low_ports[i]); } } while(0);
  do { unsigned i; for (i = 0; i < 32; ++i) { payload->high_ports[i] = htobe16(payload->high_ports[i]); } } while(0);
  payload->vrf_id = htobe32(payload->vrf_id);
}

static inline void vapi_msg_ip_source_and_port_range_check_add_del_payload_ntoh(vapi_payload_ip_source_and_port_range_check_add_del *payload)
{
  do { unsigned i; for (i = 0; i < 32; ++i) { payload->low_ports[i] = be16toh(payload->low_ports[i]); } } while(0);
  do { unsigned i; for (i = 0; i < 32; ++i) { payload->high_ports[i] = be16toh(payload->high_ports[i]); } } while(0);
  payload->vrf_id = be32toh(payload->vrf_id);
}

static inline uword vapi_calc_ip_source_and_port_range_check_add_del_msg_size(vapi_msg_ip_source_and_port_range_check_add_del *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ip_source_and_port_range_check_add_del_hton(vapi_msg_ip_source_and_port_range_check_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_source_and_port_range_check_add_del'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_ip_source_and_port_range_check_add_del_payload_hton(&msg->payload);
}

static inline void vapi_msg_ip_source_and_port_range_check_add_del_ntoh(vapi_msg_ip_source_and_port_range_check_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_source_and_port_range_check_add_del'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_ip_source_and_port_range_check_add_del_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_get_node_index_payload_hton(vapi_payload_get_node_index *payload)
{

}

static inline void vapi_msg_get_node_index_payload_ntoh(vapi_payload_get_node_index *payload)
{

}

static inline uword vapi_calc_get_node_index_msg_size(vapi_msg_get_node_index *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_get_node_index_hton(vapi_msg_get_node_index *msg)
{
  VAPI_DBG("Swapping `vapi_msg_get_node_index'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_get_node_index_payload_hton(&msg->payload);
}

static inline void vapi_msg_get_node_index_ntoh(vapi_msg_get_node_index *msg)
{
  VAPI_DBG("Swapping `vapi_msg_get_node_index'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_get_node_index_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_l2_interface_efp_filter_payload_hton(vapi_payload_l2_interface_efp_filter *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
  payload->enable_disable = htobe32(payload->enable_disable);
}

static inline void vapi_msg_l2_interface_efp_filter_payload_ntoh(vapi_payload_l2_interface_efp_filter *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
  payload->enable_disable = be32toh(payload->enable_disable);
}

static inline uword vapi_calc_l2_interface_efp_filter_msg_size(vapi_msg_l2_interface_efp_filter *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_l2_interface_efp_filter_hton(vapi_msg_l2_interface_efp_filter *msg)
{
  VAPI_DBG("Swapping `vapi_msg_l2_interface_efp_filter'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_l2_interface_efp_filter_payload_hton(&msg->payload);
}

static inline void vapi_msg_l2_interface_efp_filter_ntoh(vapi_msg_l2_interface_efp_filter *msg)
{
  VAPI_DBG("Swapping `vapi_msg_l2_interface_efp_filter'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_l2_interface_efp_filter_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_l2_interface_efp_filter_reply_payload_hton(vapi_payload_l2_interface_efp_filter_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_l2_interface_efp_filter_reply_payload_ntoh(vapi_payload_l2_interface_efp_filter_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_l2_interface_efp_filter_reply_msg_size(vapi_msg_l2_interface_efp_filter_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_l2_interface_efp_filter_reply_hton(vapi_msg_l2_interface_efp_filter_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_l2_interface_efp_filter_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_l2_interface_efp_filter_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_l2_interface_efp_filter_reply_ntoh(vapi_msg_l2_interface_efp_filter_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_l2_interface_efp_filter_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_l2_interface_efp_filter_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_proxy_arp_intfc_enable_disable_payload_hton(vapi_payload_proxy_arp_intfc_enable_disable *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_proxy_arp_intfc_enable_disable_payload_ntoh(vapi_payload_proxy_arp_intfc_enable_disable *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_proxy_arp_intfc_enable_disable_msg_size(vapi_msg_proxy_arp_intfc_enable_disable *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_proxy_arp_intfc_enable_disable_hton(vapi_msg_proxy_arp_intfc_enable_disable *msg)
{
  VAPI_DBG("Swapping `vapi_msg_proxy_arp_intfc_enable_disable'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_proxy_arp_intfc_enable_disable_payload_hton(&msg->payload);
}

static inline void vapi_msg_proxy_arp_intfc_enable_disable_ntoh(vapi_msg_proxy_arp_intfc_enable_disable *msg)
{
  VAPI_DBG("Swapping `vapi_msg_proxy_arp_intfc_enable_disable'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_proxy_arp_intfc_enable_disable_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_feature_enable_disable_payload_hton(vapi_payload_feature_enable_disable *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_feature_enable_disable_payload_ntoh(vapi_payload_feature_enable_disable *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_feature_enable_disable_msg_size(vapi_msg_feature_enable_disable *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_feature_enable_disable_hton(vapi_msg_feature_enable_disable *msg)
{
  VAPI_DBG("Swapping `vapi_msg_feature_enable_disable'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_feature_enable_disable_payload_hton(&msg->payload);
}

static inline void vapi_msg_feature_enable_disable_ntoh(vapi_msg_feature_enable_disable *msg)
{
  VAPI_DBG("Swapping `vapi_msg_feature_enable_disable'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_feature_enable_disable_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_proxy_arp_add_del_payload_hton(vapi_payload_proxy_arp_add_del *payload)
{
  payload->vrf_id = htobe32(payload->vrf_id);
}

static inline void vapi_msg_proxy_arp_add_del_payload_ntoh(vapi_payload_proxy_arp_add_del *payload)
{
  payload->vrf_id = be32toh(payload->vrf_id);
}

static inline uword vapi_calc_proxy_arp_add_del_msg_size(vapi_msg_proxy_arp_add_del *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_proxy_arp_add_del_hton(vapi_msg_proxy_arp_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_proxy_arp_add_del'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_proxy_arp_add_del_payload_hton(&msg->payload);
}

static inline void vapi_msg_proxy_arp_add_del_ntoh(vapi_msg_proxy_arp_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_proxy_arp_add_del'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_proxy_arp_add_del_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ioam_disable_reply_payload_hton(vapi_payload_ioam_disable_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_ioam_disable_reply_payload_ntoh(vapi_payload_ioam_disable_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_ioam_disable_reply_msg_size(vapi_msg_ioam_disable_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ioam_disable_reply_hton(vapi_msg_ioam_disable_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ioam_disable_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_ioam_disable_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_ioam_disable_reply_ntoh(vapi_msg_ioam_disable_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ioam_disable_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_ioam_disable_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_classify_set_interface_ip_table_payload_hton(vapi_payload_classify_set_interface_ip_table *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
  payload->table_index = htobe32(payload->table_index);
}

static inline void vapi_msg_classify_set_interface_ip_table_payload_ntoh(vapi_payload_classify_set_interface_ip_table *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
  payload->table_index = be32toh(payload->table_index);
}

static inline uword vapi_calc_classify_set_interface_ip_table_msg_size(vapi_msg_classify_set_interface_ip_table *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_classify_set_interface_ip_table_hton(vapi_msg_classify_set_interface_ip_table *msg)
{
  VAPI_DBG("Swapping `vapi_msg_classify_set_interface_ip_table'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_classify_set_interface_ip_table_payload_hton(&msg->payload);
}

static inline void vapi_msg_classify_set_interface_ip_table_ntoh(vapi_msg_classify_set_interface_ip_table *msg)
{
  VAPI_DBG("Swapping `vapi_msg_classify_set_interface_ip_table'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_classify_set_interface_ip_table_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ioam_enable_payload_hton(vapi_payload_ioam_enable *payload)
{
  payload->id = htobe16(payload->id);
  payload->node_id = htobe32(payload->node_id);
}

static inline void vapi_msg_ioam_enable_payload_ntoh(vapi_payload_ioam_enable *payload)
{
  payload->id = be16toh(payload->id);
  payload->node_id = be32toh(payload->node_id);
}

static inline uword vapi_calc_ioam_enable_msg_size(vapi_msg_ioam_enable *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ioam_enable_hton(vapi_msg_ioam_enable *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ioam_enable'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_ioam_enable_payload_hton(&msg->payload);
}

static inline void vapi_msg_ioam_enable_ntoh(vapi_msg_ioam_enable *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ioam_enable'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_ioam_enable_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_get_next_index_payload_hton(vapi_payload_get_next_index *payload)
{

}

static inline void vapi_msg_get_next_index_payload_ntoh(vapi_payload_get_next_index *payload)
{

}

static inline uword vapi_calc_get_next_index_msg_size(vapi_msg_get_next_index *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_get_next_index_hton(vapi_msg_get_next_index *msg)
{
  VAPI_DBG("Swapping `vapi_msg_get_next_index'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_get_next_index_payload_hton(&msg->payload);
}

static inline void vapi_msg_get_next_index_ntoh(vapi_msg_get_next_index *msg)
{
  VAPI_DBG("Swapping `vapi_msg_get_next_index'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_get_next_index_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_vpath_payload_hton(vapi_payload_sw_interface_set_vpath *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_sw_interface_set_vpath_payload_ntoh(vapi_payload_sw_interface_set_vpath *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_sw_interface_set_vpath_msg_size(vapi_msg_sw_interface_set_vpath *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_set_vpath_hton(vapi_msg_sw_interface_set_vpath *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_vpath'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_sw_interface_set_vpath_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_vpath_ntoh(vapi_msg_sw_interface_set_vpath *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_vpath'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_sw_interface_set_vpath_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_punt_socket_deregister_reply_payload_hton(vapi_payload_punt_socket_deregister_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_punt_socket_deregister_reply_payload_ntoh(vapi_payload_punt_socket_deregister_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_punt_socket_deregister_reply_msg_size(vapi_msg_punt_socket_deregister_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_punt_socket_deregister_reply_hton(vapi_msg_punt_socket_deregister_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_punt_socket_deregister_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_punt_socket_deregister_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_punt_socket_deregister_reply_ntoh(vapi_msg_punt_socket_deregister_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_punt_socket_deregister_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_punt_socket_deregister_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_l2_xconnect_payload_hton(vapi_payload_sw_interface_set_l2_xconnect *payload)
{
  payload->rx_sw_if_index = htobe32(payload->rx_sw_if_index);
  payload->tx_sw_if_index = htobe32(payload->tx_sw_if_index);
}

static inline void vapi_msg_sw_interface_set_l2_xconnect_payload_ntoh(vapi_payload_sw_interface_set_l2_xconnect *payload)
{
  payload->rx_sw_if_index = be32toh(payload->rx_sw_if_index);
  payload->tx_sw_if_index = be32toh(payload->tx_sw_if_index);
}

static inline uword vapi_calc_sw_interface_set_l2_xconnect_msg_size(vapi_msg_sw_interface_set_l2_xconnect *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_set_l2_xconnect_hton(vapi_msg_sw_interface_set_l2_xconnect *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_l2_xconnect'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_sw_interface_set_l2_xconnect_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_l2_xconnect_ntoh(vapi_msg_sw_interface_set_l2_xconnect *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_l2_xconnect'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_sw_interface_set_l2_xconnect_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_bd_ip_mac_add_del_reply_payload_hton(vapi_payload_bd_ip_mac_add_del_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_bd_ip_mac_add_del_reply_payload_ntoh(vapi_payload_bd_ip_mac_add_del_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_bd_ip_mac_add_del_reply_msg_size(vapi_msg_bd_ip_mac_add_del_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_bd_ip_mac_add_del_reply_hton(vapi_msg_bd_ip_mac_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_bd_ip_mac_add_del_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_bd_ip_mac_add_del_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_bd_ip_mac_add_del_reply_ntoh(vapi_msg_bd_ip_mac_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_bd_ip_mac_add_del_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_bd_ip_mac_add_del_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_reset_fib_reply_payload_hton(vapi_payload_reset_fib_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_reset_fib_reply_payload_ntoh(vapi_payload_reset_fib_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_reset_fib_reply_msg_size(vapi_msg_reset_fib_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_reset_fib_reply_hton(vapi_msg_reset_fib_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_reset_fib_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_reset_fib_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_reset_fib_reply_ntoh(vapi_msg_reset_fib_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_reset_fib_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_reset_fib_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_want_ip6_nd_events_reply_payload_hton(vapi_payload_want_ip6_nd_events_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_want_ip6_nd_events_reply_payload_ntoh(vapi_payload_want_ip6_nd_events_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_want_ip6_nd_events_reply_msg_size(vapi_msg_want_ip6_nd_events_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_want_ip6_nd_events_reply_hton(vapi_msg_want_ip6_nd_events_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_ip6_nd_events_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_want_ip6_nd_events_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_want_ip6_nd_events_reply_ntoh(vapi_msg_want_ip6_nd_events_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_ip6_nd_events_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_want_ip6_nd_events_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_l2_patch_add_del_reply_payload_hton(vapi_payload_l2_patch_add_del_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_l2_patch_add_del_reply_payload_ntoh(vapi_payload_l2_patch_add_del_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_l2_patch_add_del_reply_msg_size(vapi_msg_l2_patch_add_del_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_l2_patch_add_del_reply_hton(vapi_msg_l2_patch_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_l2_patch_add_del_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_l2_patch_add_del_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_l2_patch_add_del_reply_ntoh(vapi_msg_l2_patch_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_l2_patch_add_del_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_l2_patch_add_del_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_set_arp_neighbor_limit_payload_hton(vapi_payload_set_arp_neighbor_limit *payload)
{
  payload->arp_neighbor_limit = htobe32(payload->arp_neighbor_limit);
}

static inline void vapi_msg_set_arp_neighbor_limit_payload_ntoh(vapi_payload_set_arp_neighbor_limit *payload)
{
  payload->arp_neighbor_limit = be32toh(payload->arp_neighbor_limit);
}

static inline uword vapi_calc_set_arp_neighbor_limit_msg_size(vapi_msg_set_arp_neighbor_limit *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_set_arp_neighbor_limit_hton(vapi_msg_set_arp_neighbor_limit *msg)
{
  VAPI_DBG("Swapping `vapi_msg_set_arp_neighbor_limit'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_set_arp_neighbor_limit_payload_hton(&msg->payload);
}

static inline void vapi_msg_set_arp_neighbor_limit_ntoh(vapi_msg_set_arp_neighbor_limit *msg)
{
  VAPI_DBG("Swapping `vapi_msg_set_arp_neighbor_limit'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_set_arp_neighbor_limit_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_add_node_next_payload_hton(vapi_payload_add_node_next *payload)
{

}

static inline void vapi_msg_add_node_next_payload_ntoh(vapi_payload_add_node_next *payload)
{

}

static inline uword vapi_calc_add_node_next_msg_size(vapi_msg_add_node_next *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_add_node_next_hton(vapi_msg_add_node_next *msg)
{
  VAPI_DBG("Swapping `vapi_msg_add_node_next'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_add_node_next_payload_hton(&msg->payload);
}

static inline void vapi_msg_add_node_next_ntoh(vapi_msg_add_node_next *msg)
{
  VAPI_DBG("Swapping `vapi_msg_add_node_next'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_add_node_next_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_get_next_index_reply_payload_hton(vapi_payload_get_next_index_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->next_index = htobe32(payload->next_index);
}

static inline void vapi_msg_get_next_index_reply_payload_ntoh(vapi_payload_get_next_index_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->next_index = be32toh(payload->next_index);
}

static inline uword vapi_calc_get_next_index_reply_msg_size(vapi_msg_get_next_index_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_get_next_index_reply_hton(vapi_msg_get_next_index_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_get_next_index_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_get_next_index_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_get_next_index_reply_ntoh(vapi_msg_get_next_index_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_get_next_index_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_get_next_index_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_mpls_enable_reply_payload_hton(vapi_payload_sw_interface_set_mpls_enable_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_sw_interface_set_mpls_enable_reply_payload_ntoh(vapi_payload_sw_interface_set_mpls_enable_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_sw_interface_set_mpls_enable_reply_msg_size(vapi_msg_sw_interface_set_mpls_enable_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_set_mpls_enable_reply_hton(vapi_msg_sw_interface_set_mpls_enable_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_mpls_enable_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_sw_interface_set_mpls_enable_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_mpls_enable_reply_ntoh(vapi_msg_sw_interface_set_mpls_enable_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_mpls_enable_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_sw_interface_set_mpls_enable_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_show_version_reply_payload_hton(vapi_payload_show_version_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_show_version_reply_payload_ntoh(vapi_payload_show_version_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_show_version_reply_msg_size(vapi_msg_show_version_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_show_version_reply_hton(vapi_msg_show_version_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_show_version_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_show_version_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_show_version_reply_ntoh(vapi_msg_show_version_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_show_version_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_show_version_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_want_ip4_arp_events_payload_hton(vapi_payload_want_ip4_arp_events *payload)
{
  payload->pid = htobe32(payload->pid);
  payload->address = htobe32(payload->address);
}

static inline void vapi_msg_want_ip4_arp_events_payload_ntoh(vapi_payload_want_ip4_arp_events *payload)
{
  payload->pid = be32toh(payload->pid);
  payload->address = be32toh(payload->address);
}

static inline uword vapi_calc_want_ip4_arp_events_msg_size(vapi_msg_want_ip4_arp_events *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_want_ip4_arp_events_hton(vapi_msg_want_ip4_arp_events *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_ip4_arp_events'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_want_ip4_arp_events_payload_hton(&msg->payload);
}

static inline void vapi_msg_want_ip4_arp_events_ntoh(vapi_msg_want_ip4_arp_events *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_ip4_arp_events'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_want_ip4_arp_events_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ip_source_and_port_range_check_interface_add_del_reply_payload_hton(vapi_payload_ip_source_and_port_range_check_interface_add_del_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_ip_source_and_port_range_check_interface_add_del_reply_payload_ntoh(vapi_payload_ip_source_and_port_range_check_interface_add_del_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_ip_source_and_port_range_check_interface_add_del_reply_msg_size(vapi_msg_ip_source_and_port_range_check_interface_add_del_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ip_source_and_port_range_check_interface_add_del_reply_hton(vapi_msg_ip_source_and_port_range_check_interface_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_source_and_port_range_check_interface_add_del_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_ip_source_and_port_range_check_interface_add_del_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_ip_source_and_port_range_check_interface_add_del_reply_ntoh(vapi_msg_ip_source_and_port_range_check_interface_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_source_and_port_range_check_interface_add_del_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_ip_source_and_port_range_check_interface_add_del_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_punt_socket_register_reply_payload_hton(vapi_payload_punt_socket_register_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_punt_socket_register_reply_payload_ntoh(vapi_payload_punt_socket_register_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_punt_socket_register_reply_msg_size(vapi_msg_punt_socket_register_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_punt_socket_register_reply_hton(vapi_msg_punt_socket_register_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_punt_socket_register_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_punt_socket_register_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_punt_socket_register_reply_ntoh(vapi_msg_punt_socket_register_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_punt_socket_register_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_punt_socket_register_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_create_loopback_instance_reply_payload_hton(vapi_payload_create_loopback_instance_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_create_loopback_instance_reply_payload_ntoh(vapi_payload_create_loopback_instance_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_create_loopback_instance_reply_msg_size(vapi_msg_create_loopback_instance_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_create_loopback_instance_reply_hton(vapi_msg_create_loopback_instance_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_create_loopback_instance_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_create_loopback_instance_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_create_loopback_instance_reply_ntoh(vapi_msg_create_loopback_instance_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_create_loopback_instance_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_create_loopback_instance_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_delete_loopback_reply_payload_hton(vapi_payload_delete_loopback_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_delete_loopback_reply_payload_ntoh(vapi_payload_delete_loopback_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_delete_loopback_reply_msg_size(vapi_msg_delete_loopback_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_delete_loopback_reply_hton(vapi_msg_delete_loopback_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_delete_loopback_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_delete_loopback_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_delete_loopback_reply_ntoh(vapi_msg_delete_loopback_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_delete_loopback_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_delete_loopback_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_classify_set_interface_l2_tables_reply_payload_hton(vapi_payload_classify_set_interface_l2_tables_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_classify_set_interface_l2_tables_reply_payload_ntoh(vapi_payload_classify_set_interface_l2_tables_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_classify_set_interface_l2_tables_reply_msg_size(vapi_msg_classify_set_interface_l2_tables_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_classify_set_interface_l2_tables_reply_hton(vapi_msg_classify_set_interface_l2_tables_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_classify_set_interface_l2_tables_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_classify_set_interface_l2_tables_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_classify_set_interface_l2_tables_reply_ntoh(vapi_msg_classify_set_interface_l2_tables_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_classify_set_interface_l2_tables_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_classify_set_interface_l2_tables_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_pg_capture_payload_hton(vapi_payload_pg_capture *payload)
{
  payload->interface_id = htobe32(payload->interface_id);
  payload->count = htobe32(payload->count);
  payload->pcap_name_length = htobe32(payload->pcap_name_length);
}

static inline void vapi_msg_pg_capture_payload_ntoh(vapi_payload_pg_capture *payload)
{
  payload->interface_id = be32toh(payload->interface_id);
  payload->count = be32toh(payload->count);
  payload->pcap_name_length = be32toh(payload->pcap_name_length);
}

static inline uword vapi_calc_pg_capture_msg_size(vapi_msg_pg_capture *msg)
{
  return sizeof(*msg)+ msg->payload.pcap_name_length * sizeof(msg->payload.pcap_file_name[0]);
}

static inline void vapi_msg_pg_capture_hton(vapi_msg_pg_capture *msg)
{
  VAPI_DBG("Swapping `vapi_msg_pg_capture'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_pg_capture_payload_hton(&msg->payload);
}

static inline void vapi_msg_pg_capture_ntoh(vapi_msg_pg_capture *msg)
{
  VAPI_DBG("Swapping `vapi_msg_pg_capture'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_pg_capture_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_create_vlan_subif_payload_hton(vapi_payload_create_vlan_subif *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
  payload->vlan_id = htobe32(payload->vlan_id);
}

static inline void vapi_msg_create_vlan_subif_payload_ntoh(vapi_payload_create_vlan_subif *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
  payload->vlan_id = be32toh(payload->vlan_id);
}

static inline uword vapi_calc_create_vlan_subif_msg_size(vapi_msg_create_vlan_subif *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_create_vlan_subif_hton(vapi_msg_create_vlan_subif *msg)
{
  VAPI_DBG("Swapping `vapi_msg_create_vlan_subif'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_create_vlan_subif_payload_hton(&msg->payload);
}

static inline void vapi_msg_create_vlan_subif_ntoh(vapi_msg_create_vlan_subif *msg)
{
  VAPI_DBG("Swapping `vapi_msg_create_vlan_subif'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_create_vlan_subif_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_get_node_graph_reply_payload_hton(vapi_payload_get_node_graph_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->reply_in_shmem = htobe64(payload->reply_in_shmem);
}

static inline void vapi_msg_get_node_graph_reply_payload_ntoh(vapi_payload_get_node_graph_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->reply_in_shmem = be64toh(payload->reply_in_shmem);
}

static inline uword vapi_calc_get_node_graph_reply_msg_size(vapi_msg_get_node_graph_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_get_node_graph_reply_hton(vapi_msg_get_node_graph_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_get_node_graph_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_get_node_graph_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_get_node_graph_reply_ntoh(vapi_msg_get_node_graph_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_get_node_graph_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_get_node_graph_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_l2_bridge_payload_hton(vapi_payload_sw_interface_set_l2_bridge *payload)
{
  payload->rx_sw_if_index = htobe32(payload->rx_sw_if_index);
  payload->bd_id = htobe32(payload->bd_id);
}

static inline void vapi_msg_sw_interface_set_l2_bridge_payload_ntoh(vapi_payload_sw_interface_set_l2_bridge *payload)
{
  payload->rx_sw_if_index = be32toh(payload->rx_sw_if_index);
  payload->bd_id = be32toh(payload->bd_id);
}

static inline uword vapi_calc_sw_interface_set_l2_bridge_msg_size(vapi_msg_sw_interface_set_l2_bridge *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_set_l2_bridge_hton(vapi_msg_sw_interface_set_l2_bridge *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_l2_bridge'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_sw_interface_set_l2_bridge_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_l2_bridge_ntoh(vapi_msg_sw_interface_set_l2_bridge *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_l2_bridge'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_sw_interface_set_l2_bridge_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_punt_payload_hton(vapi_payload_punt *payload)
{
  payload->l4_port = htobe16(payload->l4_port);
}

static inline void vapi_msg_punt_payload_ntoh(vapi_payload_punt *payload)
{
  payload->l4_port = be16toh(payload->l4_port);
}

static inline uword vapi_calc_punt_msg_size(vapi_msg_punt *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_punt_hton(vapi_msg_punt *msg)
{
  VAPI_DBG("Swapping `vapi_msg_punt'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_punt_payload_hton(&msg->payload);
}

static inline void vapi_msg_punt_ntoh(vapi_msg_punt *msg)
{
  VAPI_DBG("Swapping `vapi_msg_punt'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_punt_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_delete_loopback_payload_hton(vapi_payload_delete_loopback *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_delete_loopback_payload_ntoh(vapi_payload_delete_loopback *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_delete_loopback_msg_size(vapi_msg_delete_loopback *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_delete_loopback_hton(vapi_msg_delete_loopback *msg)
{
  VAPI_DBG("Swapping `vapi_msg_delete_loopback'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_delete_loopback_payload_hton(&msg->payload);
}

static inline void vapi_msg_delete_loopback_ntoh(vapi_msg_delete_loopback *msg)
{
  VAPI_DBG("Swapping `vapi_msg_delete_loopback'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_delete_loopback_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_pg_create_interface_payload_hton(vapi_payload_pg_create_interface *payload)
{
  payload->interface_id = htobe32(payload->interface_id);
}

static inline void vapi_msg_pg_create_interface_payload_ntoh(vapi_payload_pg_create_interface *payload)
{
  payload->interface_id = be32toh(payload->interface_id);
}

static inline uword vapi_calc_pg_create_interface_msg_size(vapi_msg_pg_create_interface *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_pg_create_interface_hton(vapi_msg_pg_create_interface *msg)
{
  VAPI_DBG("Swapping `vapi_msg_pg_create_interface'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_pg_create_interface_payload_hton(&msg->payload);
}

static inline void vapi_msg_pg_create_interface_ntoh(vapi_msg_pg_create_interface *msg)
{
  VAPI_DBG("Swapping `vapi_msg_pg_create_interface'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_pg_create_interface_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ioam_enable_reply_payload_hton(vapi_payload_ioam_enable_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_ioam_enable_reply_payload_ntoh(vapi_payload_ioam_enable_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_ioam_enable_reply_msg_size(vapi_msg_ioam_enable_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ioam_enable_reply_hton(vapi_msg_ioam_enable_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ioam_enable_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_ioam_enable_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_ioam_enable_reply_ntoh(vapi_msg_ioam_enable_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ioam_enable_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_ioam_enable_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_create_subif_payload_hton(vapi_payload_create_subif *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
  payload->sub_id = htobe32(payload->sub_id);
  payload->outer_vlan_id = htobe16(payload->outer_vlan_id);
  payload->inner_vlan_id = htobe16(payload->inner_vlan_id);
}

static inline void vapi_msg_create_subif_payload_ntoh(vapi_payload_create_subif *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
  payload->sub_id = be32toh(payload->sub_id);
  payload->outer_vlan_id = be16toh(payload->outer_vlan_id);
  payload->inner_vlan_id = be16toh(payload->inner_vlan_id);
}

static inline uword vapi_calc_create_subif_msg_size(vapi_msg_create_subif *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_create_subif_hton(vapi_msg_create_subif *msg)
{
  VAPI_DBG("Swapping `vapi_msg_create_subif'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_create_subif_payload_hton(&msg->payload);
}

static inline void vapi_msg_create_subif_ntoh(vapi_msg_create_subif *msg)
{
  VAPI_DBG("Swapping `vapi_msg_create_subif'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_create_subif_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_cli_inband_payload_hton(vapi_payload_cli_inband *payload)
{
  payload->length = htobe32(payload->length);
}

static inline void vapi_msg_cli_inband_payload_ntoh(vapi_payload_cli_inband *payload)
{
  payload->length = be32toh(payload->length);
}

static inline uword vapi_calc_cli_inband_msg_size(vapi_msg_cli_inband *msg)
{
  return sizeof(*msg)+ msg->payload.length * sizeof(msg->payload.cmd[0]);
}

static inline void vapi_msg_cli_inband_hton(vapi_msg_cli_inband *msg)
{
  VAPI_DBG("Swapping `vapi_msg_cli_inband'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_cli_inband_payload_hton(&msg->payload);
}

static inline void vapi_msg_cli_inband_ntoh(vapi_msg_cli_inband *msg)
{
  VAPI_DBG("Swapping `vapi_msg_cli_inband'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_cli_inband_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_want_ip4_arp_events_reply_payload_hton(vapi_payload_want_ip4_arp_events_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_want_ip4_arp_events_reply_payload_ntoh(vapi_payload_want_ip4_arp_events_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_want_ip4_arp_events_reply_msg_size(vapi_msg_want_ip4_arp_events_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_want_ip4_arp_events_reply_hton(vapi_msg_want_ip4_arp_events_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_ip4_arp_events_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_want_ip4_arp_events_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_want_ip4_arp_events_reply_ntoh(vapi_msg_want_ip4_arp_events_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_ip4_arp_events_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_want_ip4_arp_events_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_delete_subif_payload_hton(vapi_payload_delete_subif *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_delete_subif_payload_ntoh(vapi_payload_delete_subif *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_delete_subif_msg_size(vapi_msg_delete_subif *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_delete_subif_hton(vapi_msg_delete_subif *msg)
{
  VAPI_DBG("Swapping `vapi_msg_delete_subif'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_delete_subif_payload_hton(&msg->payload);
}

static inline void vapi_msg_delete_subif_ntoh(vapi_msg_delete_subif *msg)
{
  VAPI_DBG("Swapping `vapi_msg_delete_subif'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_delete_subif_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_reset_vrf_reply_payload_hton(vapi_payload_reset_vrf_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_reset_vrf_reply_payload_ntoh(vapi_payload_reset_vrf_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_reset_vrf_reply_msg_size(vapi_msg_reset_vrf_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_reset_vrf_reply_hton(vapi_msg_reset_vrf_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_reset_vrf_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_reset_vrf_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_reset_vrf_reply_ntoh(vapi_msg_reset_vrf_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_reset_vrf_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_reset_vrf_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_feature_enable_disable_reply_payload_hton(vapi_payload_feature_enable_disable_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_feature_enable_disable_reply_payload_ntoh(vapi_payload_feature_enable_disable_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_feature_enable_disable_reply_msg_size(vapi_msg_feature_enable_disable_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_feature_enable_disable_reply_hton(vapi_msg_feature_enable_disable_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_feature_enable_disable_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_feature_enable_disable_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_feature_enable_disable_reply_ntoh(vapi_msg_feature_enable_disable_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_feature_enable_disable_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_feature_enable_disable_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_create_subif_reply_payload_hton(vapi_payload_create_subif_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_create_subif_reply_payload_ntoh(vapi_payload_create_subif_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_create_subif_reply_msg_size(vapi_msg_create_subif_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_create_subif_reply_hton(vapi_msg_create_subif_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_create_subif_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_create_subif_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_create_subif_reply_ntoh(vapi_msg_create_subif_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_create_subif_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_create_subif_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_punt_socket_register_payload_hton(vapi_payload_punt_socket_register *payload)
{
  payload->header_version = htobe32(payload->header_version);
  payload->l4_port = htobe16(payload->l4_port);
}

static inline void vapi_msg_punt_socket_register_payload_ntoh(vapi_payload_punt_socket_register *payload)
{
  payload->header_version = be32toh(payload->header_version);
  payload->l4_port = be16toh(payload->l4_port);
}

static inline uword vapi_calc_punt_socket_register_msg_size(vapi_msg_punt_socket_register *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_punt_socket_register_hton(vapi_msg_punt_socket_register *msg)
{
  VAPI_DBG("Swapping `vapi_msg_punt_socket_register'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_punt_socket_register_payload_hton(&msg->payload);
}

static inline void vapi_msg_punt_socket_register_ntoh(vapi_msg_punt_socket_register *msg)
{
  VAPI_DBG("Swapping `vapi_msg_punt_socket_register'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_punt_socket_register_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_want_oam_events_reply_payload_hton(vapi_payload_want_oam_events_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_want_oam_events_reply_payload_ntoh(vapi_payload_want_oam_events_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_want_oam_events_reply_msg_size(vapi_msg_want_oam_events_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_want_oam_events_reply_hton(vapi_msg_want_oam_events_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_oam_events_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_want_oam_events_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_want_oam_events_reply_ntoh(vapi_msg_want_oam_events_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_oam_events_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_want_oam_events_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_want_oam_events_payload_hton(vapi_payload_want_oam_events *payload)
{
  payload->enable_disable = htobe32(payload->enable_disable);
  payload->pid = htobe32(payload->pid);
}

static inline void vapi_msg_want_oam_events_payload_ntoh(vapi_payload_want_oam_events *payload)
{
  payload->enable_disable = be32toh(payload->enable_disable);
  payload->pid = be32toh(payload->pid);
}

static inline uword vapi_calc_want_oam_events_msg_size(vapi_msg_want_oam_events *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_want_oam_events_hton(vapi_msg_want_oam_events *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_oam_events'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_want_oam_events_payload_hton(&msg->payload);
}

static inline void vapi_msg_want_oam_events_ntoh(vapi_msg_want_oam_events *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_oam_events'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_want_oam_events_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ip_source_and_port_range_check_add_del_reply_payload_hton(vapi_payload_ip_source_and_port_range_check_add_del_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_ip_source_and_port_range_check_add_del_reply_payload_ntoh(vapi_payload_ip_source_and_port_range_check_add_del_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_ip_source_and_port_range_check_add_del_reply_msg_size(vapi_msg_ip_source_and_port_range_check_add_del_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ip_source_and_port_range_check_add_del_reply_hton(vapi_msg_ip_source_and_port_range_check_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_source_and_port_range_check_add_del_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_ip_source_and_port_range_check_add_del_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_ip_source_and_port_range_check_add_del_reply_ntoh(vapi_msg_ip_source_and_port_range_check_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_source_and_port_range_check_add_del_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_ip_source_and_port_range_check_add_del_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_classify_set_interface_ip_table_reply_payload_hton(vapi_payload_classify_set_interface_ip_table_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_classify_set_interface_ip_table_reply_payload_ntoh(vapi_payload_classify_set_interface_ip_table_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_classify_set_interface_ip_table_reply_msg_size(vapi_msg_classify_set_interface_ip_table_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_classify_set_interface_ip_table_reply_hton(vapi_msg_classify_set_interface_ip_table_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_classify_set_interface_ip_table_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_classify_set_interface_ip_table_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_classify_set_interface_ip_table_reply_ntoh(vapi_msg_classify_set_interface_ip_table_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_classify_set_interface_ip_table_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_classify_set_interface_ip_table_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_create_loopback_instance_payload_hton(vapi_payload_create_loopback_instance *payload)
{
  payload->user_instance = htobe32(payload->user_instance);
}

static inline void vapi_msg_create_loopback_instance_payload_ntoh(vapi_payload_create_loopback_instance *payload)
{
  payload->user_instance = be32toh(payload->user_instance);
}

static inline uword vapi_calc_create_loopback_instance_msg_size(vapi_msg_create_loopback_instance *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_create_loopback_instance_hton(vapi_msg_create_loopback_instance *msg)
{
  VAPI_DBG("Swapping `vapi_msg_create_loopback_instance'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_create_loopback_instance_payload_hton(&msg->payload);
}

static inline void vapi_msg_create_loopback_instance_ntoh(vapi_msg_create_loopback_instance *msg)
{
  VAPI_DBG("Swapping `vapi_msg_create_loopback_instance'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_create_loopback_instance_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_l2_xconnect_reply_payload_hton(vapi_payload_sw_interface_set_l2_xconnect_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_sw_interface_set_l2_xconnect_reply_payload_ntoh(vapi_payload_sw_interface_set_l2_xconnect_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_sw_interface_set_l2_xconnect_reply_msg_size(vapi_msg_sw_interface_set_l2_xconnect_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_set_l2_xconnect_reply_hton(vapi_msg_sw_interface_set_l2_xconnect_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_l2_xconnect_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_sw_interface_set_l2_xconnect_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_l2_xconnect_reply_ntoh(vapi_msg_sw_interface_set_l2_xconnect_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_l2_xconnect_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_sw_interface_set_l2_xconnect_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_cli_inband_reply_payload_hton(vapi_payload_cli_inband_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->length = htobe32(payload->length);
}

static inline void vapi_msg_cli_inband_reply_payload_ntoh(vapi_payload_cli_inband_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->length = be32toh(payload->length);
}

static inline uword vapi_calc_cli_inband_reply_msg_size(vapi_msg_cli_inband_reply *msg)
{
  return sizeof(*msg)+ msg->payload.length * sizeof(msg->payload.reply[0]);
}

static inline void vapi_msg_cli_inband_reply_hton(vapi_msg_cli_inband_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_cli_inband_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_cli_inband_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_cli_inband_reply_ntoh(vapi_msg_cli_inband_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_cli_inband_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_cli_inband_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_input_acl_set_interface_payload_hton(vapi_payload_input_acl_set_interface *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
  payload->ip4_table_index = htobe32(payload->ip4_table_index);
  payload->ip6_table_index = htobe32(payload->ip6_table_index);
  payload->l2_table_index = htobe32(payload->l2_table_index);
}

static inline void vapi_msg_input_acl_set_interface_payload_ntoh(vapi_payload_input_acl_set_interface *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
  payload->ip4_table_index = be32toh(payload->ip4_table_index);
  payload->ip6_table_index = be32toh(payload->ip6_table_index);
  payload->l2_table_index = be32toh(payload->l2_table_index);
}

static inline uword vapi_calc_input_acl_set_interface_msg_size(vapi_msg_input_acl_set_interface *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_input_acl_set_interface_hton(vapi_msg_input_acl_set_interface *msg)
{
  VAPI_DBG("Swapping `vapi_msg_input_acl_set_interface'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_input_acl_set_interface_payload_hton(&msg->payload);
}

static inline void vapi_msg_input_acl_set_interface_ntoh(vapi_msg_input_acl_set_interface *msg)
{
  VAPI_DBG("Swapping `vapi_msg_input_acl_set_interface'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_input_acl_set_interface_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ioam_disable_payload_hton(vapi_payload_ioam_disable *payload)
{
  payload->id = htobe16(payload->id);
}

static inline void vapi_msg_ioam_disable_payload_ntoh(vapi_payload_ioam_disable *payload)
{
  payload->id = be16toh(payload->id);
}

static inline uword vapi_calc_ioam_disable_msg_size(vapi_msg_ioam_disable *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ioam_disable_hton(vapi_msg_ioam_disable *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ioam_disable'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_ioam_disable_payload_hton(&msg->payload);
}

static inline void vapi_msg_ioam_disable_ntoh(vapi_msg_ioam_disable *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ioam_disable'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_ioam_disable_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_proxy_arp_add_del_reply_payload_hton(vapi_payload_proxy_arp_add_del_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_proxy_arp_add_del_reply_payload_ntoh(vapi_payload_proxy_arp_add_del_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_proxy_arp_add_del_reply_msg_size(vapi_msg_proxy_arp_add_del_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_proxy_arp_add_del_reply_hton(vapi_msg_proxy_arp_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_proxy_arp_add_del_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_proxy_arp_add_del_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_proxy_arp_add_del_reply_ntoh(vapi_msg_proxy_arp_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_proxy_arp_add_del_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_proxy_arp_add_del_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_create_vlan_subif_reply_payload_hton(vapi_payload_create_vlan_subif_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_create_vlan_subif_reply_payload_ntoh(vapi_payload_create_vlan_subif_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_create_vlan_subif_reply_msg_size(vapi_msg_create_vlan_subif_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_create_vlan_subif_reply_hton(vapi_msg_create_vlan_subif_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_create_vlan_subif_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_create_vlan_subif_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_create_vlan_subif_reply_ntoh(vapi_msg_create_vlan_subif_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_create_vlan_subif_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_create_vlan_subif_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_reset_fib_payload_hton(vapi_payload_reset_fib *payload)
{
  payload->vrf_id = htobe32(payload->vrf_id);
}

static inline void vapi_msg_reset_fib_payload_ntoh(vapi_payload_reset_fib *payload)
{
  payload->vrf_id = be32toh(payload->vrf_id);
}

static inline uword vapi_calc_reset_fib_msg_size(vapi_msg_reset_fib *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_reset_fib_hton(vapi_msg_reset_fib *msg)
{
  VAPI_DBG("Swapping `vapi_msg_reset_fib'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_reset_fib_payload_hton(&msg->payload);
}

static inline void vapi_msg_reset_fib_ntoh(vapi_msg_reset_fib *msg)
{
  VAPI_DBG("Swapping `vapi_msg_reset_fib'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_reset_fib_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_pg_enable_disable_payload_hton(vapi_payload_pg_enable_disable *payload)
{
  payload->stream_name_length = htobe32(payload->stream_name_length);
}

static inline void vapi_msg_pg_enable_disable_payload_ntoh(vapi_payload_pg_enable_disable *payload)
{
  payload->stream_name_length = be32toh(payload->stream_name_length);
}

static inline uword vapi_calc_pg_enable_disable_msg_size(vapi_msg_pg_enable_disable *msg)
{
  return sizeof(*msg)+ msg->payload.stream_name_length * sizeof(msg->payload.stream_name[0]);
}

static inline void vapi_msg_pg_enable_disable_hton(vapi_msg_pg_enable_disable *msg)
{
  VAPI_DBG("Swapping `vapi_msg_pg_enable_disable'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_pg_enable_disable_payload_hton(&msg->payload);
}

static inline void vapi_msg_pg_enable_disable_ntoh(vapi_msg_pg_enable_disable *msg)
{
  VAPI_DBG("Swapping `vapi_msg_pg_enable_disable'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_pg_enable_disable_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_want_ip6_nd_events_payload_hton(vapi_payload_want_ip6_nd_events *payload)
{
  payload->pid = htobe32(payload->pid);
}

static inline void vapi_msg_want_ip6_nd_events_payload_ntoh(vapi_payload_want_ip6_nd_events *payload)
{
  payload->pid = be32toh(payload->pid);
}

static inline uword vapi_calc_want_ip6_nd_events_msg_size(vapi_msg_want_ip6_nd_events *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_want_ip6_nd_events_hton(vapi_msg_want_ip6_nd_events *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_ip6_nd_events'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_want_ip6_nd_events_payload_hton(&msg->payload);
}

static inline void vapi_msg_want_ip6_nd_events_ntoh(vapi_msg_want_ip6_nd_events *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_ip6_nd_events'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_want_ip6_nd_events_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_l2_patch_add_del_payload_hton(vapi_payload_l2_patch_add_del *payload)
{
  payload->rx_sw_if_index = htobe32(payload->rx_sw_if_index);
  payload->tx_sw_if_index = htobe32(payload->tx_sw_if_index);
}

static inline void vapi_msg_l2_patch_add_del_payload_ntoh(vapi_payload_l2_patch_add_del *payload)
{
  payload->rx_sw_if_index = be32toh(payload->rx_sw_if_index);
  payload->tx_sw_if_index = be32toh(payload->tx_sw_if_index);
}

static inline uword vapi_calc_l2_patch_add_del_msg_size(vapi_msg_l2_patch_add_del *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_l2_patch_add_del_hton(vapi_msg_l2_patch_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_l2_patch_add_del'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_l2_patch_add_del_payload_hton(&msg->payload);
}

static inline void vapi_msg_l2_patch_add_del_ntoh(vapi_msg_l2_patch_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_l2_patch_add_del'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_l2_patch_add_del_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_cli_reply_payload_hton(vapi_payload_cli_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->reply_in_shmem = htobe64(payload->reply_in_shmem);
}

static inline void vapi_msg_cli_reply_payload_ntoh(vapi_payload_cli_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->reply_in_shmem = be64toh(payload->reply_in_shmem);
}

static inline uword vapi_calc_cli_reply_msg_size(vapi_msg_cli_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_cli_reply_hton(vapi_msg_cli_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_cli_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_cli_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_cli_reply_ntoh(vapi_msg_cli_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_cli_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_cli_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_proxy_arp_intfc_enable_disable_reply_payload_hton(vapi_payload_proxy_arp_intfc_enable_disable_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_proxy_arp_intfc_enable_disable_reply_payload_ntoh(vapi_payload_proxy_arp_intfc_enable_disable_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_proxy_arp_intfc_enable_disable_reply_msg_size(vapi_msg_proxy_arp_intfc_enable_disable_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_proxy_arp_intfc_enable_disable_reply_hton(vapi_msg_proxy_arp_intfc_enable_disable_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_proxy_arp_intfc_enable_disable_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_proxy_arp_intfc_enable_disable_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_proxy_arp_intfc_enable_disable_reply_ntoh(vapi_msg_proxy_arp_intfc_enable_disable_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_proxy_arp_intfc_enable_disable_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_proxy_arp_intfc_enable_disable_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_control_ping_reply_payload_hton(vapi_payload_control_ping_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->client_index = htobe32(payload->client_index);
  payload->vpe_pid = htobe32(payload->vpe_pid);
}

static inline void vapi_msg_control_ping_reply_payload_ntoh(vapi_payload_control_ping_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->client_index = be32toh(payload->client_index);
  payload->vpe_pid = be32toh(payload->vpe_pid);
}

static inline uword vapi_calc_control_ping_reply_msg_size(vapi_msg_control_ping_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_control_ping_reply_hton(vapi_msg_control_ping_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_control_ping_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_control_ping_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_control_ping_reply_ntoh(vapi_msg_control_ping_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_control_ping_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_control_ping_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_oam_event_payload_hton(vapi_payload_oam_event *payload)
{
  payload->_vl_msg_id = htobe16(payload->_vl_msg_id);
}

static inline void vapi_msg_oam_event_payload_ntoh(vapi_payload_oam_event *payload)
{
  payload->_vl_msg_id = be16toh(payload->_vl_msg_id);
}

static inline uword vapi_calc_oam_event_msg_size(vapi_msg_oam_event *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_oam_event_hton(vapi_msg_oam_event *msg)
{
  VAPI_DBG("Swapping `vapi_msg_oam_event'@%p to big endian", msg);

  vapi_msg_oam_event_payload_hton(&msg->payload);
}

static inline void vapi_msg_oam_event_ntoh(vapi_msg_oam_event *msg)
{
  VAPI_DBG("Swapping `vapi_msg_oam_event'@%p to host byte order", msg);

  vapi_msg_oam_event_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_show_version_msg_size(vapi_msg_show_version *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_show_version_hton(vapi_msg_show_version *msg)
{
  VAPI_DBG("Swapping `vapi_msg_show_version'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_show_version_ntoh(vapi_msg_show_version *msg)
{
  VAPI_DBG("Swapping `vapi_msg_show_version'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_classify_set_interface_l2_tables_payload_hton(vapi_payload_classify_set_interface_l2_tables *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
  payload->ip4_table_index = htobe32(payload->ip4_table_index);
  payload->ip6_table_index = htobe32(payload->ip6_table_index);
  payload->other_table_index = htobe32(payload->other_table_index);
}

static inline void vapi_msg_classify_set_interface_l2_tables_payload_ntoh(vapi_payload_classify_set_interface_l2_tables *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
  payload->ip4_table_index = be32toh(payload->ip4_table_index);
  payload->ip6_table_index = be32toh(payload->ip6_table_index);
  payload->other_table_index = be32toh(payload->other_table_index);
}

static inline uword vapi_calc_classify_set_interface_l2_tables_msg_size(vapi_msg_classify_set_interface_l2_tables *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_classify_set_interface_l2_tables_hton(vapi_msg_classify_set_interface_l2_tables *msg)
{
  VAPI_DBG("Swapping `vapi_msg_classify_set_interface_l2_tables'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_classify_set_interface_l2_tables_payload_hton(&msg->payload);
}

static inline void vapi_msg_classify_set_interface_l2_tables_ntoh(vapi_msg_classify_set_interface_l2_tables *msg)
{
  VAPI_DBG("Swapping `vapi_msg_classify_set_interface_l2_tables'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_classify_set_interface_l2_tables_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_reset_vrf_payload_hton(vapi_payload_reset_vrf *payload)
{
  payload->vrf_id = htobe32(payload->vrf_id);
}

static inline void vapi_msg_reset_vrf_payload_ntoh(vapi_payload_reset_vrf *payload)
{
  payload->vrf_id = be32toh(payload->vrf_id);
}

static inline uword vapi_calc_reset_vrf_msg_size(vapi_msg_reset_vrf *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_reset_vrf_hton(vapi_msg_reset_vrf *msg)
{
  VAPI_DBG("Swapping `vapi_msg_reset_vrf'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_reset_vrf_payload_hton(&msg->payload);
}

static inline void vapi_msg_reset_vrf_ntoh(vapi_msg_reset_vrf *msg)
{
  VAPI_DBG("Swapping `vapi_msg_reset_vrf'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_reset_vrf_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_input_acl_set_interface_reply_payload_hton(vapi_payload_input_acl_set_interface_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_input_acl_set_interface_reply_payload_ntoh(vapi_payload_input_acl_set_interface_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_input_acl_set_interface_reply_msg_size(vapi_msg_input_acl_set_interface_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_input_acl_set_interface_reply_hton(vapi_msg_input_acl_set_interface_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_input_acl_set_interface_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_input_acl_set_interface_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_input_acl_set_interface_reply_ntoh(vapi_msg_input_acl_set_interface_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_input_acl_set_interface_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_input_acl_set_interface_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_bd_ip_mac_add_del_payload_hton(vapi_payload_bd_ip_mac_add_del *payload)
{
  payload->bd_id = htobe32(payload->bd_id);
}

static inline void vapi_msg_bd_ip_mac_add_del_payload_ntoh(vapi_payload_bd_ip_mac_add_del *payload)
{
  payload->bd_id = be32toh(payload->bd_id);
}

static inline uword vapi_calc_bd_ip_mac_add_del_msg_size(vapi_msg_bd_ip_mac_add_del *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_bd_ip_mac_add_del_hton(vapi_msg_bd_ip_mac_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_bd_ip_mac_add_del'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_bd_ip_mac_add_del_payload_hton(&msg->payload);
}

static inline void vapi_msg_bd_ip_mac_add_del_ntoh(vapi_msg_bd_ip_mac_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_bd_ip_mac_add_del'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_bd_ip_mac_add_del_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_l2_bridge_reply_payload_hton(vapi_payload_sw_interface_set_l2_bridge_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_sw_interface_set_l2_bridge_reply_payload_ntoh(vapi_payload_sw_interface_set_l2_bridge_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_sw_interface_set_l2_bridge_reply_msg_size(vapi_msg_sw_interface_set_l2_bridge_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_set_l2_bridge_reply_hton(vapi_msg_sw_interface_set_l2_bridge_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_l2_bridge_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_sw_interface_set_l2_bridge_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_l2_bridge_reply_ntoh(vapi_msg_sw_interface_set_l2_bridge_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_l2_bridge_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_sw_interface_set_l2_bridge_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_oam_add_del_payload_hton(vapi_payload_oam_add_del *payload)
{
  payload->vrf_id = htobe32(payload->vrf_id);
}

static inline void vapi_msg_oam_add_del_payload_ntoh(vapi_payload_oam_add_del *payload)
{
  payload->vrf_id = be32toh(payload->vrf_id);
}

static inline uword vapi_calc_oam_add_del_msg_size(vapi_msg_oam_add_del *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_oam_add_del_hton(vapi_msg_oam_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_oam_add_del'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_oam_add_del_payload_hton(&msg->payload);
}

static inline void vapi_msg_oam_add_del_ntoh(vapi_msg_oam_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_oam_add_del'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_oam_add_del_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_get_node_graph_msg_size(vapi_msg_get_node_graph *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_get_node_graph_hton(vapi_msg_get_node_graph *msg)
{
  VAPI_DBG("Swapping `vapi_msg_get_node_graph'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_get_node_graph_ntoh(vapi_msg_get_node_graph *msg)
{
  VAPI_DBG("Swapping `vapi_msg_get_node_graph'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_interface_name_renumber_payload_hton(vapi_payload_interface_name_renumber *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
  payload->new_show_dev_instance = htobe32(payload->new_show_dev_instance);
}

static inline void vapi_msg_interface_name_renumber_payload_ntoh(vapi_payload_interface_name_renumber *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
  payload->new_show_dev_instance = be32toh(payload->new_show_dev_instance);
}

static inline uword vapi_calc_interface_name_renumber_msg_size(vapi_msg_interface_name_renumber *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_interface_name_renumber_hton(vapi_msg_interface_name_renumber *msg)
{
  VAPI_DBG("Swapping `vapi_msg_interface_name_renumber'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_interface_name_renumber_payload_hton(&msg->payload);
}

static inline void vapi_msg_interface_name_renumber_ntoh(vapi_msg_interface_name_renumber *msg)
{
  VAPI_DBG("Swapping `vapi_msg_interface_name_renumber'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_interface_name_renumber_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_pg_enable_disable_reply_payload_hton(vapi_payload_pg_enable_disable_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_pg_enable_disable_reply_payload_ntoh(vapi_payload_pg_enable_disable_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_pg_enable_disable_reply_msg_size(vapi_msg_pg_enable_disable_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_pg_enable_disable_reply_hton(vapi_msg_pg_enable_disable_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_pg_enable_disable_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_pg_enable_disable_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_pg_enable_disable_reply_ntoh(vapi_msg_pg_enable_disable_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_pg_enable_disable_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_pg_enable_disable_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_create_loopback_payload_hton(vapi_payload_create_loopback *payload)
{

}

static inline void vapi_msg_create_loopback_payload_ntoh(vapi_payload_create_loopback *payload)
{

}

static inline uword vapi_calc_create_loopback_msg_size(vapi_msg_create_loopback *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_create_loopback_hton(vapi_msg_create_loopback *msg)
{
  VAPI_DBG("Swapping `vapi_msg_create_loopback'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_create_loopback_payload_hton(&msg->payload);
}

static inline void vapi_msg_create_loopback_ntoh(vapi_msg_create_loopback *msg)
{
  VAPI_DBG("Swapping `vapi_msg_create_loopback'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_create_loopback_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_create_loopback_reply_payload_hton(vapi_payload_create_loopback_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_create_loopback_reply_payload_ntoh(vapi_payload_create_loopback_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_create_loopback_reply_msg_size(vapi_msg_create_loopback_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_create_loopback_reply_hton(vapi_msg_create_loopback_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_create_loopback_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_create_loopback_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_create_loopback_reply_ntoh(vapi_msg_create_loopback_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_create_loopback_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_create_loopback_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_set_arp_neighbor_limit_reply_payload_hton(vapi_payload_set_arp_neighbor_limit_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_set_arp_neighbor_limit_reply_payload_ntoh(vapi_payload_set_arp_neighbor_limit_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_set_arp_neighbor_limit_reply_msg_size(vapi_msg_set_arp_neighbor_limit_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_set_arp_neighbor_limit_reply_hton(vapi_msg_set_arp_neighbor_limit_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_set_arp_neighbor_limit_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_set_arp_neighbor_limit_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_set_arp_neighbor_limit_reply_ntoh(vapi_msg_set_arp_neighbor_limit_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_set_arp_neighbor_limit_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_set_arp_neighbor_limit_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_add_node_next_reply_payload_hton(vapi_payload_add_node_next_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->next_index = htobe32(payload->next_index);
}

static inline void vapi_msg_add_node_next_reply_payload_ntoh(vapi_payload_add_node_next_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->next_index = be32toh(payload->next_index);
}

static inline uword vapi_calc_add_node_next_reply_msg_size(vapi_msg_add_node_next_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_add_node_next_reply_hton(vapi_msg_add_node_next_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_add_node_next_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_add_node_next_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_add_node_next_reply_ntoh(vapi_msg_add_node_next_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_add_node_next_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_add_node_next_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_mpls_enable_payload_hton(vapi_payload_sw_interface_set_mpls_enable *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_sw_interface_set_mpls_enable_payload_ntoh(vapi_payload_sw_interface_set_mpls_enable *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_sw_interface_set_mpls_enable_msg_size(vapi_msg_sw_interface_set_mpls_enable *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_set_mpls_enable_hton(vapi_msg_sw_interface_set_mpls_enable *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_mpls_enable'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_sw_interface_set_mpls_enable_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_mpls_enable_ntoh(vapi_msg_sw_interface_set_mpls_enable *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_mpls_enable'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_sw_interface_set_mpls_enable_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_punt_socket_deregister_payload_hton(vapi_payload_punt_socket_deregister *payload)
{
  payload->l4_port = htobe16(payload->l4_port);
}

static inline void vapi_msg_punt_socket_deregister_payload_ntoh(vapi_payload_punt_socket_deregister *payload)
{
  payload->l4_port = be16toh(payload->l4_port);
}

static inline uword vapi_calc_punt_socket_deregister_msg_size(vapi_msg_punt_socket_deregister *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_punt_socket_deregister_hton(vapi_msg_punt_socket_deregister *msg)
{
  VAPI_DBG("Swapping `vapi_msg_punt_socket_deregister'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_punt_socket_deregister_payload_hton(&msg->payload);
}

static inline void vapi_msg_punt_socket_deregister_ntoh(vapi_msg_punt_socket_deregister *msg)
{
  VAPI_DBG("Swapping `vapi_msg_punt_socket_deregister'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_punt_socket_deregister_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_ip_source_and_port_range_check_interface_add_del_payload_hton(vapi_payload_ip_source_and_port_range_check_interface_add_del *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
  payload->tcp_in_vrf_id = htobe32(payload->tcp_in_vrf_id);
  payload->tcp_out_vrf_id = htobe32(payload->tcp_out_vrf_id);
  payload->udp_in_vrf_id = htobe32(payload->udp_in_vrf_id);
  payload->udp_out_vrf_id = htobe32(payload->udp_out_vrf_id);
}

static inline void vapi_msg_ip_source_and_port_range_check_interface_add_del_payload_ntoh(vapi_payload_ip_source_and_port_range_check_interface_add_del *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
  payload->tcp_in_vrf_id = be32toh(payload->tcp_in_vrf_id);
  payload->tcp_out_vrf_id = be32toh(payload->tcp_out_vrf_id);
  payload->udp_in_vrf_id = be32toh(payload->udp_in_vrf_id);
  payload->udp_out_vrf_id = be32toh(payload->udp_out_vrf_id);
}

static inline uword vapi_calc_ip_source_and_port_range_check_interface_add_del_msg_size(vapi_msg_ip_source_and_port_range_check_interface_add_del *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_ip_source_and_port_range_check_interface_add_del_hton(vapi_msg_ip_source_and_port_range_check_interface_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_source_and_port_range_check_interface_add_del'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_ip_source_and_port_range_check_interface_add_del_payload_hton(&msg->payload);
}

static inline void vapi_msg_ip_source_and_port_range_check_interface_add_del_ntoh(vapi_msg_ip_source_and_port_range_check_interface_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_ip_source_and_port_range_check_interface_add_del'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_ip_source_and_port_range_check_interface_add_del_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_punt_reply_payload_hton(vapi_payload_punt_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_punt_reply_payload_ntoh(vapi_payload_punt_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_punt_reply_msg_size(vapi_msg_punt_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_punt_reply_hton(vapi_msg_punt_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_punt_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_punt_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_punt_reply_ntoh(vapi_msg_punt_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_punt_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_punt_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_control_ping_msg_size(vapi_msg_control_ping *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_control_ping_hton(vapi_msg_control_ping *msg)
{
  VAPI_DBG("Swapping `vapi_msg_control_ping'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_control_ping_ntoh(vapi_msg_control_ping *msg)
{
  VAPI_DBG("Swapping `vapi_msg_control_ping'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline vapi_msg_cli* vapi_alloc_cli(struct vapi_ctx_s *ctx)
{
  vapi_msg_cli *msg = NULL;
  const size_t size = sizeof(vapi_msg_cli);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_cli*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_cli);

  return msg;
}

static inline vapi_error_e vapi_cli(struct vapi_ctx_s *ctx,
  vapi_msg_cli *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_cli_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_cli_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_cli_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_ip_source_and_port_range_check_add_del* vapi_alloc_ip_source_and_port_range_check_add_del(struct vapi_ctx_s *ctx)
{
  vapi_msg_ip_source_and_port_range_check_add_del *msg = NULL;
  const size_t size = sizeof(vapi_msg_ip_source_and_port_range_check_add_del);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_ip_source_and_port_range_check_add_del*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_ip_source_and_port_range_check_add_del);

  return msg;
}

static inline vapi_error_e vapi_ip_source_and_port_range_check_add_del(struct vapi_ctx_s *ctx,
  vapi_msg_ip_source_and_port_range_check_add_del *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_ip_source_and_port_range_check_add_del_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_ip_source_and_port_range_check_add_del_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_ip_source_and_port_range_check_add_del_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_get_node_index* vapi_alloc_get_node_index(struct vapi_ctx_s *ctx)
{
  vapi_msg_get_node_index *msg = NULL;
  const size_t size = sizeof(vapi_msg_get_node_index);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_get_node_index*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_get_node_index);

  return msg;
}

static inline vapi_error_e vapi_get_node_index(struct vapi_ctx_s *ctx,
  vapi_msg_get_node_index *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_get_node_index_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_get_node_index_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_get_node_index_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_l2_interface_efp_filter* vapi_alloc_l2_interface_efp_filter(struct vapi_ctx_s *ctx)
{
  vapi_msg_l2_interface_efp_filter *msg = NULL;
  const size_t size = sizeof(vapi_msg_l2_interface_efp_filter);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_l2_interface_efp_filter*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_l2_interface_efp_filter);

  return msg;
}

static inline vapi_error_e vapi_l2_interface_efp_filter(struct vapi_ctx_s *ctx,
  vapi_msg_l2_interface_efp_filter *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_l2_interface_efp_filter_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_l2_interface_efp_filter_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_l2_interface_efp_filter_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_proxy_arp_intfc_enable_disable* vapi_alloc_proxy_arp_intfc_enable_disable(struct vapi_ctx_s *ctx)
{
  vapi_msg_proxy_arp_intfc_enable_disable *msg = NULL;
  const size_t size = sizeof(vapi_msg_proxy_arp_intfc_enable_disable);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_proxy_arp_intfc_enable_disable*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_proxy_arp_intfc_enable_disable);

  return msg;
}

static inline vapi_error_e vapi_proxy_arp_intfc_enable_disable(struct vapi_ctx_s *ctx,
  vapi_msg_proxy_arp_intfc_enable_disable *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_proxy_arp_intfc_enable_disable_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_proxy_arp_intfc_enable_disable_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_proxy_arp_intfc_enable_disable_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_feature_enable_disable* vapi_alloc_feature_enable_disable(struct vapi_ctx_s *ctx)
{
  vapi_msg_feature_enable_disable *msg = NULL;
  const size_t size = sizeof(vapi_msg_feature_enable_disable);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_feature_enable_disable*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_feature_enable_disable);

  return msg;
}

static inline vapi_error_e vapi_feature_enable_disable(struct vapi_ctx_s *ctx,
  vapi_msg_feature_enable_disable *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_feature_enable_disable_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_feature_enable_disable_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_feature_enable_disable_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_proxy_arp_add_del* vapi_alloc_proxy_arp_add_del(struct vapi_ctx_s *ctx)
{
  vapi_msg_proxy_arp_add_del *msg = NULL;
  const size_t size = sizeof(vapi_msg_proxy_arp_add_del);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_proxy_arp_add_del*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_proxy_arp_add_del);

  return msg;
}

static inline vapi_error_e vapi_proxy_arp_add_del(struct vapi_ctx_s *ctx,
  vapi_msg_proxy_arp_add_del *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_proxy_arp_add_del_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_proxy_arp_add_del_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_proxy_arp_add_del_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_classify_set_interface_ip_table* vapi_alloc_classify_set_interface_ip_table(struct vapi_ctx_s *ctx)
{
  vapi_msg_classify_set_interface_ip_table *msg = NULL;
  const size_t size = sizeof(vapi_msg_classify_set_interface_ip_table);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_classify_set_interface_ip_table*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_classify_set_interface_ip_table);

  return msg;
}

static inline vapi_error_e vapi_classify_set_interface_ip_table(struct vapi_ctx_s *ctx,
  vapi_msg_classify_set_interface_ip_table *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_classify_set_interface_ip_table_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_classify_set_interface_ip_table_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_classify_set_interface_ip_table_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_ioam_enable* vapi_alloc_ioam_enable(struct vapi_ctx_s *ctx)
{
  vapi_msg_ioam_enable *msg = NULL;
  const size_t size = sizeof(vapi_msg_ioam_enable);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_ioam_enable*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_ioam_enable);

  return msg;
}

static inline vapi_error_e vapi_ioam_enable(struct vapi_ctx_s *ctx,
  vapi_msg_ioam_enable *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_ioam_enable_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_ioam_enable_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_ioam_enable_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_get_next_index* vapi_alloc_get_next_index(struct vapi_ctx_s *ctx)
{
  vapi_msg_get_next_index *msg = NULL;
  const size_t size = sizeof(vapi_msg_get_next_index);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_get_next_index*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_get_next_index);

  return msg;
}

static inline vapi_error_e vapi_get_next_index(struct vapi_ctx_s *ctx,
  vapi_msg_get_next_index *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_get_next_index_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_get_next_index_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_get_next_index_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_sw_interface_set_vpath* vapi_alloc_sw_interface_set_vpath(struct vapi_ctx_s *ctx)
{
  vapi_msg_sw_interface_set_vpath *msg = NULL;
  const size_t size = sizeof(vapi_msg_sw_interface_set_vpath);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_sw_interface_set_vpath*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_sw_interface_set_vpath);

  return msg;
}

static inline vapi_error_e vapi_sw_interface_set_vpath(struct vapi_ctx_s *ctx,
  vapi_msg_sw_interface_set_vpath *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_sw_interface_set_vpath_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_sw_interface_set_vpath_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_sw_interface_set_vpath_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_sw_interface_set_l2_xconnect* vapi_alloc_sw_interface_set_l2_xconnect(struct vapi_ctx_s *ctx)
{
  vapi_msg_sw_interface_set_l2_xconnect *msg = NULL;
  const size_t size = sizeof(vapi_msg_sw_interface_set_l2_xconnect);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_sw_interface_set_l2_xconnect*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_sw_interface_set_l2_xconnect);

  return msg;
}

static inline vapi_error_e vapi_sw_interface_set_l2_xconnect(struct vapi_ctx_s *ctx,
  vapi_msg_sw_interface_set_l2_xconnect *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_sw_interface_set_l2_xconnect_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_sw_interface_set_l2_xconnect_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_sw_interface_set_l2_xconnect_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_set_arp_neighbor_limit* vapi_alloc_set_arp_neighbor_limit(struct vapi_ctx_s *ctx)
{
  vapi_msg_set_arp_neighbor_limit *msg = NULL;
  const size_t size = sizeof(vapi_msg_set_arp_neighbor_limit);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_set_arp_neighbor_limit*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_set_arp_neighbor_limit);

  return msg;
}

static inline vapi_error_e vapi_set_arp_neighbor_limit(struct vapi_ctx_s *ctx,
  vapi_msg_set_arp_neighbor_limit *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_set_arp_neighbor_limit_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_set_arp_neighbor_limit_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_set_arp_neighbor_limit_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_add_node_next* vapi_alloc_add_node_next(struct vapi_ctx_s *ctx)
{
  vapi_msg_add_node_next *msg = NULL;
  const size_t size = sizeof(vapi_msg_add_node_next);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_add_node_next*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_add_node_next);

  return msg;
}

static inline vapi_error_e vapi_add_node_next(struct vapi_ctx_s *ctx,
  vapi_msg_add_node_next *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_add_node_next_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_add_node_next_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_add_node_next_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_want_ip4_arp_events* vapi_alloc_want_ip4_arp_events(struct vapi_ctx_s *ctx)
{
  vapi_msg_want_ip4_arp_events *msg = NULL;
  const size_t size = sizeof(vapi_msg_want_ip4_arp_events);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_want_ip4_arp_events*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_want_ip4_arp_events);

  return msg;
}

static inline vapi_error_e vapi_want_ip4_arp_events(struct vapi_ctx_s *ctx,
  vapi_msg_want_ip4_arp_events *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_want_ip4_arp_events_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_want_ip4_arp_events_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_want_ip4_arp_events_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_pg_capture* vapi_alloc_pg_capture(struct vapi_ctx_s *ctx, size_t pcap_file_name_array_size)
{
  vapi_msg_pg_capture *msg = NULL;
  const size_t size = sizeof(vapi_msg_pg_capture) + sizeof(msg->payload.pcap_file_name[0]) * pcap_file_name_array_size;
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_pg_capture*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_pg_capture);
  msg->payload.pcap_name_length = pcap_file_name_array_size;
  return msg;
}

static inline vapi_error_e vapi_pg_capture(struct vapi_ctx_s *ctx,
  vapi_msg_pg_capture *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_pg_capture_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_pg_capture_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_pg_capture_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_create_vlan_subif* vapi_alloc_create_vlan_subif(struct vapi_ctx_s *ctx)
{
  vapi_msg_create_vlan_subif *msg = NULL;
  const size_t size = sizeof(vapi_msg_create_vlan_subif);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_create_vlan_subif*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_create_vlan_subif);

  return msg;
}

static inline vapi_error_e vapi_create_vlan_subif(struct vapi_ctx_s *ctx,
  vapi_msg_create_vlan_subif *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_create_vlan_subif_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_create_vlan_subif_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_create_vlan_subif_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_sw_interface_set_l2_bridge* vapi_alloc_sw_interface_set_l2_bridge(struct vapi_ctx_s *ctx)
{
  vapi_msg_sw_interface_set_l2_bridge *msg = NULL;
  const size_t size = sizeof(vapi_msg_sw_interface_set_l2_bridge);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_sw_interface_set_l2_bridge*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_sw_interface_set_l2_bridge);

  return msg;
}

static inline vapi_error_e vapi_sw_interface_set_l2_bridge(struct vapi_ctx_s *ctx,
  vapi_msg_sw_interface_set_l2_bridge *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_sw_interface_set_l2_bridge_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_sw_interface_set_l2_bridge_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_sw_interface_set_l2_bridge_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_punt* vapi_alloc_punt(struct vapi_ctx_s *ctx)
{
  vapi_msg_punt *msg = NULL;
  const size_t size = sizeof(vapi_msg_punt);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_punt*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_punt);

  return msg;
}

static inline vapi_error_e vapi_punt(struct vapi_ctx_s *ctx,
  vapi_msg_punt *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_punt_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_punt_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_punt_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_delete_loopback* vapi_alloc_delete_loopback(struct vapi_ctx_s *ctx)
{
  vapi_msg_delete_loopback *msg = NULL;
  const size_t size = sizeof(vapi_msg_delete_loopback);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_delete_loopback*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_delete_loopback);

  return msg;
}

static inline vapi_error_e vapi_delete_loopback(struct vapi_ctx_s *ctx,
  vapi_msg_delete_loopback *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_delete_loopback_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_delete_loopback_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_delete_loopback_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_pg_create_interface* vapi_alloc_pg_create_interface(struct vapi_ctx_s *ctx)
{
  vapi_msg_pg_create_interface *msg = NULL;
  const size_t size = sizeof(vapi_msg_pg_create_interface);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_pg_create_interface*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_pg_create_interface);

  return msg;
}

static inline vapi_error_e vapi_pg_create_interface(struct vapi_ctx_s *ctx,
  vapi_msg_pg_create_interface *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_pg_create_interface_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_pg_create_interface_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_pg_create_interface_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_create_subif* vapi_alloc_create_subif(struct vapi_ctx_s *ctx)
{
  vapi_msg_create_subif *msg = NULL;
  const size_t size = sizeof(vapi_msg_create_subif);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_create_subif*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_create_subif);

  return msg;
}

static inline vapi_error_e vapi_create_subif(struct vapi_ctx_s *ctx,
  vapi_msg_create_subif *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_create_subif_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_create_subif_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_create_subif_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_cli_inband* vapi_alloc_cli_inband(struct vapi_ctx_s *ctx, size_t cmd_array_size)
{
  vapi_msg_cli_inband *msg = NULL;
  const size_t size = sizeof(vapi_msg_cli_inband) + sizeof(msg->payload.cmd[0]) * cmd_array_size;
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_cli_inband*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_cli_inband);
  msg->payload.length = cmd_array_size;
  return msg;
}

static inline vapi_error_e vapi_cli_inband(struct vapi_ctx_s *ctx,
  vapi_msg_cli_inband *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_cli_inband_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_cli_inband_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_cli_inband_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_delete_subif* vapi_alloc_delete_subif(struct vapi_ctx_s *ctx)
{
  vapi_msg_delete_subif *msg = NULL;
  const size_t size = sizeof(vapi_msg_delete_subif);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_delete_subif*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_delete_subif);

  return msg;
}

static inline vapi_error_e vapi_delete_subif(struct vapi_ctx_s *ctx,
  vapi_msg_delete_subif *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_delete_subif_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_delete_subif_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_delete_subif_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_punt_socket_register* vapi_alloc_punt_socket_register(struct vapi_ctx_s *ctx)
{
  vapi_msg_punt_socket_register *msg = NULL;
  const size_t size = sizeof(vapi_msg_punt_socket_register);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_punt_socket_register*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_punt_socket_register);

  return msg;
}

static inline vapi_error_e vapi_punt_socket_register(struct vapi_ctx_s *ctx,
  vapi_msg_punt_socket_register *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_punt_socket_register_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_punt_socket_register_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_punt_socket_register_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_want_oam_events* vapi_alloc_want_oam_events(struct vapi_ctx_s *ctx)
{
  vapi_msg_want_oam_events *msg = NULL;
  const size_t size = sizeof(vapi_msg_want_oam_events);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_want_oam_events*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_want_oam_events);

  return msg;
}

static inline vapi_error_e vapi_want_oam_events(struct vapi_ctx_s *ctx,
  vapi_msg_want_oam_events *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_want_oam_events_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_want_oam_events_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_want_oam_events_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_create_loopback_instance* vapi_alloc_create_loopback_instance(struct vapi_ctx_s *ctx)
{
  vapi_msg_create_loopback_instance *msg = NULL;
  const size_t size = sizeof(vapi_msg_create_loopback_instance);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_create_loopback_instance*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_create_loopback_instance);

  return msg;
}

static inline vapi_error_e vapi_create_loopback_instance(struct vapi_ctx_s *ctx,
  vapi_msg_create_loopback_instance *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_create_loopback_instance_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_create_loopback_instance_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_create_loopback_instance_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_input_acl_set_interface* vapi_alloc_input_acl_set_interface(struct vapi_ctx_s *ctx)
{
  vapi_msg_input_acl_set_interface *msg = NULL;
  const size_t size = sizeof(vapi_msg_input_acl_set_interface);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_input_acl_set_interface*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_input_acl_set_interface);

  return msg;
}

static inline vapi_error_e vapi_input_acl_set_interface(struct vapi_ctx_s *ctx,
  vapi_msg_input_acl_set_interface *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_input_acl_set_interface_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_input_acl_set_interface_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_input_acl_set_interface_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_ioam_disable* vapi_alloc_ioam_disable(struct vapi_ctx_s *ctx)
{
  vapi_msg_ioam_disable *msg = NULL;
  const size_t size = sizeof(vapi_msg_ioam_disable);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_ioam_disable*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_ioam_disable);

  return msg;
}

static inline vapi_error_e vapi_ioam_disable(struct vapi_ctx_s *ctx,
  vapi_msg_ioam_disable *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_ioam_disable_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_ioam_disable_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_ioam_disable_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_reset_fib* vapi_alloc_reset_fib(struct vapi_ctx_s *ctx)
{
  vapi_msg_reset_fib *msg = NULL;
  const size_t size = sizeof(vapi_msg_reset_fib);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_reset_fib*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_reset_fib);

  return msg;
}

static inline vapi_error_e vapi_reset_fib(struct vapi_ctx_s *ctx,
  vapi_msg_reset_fib *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_reset_fib_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_reset_fib_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_reset_fib_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_pg_enable_disable* vapi_alloc_pg_enable_disable(struct vapi_ctx_s *ctx, size_t stream_name_array_size)
{
  vapi_msg_pg_enable_disable *msg = NULL;
  const size_t size = sizeof(vapi_msg_pg_enable_disable) + sizeof(msg->payload.stream_name[0]) * stream_name_array_size;
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_pg_enable_disable*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_pg_enable_disable);
  msg->payload.stream_name_length = stream_name_array_size;
  return msg;
}

static inline vapi_error_e vapi_pg_enable_disable(struct vapi_ctx_s *ctx,
  vapi_msg_pg_enable_disable *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_pg_enable_disable_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_pg_enable_disable_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_pg_enable_disable_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_want_ip6_nd_events* vapi_alloc_want_ip6_nd_events(struct vapi_ctx_s *ctx)
{
  vapi_msg_want_ip6_nd_events *msg = NULL;
  const size_t size = sizeof(vapi_msg_want_ip6_nd_events);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_want_ip6_nd_events*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_want_ip6_nd_events);

  return msg;
}

static inline vapi_error_e vapi_want_ip6_nd_events(struct vapi_ctx_s *ctx,
  vapi_msg_want_ip6_nd_events *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_want_ip6_nd_events_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_want_ip6_nd_events_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_want_ip6_nd_events_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_l2_patch_add_del* vapi_alloc_l2_patch_add_del(struct vapi_ctx_s *ctx)
{
  vapi_msg_l2_patch_add_del *msg = NULL;
  const size_t size = sizeof(vapi_msg_l2_patch_add_del);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_l2_patch_add_del*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_l2_patch_add_del);

  return msg;
}

static inline vapi_error_e vapi_l2_patch_add_del(struct vapi_ctx_s *ctx,
  vapi_msg_l2_patch_add_del *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_l2_patch_add_del_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_l2_patch_add_del_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_l2_patch_add_del_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_show_version* vapi_alloc_show_version(struct vapi_ctx_s *ctx)
{
  vapi_msg_show_version *msg = NULL;
  const size_t size = sizeof(vapi_msg_show_version);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_show_version*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_show_version);

  return msg;
}

static inline vapi_error_e vapi_show_version(struct vapi_ctx_s *ctx,
  vapi_msg_show_version *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_show_version_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_show_version_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_show_version_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_classify_set_interface_l2_tables* vapi_alloc_classify_set_interface_l2_tables(struct vapi_ctx_s *ctx)
{
  vapi_msg_classify_set_interface_l2_tables *msg = NULL;
  const size_t size = sizeof(vapi_msg_classify_set_interface_l2_tables);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_classify_set_interface_l2_tables*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_classify_set_interface_l2_tables);

  return msg;
}

static inline vapi_error_e vapi_classify_set_interface_l2_tables(struct vapi_ctx_s *ctx,
  vapi_msg_classify_set_interface_l2_tables *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_classify_set_interface_l2_tables_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_classify_set_interface_l2_tables_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_classify_set_interface_l2_tables_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_reset_vrf* vapi_alloc_reset_vrf(struct vapi_ctx_s *ctx)
{
  vapi_msg_reset_vrf *msg = NULL;
  const size_t size = sizeof(vapi_msg_reset_vrf);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_reset_vrf*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_reset_vrf);

  return msg;
}

static inline vapi_error_e vapi_reset_vrf(struct vapi_ctx_s *ctx,
  vapi_msg_reset_vrf *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_reset_vrf_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_reset_vrf_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_reset_vrf_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_bd_ip_mac_add_del* vapi_alloc_bd_ip_mac_add_del(struct vapi_ctx_s *ctx)
{
  vapi_msg_bd_ip_mac_add_del *msg = NULL;
  const size_t size = sizeof(vapi_msg_bd_ip_mac_add_del);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_bd_ip_mac_add_del*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_bd_ip_mac_add_del);

  return msg;
}

static inline vapi_error_e vapi_bd_ip_mac_add_del(struct vapi_ctx_s *ctx,
  vapi_msg_bd_ip_mac_add_del *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_bd_ip_mac_add_del_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_bd_ip_mac_add_del_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_bd_ip_mac_add_del_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_oam_add_del* vapi_alloc_oam_add_del(struct vapi_ctx_s *ctx)
{
  vapi_msg_oam_add_del *msg = NULL;
  const size_t size = sizeof(vapi_msg_oam_add_del);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_oam_add_del*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_oam_add_del);

  return msg;
}

static inline vapi_error_e vapi_oam_add_del(struct vapi_ctx_s *ctx,
  vapi_msg_oam_add_del *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_oam_add_del_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_oam_add_del_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_oam_add_del_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_get_node_graph* vapi_alloc_get_node_graph(struct vapi_ctx_s *ctx)
{
  vapi_msg_get_node_graph *msg = NULL;
  const size_t size = sizeof(vapi_msg_get_node_graph);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_get_node_graph*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_get_node_graph);

  return msg;
}

static inline vapi_error_e vapi_get_node_graph(struct vapi_ctx_s *ctx,
  vapi_msg_get_node_graph *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_get_node_graph_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_get_node_graph_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_get_node_graph_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_interface_name_renumber* vapi_alloc_interface_name_renumber(struct vapi_ctx_s *ctx)
{
  vapi_msg_interface_name_renumber *msg = NULL;
  const size_t size = sizeof(vapi_msg_interface_name_renumber);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_interface_name_renumber*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_interface_name_renumber);

  return msg;
}

static inline vapi_error_e vapi_interface_name_renumber(struct vapi_ctx_s *ctx,
  vapi_msg_interface_name_renumber *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_interface_name_renumber_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_interface_name_renumber_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_interface_name_renumber_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_create_loopback* vapi_alloc_create_loopback(struct vapi_ctx_s *ctx)
{
  vapi_msg_create_loopback *msg = NULL;
  const size_t size = sizeof(vapi_msg_create_loopback);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_create_loopback*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_create_loopback);

  return msg;
}

static inline vapi_error_e vapi_create_loopback(struct vapi_ctx_s *ctx,
  vapi_msg_create_loopback *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_create_loopback_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_create_loopback_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_create_loopback_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_sw_interface_set_mpls_enable* vapi_alloc_sw_interface_set_mpls_enable(struct vapi_ctx_s *ctx)
{
  vapi_msg_sw_interface_set_mpls_enable *msg = NULL;
  const size_t size = sizeof(vapi_msg_sw_interface_set_mpls_enable);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_sw_interface_set_mpls_enable*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_sw_interface_set_mpls_enable);

  return msg;
}

static inline vapi_error_e vapi_sw_interface_set_mpls_enable(struct vapi_ctx_s *ctx,
  vapi_msg_sw_interface_set_mpls_enable *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_sw_interface_set_mpls_enable_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_sw_interface_set_mpls_enable_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_sw_interface_set_mpls_enable_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_punt_socket_deregister* vapi_alloc_punt_socket_deregister(struct vapi_ctx_s *ctx)
{
  vapi_msg_punt_socket_deregister *msg = NULL;
  const size_t size = sizeof(vapi_msg_punt_socket_deregister);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_punt_socket_deregister*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_punt_socket_deregister);

  return msg;
}

static inline vapi_error_e vapi_punt_socket_deregister(struct vapi_ctx_s *ctx,
  vapi_msg_punt_socket_deregister *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_punt_socket_deregister_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_punt_socket_deregister_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_punt_socket_deregister_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_ip_source_and_port_range_check_interface_add_del* vapi_alloc_ip_source_and_port_range_check_interface_add_del(struct vapi_ctx_s *ctx)
{
  vapi_msg_ip_source_and_port_range_check_interface_add_del *msg = NULL;
  const size_t size = sizeof(vapi_msg_ip_source_and_port_range_check_interface_add_del);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_ip_source_and_port_range_check_interface_add_del*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_ip_source_and_port_range_check_interface_add_del);

  return msg;
}

static inline vapi_error_e vapi_ip_source_and_port_range_check_interface_add_del(struct vapi_ctx_s *ctx,
  vapi_msg_ip_source_and_port_range_check_interface_add_del *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_ip_source_and_port_range_check_interface_add_del_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_ip_source_and_port_range_check_interface_add_del_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_ip_source_and_port_range_check_interface_add_del_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_control_ping* vapi_alloc_control_ping(struct vapi_ctx_s *ctx)
{
  vapi_msg_control_ping *msg = NULL;
  const size_t size = sizeof(vapi_msg_control_ping);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_control_ping*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_control_ping);

  return msg;
}

static inline vapi_error_e vapi_control_ping(struct vapi_ctx_s *ctx,
  vapi_msg_control_ping *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_control_ping_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_control_ping_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_control_ping_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}



static void __attribute__((constructor)) __vapi_constructor_delete_subif_reply()
{
  static const char name[] = "delete_subif_reply";
  static const char name_with_crc[] = "delete_subif_reply_9d6015dc";
  static vapi_message_desc_t __vapi_metadata_delete_subif_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_delete_subif_reply, payload),
    sizeof(vapi_msg_delete_subif_reply),
    (generic_swap_fn_t)vapi_msg_delete_subif_reply_hton,
    (generic_swap_fn_t)vapi_msg_delete_subif_reply_ntoh,
    ~0,
  };

  vapi_msg_id_delete_subif_reply = vapi_register_msg(&__vapi_metadata_delete_subif_reply);
  VAPI_DBG("Assigned msg id %d to delete_subif_reply", vapi_msg_id_delete_subif_reply);
}

static void __attribute__((constructor)) __vapi_constructor_ip6_nd_event()
{
  static const char name[] = "ip6_nd_event";
  static const char name_with_crc[] = "ip6_nd_event_b9c7870c";
  static vapi_message_desc_t __vapi_metadata_ip6_nd_event = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    false,
    0,
    offsetof(vapi_msg_ip6_nd_event, payload),
    sizeof(vapi_msg_ip6_nd_event),
    (generic_swap_fn_t)vapi_msg_ip6_nd_event_hton,
    (generic_swap_fn_t)vapi_msg_ip6_nd_event_ntoh,
    ~0,
  };

  vapi_msg_id_ip6_nd_event = vapi_register_msg(&__vapi_metadata_ip6_nd_event);
  VAPI_DBG("Assigned msg id %d to ip6_nd_event", vapi_msg_id_ip6_nd_event);
}

static void __attribute__((constructor)) __vapi_constructor_pg_create_interface_reply()
{
  static const char name[] = "pg_create_interface_reply";
  static const char name_with_crc[] = "pg_create_interface_reply_21b4f949";
  static vapi_message_desc_t __vapi_metadata_pg_create_interface_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_pg_create_interface_reply, payload),
    sizeof(vapi_msg_pg_create_interface_reply),
    (generic_swap_fn_t)vapi_msg_pg_create_interface_reply_hton,
    (generic_swap_fn_t)vapi_msg_pg_create_interface_reply_ntoh,
    ~0,
  };

  vapi_msg_id_pg_create_interface_reply = vapi_register_msg(&__vapi_metadata_pg_create_interface_reply);
  VAPI_DBG("Assigned msg id %d to pg_create_interface_reply", vapi_msg_id_pg_create_interface_reply);
}

static void __attribute__((constructor)) __vapi_constructor_pg_capture_reply()
{
  static const char name[] = "pg_capture_reply";
  static const char name_with_crc[] = "pg_capture_reply_f403693b";
  static vapi_message_desc_t __vapi_metadata_pg_capture_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_pg_capture_reply, payload),
    sizeof(vapi_msg_pg_capture_reply),
    (generic_swap_fn_t)vapi_msg_pg_capture_reply_hton,
    (generic_swap_fn_t)vapi_msg_pg_capture_reply_ntoh,
    ~0,
  };

  vapi_msg_id_pg_capture_reply = vapi_register_msg(&__vapi_metadata_pg_capture_reply);
  VAPI_DBG("Assigned msg id %d to pg_capture_reply", vapi_msg_id_pg_capture_reply);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_set_vpath_reply()
{
  static const char name[] = "sw_interface_set_vpath_reply";
  static const char name_with_crc[] = "sw_interface_set_vpath_reply_828dbe62";
  static vapi_message_desc_t __vapi_metadata_sw_interface_set_vpath_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_sw_interface_set_vpath_reply, payload),
    sizeof(vapi_msg_sw_interface_set_vpath_reply),
    (generic_swap_fn_t)vapi_msg_sw_interface_set_vpath_reply_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_set_vpath_reply_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_set_vpath_reply = vapi_register_msg(&__vapi_metadata_sw_interface_set_vpath_reply);
  VAPI_DBG("Assigned msg id %d to sw_interface_set_vpath_reply", vapi_msg_id_sw_interface_set_vpath_reply);
}

static void __attribute__((constructor)) __vapi_constructor_get_node_index_reply()
{
  static const char name[] = "get_node_index_reply";
  static const char name_with_crc[] = "get_node_index_reply_29116865";
  static vapi_message_desc_t __vapi_metadata_get_node_index_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_get_node_index_reply, payload),
    sizeof(vapi_msg_get_node_index_reply),
    (generic_swap_fn_t)vapi_msg_get_node_index_reply_hton,
    (generic_swap_fn_t)vapi_msg_get_node_index_reply_ntoh,
    ~0,
  };

  vapi_msg_id_get_node_index_reply = vapi_register_msg(&__vapi_metadata_get_node_index_reply);
  VAPI_DBG("Assigned msg id %d to get_node_index_reply", vapi_msg_id_get_node_index_reply);
}

static void __attribute__((constructor)) __vapi_constructor_interface_name_renumber_reply()
{
  static const char name[] = "interface_name_renumber_reply";
  static const char name_with_crc[] = "interface_name_renumber_reply_31594963";
  static vapi_message_desc_t __vapi_metadata_interface_name_renumber_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_interface_name_renumber_reply, payload),
    sizeof(vapi_msg_interface_name_renumber_reply),
    (generic_swap_fn_t)vapi_msg_interface_name_renumber_reply_hton,
    (generic_swap_fn_t)vapi_msg_interface_name_renumber_reply_ntoh,
    ~0,
  };

  vapi_msg_id_interface_name_renumber_reply = vapi_register_msg(&__vapi_metadata_interface_name_renumber_reply);
  VAPI_DBG("Assigned msg id %d to interface_name_renumber_reply", vapi_msg_id_interface_name_renumber_reply);
}

static void __attribute__((constructor)) __vapi_constructor_cli()
{
  static const char name[] = "cli";
  static const char name_with_crc[] = "cli_543d8e2e";
  static vapi_message_desc_t __vapi_metadata_cli = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_cli, payload),
    sizeof(vapi_msg_cli),
    (generic_swap_fn_t)vapi_msg_cli_hton,
    (generic_swap_fn_t)vapi_msg_cli_ntoh,
    ~0,
  };

  vapi_msg_id_cli = vapi_register_msg(&__vapi_metadata_cli);
  VAPI_DBG("Assigned msg id %d to cli", vapi_msg_id_cli);
}

static void __attribute__((constructor)) __vapi_constructor_ip4_arp_event()
{
  static const char name[] = "ip4_arp_event";
  static const char name_with_crc[] = "ip4_arp_event_79b2d94d";
  static vapi_message_desc_t __vapi_metadata_ip4_arp_event = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    false,
    0,
    offsetof(vapi_msg_ip4_arp_event, payload),
    sizeof(vapi_msg_ip4_arp_event),
    (generic_swap_fn_t)vapi_msg_ip4_arp_event_hton,
    (generic_swap_fn_t)vapi_msg_ip4_arp_event_ntoh,
    ~0,
  };

  vapi_msg_id_ip4_arp_event = vapi_register_msg(&__vapi_metadata_ip4_arp_event);
  VAPI_DBG("Assigned msg id %d to ip4_arp_event", vapi_msg_id_ip4_arp_event);
}

static void __attribute__((constructor)) __vapi_constructor_oam_add_del_reply()
{
  static const char name[] = "oam_add_del_reply";
  static const char name_with_crc[] = "oam_add_del_reply_c5594eec";
  static vapi_message_desc_t __vapi_metadata_oam_add_del_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_oam_add_del_reply, payload),
    sizeof(vapi_msg_oam_add_del_reply),
    (generic_swap_fn_t)vapi_msg_oam_add_del_reply_hton,
    (generic_swap_fn_t)vapi_msg_oam_add_del_reply_ntoh,
    ~0,
  };

  vapi_msg_id_oam_add_del_reply = vapi_register_msg(&__vapi_metadata_oam_add_del_reply);
  VAPI_DBG("Assigned msg id %d to oam_add_del_reply", vapi_msg_id_oam_add_del_reply);
}

static void __attribute__((constructor)) __vapi_constructor_ip_source_and_port_range_check_add_del()
{
  static const char name[] = "ip_source_and_port_range_check_add_del";
  static const char name_with_crc[] = "ip_source_and_port_range_check_add_del_0f8c6ba0";
  static vapi_message_desc_t __vapi_metadata_ip_source_and_port_range_check_add_del = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_ip_source_and_port_range_check_add_del, payload),
    sizeof(vapi_msg_ip_source_and_port_range_check_add_del),
    (generic_swap_fn_t)vapi_msg_ip_source_and_port_range_check_add_del_hton,
    (generic_swap_fn_t)vapi_msg_ip_source_and_port_range_check_add_del_ntoh,
    ~0,
  };

  vapi_msg_id_ip_source_and_port_range_check_add_del = vapi_register_msg(&__vapi_metadata_ip_source_and_port_range_check_add_del);
  VAPI_DBG("Assigned msg id %d to ip_source_and_port_range_check_add_del", vapi_msg_id_ip_source_and_port_range_check_add_del);
}

static void __attribute__((constructor)) __vapi_constructor_get_node_index()
{
  static const char name[] = "get_node_index";
  static const char name_with_crc[] = "get_node_index_226d3f8c";
  static vapi_message_desc_t __vapi_metadata_get_node_index = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_get_node_index, payload),
    sizeof(vapi_msg_get_node_index),
    (generic_swap_fn_t)vapi_msg_get_node_index_hton,
    (generic_swap_fn_t)vapi_msg_get_node_index_ntoh,
    ~0,
  };

  vapi_msg_id_get_node_index = vapi_register_msg(&__vapi_metadata_get_node_index);
  VAPI_DBG("Assigned msg id %d to get_node_index", vapi_msg_id_get_node_index);
}

static void __attribute__((constructor)) __vapi_constructor_l2_interface_efp_filter()
{
  static const char name[] = "l2_interface_efp_filter";
  static const char name_with_crc[] = "l2_interface_efp_filter_07c9d601";
  static vapi_message_desc_t __vapi_metadata_l2_interface_efp_filter = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_l2_interface_efp_filter, payload),
    sizeof(vapi_msg_l2_interface_efp_filter),
    (generic_swap_fn_t)vapi_msg_l2_interface_efp_filter_hton,
    (generic_swap_fn_t)vapi_msg_l2_interface_efp_filter_ntoh,
    ~0,
  };

  vapi_msg_id_l2_interface_efp_filter = vapi_register_msg(&__vapi_metadata_l2_interface_efp_filter);
  VAPI_DBG("Assigned msg id %d to l2_interface_efp_filter", vapi_msg_id_l2_interface_efp_filter);
}

static void __attribute__((constructor)) __vapi_constructor_l2_interface_efp_filter_reply()
{
  static const char name[] = "l2_interface_efp_filter_reply";
  static const char name_with_crc[] = "l2_interface_efp_filter_reply_0f4bb0c0";
  static vapi_message_desc_t __vapi_metadata_l2_interface_efp_filter_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_l2_interface_efp_filter_reply, payload),
    sizeof(vapi_msg_l2_interface_efp_filter_reply),
    (generic_swap_fn_t)vapi_msg_l2_interface_efp_filter_reply_hton,
    (generic_swap_fn_t)vapi_msg_l2_interface_efp_filter_reply_ntoh,
    ~0,
  };

  vapi_msg_id_l2_interface_efp_filter_reply = vapi_register_msg(&__vapi_metadata_l2_interface_efp_filter_reply);
  VAPI_DBG("Assigned msg id %d to l2_interface_efp_filter_reply", vapi_msg_id_l2_interface_efp_filter_reply);
}

static void __attribute__((constructor)) __vapi_constructor_proxy_arp_intfc_enable_disable()
{
  static const char name[] = "proxy_arp_intfc_enable_disable";
  static const char name_with_crc[] = "proxy_arp_intfc_enable_disable_3ee1998e";
  static vapi_message_desc_t __vapi_metadata_proxy_arp_intfc_enable_disable = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_proxy_arp_intfc_enable_disable, payload),
    sizeof(vapi_msg_proxy_arp_intfc_enable_disable),
    (generic_swap_fn_t)vapi_msg_proxy_arp_intfc_enable_disable_hton,
    (generic_swap_fn_t)vapi_msg_proxy_arp_intfc_enable_disable_ntoh,
    ~0,
  };

  vapi_msg_id_proxy_arp_intfc_enable_disable = vapi_register_msg(&__vapi_metadata_proxy_arp_intfc_enable_disable);
  VAPI_DBG("Assigned msg id %d to proxy_arp_intfc_enable_disable", vapi_msg_id_proxy_arp_intfc_enable_disable);
}

static void __attribute__((constructor)) __vapi_constructor_feature_enable_disable()
{
  static const char name[] = "feature_enable_disable";
  static const char name_with_crc[] = "feature_enable_disable_bc86393b";
  static vapi_message_desc_t __vapi_metadata_feature_enable_disable = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_feature_enable_disable, payload),
    sizeof(vapi_msg_feature_enable_disable),
    (generic_swap_fn_t)vapi_msg_feature_enable_disable_hton,
    (generic_swap_fn_t)vapi_msg_feature_enable_disable_ntoh,
    ~0,
  };

  vapi_msg_id_feature_enable_disable = vapi_register_msg(&__vapi_metadata_feature_enable_disable);
  VAPI_DBG("Assigned msg id %d to feature_enable_disable", vapi_msg_id_feature_enable_disable);
}

static void __attribute__((constructor)) __vapi_constructor_proxy_arp_add_del()
{
  static const char name[] = "proxy_arp_add_del";
  static const char name_with_crc[] = "proxy_arp_add_del_4bef9951";
  static vapi_message_desc_t __vapi_metadata_proxy_arp_add_del = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_proxy_arp_add_del, payload),
    sizeof(vapi_msg_proxy_arp_add_del),
    (generic_swap_fn_t)vapi_msg_proxy_arp_add_del_hton,
    (generic_swap_fn_t)vapi_msg_proxy_arp_add_del_ntoh,
    ~0,
  };

  vapi_msg_id_proxy_arp_add_del = vapi_register_msg(&__vapi_metadata_proxy_arp_add_del);
  VAPI_DBG("Assigned msg id %d to proxy_arp_add_del", vapi_msg_id_proxy_arp_add_del);
}

static void __attribute__((constructor)) __vapi_constructor_ioam_disable_reply()
{
  static const char name[] = "ioam_disable_reply";
  static const char name_with_crc[] = "ioam_disable_reply_ef118a9d";
  static vapi_message_desc_t __vapi_metadata_ioam_disable_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_ioam_disable_reply, payload),
    sizeof(vapi_msg_ioam_disable_reply),
    (generic_swap_fn_t)vapi_msg_ioam_disable_reply_hton,
    (generic_swap_fn_t)vapi_msg_ioam_disable_reply_ntoh,
    ~0,
  };

  vapi_msg_id_ioam_disable_reply = vapi_register_msg(&__vapi_metadata_ioam_disable_reply);
  VAPI_DBG("Assigned msg id %d to ioam_disable_reply", vapi_msg_id_ioam_disable_reply);
}

static void __attribute__((constructor)) __vapi_constructor_classify_set_interface_ip_table()
{
  static const char name[] = "classify_set_interface_ip_table";
  static const char name_with_crc[] = "classify_set_interface_ip_table_0dc45308";
  static vapi_message_desc_t __vapi_metadata_classify_set_interface_ip_table = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_classify_set_interface_ip_table, payload),
    sizeof(vapi_msg_classify_set_interface_ip_table),
    (generic_swap_fn_t)vapi_msg_classify_set_interface_ip_table_hton,
    (generic_swap_fn_t)vapi_msg_classify_set_interface_ip_table_ntoh,
    ~0,
  };

  vapi_msg_id_classify_set_interface_ip_table = vapi_register_msg(&__vapi_metadata_classify_set_interface_ip_table);
  VAPI_DBG("Assigned msg id %d to classify_set_interface_ip_table", vapi_msg_id_classify_set_interface_ip_table);
}

static void __attribute__((constructor)) __vapi_constructor_ioam_enable()
{
  static const char name[] = "ioam_enable";
  static const char name_with_crc[] = "ioam_enable_7bd4abf9";
  static vapi_message_desc_t __vapi_metadata_ioam_enable = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_ioam_enable, payload),
    sizeof(vapi_msg_ioam_enable),
    (generic_swap_fn_t)vapi_msg_ioam_enable_hton,
    (generic_swap_fn_t)vapi_msg_ioam_enable_ntoh,
    ~0,
  };

  vapi_msg_id_ioam_enable = vapi_register_msg(&__vapi_metadata_ioam_enable);
  VAPI_DBG("Assigned msg id %d to ioam_enable", vapi_msg_id_ioam_enable);
}

static void __attribute__((constructor)) __vapi_constructor_get_next_index()
{
  static const char name[] = "get_next_index";
  static const char name_with_crc[] = "get_next_index_52f0e416";
  static vapi_message_desc_t __vapi_metadata_get_next_index = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_get_next_index, payload),
    sizeof(vapi_msg_get_next_index),
    (generic_swap_fn_t)vapi_msg_get_next_index_hton,
    (generic_swap_fn_t)vapi_msg_get_next_index_ntoh,
    ~0,
  };

  vapi_msg_id_get_next_index = vapi_register_msg(&__vapi_metadata_get_next_index);
  VAPI_DBG("Assigned msg id %d to get_next_index", vapi_msg_id_get_next_index);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_set_vpath()
{
  static const char name[] = "sw_interface_set_vpath";
  static const char name_with_crc[] = "sw_interface_set_vpath_1bc2fd5e";
  static vapi_message_desc_t __vapi_metadata_sw_interface_set_vpath = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_sw_interface_set_vpath, payload),
    sizeof(vapi_msg_sw_interface_set_vpath),
    (generic_swap_fn_t)vapi_msg_sw_interface_set_vpath_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_set_vpath_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_set_vpath = vapi_register_msg(&__vapi_metadata_sw_interface_set_vpath);
  VAPI_DBG("Assigned msg id %d to sw_interface_set_vpath", vapi_msg_id_sw_interface_set_vpath);
}

static void __attribute__((constructor)) __vapi_constructor_punt_socket_deregister_reply()
{
  static const char name[] = "punt_socket_deregister_reply";
  static const char name_with_crc[] = "punt_socket_deregister_reply_e3cfe144";
  static vapi_message_desc_t __vapi_metadata_punt_socket_deregister_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_punt_socket_deregister_reply, payload),
    sizeof(vapi_msg_punt_socket_deregister_reply),
    (generic_swap_fn_t)vapi_msg_punt_socket_deregister_reply_hton,
    (generic_swap_fn_t)vapi_msg_punt_socket_deregister_reply_ntoh,
    ~0,
  };

  vapi_msg_id_punt_socket_deregister_reply = vapi_register_msg(&__vapi_metadata_punt_socket_deregister_reply);
  VAPI_DBG("Assigned msg id %d to punt_socket_deregister_reply", vapi_msg_id_punt_socket_deregister_reply);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_set_l2_xconnect()
{
  static const char name[] = "sw_interface_set_l2_xconnect";
  static const char name_with_crc[] = "sw_interface_set_l2_xconnect_48a4c4c8";
  static vapi_message_desc_t __vapi_metadata_sw_interface_set_l2_xconnect = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_sw_interface_set_l2_xconnect, payload),
    sizeof(vapi_msg_sw_interface_set_l2_xconnect),
    (generic_swap_fn_t)vapi_msg_sw_interface_set_l2_xconnect_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_set_l2_xconnect_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_set_l2_xconnect = vapi_register_msg(&__vapi_metadata_sw_interface_set_l2_xconnect);
  VAPI_DBG("Assigned msg id %d to sw_interface_set_l2_xconnect", vapi_msg_id_sw_interface_set_l2_xconnect);
}

static void __attribute__((constructor)) __vapi_constructor_bd_ip_mac_add_del_reply()
{
  static const char name[] = "bd_ip_mac_add_del_reply";
  static const char name_with_crc[] = "bd_ip_mac_add_del_reply_55bab3b4";
  static vapi_message_desc_t __vapi_metadata_bd_ip_mac_add_del_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_bd_ip_mac_add_del_reply, payload),
    sizeof(vapi_msg_bd_ip_mac_add_del_reply),
    (generic_swap_fn_t)vapi_msg_bd_ip_mac_add_del_reply_hton,
    (generic_swap_fn_t)vapi_msg_bd_ip_mac_add_del_reply_ntoh,
    ~0,
  };

  vapi_msg_id_bd_ip_mac_add_del_reply = vapi_register_msg(&__vapi_metadata_bd_ip_mac_add_del_reply);
  VAPI_DBG("Assigned msg id %d to bd_ip_mac_add_del_reply", vapi_msg_id_bd_ip_mac_add_del_reply);
}

static void __attribute__((constructor)) __vapi_constructor_reset_fib_reply()
{
  static const char name[] = "reset_fib_reply";
  static const char name_with_crc[] = "reset_fib_reply_990dcbf8";
  static vapi_message_desc_t __vapi_metadata_reset_fib_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_reset_fib_reply, payload),
    sizeof(vapi_msg_reset_fib_reply),
    (generic_swap_fn_t)vapi_msg_reset_fib_reply_hton,
    (generic_swap_fn_t)vapi_msg_reset_fib_reply_ntoh,
    ~0,
  };

  vapi_msg_id_reset_fib_reply = vapi_register_msg(&__vapi_metadata_reset_fib_reply);
  VAPI_DBG("Assigned msg id %d to reset_fib_reply", vapi_msg_id_reset_fib_reply);
}

static void __attribute__((constructor)) __vapi_constructor_want_ip6_nd_events_reply()
{
  static const char name[] = "want_ip6_nd_events_reply";
  static const char name_with_crc[] = "want_ip6_nd_events_reply_95458aad";
  static vapi_message_desc_t __vapi_metadata_want_ip6_nd_events_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_want_ip6_nd_events_reply, payload),
    sizeof(vapi_msg_want_ip6_nd_events_reply),
    (generic_swap_fn_t)vapi_msg_want_ip6_nd_events_reply_hton,
    (generic_swap_fn_t)vapi_msg_want_ip6_nd_events_reply_ntoh,
    ~0,
  };

  vapi_msg_id_want_ip6_nd_events_reply = vapi_register_msg(&__vapi_metadata_want_ip6_nd_events_reply);
  VAPI_DBG("Assigned msg id %d to want_ip6_nd_events_reply", vapi_msg_id_want_ip6_nd_events_reply);
}

static void __attribute__((constructor)) __vapi_constructor_l2_patch_add_del_reply()
{
  static const char name[] = "l2_patch_add_del_reply";
  static const char name_with_crc[] = "l2_patch_add_del_reply_a85e37be";
  static vapi_message_desc_t __vapi_metadata_l2_patch_add_del_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_l2_patch_add_del_reply, payload),
    sizeof(vapi_msg_l2_patch_add_del_reply),
    (generic_swap_fn_t)vapi_msg_l2_patch_add_del_reply_hton,
    (generic_swap_fn_t)vapi_msg_l2_patch_add_del_reply_ntoh,
    ~0,
  };

  vapi_msg_id_l2_patch_add_del_reply = vapi_register_msg(&__vapi_metadata_l2_patch_add_del_reply);
  VAPI_DBG("Assigned msg id %d to l2_patch_add_del_reply", vapi_msg_id_l2_patch_add_del_reply);
}

static void __attribute__((constructor)) __vapi_constructor_set_arp_neighbor_limit()
{
  static const char name[] = "set_arp_neighbor_limit";
  static const char name_with_crc[] = "set_arp_neighbor_limit_c1690cb4";
  static vapi_message_desc_t __vapi_metadata_set_arp_neighbor_limit = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_set_arp_neighbor_limit, payload),
    sizeof(vapi_msg_set_arp_neighbor_limit),
    (generic_swap_fn_t)vapi_msg_set_arp_neighbor_limit_hton,
    (generic_swap_fn_t)vapi_msg_set_arp_neighbor_limit_ntoh,
    ~0,
  };

  vapi_msg_id_set_arp_neighbor_limit = vapi_register_msg(&__vapi_metadata_set_arp_neighbor_limit);
  VAPI_DBG("Assigned msg id %d to set_arp_neighbor_limit", vapi_msg_id_set_arp_neighbor_limit);
}

static void __attribute__((constructor)) __vapi_constructor_add_node_next()
{
  static const char name[] = "add_node_next";
  static const char name_with_crc[] = "add_node_next_e4202993";
  static vapi_message_desc_t __vapi_metadata_add_node_next = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_add_node_next, payload),
    sizeof(vapi_msg_add_node_next),
    (generic_swap_fn_t)vapi_msg_add_node_next_hton,
    (generic_swap_fn_t)vapi_msg_add_node_next_ntoh,
    ~0,
  };

  vapi_msg_id_add_node_next = vapi_register_msg(&__vapi_metadata_add_node_next);
  VAPI_DBG("Assigned msg id %d to add_node_next", vapi_msg_id_add_node_next);
}

static void __attribute__((constructor)) __vapi_constructor_get_next_index_reply()
{
  static const char name[] = "get_next_index_reply";
  static const char name_with_crc[] = "get_next_index_reply_671fbdb1";
  static vapi_message_desc_t __vapi_metadata_get_next_index_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_get_next_index_reply, payload),
    sizeof(vapi_msg_get_next_index_reply),
    (generic_swap_fn_t)vapi_msg_get_next_index_reply_hton,
    (generic_swap_fn_t)vapi_msg_get_next_index_reply_ntoh,
    ~0,
  };

  vapi_msg_id_get_next_index_reply = vapi_register_msg(&__vapi_metadata_get_next_index_reply);
  VAPI_DBG("Assigned msg id %d to get_next_index_reply", vapi_msg_id_get_next_index_reply);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_set_mpls_enable_reply()
{
  static const char name[] = "sw_interface_set_mpls_enable_reply";
  static const char name_with_crc[] = "sw_interface_set_mpls_enable_reply_5ffd3ca9";
  static vapi_message_desc_t __vapi_metadata_sw_interface_set_mpls_enable_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_sw_interface_set_mpls_enable_reply, payload),
    sizeof(vapi_msg_sw_interface_set_mpls_enable_reply),
    (generic_swap_fn_t)vapi_msg_sw_interface_set_mpls_enable_reply_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_set_mpls_enable_reply_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_set_mpls_enable_reply = vapi_register_msg(&__vapi_metadata_sw_interface_set_mpls_enable_reply);
  VAPI_DBG("Assigned msg id %d to sw_interface_set_mpls_enable_reply", vapi_msg_id_sw_interface_set_mpls_enable_reply);
}

static void __attribute__((constructor)) __vapi_constructor_show_version_reply()
{
  static const char name[] = "show_version_reply";
  static const char name_with_crc[] = "show_version_reply_83186d9e";
  static vapi_message_desc_t __vapi_metadata_show_version_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_show_version_reply, payload),
    sizeof(vapi_msg_show_version_reply),
    (generic_swap_fn_t)vapi_msg_show_version_reply_hton,
    (generic_swap_fn_t)vapi_msg_show_version_reply_ntoh,
    ~0,
  };

  vapi_msg_id_show_version_reply = vapi_register_msg(&__vapi_metadata_show_version_reply);
  VAPI_DBG("Assigned msg id %d to show_version_reply", vapi_msg_id_show_version_reply);
}

static void __attribute__((constructor)) __vapi_constructor_want_ip4_arp_events()
{
  static const char name[] = "want_ip4_arp_events";
  static const char name_with_crc[] = "want_ip4_arp_events_5ae044c2";
  static vapi_message_desc_t __vapi_metadata_want_ip4_arp_events = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_want_ip4_arp_events, payload),
    sizeof(vapi_msg_want_ip4_arp_events),
    (generic_swap_fn_t)vapi_msg_want_ip4_arp_events_hton,
    (generic_swap_fn_t)vapi_msg_want_ip4_arp_events_ntoh,
    ~0,
  };

  vapi_msg_id_want_ip4_arp_events = vapi_register_msg(&__vapi_metadata_want_ip4_arp_events);
  VAPI_DBG("Assigned msg id %d to want_ip4_arp_events", vapi_msg_id_want_ip4_arp_events);
}

static void __attribute__((constructor)) __vapi_constructor_ip_source_and_port_range_check_interface_add_del_reply()
{
  static const char name[] = "ip_source_and_port_range_check_interface_add_del_reply";
  static const char name_with_crc[] = "ip_source_and_port_range_check_interface_add_del_reply_6b940f04";
  static vapi_message_desc_t __vapi_metadata_ip_source_and_port_range_check_interface_add_del_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_ip_source_and_port_range_check_interface_add_del_reply, payload),
    sizeof(vapi_msg_ip_source_and_port_range_check_interface_add_del_reply),
    (generic_swap_fn_t)vapi_msg_ip_source_and_port_range_check_interface_add_del_reply_hton,
    (generic_swap_fn_t)vapi_msg_ip_source_and_port_range_check_interface_add_del_reply_ntoh,
    ~0,
  };

  vapi_msg_id_ip_source_and_port_range_check_interface_add_del_reply = vapi_register_msg(&__vapi_metadata_ip_source_and_port_range_check_interface_add_del_reply);
  VAPI_DBG("Assigned msg id %d to ip_source_and_port_range_check_interface_add_del_reply", vapi_msg_id_ip_source_and_port_range_check_interface_add_del_reply);
}

static void __attribute__((constructor)) __vapi_constructor_punt_socket_register_reply()
{
  static const char name[] = "punt_socket_register_reply";
  static const char name_with_crc[] = "punt_socket_register_reply_b6059978";
  static vapi_message_desc_t __vapi_metadata_punt_socket_register_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_punt_socket_register_reply, payload),
    sizeof(vapi_msg_punt_socket_register_reply),
    (generic_swap_fn_t)vapi_msg_punt_socket_register_reply_hton,
    (generic_swap_fn_t)vapi_msg_punt_socket_register_reply_ntoh,
    ~0,
  };

  vapi_msg_id_punt_socket_register_reply = vapi_register_msg(&__vapi_metadata_punt_socket_register_reply);
  VAPI_DBG("Assigned msg id %d to punt_socket_register_reply", vapi_msg_id_punt_socket_register_reply);
}

static void __attribute__((constructor)) __vapi_constructor_create_loopback_instance_reply()
{
  static const char name[] = "create_loopback_instance_reply";
  static const char name_with_crc[] = "create_loopback_instance_reply_d52c63b6";
  static vapi_message_desc_t __vapi_metadata_create_loopback_instance_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_create_loopback_instance_reply, payload),
    sizeof(vapi_msg_create_loopback_instance_reply),
    (generic_swap_fn_t)vapi_msg_create_loopback_instance_reply_hton,
    (generic_swap_fn_t)vapi_msg_create_loopback_instance_reply_ntoh,
    ~0,
  };

  vapi_msg_id_create_loopback_instance_reply = vapi_register_msg(&__vapi_metadata_create_loopback_instance_reply);
  VAPI_DBG("Assigned msg id %d to create_loopback_instance_reply", vapi_msg_id_create_loopback_instance_reply);
}

static void __attribute__((constructor)) __vapi_constructor_delete_loopback_reply()
{
  static const char name[] = "delete_loopback_reply";
  static const char name_with_crc[] = "delete_loopback_reply_c91dafa5";
  static vapi_message_desc_t __vapi_metadata_delete_loopback_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_delete_loopback_reply, payload),
    sizeof(vapi_msg_delete_loopback_reply),
    (generic_swap_fn_t)vapi_msg_delete_loopback_reply_hton,
    (generic_swap_fn_t)vapi_msg_delete_loopback_reply_ntoh,
    ~0,
  };

  vapi_msg_id_delete_loopback_reply = vapi_register_msg(&__vapi_metadata_delete_loopback_reply);
  VAPI_DBG("Assigned msg id %d to delete_loopback_reply", vapi_msg_id_delete_loopback_reply);
}

static void __attribute__((constructor)) __vapi_constructor_classify_set_interface_l2_tables_reply()
{
  static const char name[] = "classify_set_interface_l2_tables_reply";
  static const char name_with_crc[] = "classify_set_interface_l2_tables_reply_8df20579";
  static vapi_message_desc_t __vapi_metadata_classify_set_interface_l2_tables_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_classify_set_interface_l2_tables_reply, payload),
    sizeof(vapi_msg_classify_set_interface_l2_tables_reply),
    (generic_swap_fn_t)vapi_msg_classify_set_interface_l2_tables_reply_hton,
    (generic_swap_fn_t)vapi_msg_classify_set_interface_l2_tables_reply_ntoh,
    ~0,
  };

  vapi_msg_id_classify_set_interface_l2_tables_reply = vapi_register_msg(&__vapi_metadata_classify_set_interface_l2_tables_reply);
  VAPI_DBG("Assigned msg id %d to classify_set_interface_l2_tables_reply", vapi_msg_id_classify_set_interface_l2_tables_reply);
}

static void __attribute__((constructor)) __vapi_constructor_pg_capture()
{
  static const char name[] = "pg_capture";
  static const char name_with_crc[] = "pg_capture_6ac7fe78";
  static vapi_message_desc_t __vapi_metadata_pg_capture = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_pg_capture, payload),
    sizeof(vapi_msg_pg_capture),
    (generic_swap_fn_t)vapi_msg_pg_capture_hton,
    (generic_swap_fn_t)vapi_msg_pg_capture_ntoh,
    ~0,
  };

  vapi_msg_id_pg_capture = vapi_register_msg(&__vapi_metadata_pg_capture);
  VAPI_DBG("Assigned msg id %d to pg_capture", vapi_msg_id_pg_capture);
}

static void __attribute__((constructor)) __vapi_constructor_create_vlan_subif()
{
  static const char name[] = "create_vlan_subif";
  static const char name_with_crc[] = "create_vlan_subif_af9ae1e9";
  static vapi_message_desc_t __vapi_metadata_create_vlan_subif = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_create_vlan_subif, payload),
    sizeof(vapi_msg_create_vlan_subif),
    (generic_swap_fn_t)vapi_msg_create_vlan_subif_hton,
    (generic_swap_fn_t)vapi_msg_create_vlan_subif_ntoh,
    ~0,
  };

  vapi_msg_id_create_vlan_subif = vapi_register_msg(&__vapi_metadata_create_vlan_subif);
  VAPI_DBG("Assigned msg id %d to create_vlan_subif", vapi_msg_id_create_vlan_subif);
}

static void __attribute__((constructor)) __vapi_constructor_get_node_graph_reply()
{
  static const char name[] = "get_node_graph_reply";
  static const char name_with_crc[] = "get_node_graph_reply_816d91b6";
  static vapi_message_desc_t __vapi_metadata_get_node_graph_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_get_node_graph_reply, payload),
    sizeof(vapi_msg_get_node_graph_reply),
    (generic_swap_fn_t)vapi_msg_get_node_graph_reply_hton,
    (generic_swap_fn_t)vapi_msg_get_node_graph_reply_ntoh,
    ~0,
  };

  vapi_msg_id_get_node_graph_reply = vapi_register_msg(&__vapi_metadata_get_node_graph_reply);
  VAPI_DBG("Assigned msg id %d to get_node_graph_reply", vapi_msg_id_get_node_graph_reply);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_set_l2_bridge()
{
  static const char name[] = "sw_interface_set_l2_bridge";
  static const char name_with_crc[] = "sw_interface_set_l2_bridge_36c739e8";
  static vapi_message_desc_t __vapi_metadata_sw_interface_set_l2_bridge = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_sw_interface_set_l2_bridge, payload),
    sizeof(vapi_msg_sw_interface_set_l2_bridge),
    (generic_swap_fn_t)vapi_msg_sw_interface_set_l2_bridge_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_set_l2_bridge_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_set_l2_bridge = vapi_register_msg(&__vapi_metadata_sw_interface_set_l2_bridge);
  VAPI_DBG("Assigned msg id %d to sw_interface_set_l2_bridge", vapi_msg_id_sw_interface_set_l2_bridge);
}

static void __attribute__((constructor)) __vapi_constructor_punt()
{
  static const char name[] = "punt";
  static const char name_with_crc[] = "punt_4559c976";
  static vapi_message_desc_t __vapi_metadata_punt = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_punt, payload),
    sizeof(vapi_msg_punt),
    (generic_swap_fn_t)vapi_msg_punt_hton,
    (generic_swap_fn_t)vapi_msg_punt_ntoh,
    ~0,
  };

  vapi_msg_id_punt = vapi_register_msg(&__vapi_metadata_punt);
  VAPI_DBG("Assigned msg id %d to punt", vapi_msg_id_punt);
}

static void __attribute__((constructor)) __vapi_constructor_delete_loopback()
{
  static const char name[] = "delete_loopback";
  static const char name_with_crc[] = "delete_loopback_ded428b0";
  static vapi_message_desc_t __vapi_metadata_delete_loopback = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_delete_loopback, payload),
    sizeof(vapi_msg_delete_loopback),
    (generic_swap_fn_t)vapi_msg_delete_loopback_hton,
    (generic_swap_fn_t)vapi_msg_delete_loopback_ntoh,
    ~0,
  };

  vapi_msg_id_delete_loopback = vapi_register_msg(&__vapi_metadata_delete_loopback);
  VAPI_DBG("Assigned msg id %d to delete_loopback", vapi_msg_id_delete_loopback);
}

static void __attribute__((constructor)) __vapi_constructor_pg_create_interface()
{
  static const char name[] = "pg_create_interface";
  static const char name_with_crc[] = "pg_create_interface_253c5959";
  static vapi_message_desc_t __vapi_metadata_pg_create_interface = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_pg_create_interface, payload),
    sizeof(vapi_msg_pg_create_interface),
    (generic_swap_fn_t)vapi_msg_pg_create_interface_hton,
    (generic_swap_fn_t)vapi_msg_pg_create_interface_ntoh,
    ~0,
  };

  vapi_msg_id_pg_create_interface = vapi_register_msg(&__vapi_metadata_pg_create_interface);
  VAPI_DBG("Assigned msg id %d to pg_create_interface", vapi_msg_id_pg_create_interface);
}

static void __attribute__((constructor)) __vapi_constructor_ioam_enable_reply()
{
  static const char name[] = "ioam_enable_reply";
  static const char name_with_crc[] = "ioam_enable_reply_58a8fedc";
  static vapi_message_desc_t __vapi_metadata_ioam_enable_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_ioam_enable_reply, payload),
    sizeof(vapi_msg_ioam_enable_reply),
    (generic_swap_fn_t)vapi_msg_ioam_enable_reply_hton,
    (generic_swap_fn_t)vapi_msg_ioam_enable_reply_ntoh,
    ~0,
  };

  vapi_msg_id_ioam_enable_reply = vapi_register_msg(&__vapi_metadata_ioam_enable_reply);
  VAPI_DBG("Assigned msg id %d to ioam_enable_reply", vapi_msg_id_ioam_enable_reply);
}

static void __attribute__((constructor)) __vapi_constructor_create_subif()
{
  static const char name[] = "create_subif";
  static const char name_with_crc[] = "create_subif_150e6757";
  static vapi_message_desc_t __vapi_metadata_create_subif = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_create_subif, payload),
    sizeof(vapi_msg_create_subif),
    (generic_swap_fn_t)vapi_msg_create_subif_hton,
    (generic_swap_fn_t)vapi_msg_create_subif_ntoh,
    ~0,
  };

  vapi_msg_id_create_subif = vapi_register_msg(&__vapi_metadata_create_subif);
  VAPI_DBG("Assigned msg id %d to create_subif", vapi_msg_id_create_subif);
}

static void __attribute__((constructor)) __vapi_constructor_cli_inband()
{
  static const char name[] = "cli_inband";
  static const char name_with_crc[] = "cli_inband_22345937";
  static vapi_message_desc_t __vapi_metadata_cli_inband = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_cli_inband, payload),
    sizeof(vapi_msg_cli_inband),
    (generic_swap_fn_t)vapi_msg_cli_inband_hton,
    (generic_swap_fn_t)vapi_msg_cli_inband_ntoh,
    ~0,
  };

  vapi_msg_id_cli_inband = vapi_register_msg(&__vapi_metadata_cli_inband);
  VAPI_DBG("Assigned msg id %d to cli_inband", vapi_msg_id_cli_inband);
}

static void __attribute__((constructor)) __vapi_constructor_want_ip4_arp_events_reply()
{
  static const char name[] = "want_ip4_arp_events_reply";
  static const char name_with_crc[] = "want_ip4_arp_events_reply_e1c0b59e";
  static vapi_message_desc_t __vapi_metadata_want_ip4_arp_events_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_want_ip4_arp_events_reply, payload),
    sizeof(vapi_msg_want_ip4_arp_events_reply),
    (generic_swap_fn_t)vapi_msg_want_ip4_arp_events_reply_hton,
    (generic_swap_fn_t)vapi_msg_want_ip4_arp_events_reply_ntoh,
    ~0,
  };

  vapi_msg_id_want_ip4_arp_events_reply = vapi_register_msg(&__vapi_metadata_want_ip4_arp_events_reply);
  VAPI_DBG("Assigned msg id %d to want_ip4_arp_events_reply", vapi_msg_id_want_ip4_arp_events_reply);
}

static void __attribute__((constructor)) __vapi_constructor_delete_subif()
{
  static const char name[] = "delete_subif";
  static const char name_with_crc[] = "delete_subif_6038f848";
  static vapi_message_desc_t __vapi_metadata_delete_subif = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_delete_subif, payload),
    sizeof(vapi_msg_delete_subif),
    (generic_swap_fn_t)vapi_msg_delete_subif_hton,
    (generic_swap_fn_t)vapi_msg_delete_subif_ntoh,
    ~0,
  };

  vapi_msg_id_delete_subif = vapi_register_msg(&__vapi_metadata_delete_subif);
  VAPI_DBG("Assigned msg id %d to delete_subif", vapi_msg_id_delete_subif);
}

static void __attribute__((constructor)) __vapi_constructor_reset_vrf_reply()
{
  static const char name[] = "reset_vrf_reply";
  static const char name_with_crc[] = "reset_vrf_reply_5f283863";
  static vapi_message_desc_t __vapi_metadata_reset_vrf_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_reset_vrf_reply, payload),
    sizeof(vapi_msg_reset_vrf_reply),
    (generic_swap_fn_t)vapi_msg_reset_vrf_reply_hton,
    (generic_swap_fn_t)vapi_msg_reset_vrf_reply_ntoh,
    ~0,
  };

  vapi_msg_id_reset_vrf_reply = vapi_register_msg(&__vapi_metadata_reset_vrf_reply);
  VAPI_DBG("Assigned msg id %d to reset_vrf_reply", vapi_msg_id_reset_vrf_reply);
}

static void __attribute__((constructor)) __vapi_constructor_feature_enable_disable_reply()
{
  static const char name[] = "feature_enable_disable_reply";
  static const char name_with_crc[] = "feature_enable_disable_reply_f6e14373";
  static vapi_message_desc_t __vapi_metadata_feature_enable_disable_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_feature_enable_disable_reply, payload),
    sizeof(vapi_msg_feature_enable_disable_reply),
    (generic_swap_fn_t)vapi_msg_feature_enable_disable_reply_hton,
    (generic_swap_fn_t)vapi_msg_feature_enable_disable_reply_ntoh,
    ~0,
  };

  vapi_msg_id_feature_enable_disable_reply = vapi_register_msg(&__vapi_metadata_feature_enable_disable_reply);
  VAPI_DBG("Assigned msg id %d to feature_enable_disable_reply", vapi_msg_id_feature_enable_disable_reply);
}

static void __attribute__((constructor)) __vapi_constructor_create_subif_reply()
{
  static const char name[] = "create_subif_reply";
  static const char name_with_crc[] = "create_subif_reply_92272bcb";
  static vapi_message_desc_t __vapi_metadata_create_subif_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_create_subif_reply, payload),
    sizeof(vapi_msg_create_subif_reply),
    (generic_swap_fn_t)vapi_msg_create_subif_reply_hton,
    (generic_swap_fn_t)vapi_msg_create_subif_reply_ntoh,
    ~0,
  };

  vapi_msg_id_create_subif_reply = vapi_register_msg(&__vapi_metadata_create_subif_reply);
  VAPI_DBG("Assigned msg id %d to create_subif_reply", vapi_msg_id_create_subif_reply);
}

static void __attribute__((constructor)) __vapi_constructor_punt_socket_register()
{
  static const char name[] = "punt_socket_register";
  static const char name_with_crc[] = "punt_socket_register_fbd069cb";
  static vapi_message_desc_t __vapi_metadata_punt_socket_register = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_punt_socket_register, payload),
    sizeof(vapi_msg_punt_socket_register),
    (generic_swap_fn_t)vapi_msg_punt_socket_register_hton,
    (generic_swap_fn_t)vapi_msg_punt_socket_register_ntoh,
    ~0,
  };

  vapi_msg_id_punt_socket_register = vapi_register_msg(&__vapi_metadata_punt_socket_register);
  VAPI_DBG("Assigned msg id %d to punt_socket_register", vapi_msg_id_punt_socket_register);
}

static void __attribute__((constructor)) __vapi_constructor_want_oam_events_reply()
{
  static const char name[] = "want_oam_events_reply";
  static const char name_with_crc[] = "want_oam_events_reply_266a677d";
  static vapi_message_desc_t __vapi_metadata_want_oam_events_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_want_oam_events_reply, payload),
    sizeof(vapi_msg_want_oam_events_reply),
    (generic_swap_fn_t)vapi_msg_want_oam_events_reply_hton,
    (generic_swap_fn_t)vapi_msg_want_oam_events_reply_ntoh,
    ~0,
  };

  vapi_msg_id_want_oam_events_reply = vapi_register_msg(&__vapi_metadata_want_oam_events_reply);
  VAPI_DBG("Assigned msg id %d to want_oam_events_reply", vapi_msg_id_want_oam_events_reply);
}

static void __attribute__((constructor)) __vapi_constructor_want_oam_events()
{
  static const char name[] = "want_oam_events";
  static const char name_with_crc[] = "want_oam_events_948ef12a";
  static vapi_message_desc_t __vapi_metadata_want_oam_events = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_want_oam_events, payload),
    sizeof(vapi_msg_want_oam_events),
    (generic_swap_fn_t)vapi_msg_want_oam_events_hton,
    (generic_swap_fn_t)vapi_msg_want_oam_events_ntoh,
    ~0,
  };

  vapi_msg_id_want_oam_events = vapi_register_msg(&__vapi_metadata_want_oam_events);
  VAPI_DBG("Assigned msg id %d to want_oam_events", vapi_msg_id_want_oam_events);
}

static void __attribute__((constructor)) __vapi_constructor_ip_source_and_port_range_check_add_del_reply()
{
  static const char name[] = "ip_source_and_port_range_check_add_del_reply";
  static const char name_with_crc[] = "ip_source_and_port_range_check_add_del_reply_35df8160";
  static vapi_message_desc_t __vapi_metadata_ip_source_and_port_range_check_add_del_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_ip_source_and_port_range_check_add_del_reply, payload),
    sizeof(vapi_msg_ip_source_and_port_range_check_add_del_reply),
    (generic_swap_fn_t)vapi_msg_ip_source_and_port_range_check_add_del_reply_hton,
    (generic_swap_fn_t)vapi_msg_ip_source_and_port_range_check_add_del_reply_ntoh,
    ~0,
  };

  vapi_msg_id_ip_source_and_port_range_check_add_del_reply = vapi_register_msg(&__vapi_metadata_ip_source_and_port_range_check_add_del_reply);
  VAPI_DBG("Assigned msg id %d to ip_source_and_port_range_check_add_del_reply", vapi_msg_id_ip_source_and_port_range_check_add_del_reply);
}

static void __attribute__((constructor)) __vapi_constructor_classify_set_interface_ip_table_reply()
{
  static const char name[] = "classify_set_interface_ip_table_reply";
  static const char name_with_crc[] = "classify_set_interface_ip_table_reply_dc391c34";
  static vapi_message_desc_t __vapi_metadata_classify_set_interface_ip_table_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_classify_set_interface_ip_table_reply, payload),
    sizeof(vapi_msg_classify_set_interface_ip_table_reply),
    (generic_swap_fn_t)vapi_msg_classify_set_interface_ip_table_reply_hton,
    (generic_swap_fn_t)vapi_msg_classify_set_interface_ip_table_reply_ntoh,
    ~0,
  };

  vapi_msg_id_classify_set_interface_ip_table_reply = vapi_register_msg(&__vapi_metadata_classify_set_interface_ip_table_reply);
  VAPI_DBG("Assigned msg id %d to classify_set_interface_ip_table_reply", vapi_msg_id_classify_set_interface_ip_table_reply);
}

static void __attribute__((constructor)) __vapi_constructor_create_loopback_instance()
{
  static const char name[] = "create_loopback_instance";
  static const char name_with_crc[] = "create_loopback_instance_967694f1";
  static vapi_message_desc_t __vapi_metadata_create_loopback_instance = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_create_loopback_instance, payload),
    sizeof(vapi_msg_create_loopback_instance),
    (generic_swap_fn_t)vapi_msg_create_loopback_instance_hton,
    (generic_swap_fn_t)vapi_msg_create_loopback_instance_ntoh,
    ~0,
  };

  vapi_msg_id_create_loopback_instance = vapi_register_msg(&__vapi_metadata_create_loopback_instance);
  VAPI_DBG("Assigned msg id %d to create_loopback_instance", vapi_msg_id_create_loopback_instance);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_set_l2_xconnect_reply()
{
  static const char name[] = "sw_interface_set_l2_xconnect_reply";
  static const char name_with_crc[] = "sw_interface_set_l2_xconnect_reply_6e45eed4";
  static vapi_message_desc_t __vapi_metadata_sw_interface_set_l2_xconnect_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_sw_interface_set_l2_xconnect_reply, payload),
    sizeof(vapi_msg_sw_interface_set_l2_xconnect_reply),
    (generic_swap_fn_t)vapi_msg_sw_interface_set_l2_xconnect_reply_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_set_l2_xconnect_reply_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_set_l2_xconnect_reply = vapi_register_msg(&__vapi_metadata_sw_interface_set_l2_xconnect_reply);
  VAPI_DBG("Assigned msg id %d to sw_interface_set_l2_xconnect_reply", vapi_msg_id_sw_interface_set_l2_xconnect_reply);
}

static void __attribute__((constructor)) __vapi_constructor_cli_inband_reply()
{
  static const char name[] = "cli_inband_reply";
  static const char name_with_crc[] = "cli_inband_reply_c1835761";
  static vapi_message_desc_t __vapi_metadata_cli_inband_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_cli_inband_reply, payload),
    sizeof(vapi_msg_cli_inband_reply),
    (generic_swap_fn_t)vapi_msg_cli_inband_reply_hton,
    (generic_swap_fn_t)vapi_msg_cli_inband_reply_ntoh,
    ~0,
  };

  vapi_msg_id_cli_inband_reply = vapi_register_msg(&__vapi_metadata_cli_inband_reply);
  VAPI_DBG("Assigned msg id %d to cli_inband_reply", vapi_msg_id_cli_inband_reply);
}

static void __attribute__((constructor)) __vapi_constructor_input_acl_set_interface()
{
  static const char name[] = "input_acl_set_interface";
  static const char name_with_crc[] = "input_acl_set_interface_34d2fc33";
  static vapi_message_desc_t __vapi_metadata_input_acl_set_interface = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_input_acl_set_interface, payload),
    sizeof(vapi_msg_input_acl_set_interface),
    (generic_swap_fn_t)vapi_msg_input_acl_set_interface_hton,
    (generic_swap_fn_t)vapi_msg_input_acl_set_interface_ntoh,
    ~0,
  };

  vapi_msg_id_input_acl_set_interface = vapi_register_msg(&__vapi_metadata_input_acl_set_interface);
  VAPI_DBG("Assigned msg id %d to input_acl_set_interface", vapi_msg_id_input_acl_set_interface);
}

static void __attribute__((constructor)) __vapi_constructor_ioam_disable()
{
  static const char name[] = "ioam_disable";
  static const char name_with_crc[] = "ioam_disable_aff26d33";
  static vapi_message_desc_t __vapi_metadata_ioam_disable = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_ioam_disable, payload),
    sizeof(vapi_msg_ioam_disable),
    (generic_swap_fn_t)vapi_msg_ioam_disable_hton,
    (generic_swap_fn_t)vapi_msg_ioam_disable_ntoh,
    ~0,
  };

  vapi_msg_id_ioam_disable = vapi_register_msg(&__vapi_metadata_ioam_disable);
  VAPI_DBG("Assigned msg id %d to ioam_disable", vapi_msg_id_ioam_disable);
}

static void __attribute__((constructor)) __vapi_constructor_proxy_arp_add_del_reply()
{
  static const char name[] = "proxy_arp_add_del_reply";
  static const char name_with_crc[] = "proxy_arp_add_del_reply_8e2d621d";
  static vapi_message_desc_t __vapi_metadata_proxy_arp_add_del_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_proxy_arp_add_del_reply, payload),
    sizeof(vapi_msg_proxy_arp_add_del_reply),
    (generic_swap_fn_t)vapi_msg_proxy_arp_add_del_reply_hton,
    (generic_swap_fn_t)vapi_msg_proxy_arp_add_del_reply_ntoh,
    ~0,
  };

  vapi_msg_id_proxy_arp_add_del_reply = vapi_register_msg(&__vapi_metadata_proxy_arp_add_del_reply);
  VAPI_DBG("Assigned msg id %d to proxy_arp_add_del_reply", vapi_msg_id_proxy_arp_add_del_reply);
}

static void __attribute__((constructor)) __vapi_constructor_create_vlan_subif_reply()
{
  static const char name[] = "create_vlan_subif_reply";
  static const char name_with_crc[] = "create_vlan_subif_reply_8f36b888";
  static vapi_message_desc_t __vapi_metadata_create_vlan_subif_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_create_vlan_subif_reply, payload),
    sizeof(vapi_msg_create_vlan_subif_reply),
    (generic_swap_fn_t)vapi_msg_create_vlan_subif_reply_hton,
    (generic_swap_fn_t)vapi_msg_create_vlan_subif_reply_ntoh,
    ~0,
  };

  vapi_msg_id_create_vlan_subif_reply = vapi_register_msg(&__vapi_metadata_create_vlan_subif_reply);
  VAPI_DBG("Assigned msg id %d to create_vlan_subif_reply", vapi_msg_id_create_vlan_subif_reply);
}

static void __attribute__((constructor)) __vapi_constructor_reset_fib()
{
  static const char name[] = "reset_fib";
  static const char name_with_crc[] = "reset_fib_6f17106b";
  static vapi_message_desc_t __vapi_metadata_reset_fib = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_reset_fib, payload),
    sizeof(vapi_msg_reset_fib),
    (generic_swap_fn_t)vapi_msg_reset_fib_hton,
    (generic_swap_fn_t)vapi_msg_reset_fib_ntoh,
    ~0,
  };

  vapi_msg_id_reset_fib = vapi_register_msg(&__vapi_metadata_reset_fib);
  VAPI_DBG("Assigned msg id %d to reset_fib", vapi_msg_id_reset_fib);
}

static void __attribute__((constructor)) __vapi_constructor_pg_enable_disable()
{
  static const char name[] = "pg_enable_disable";
  static const char name_with_crc[] = "pg_enable_disable_7d0b90ff";
  static vapi_message_desc_t __vapi_metadata_pg_enable_disable = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_pg_enable_disable, payload),
    sizeof(vapi_msg_pg_enable_disable),
    (generic_swap_fn_t)vapi_msg_pg_enable_disable_hton,
    (generic_swap_fn_t)vapi_msg_pg_enable_disable_ntoh,
    ~0,
  };

  vapi_msg_id_pg_enable_disable = vapi_register_msg(&__vapi_metadata_pg_enable_disable);
  VAPI_DBG("Assigned msg id %d to pg_enable_disable", vapi_msg_id_pg_enable_disable);
}

static void __attribute__((constructor)) __vapi_constructor_want_ip6_nd_events()
{
  static const char name[] = "want_ip6_nd_events";
  static const char name_with_crc[] = "want_ip6_nd_events_9586ba55";
  static vapi_message_desc_t __vapi_metadata_want_ip6_nd_events = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_want_ip6_nd_events, payload),
    sizeof(vapi_msg_want_ip6_nd_events),
    (generic_swap_fn_t)vapi_msg_want_ip6_nd_events_hton,
    (generic_swap_fn_t)vapi_msg_want_ip6_nd_events_ntoh,
    ~0,
  };

  vapi_msg_id_want_ip6_nd_events = vapi_register_msg(&__vapi_metadata_want_ip6_nd_events);
  VAPI_DBG("Assigned msg id %d to want_ip6_nd_events", vapi_msg_id_want_ip6_nd_events);
}

static void __attribute__((constructor)) __vapi_constructor_l2_patch_add_del()
{
  static const char name[] = "l2_patch_add_del";
  static const char name_with_crc[] = "l2_patch_add_del_9b10029a";
  static vapi_message_desc_t __vapi_metadata_l2_patch_add_del = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_l2_patch_add_del, payload),
    sizeof(vapi_msg_l2_patch_add_del),
    (generic_swap_fn_t)vapi_msg_l2_patch_add_del_hton,
    (generic_swap_fn_t)vapi_msg_l2_patch_add_del_ntoh,
    ~0,
  };

  vapi_msg_id_l2_patch_add_del = vapi_register_msg(&__vapi_metadata_l2_patch_add_del);
  VAPI_DBG("Assigned msg id %d to l2_patch_add_del", vapi_msg_id_l2_patch_add_del);
}

static void __attribute__((constructor)) __vapi_constructor_cli_reply()
{
  static const char name[] = "cli_reply";
  static const char name_with_crc[] = "cli_reply_594a0b2e";
  static vapi_message_desc_t __vapi_metadata_cli_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_cli_reply, payload),
    sizeof(vapi_msg_cli_reply),
    (generic_swap_fn_t)vapi_msg_cli_reply_hton,
    (generic_swap_fn_t)vapi_msg_cli_reply_ntoh,
    ~0,
  };

  vapi_msg_id_cli_reply = vapi_register_msg(&__vapi_metadata_cli_reply);
  VAPI_DBG("Assigned msg id %d to cli_reply", vapi_msg_id_cli_reply);
}

static void __attribute__((constructor)) __vapi_constructor_proxy_arp_intfc_enable_disable_reply()
{
  static const char name[] = "proxy_arp_intfc_enable_disable_reply";
  static const char name_with_crc[] = "proxy_arp_intfc_enable_disable_reply_23d273cd";
  static vapi_message_desc_t __vapi_metadata_proxy_arp_intfc_enable_disable_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_proxy_arp_intfc_enable_disable_reply, payload),
    sizeof(vapi_msg_proxy_arp_intfc_enable_disable_reply),
    (generic_swap_fn_t)vapi_msg_proxy_arp_intfc_enable_disable_reply_hton,
    (generic_swap_fn_t)vapi_msg_proxy_arp_intfc_enable_disable_reply_ntoh,
    ~0,
  };

  vapi_msg_id_proxy_arp_intfc_enable_disable_reply = vapi_register_msg(&__vapi_metadata_proxy_arp_intfc_enable_disable_reply);
  VAPI_DBG("Assigned msg id %d to proxy_arp_intfc_enable_disable_reply", vapi_msg_id_proxy_arp_intfc_enable_disable_reply);
}

static void __attribute__((constructor)) __vapi_constructor_control_ping_reply()
{
  static const char name[] = "control_ping_reply";
  static const char name_with_crc[] = "control_ping_reply_aa016e7b";
  static vapi_message_desc_t __vapi_metadata_control_ping_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_control_ping_reply, payload),
    sizeof(vapi_msg_control_ping_reply),
    (generic_swap_fn_t)vapi_msg_control_ping_reply_hton,
    (generic_swap_fn_t)vapi_msg_control_ping_reply_ntoh,
    ~0,
  };

  vapi_msg_id_control_ping_reply = vapi_register_msg(&__vapi_metadata_control_ping_reply);
  VAPI_DBG("Assigned msg id %d to control_ping_reply", vapi_msg_id_control_ping_reply);
}

static void __attribute__((constructor)) __vapi_constructor_oam_event()
{
  static const char name[] = "oam_event";
  static const char name_with_crc[] = "oam_event_4f285ade";
  static vapi_message_desc_t __vapi_metadata_oam_event = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    false,
    0,
    offsetof(vapi_msg_oam_event, payload),
    sizeof(vapi_msg_oam_event),
    (generic_swap_fn_t)vapi_msg_oam_event_hton,
    (generic_swap_fn_t)vapi_msg_oam_event_ntoh,
    ~0,
  };

  vapi_msg_id_oam_event = vapi_register_msg(&__vapi_metadata_oam_event);
  VAPI_DBG("Assigned msg id %d to oam_event", vapi_msg_id_oam_event);
}

static void __attribute__((constructor)) __vapi_constructor_show_version()
{
  static const char name[] = "show_version";
  static const char name_with_crc[] = "show_version_f18f9480";
  static vapi_message_desc_t __vapi_metadata_show_version = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_show_version),
    (generic_swap_fn_t)vapi_msg_show_version_hton,
    (generic_swap_fn_t)vapi_msg_show_version_ntoh,
    ~0,
  };

  vapi_msg_id_show_version = vapi_register_msg(&__vapi_metadata_show_version);
  VAPI_DBG("Assigned msg id %d to show_version", vapi_msg_id_show_version);
}

static void __attribute__((constructor)) __vapi_constructor_classify_set_interface_l2_tables()
{
  static const char name[] = "classify_set_interface_l2_tables";
  static const char name_with_crc[] = "classify_set_interface_l2_tables_ed9ccf0d";
  static vapi_message_desc_t __vapi_metadata_classify_set_interface_l2_tables = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_classify_set_interface_l2_tables, payload),
    sizeof(vapi_msg_classify_set_interface_l2_tables),
    (generic_swap_fn_t)vapi_msg_classify_set_interface_l2_tables_hton,
    (generic_swap_fn_t)vapi_msg_classify_set_interface_l2_tables_ntoh,
    ~0,
  };

  vapi_msg_id_classify_set_interface_l2_tables = vapi_register_msg(&__vapi_metadata_classify_set_interface_l2_tables);
  VAPI_DBG("Assigned msg id %d to classify_set_interface_l2_tables", vapi_msg_id_classify_set_interface_l2_tables);
}

static void __attribute__((constructor)) __vapi_constructor_reset_vrf()
{
  static const char name[] = "reset_vrf";
  static const char name_with_crc[] = "reset_vrf_eb07deb0";
  static vapi_message_desc_t __vapi_metadata_reset_vrf = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_reset_vrf, payload),
    sizeof(vapi_msg_reset_vrf),
    (generic_swap_fn_t)vapi_msg_reset_vrf_hton,
    (generic_swap_fn_t)vapi_msg_reset_vrf_ntoh,
    ~0,
  };

  vapi_msg_id_reset_vrf = vapi_register_msg(&__vapi_metadata_reset_vrf);
  VAPI_DBG("Assigned msg id %d to reset_vrf", vapi_msg_id_reset_vrf);
}

static void __attribute__((constructor)) __vapi_constructor_input_acl_set_interface_reply()
{
  static const char name[] = "input_acl_set_interface_reply";
  static const char name_with_crc[] = "input_acl_set_interface_reply_ba0110e3";
  static vapi_message_desc_t __vapi_metadata_input_acl_set_interface_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_input_acl_set_interface_reply, payload),
    sizeof(vapi_msg_input_acl_set_interface_reply),
    (generic_swap_fn_t)vapi_msg_input_acl_set_interface_reply_hton,
    (generic_swap_fn_t)vapi_msg_input_acl_set_interface_reply_ntoh,
    ~0,
  };

  vapi_msg_id_input_acl_set_interface_reply = vapi_register_msg(&__vapi_metadata_input_acl_set_interface_reply);
  VAPI_DBG("Assigned msg id %d to input_acl_set_interface_reply", vapi_msg_id_input_acl_set_interface_reply);
}

static void __attribute__((constructor)) __vapi_constructor_bd_ip_mac_add_del()
{
  static const char name[] = "bd_ip_mac_add_del";
  static const char name_with_crc[] = "bd_ip_mac_add_del_ad819817";
  static vapi_message_desc_t __vapi_metadata_bd_ip_mac_add_del = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_bd_ip_mac_add_del, payload),
    sizeof(vapi_msg_bd_ip_mac_add_del),
    (generic_swap_fn_t)vapi_msg_bd_ip_mac_add_del_hton,
    (generic_swap_fn_t)vapi_msg_bd_ip_mac_add_del_ntoh,
    ~0,
  };

  vapi_msg_id_bd_ip_mac_add_del = vapi_register_msg(&__vapi_metadata_bd_ip_mac_add_del);
  VAPI_DBG("Assigned msg id %d to bd_ip_mac_add_del", vapi_msg_id_bd_ip_mac_add_del);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_set_l2_bridge_reply()
{
  static const char name[] = "sw_interface_set_l2_bridge_reply";
  static const char name_with_crc[] = "sw_interface_set_l2_bridge_reply_347e08d9";
  static vapi_message_desc_t __vapi_metadata_sw_interface_set_l2_bridge_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_sw_interface_set_l2_bridge_reply, payload),
    sizeof(vapi_msg_sw_interface_set_l2_bridge_reply),
    (generic_swap_fn_t)vapi_msg_sw_interface_set_l2_bridge_reply_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_set_l2_bridge_reply_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_set_l2_bridge_reply = vapi_register_msg(&__vapi_metadata_sw_interface_set_l2_bridge_reply);
  VAPI_DBG("Assigned msg id %d to sw_interface_set_l2_bridge_reply", vapi_msg_id_sw_interface_set_l2_bridge_reply);
}

static void __attribute__((constructor)) __vapi_constructor_oam_add_del()
{
  static const char name[] = "oam_add_del";
  static const char name_with_crc[] = "oam_add_del_b14bc7df";
  static vapi_message_desc_t __vapi_metadata_oam_add_del = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_oam_add_del, payload),
    sizeof(vapi_msg_oam_add_del),
    (generic_swap_fn_t)vapi_msg_oam_add_del_hton,
    (generic_swap_fn_t)vapi_msg_oam_add_del_ntoh,
    ~0,
  };

  vapi_msg_id_oam_add_del = vapi_register_msg(&__vapi_metadata_oam_add_del);
  VAPI_DBG("Assigned msg id %d to oam_add_del", vapi_msg_id_oam_add_del);
}

static void __attribute__((constructor)) __vapi_constructor_get_node_graph()
{
  static const char name[] = "get_node_graph";
  static const char name_with_crc[] = "get_node_graph_f8636a76";
  static vapi_message_desc_t __vapi_metadata_get_node_graph = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_get_node_graph),
    (generic_swap_fn_t)vapi_msg_get_node_graph_hton,
    (generic_swap_fn_t)vapi_msg_get_node_graph_ntoh,
    ~0,
  };

  vapi_msg_id_get_node_graph = vapi_register_msg(&__vapi_metadata_get_node_graph);
  VAPI_DBG("Assigned msg id %d to get_node_graph", vapi_msg_id_get_node_graph);
}

static void __attribute__((constructor)) __vapi_constructor_interface_name_renumber()
{
  static const char name[] = "interface_name_renumber";
  static const char name_with_crc[] = "interface_name_renumber_11b7bcec";
  static vapi_message_desc_t __vapi_metadata_interface_name_renumber = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_interface_name_renumber, payload),
    sizeof(vapi_msg_interface_name_renumber),
    (generic_swap_fn_t)vapi_msg_interface_name_renumber_hton,
    (generic_swap_fn_t)vapi_msg_interface_name_renumber_ntoh,
    ~0,
  };

  vapi_msg_id_interface_name_renumber = vapi_register_msg(&__vapi_metadata_interface_name_renumber);
  VAPI_DBG("Assigned msg id %d to interface_name_renumber", vapi_msg_id_interface_name_renumber);
}

static void __attribute__((constructor)) __vapi_constructor_pg_enable_disable_reply()
{
  static const char name[] = "pg_enable_disable_reply";
  static const char name_with_crc[] = "pg_enable_disable_reply_02253bd6";
  static vapi_message_desc_t __vapi_metadata_pg_enable_disable_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_pg_enable_disable_reply, payload),
    sizeof(vapi_msg_pg_enable_disable_reply),
    (generic_swap_fn_t)vapi_msg_pg_enable_disable_reply_hton,
    (generic_swap_fn_t)vapi_msg_pg_enable_disable_reply_ntoh,
    ~0,
  };

  vapi_msg_id_pg_enable_disable_reply = vapi_register_msg(&__vapi_metadata_pg_enable_disable_reply);
  VAPI_DBG("Assigned msg id %d to pg_enable_disable_reply", vapi_msg_id_pg_enable_disable_reply);
}

static void __attribute__((constructor)) __vapi_constructor_create_loopback()
{
  static const char name[] = "create_loopback";
  static const char name_with_crc[] = "create_loopback_b2602de5";
  static vapi_message_desc_t __vapi_metadata_create_loopback = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_create_loopback, payload),
    sizeof(vapi_msg_create_loopback),
    (generic_swap_fn_t)vapi_msg_create_loopback_hton,
    (generic_swap_fn_t)vapi_msg_create_loopback_ntoh,
    ~0,
  };

  vapi_msg_id_create_loopback = vapi_register_msg(&__vapi_metadata_create_loopback);
  VAPI_DBG("Assigned msg id %d to create_loopback", vapi_msg_id_create_loopback);
}

static void __attribute__((constructor)) __vapi_constructor_create_loopback_reply()
{
  static const char name[] = "create_loopback_reply";
  static const char name_with_crc[] = "create_loopback_reply_9520f804";
  static vapi_message_desc_t __vapi_metadata_create_loopback_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_create_loopback_reply, payload),
    sizeof(vapi_msg_create_loopback_reply),
    (generic_swap_fn_t)vapi_msg_create_loopback_reply_hton,
    (generic_swap_fn_t)vapi_msg_create_loopback_reply_ntoh,
    ~0,
  };

  vapi_msg_id_create_loopback_reply = vapi_register_msg(&__vapi_metadata_create_loopback_reply);
  VAPI_DBG("Assigned msg id %d to create_loopback_reply", vapi_msg_id_create_loopback_reply);
}

static void __attribute__((constructor)) __vapi_constructor_set_arp_neighbor_limit_reply()
{
  static const char name[] = "set_arp_neighbor_limit_reply";
  static const char name_with_crc[] = "set_arp_neighbor_limit_reply_a6b30518";
  static vapi_message_desc_t __vapi_metadata_set_arp_neighbor_limit_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_set_arp_neighbor_limit_reply, payload),
    sizeof(vapi_msg_set_arp_neighbor_limit_reply),
    (generic_swap_fn_t)vapi_msg_set_arp_neighbor_limit_reply_hton,
    (generic_swap_fn_t)vapi_msg_set_arp_neighbor_limit_reply_ntoh,
    ~0,
  };

  vapi_msg_id_set_arp_neighbor_limit_reply = vapi_register_msg(&__vapi_metadata_set_arp_neighbor_limit_reply);
  VAPI_DBG("Assigned msg id %d to set_arp_neighbor_limit_reply", vapi_msg_id_set_arp_neighbor_limit_reply);
}

static void __attribute__((constructor)) __vapi_constructor_add_node_next_reply()
{
  static const char name[] = "add_node_next_reply";
  static const char name_with_crc[] = "add_node_next_reply_e89d6eed";
  static vapi_message_desc_t __vapi_metadata_add_node_next_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_add_node_next_reply, payload),
    sizeof(vapi_msg_add_node_next_reply),
    (generic_swap_fn_t)vapi_msg_add_node_next_reply_hton,
    (generic_swap_fn_t)vapi_msg_add_node_next_reply_ntoh,
    ~0,
  };

  vapi_msg_id_add_node_next_reply = vapi_register_msg(&__vapi_metadata_add_node_next_reply);
  VAPI_DBG("Assigned msg id %d to add_node_next_reply", vapi_msg_id_add_node_next_reply);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_set_mpls_enable()
{
  static const char name[] = "sw_interface_set_mpls_enable";
  static const char name_with_crc[] = "sw_interface_set_mpls_enable_37f6357e";
  static vapi_message_desc_t __vapi_metadata_sw_interface_set_mpls_enable = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_sw_interface_set_mpls_enable, payload),
    sizeof(vapi_msg_sw_interface_set_mpls_enable),
    (generic_swap_fn_t)vapi_msg_sw_interface_set_mpls_enable_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_set_mpls_enable_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_set_mpls_enable = vapi_register_msg(&__vapi_metadata_sw_interface_set_mpls_enable);
  VAPI_DBG("Assigned msg id %d to sw_interface_set_mpls_enable", vapi_msg_id_sw_interface_set_mpls_enable);
}

static void __attribute__((constructor)) __vapi_constructor_punt_socket_deregister()
{
  static const char name[] = "punt_socket_deregister";
  static const char name_with_crc[] = "punt_socket_deregister_c02dbee8";
  static vapi_message_desc_t __vapi_metadata_punt_socket_deregister = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_punt_socket_deregister, payload),
    sizeof(vapi_msg_punt_socket_deregister),
    (generic_swap_fn_t)vapi_msg_punt_socket_deregister_hton,
    (generic_swap_fn_t)vapi_msg_punt_socket_deregister_ntoh,
    ~0,
  };

  vapi_msg_id_punt_socket_deregister = vapi_register_msg(&__vapi_metadata_punt_socket_deregister);
  VAPI_DBG("Assigned msg id %d to punt_socket_deregister", vapi_msg_id_punt_socket_deregister);
}

static void __attribute__((constructor)) __vapi_constructor_ip_source_and_port_range_check_interface_add_del()
{
  static const char name[] = "ip_source_and_port_range_check_interface_add_del";
  static const char name_with_crc[] = "ip_source_and_port_range_check_interface_add_del_4a6438f1";
  static vapi_message_desc_t __vapi_metadata_ip_source_and_port_range_check_interface_add_del = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_ip_source_and_port_range_check_interface_add_del, payload),
    sizeof(vapi_msg_ip_source_and_port_range_check_interface_add_del),
    (generic_swap_fn_t)vapi_msg_ip_source_and_port_range_check_interface_add_del_hton,
    (generic_swap_fn_t)vapi_msg_ip_source_and_port_range_check_interface_add_del_ntoh,
    ~0,
  };

  vapi_msg_id_ip_source_and_port_range_check_interface_add_del = vapi_register_msg(&__vapi_metadata_ip_source_and_port_range_check_interface_add_del);
  VAPI_DBG("Assigned msg id %d to ip_source_and_port_range_check_interface_add_del", vapi_msg_id_ip_source_and_port_range_check_interface_add_del);
}

static void __attribute__((constructor)) __vapi_constructor_punt_reply()
{
  static const char name[] = "punt_reply";
  static const char name_with_crc[] = "punt_reply_cca27fbe";
  static vapi_message_desc_t __vapi_metadata_punt_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_punt_reply, payload),
    sizeof(vapi_msg_punt_reply),
    (generic_swap_fn_t)vapi_msg_punt_reply_hton,
    (generic_swap_fn_t)vapi_msg_punt_reply_ntoh,
    ~0,
  };

  vapi_msg_id_punt_reply = vapi_register_msg(&__vapi_metadata_punt_reply);
  VAPI_DBG("Assigned msg id %d to punt_reply", vapi_msg_id_punt_reply);
}

static void __attribute__((constructor)) __vapi_constructor_control_ping()
{
  static const char name[] = "control_ping";
  static const char name_with_crc[] = "control_ping_ea1bf4f7";
  static vapi_message_desc_t __vapi_metadata_control_ping = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_control_ping),
    (generic_swap_fn_t)vapi_msg_control_ping_hton,
    (generic_swap_fn_t)vapi_msg_control_ping_ntoh,
    ~0,
  };

  vapi_msg_id_control_ping = vapi_register_msg(&__vapi_metadata_control_ping);
  VAPI_DBG("Assigned msg id %d to control_ping", vapi_msg_id_control_ping);
}


static inline void vapi_set_vapi_msg_delete_subif_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_delete_subif_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_delete_subif_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ip6_nd_event_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ip6_nd_event *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ip6_nd_event, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_pg_create_interface_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_pg_create_interface_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_pg_create_interface_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_pg_capture_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_pg_capture_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_pg_capture_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_sw_interface_set_vpath_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_sw_interface_set_vpath_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_sw_interface_set_vpath_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_get_node_index_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_get_node_index_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_get_node_index_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_interface_name_renumber_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_interface_name_renumber_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_interface_name_renumber_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ip4_arp_event_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ip4_arp_event *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ip4_arp_event, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_oam_add_del_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_oam_add_del_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_oam_add_del_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_l2_interface_efp_filter_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_l2_interface_efp_filter_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_l2_interface_efp_filter_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ioam_disable_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ioam_disable_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ioam_disable_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_punt_socket_deregister_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_punt_socket_deregister_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_punt_socket_deregister_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_bd_ip_mac_add_del_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_bd_ip_mac_add_del_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_bd_ip_mac_add_del_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_reset_fib_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_reset_fib_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_reset_fib_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_want_ip6_nd_events_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_want_ip6_nd_events_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_want_ip6_nd_events_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_l2_patch_add_del_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_l2_patch_add_del_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_l2_patch_add_del_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_get_next_index_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_get_next_index_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_get_next_index_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_sw_interface_set_mpls_enable_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_sw_interface_set_mpls_enable_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_sw_interface_set_mpls_enable_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_show_version_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_show_version_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_show_version_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ip_source_and_port_range_check_interface_add_del_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ip_source_and_port_range_check_interface_add_del_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ip_source_and_port_range_check_interface_add_del_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_punt_socket_register_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_punt_socket_register_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_punt_socket_register_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_create_loopback_instance_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_create_loopback_instance_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_create_loopback_instance_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_delete_loopback_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_delete_loopback_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_delete_loopback_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_classify_set_interface_l2_tables_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_classify_set_interface_l2_tables_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_classify_set_interface_l2_tables_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_get_node_graph_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_get_node_graph_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_get_node_graph_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ioam_enable_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ioam_enable_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ioam_enable_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_want_ip4_arp_events_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_want_ip4_arp_events_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_want_ip4_arp_events_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_reset_vrf_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_reset_vrf_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_reset_vrf_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_feature_enable_disable_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_feature_enable_disable_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_feature_enable_disable_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_create_subif_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_create_subif_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_create_subif_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_want_oam_events_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_want_oam_events_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_want_oam_events_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_ip_source_and_port_range_check_add_del_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_ip_source_and_port_range_check_add_del_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_ip_source_and_port_range_check_add_del_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_classify_set_interface_ip_table_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_classify_set_interface_ip_table_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_classify_set_interface_ip_table_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_sw_interface_set_l2_xconnect_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_sw_interface_set_l2_xconnect_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_sw_interface_set_l2_xconnect_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_cli_inband_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_cli_inband_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_cli_inband_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_proxy_arp_add_del_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_proxy_arp_add_del_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_proxy_arp_add_del_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_create_vlan_subif_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_create_vlan_subif_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_create_vlan_subif_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_cli_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_cli_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_cli_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_proxy_arp_intfc_enable_disable_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_proxy_arp_intfc_enable_disable_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_proxy_arp_intfc_enable_disable_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_control_ping_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_control_ping_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_control_ping_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_oam_event_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_oam_event *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_oam_event, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_input_acl_set_interface_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_input_acl_set_interface_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_input_acl_set_interface_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_sw_interface_set_l2_bridge_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_sw_interface_set_l2_bridge_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_sw_interface_set_l2_bridge_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_pg_enable_disable_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_pg_enable_disable_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_pg_enable_disable_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_create_loopback_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_create_loopback_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_create_loopback_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_set_arp_neighbor_limit_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_set_arp_neighbor_limit_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_set_arp_neighbor_limit_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_add_node_next_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_add_node_next_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_add_node_next_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_punt_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_punt_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_punt_reply, (vapi_event_cb)callback, callback_ctx);
};



static inline vapi_error_e
vapi_send_with_control_ping (vapi_ctx_t ctx, void *msg, u32 context)
{
  vapi_msg_control_ping *ping = vapi_alloc_control_ping (ctx);
  if (!ping)
    {
      return VAPI_ENOMEM;
    }
  ping->header.context = context;
  vapi_msg_control_ping_hton (ping);
  return vapi_send2 (ctx, msg, ping);
}


#ifdef __cplusplus
}
#endif

#endif
