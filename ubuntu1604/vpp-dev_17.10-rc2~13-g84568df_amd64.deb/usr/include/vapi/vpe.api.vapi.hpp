#ifndef __included_hpp_vpe_api_json
#define __included_hpp_vpe_api_json

#include <vapi/vapi.hpp>
#include <vapi/vpe.api.vapi.h>

namespace vapi {

template <> inline void vapi_swap_to_be<vapi_msg_delete_subif_reply>(vapi_msg_delete_subif_reply *msg)
{
  vapi_msg_delete_subif_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_delete_subif_reply>(vapi_msg_delete_subif_reply *msg)
{
  vapi_msg_delete_subif_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_delete_subif_reply>()
{
  return ::vapi_msg_id_delete_subif_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_delete_subif_reply>>()
{
  return ::vapi_msg_id_delete_subif_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_delete_subif_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_delete_subif_reply>(vapi_msg_id_delete_subif_reply);
}

template class Msg<vapi_msg_delete_subif_reply>;

using Delete_subif_reply = Msg<vapi_msg_delete_subif_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_ip6_nd_event>(vapi_msg_ip6_nd_event *msg)
{
  vapi_msg_ip6_nd_event_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip6_nd_event>(vapi_msg_ip6_nd_event *msg)
{
  vapi_msg_ip6_nd_event_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip6_nd_event>()
{
  return ::vapi_msg_id_ip6_nd_event; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip6_nd_event>>()
{
  return ::vapi_msg_id_ip6_nd_event; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip6_nd_event()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip6_nd_event>(vapi_msg_id_ip6_nd_event);
}

template class Msg<vapi_msg_ip6_nd_event>;

using Ip6_nd_event = Msg<vapi_msg_ip6_nd_event>;
template <> inline void vapi_swap_to_be<vapi_msg_pg_create_interface_reply>(vapi_msg_pg_create_interface_reply *msg)
{
  vapi_msg_pg_create_interface_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_pg_create_interface_reply>(vapi_msg_pg_create_interface_reply *msg)
{
  vapi_msg_pg_create_interface_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_pg_create_interface_reply>()
{
  return ::vapi_msg_id_pg_create_interface_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_pg_create_interface_reply>>()
{
  return ::vapi_msg_id_pg_create_interface_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_pg_create_interface_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_pg_create_interface_reply>(vapi_msg_id_pg_create_interface_reply);
}

template class Msg<vapi_msg_pg_create_interface_reply>;

using Pg_create_interface_reply = Msg<vapi_msg_pg_create_interface_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_pg_capture_reply>(vapi_msg_pg_capture_reply *msg)
{
  vapi_msg_pg_capture_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_pg_capture_reply>(vapi_msg_pg_capture_reply *msg)
{
  vapi_msg_pg_capture_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_pg_capture_reply>()
{
  return ::vapi_msg_id_pg_capture_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_pg_capture_reply>>()
{
  return ::vapi_msg_id_pg_capture_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_pg_capture_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_pg_capture_reply>(vapi_msg_id_pg_capture_reply);
}

template class Msg<vapi_msg_pg_capture_reply>;

using Pg_capture_reply = Msg<vapi_msg_pg_capture_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_set_vpath_reply>(vapi_msg_sw_interface_set_vpath_reply *msg)
{
  vapi_msg_sw_interface_set_vpath_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_set_vpath_reply>(vapi_msg_sw_interface_set_vpath_reply *msg)
{
  vapi_msg_sw_interface_set_vpath_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_set_vpath_reply>()
{
  return ::vapi_msg_id_sw_interface_set_vpath_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_set_vpath_reply>>()
{
  return ::vapi_msg_id_sw_interface_set_vpath_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_set_vpath_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_set_vpath_reply>(vapi_msg_id_sw_interface_set_vpath_reply);
}

template class Msg<vapi_msg_sw_interface_set_vpath_reply>;

using Sw_interface_set_vpath_reply = Msg<vapi_msg_sw_interface_set_vpath_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_get_node_index_reply>(vapi_msg_get_node_index_reply *msg)
{
  vapi_msg_get_node_index_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_get_node_index_reply>(vapi_msg_get_node_index_reply *msg)
{
  vapi_msg_get_node_index_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_get_node_index_reply>()
{
  return ::vapi_msg_id_get_node_index_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_get_node_index_reply>>()
{
  return ::vapi_msg_id_get_node_index_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_get_node_index_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_get_node_index_reply>(vapi_msg_id_get_node_index_reply);
}

template class Msg<vapi_msg_get_node_index_reply>;

using Get_node_index_reply = Msg<vapi_msg_get_node_index_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_interface_name_renumber_reply>(vapi_msg_interface_name_renumber_reply *msg)
{
  vapi_msg_interface_name_renumber_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_interface_name_renumber_reply>(vapi_msg_interface_name_renumber_reply *msg)
{
  vapi_msg_interface_name_renumber_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_interface_name_renumber_reply>()
{
  return ::vapi_msg_id_interface_name_renumber_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_interface_name_renumber_reply>>()
{
  return ::vapi_msg_id_interface_name_renumber_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_interface_name_renumber_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_interface_name_renumber_reply>(vapi_msg_id_interface_name_renumber_reply);
}

template class Msg<vapi_msg_interface_name_renumber_reply>;

using Interface_name_renumber_reply = Msg<vapi_msg_interface_name_renumber_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_cli>(vapi_msg_cli *msg)
{
  vapi_msg_cli_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_cli>(vapi_msg_cli *msg)
{
  vapi_msg_cli_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_cli>()
{
  return ::vapi_msg_id_cli; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_cli>>()
{
  return ::vapi_msg_id_cli; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_cli()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_cli>(vapi_msg_id_cli);
}

template <> inline vapi_msg_cli* vapi_alloc<vapi_msg_cli>(Connection &con)
{
  vapi_msg_cli* result = vapi_alloc_cli(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_cli>;

template class Request<vapi_msg_cli, vapi_msg_cli_reply>;

using Cli = Request<vapi_msg_cli, vapi_msg_cli_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_ip4_arp_event>(vapi_msg_ip4_arp_event *msg)
{
  vapi_msg_ip4_arp_event_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip4_arp_event>(vapi_msg_ip4_arp_event *msg)
{
  vapi_msg_ip4_arp_event_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip4_arp_event>()
{
  return ::vapi_msg_id_ip4_arp_event; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip4_arp_event>>()
{
  return ::vapi_msg_id_ip4_arp_event; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip4_arp_event()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip4_arp_event>(vapi_msg_id_ip4_arp_event);
}

template class Msg<vapi_msg_ip4_arp_event>;

using Ip4_arp_event = Msg<vapi_msg_ip4_arp_event>;
template <> inline void vapi_swap_to_be<vapi_msg_oam_add_del_reply>(vapi_msg_oam_add_del_reply *msg)
{
  vapi_msg_oam_add_del_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_oam_add_del_reply>(vapi_msg_oam_add_del_reply *msg)
{
  vapi_msg_oam_add_del_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_oam_add_del_reply>()
{
  return ::vapi_msg_id_oam_add_del_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_oam_add_del_reply>>()
{
  return ::vapi_msg_id_oam_add_del_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_oam_add_del_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_oam_add_del_reply>(vapi_msg_id_oam_add_del_reply);
}

template class Msg<vapi_msg_oam_add_del_reply>;

using Oam_add_del_reply = Msg<vapi_msg_oam_add_del_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_ip_source_and_port_range_check_add_del>(vapi_msg_ip_source_and_port_range_check_add_del *msg)
{
  vapi_msg_ip_source_and_port_range_check_add_del_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip_source_and_port_range_check_add_del>(vapi_msg_ip_source_and_port_range_check_add_del *msg)
{
  vapi_msg_ip_source_and_port_range_check_add_del_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip_source_and_port_range_check_add_del>()
{
  return ::vapi_msg_id_ip_source_and_port_range_check_add_del; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip_source_and_port_range_check_add_del>>()
{
  return ::vapi_msg_id_ip_source_and_port_range_check_add_del; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip_source_and_port_range_check_add_del()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip_source_and_port_range_check_add_del>(vapi_msg_id_ip_source_and_port_range_check_add_del);
}

template <> inline vapi_msg_ip_source_and_port_range_check_add_del* vapi_alloc<vapi_msg_ip_source_and_port_range_check_add_del>(Connection &con)
{
  vapi_msg_ip_source_and_port_range_check_add_del* result = vapi_alloc_ip_source_and_port_range_check_add_del(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_ip_source_and_port_range_check_add_del>;

template class Request<vapi_msg_ip_source_and_port_range_check_add_del, vapi_msg_ip_source_and_port_range_check_add_del_reply>;

using Ip_source_and_port_range_check_add_del = Request<vapi_msg_ip_source_and_port_range_check_add_del, vapi_msg_ip_source_and_port_range_check_add_del_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_get_node_index>(vapi_msg_get_node_index *msg)
{
  vapi_msg_get_node_index_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_get_node_index>(vapi_msg_get_node_index *msg)
{
  vapi_msg_get_node_index_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_get_node_index>()
{
  return ::vapi_msg_id_get_node_index; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_get_node_index>>()
{
  return ::vapi_msg_id_get_node_index; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_get_node_index()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_get_node_index>(vapi_msg_id_get_node_index);
}

template <> inline vapi_msg_get_node_index* vapi_alloc<vapi_msg_get_node_index>(Connection &con)
{
  vapi_msg_get_node_index* result = vapi_alloc_get_node_index(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_get_node_index>;

template class Request<vapi_msg_get_node_index, vapi_msg_get_node_index_reply>;

using Get_node_index = Request<vapi_msg_get_node_index, vapi_msg_get_node_index_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_l2_interface_efp_filter>(vapi_msg_l2_interface_efp_filter *msg)
{
  vapi_msg_l2_interface_efp_filter_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_l2_interface_efp_filter>(vapi_msg_l2_interface_efp_filter *msg)
{
  vapi_msg_l2_interface_efp_filter_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_l2_interface_efp_filter>()
{
  return ::vapi_msg_id_l2_interface_efp_filter; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_l2_interface_efp_filter>>()
{
  return ::vapi_msg_id_l2_interface_efp_filter; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_l2_interface_efp_filter()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_l2_interface_efp_filter>(vapi_msg_id_l2_interface_efp_filter);
}

template <> inline vapi_msg_l2_interface_efp_filter* vapi_alloc<vapi_msg_l2_interface_efp_filter>(Connection &con)
{
  vapi_msg_l2_interface_efp_filter* result = vapi_alloc_l2_interface_efp_filter(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_l2_interface_efp_filter>;

template class Request<vapi_msg_l2_interface_efp_filter, vapi_msg_l2_interface_efp_filter_reply>;

using L2_interface_efp_filter = Request<vapi_msg_l2_interface_efp_filter, vapi_msg_l2_interface_efp_filter_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_l2_interface_efp_filter_reply>(vapi_msg_l2_interface_efp_filter_reply *msg)
{
  vapi_msg_l2_interface_efp_filter_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_l2_interface_efp_filter_reply>(vapi_msg_l2_interface_efp_filter_reply *msg)
{
  vapi_msg_l2_interface_efp_filter_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_l2_interface_efp_filter_reply>()
{
  return ::vapi_msg_id_l2_interface_efp_filter_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_l2_interface_efp_filter_reply>>()
{
  return ::vapi_msg_id_l2_interface_efp_filter_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_l2_interface_efp_filter_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_l2_interface_efp_filter_reply>(vapi_msg_id_l2_interface_efp_filter_reply);
}

template class Msg<vapi_msg_l2_interface_efp_filter_reply>;

using L2_interface_efp_filter_reply = Msg<vapi_msg_l2_interface_efp_filter_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_proxy_arp_intfc_enable_disable>(vapi_msg_proxy_arp_intfc_enable_disable *msg)
{
  vapi_msg_proxy_arp_intfc_enable_disable_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_proxy_arp_intfc_enable_disable>(vapi_msg_proxy_arp_intfc_enable_disable *msg)
{
  vapi_msg_proxy_arp_intfc_enable_disable_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_proxy_arp_intfc_enable_disable>()
{
  return ::vapi_msg_id_proxy_arp_intfc_enable_disable; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_proxy_arp_intfc_enable_disable>>()
{
  return ::vapi_msg_id_proxy_arp_intfc_enable_disable; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_proxy_arp_intfc_enable_disable()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_proxy_arp_intfc_enable_disable>(vapi_msg_id_proxy_arp_intfc_enable_disable);
}

template <> inline vapi_msg_proxy_arp_intfc_enable_disable* vapi_alloc<vapi_msg_proxy_arp_intfc_enable_disable>(Connection &con)
{
  vapi_msg_proxy_arp_intfc_enable_disable* result = vapi_alloc_proxy_arp_intfc_enable_disable(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_proxy_arp_intfc_enable_disable>;

template class Request<vapi_msg_proxy_arp_intfc_enable_disable, vapi_msg_proxy_arp_intfc_enable_disable_reply>;

using Proxy_arp_intfc_enable_disable = Request<vapi_msg_proxy_arp_intfc_enable_disable, vapi_msg_proxy_arp_intfc_enable_disable_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_feature_enable_disable>(vapi_msg_feature_enable_disable *msg)
{
  vapi_msg_feature_enable_disable_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_feature_enable_disable>(vapi_msg_feature_enable_disable *msg)
{
  vapi_msg_feature_enable_disable_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_feature_enable_disable>()
{
  return ::vapi_msg_id_feature_enable_disable; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_feature_enable_disable>>()
{
  return ::vapi_msg_id_feature_enable_disable; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_feature_enable_disable()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_feature_enable_disable>(vapi_msg_id_feature_enable_disable);
}

template <> inline vapi_msg_feature_enable_disable* vapi_alloc<vapi_msg_feature_enable_disable>(Connection &con)
{
  vapi_msg_feature_enable_disable* result = vapi_alloc_feature_enable_disable(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_feature_enable_disable>;

template class Request<vapi_msg_feature_enable_disable, vapi_msg_feature_enable_disable_reply>;

using Feature_enable_disable = Request<vapi_msg_feature_enable_disable, vapi_msg_feature_enable_disable_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_proxy_arp_add_del>(vapi_msg_proxy_arp_add_del *msg)
{
  vapi_msg_proxy_arp_add_del_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_proxy_arp_add_del>(vapi_msg_proxy_arp_add_del *msg)
{
  vapi_msg_proxy_arp_add_del_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_proxy_arp_add_del>()
{
  return ::vapi_msg_id_proxy_arp_add_del; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_proxy_arp_add_del>>()
{
  return ::vapi_msg_id_proxy_arp_add_del; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_proxy_arp_add_del()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_proxy_arp_add_del>(vapi_msg_id_proxy_arp_add_del);
}

template <> inline vapi_msg_proxy_arp_add_del* vapi_alloc<vapi_msg_proxy_arp_add_del>(Connection &con)
{
  vapi_msg_proxy_arp_add_del* result = vapi_alloc_proxy_arp_add_del(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_proxy_arp_add_del>;

template class Request<vapi_msg_proxy_arp_add_del, vapi_msg_proxy_arp_add_del_reply>;

using Proxy_arp_add_del = Request<vapi_msg_proxy_arp_add_del, vapi_msg_proxy_arp_add_del_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_ioam_disable_reply>(vapi_msg_ioam_disable_reply *msg)
{
  vapi_msg_ioam_disable_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ioam_disable_reply>(vapi_msg_ioam_disable_reply *msg)
{
  vapi_msg_ioam_disable_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ioam_disable_reply>()
{
  return ::vapi_msg_id_ioam_disable_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ioam_disable_reply>>()
{
  return ::vapi_msg_id_ioam_disable_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ioam_disable_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ioam_disable_reply>(vapi_msg_id_ioam_disable_reply);
}

template class Msg<vapi_msg_ioam_disable_reply>;

using Ioam_disable_reply = Msg<vapi_msg_ioam_disable_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_classify_set_interface_ip_table>(vapi_msg_classify_set_interface_ip_table *msg)
{
  vapi_msg_classify_set_interface_ip_table_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_classify_set_interface_ip_table>(vapi_msg_classify_set_interface_ip_table *msg)
{
  vapi_msg_classify_set_interface_ip_table_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_classify_set_interface_ip_table>()
{
  return ::vapi_msg_id_classify_set_interface_ip_table; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_classify_set_interface_ip_table>>()
{
  return ::vapi_msg_id_classify_set_interface_ip_table; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_classify_set_interface_ip_table()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_classify_set_interface_ip_table>(vapi_msg_id_classify_set_interface_ip_table);
}

template <> inline vapi_msg_classify_set_interface_ip_table* vapi_alloc<vapi_msg_classify_set_interface_ip_table>(Connection &con)
{
  vapi_msg_classify_set_interface_ip_table* result = vapi_alloc_classify_set_interface_ip_table(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_classify_set_interface_ip_table>;

template class Request<vapi_msg_classify_set_interface_ip_table, vapi_msg_classify_set_interface_ip_table_reply>;

using Classify_set_interface_ip_table = Request<vapi_msg_classify_set_interface_ip_table, vapi_msg_classify_set_interface_ip_table_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_ioam_enable>(vapi_msg_ioam_enable *msg)
{
  vapi_msg_ioam_enable_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ioam_enable>(vapi_msg_ioam_enable *msg)
{
  vapi_msg_ioam_enable_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ioam_enable>()
{
  return ::vapi_msg_id_ioam_enable; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ioam_enable>>()
{
  return ::vapi_msg_id_ioam_enable; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ioam_enable()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ioam_enable>(vapi_msg_id_ioam_enable);
}

template <> inline vapi_msg_ioam_enable* vapi_alloc<vapi_msg_ioam_enable>(Connection &con)
{
  vapi_msg_ioam_enable* result = vapi_alloc_ioam_enable(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_ioam_enable>;

template class Request<vapi_msg_ioam_enable, vapi_msg_ioam_enable_reply>;

using Ioam_enable = Request<vapi_msg_ioam_enable, vapi_msg_ioam_enable_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_get_next_index>(vapi_msg_get_next_index *msg)
{
  vapi_msg_get_next_index_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_get_next_index>(vapi_msg_get_next_index *msg)
{
  vapi_msg_get_next_index_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_get_next_index>()
{
  return ::vapi_msg_id_get_next_index; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_get_next_index>>()
{
  return ::vapi_msg_id_get_next_index; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_get_next_index()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_get_next_index>(vapi_msg_id_get_next_index);
}

template <> inline vapi_msg_get_next_index* vapi_alloc<vapi_msg_get_next_index>(Connection &con)
{
  vapi_msg_get_next_index* result = vapi_alloc_get_next_index(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_get_next_index>;

template class Request<vapi_msg_get_next_index, vapi_msg_get_next_index_reply>;

using Get_next_index = Request<vapi_msg_get_next_index, vapi_msg_get_next_index_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_set_vpath>(vapi_msg_sw_interface_set_vpath *msg)
{
  vapi_msg_sw_interface_set_vpath_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_set_vpath>(vapi_msg_sw_interface_set_vpath *msg)
{
  vapi_msg_sw_interface_set_vpath_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_set_vpath>()
{
  return ::vapi_msg_id_sw_interface_set_vpath; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_set_vpath>>()
{
  return ::vapi_msg_id_sw_interface_set_vpath; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_set_vpath()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_set_vpath>(vapi_msg_id_sw_interface_set_vpath);
}

template <> inline vapi_msg_sw_interface_set_vpath* vapi_alloc<vapi_msg_sw_interface_set_vpath>(Connection &con)
{
  vapi_msg_sw_interface_set_vpath* result = vapi_alloc_sw_interface_set_vpath(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sw_interface_set_vpath>;

template class Request<vapi_msg_sw_interface_set_vpath, vapi_msg_sw_interface_set_vpath_reply>;

using Sw_interface_set_vpath = Request<vapi_msg_sw_interface_set_vpath, vapi_msg_sw_interface_set_vpath_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_punt_socket_deregister_reply>(vapi_msg_punt_socket_deregister_reply *msg)
{
  vapi_msg_punt_socket_deregister_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_punt_socket_deregister_reply>(vapi_msg_punt_socket_deregister_reply *msg)
{
  vapi_msg_punt_socket_deregister_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_punt_socket_deregister_reply>()
{
  return ::vapi_msg_id_punt_socket_deregister_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_punt_socket_deregister_reply>>()
{
  return ::vapi_msg_id_punt_socket_deregister_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_punt_socket_deregister_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_punt_socket_deregister_reply>(vapi_msg_id_punt_socket_deregister_reply);
}

template class Msg<vapi_msg_punt_socket_deregister_reply>;

using Punt_socket_deregister_reply = Msg<vapi_msg_punt_socket_deregister_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_set_l2_xconnect>(vapi_msg_sw_interface_set_l2_xconnect *msg)
{
  vapi_msg_sw_interface_set_l2_xconnect_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_set_l2_xconnect>(vapi_msg_sw_interface_set_l2_xconnect *msg)
{
  vapi_msg_sw_interface_set_l2_xconnect_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_set_l2_xconnect>()
{
  return ::vapi_msg_id_sw_interface_set_l2_xconnect; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_set_l2_xconnect>>()
{
  return ::vapi_msg_id_sw_interface_set_l2_xconnect; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_set_l2_xconnect()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_set_l2_xconnect>(vapi_msg_id_sw_interface_set_l2_xconnect);
}

template <> inline vapi_msg_sw_interface_set_l2_xconnect* vapi_alloc<vapi_msg_sw_interface_set_l2_xconnect>(Connection &con)
{
  vapi_msg_sw_interface_set_l2_xconnect* result = vapi_alloc_sw_interface_set_l2_xconnect(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sw_interface_set_l2_xconnect>;

template class Request<vapi_msg_sw_interface_set_l2_xconnect, vapi_msg_sw_interface_set_l2_xconnect_reply>;

using Sw_interface_set_l2_xconnect = Request<vapi_msg_sw_interface_set_l2_xconnect, vapi_msg_sw_interface_set_l2_xconnect_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_bd_ip_mac_add_del_reply>(vapi_msg_bd_ip_mac_add_del_reply *msg)
{
  vapi_msg_bd_ip_mac_add_del_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_bd_ip_mac_add_del_reply>(vapi_msg_bd_ip_mac_add_del_reply *msg)
{
  vapi_msg_bd_ip_mac_add_del_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_bd_ip_mac_add_del_reply>()
{
  return ::vapi_msg_id_bd_ip_mac_add_del_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_bd_ip_mac_add_del_reply>>()
{
  return ::vapi_msg_id_bd_ip_mac_add_del_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_bd_ip_mac_add_del_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_bd_ip_mac_add_del_reply>(vapi_msg_id_bd_ip_mac_add_del_reply);
}

template class Msg<vapi_msg_bd_ip_mac_add_del_reply>;

using Bd_ip_mac_add_del_reply = Msg<vapi_msg_bd_ip_mac_add_del_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_reset_fib_reply>(vapi_msg_reset_fib_reply *msg)
{
  vapi_msg_reset_fib_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_reset_fib_reply>(vapi_msg_reset_fib_reply *msg)
{
  vapi_msg_reset_fib_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_reset_fib_reply>()
{
  return ::vapi_msg_id_reset_fib_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_reset_fib_reply>>()
{
  return ::vapi_msg_id_reset_fib_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_reset_fib_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_reset_fib_reply>(vapi_msg_id_reset_fib_reply);
}

template class Msg<vapi_msg_reset_fib_reply>;

using Reset_fib_reply = Msg<vapi_msg_reset_fib_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_want_ip6_nd_events_reply>(vapi_msg_want_ip6_nd_events_reply *msg)
{
  vapi_msg_want_ip6_nd_events_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_want_ip6_nd_events_reply>(vapi_msg_want_ip6_nd_events_reply *msg)
{
  vapi_msg_want_ip6_nd_events_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_want_ip6_nd_events_reply>()
{
  return ::vapi_msg_id_want_ip6_nd_events_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_want_ip6_nd_events_reply>>()
{
  return ::vapi_msg_id_want_ip6_nd_events_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_want_ip6_nd_events_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_want_ip6_nd_events_reply>(vapi_msg_id_want_ip6_nd_events_reply);
}

template class Msg<vapi_msg_want_ip6_nd_events_reply>;

using Want_ip6_nd_events_reply = Msg<vapi_msg_want_ip6_nd_events_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_l2_patch_add_del_reply>(vapi_msg_l2_patch_add_del_reply *msg)
{
  vapi_msg_l2_patch_add_del_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_l2_patch_add_del_reply>(vapi_msg_l2_patch_add_del_reply *msg)
{
  vapi_msg_l2_patch_add_del_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_l2_patch_add_del_reply>()
{
  return ::vapi_msg_id_l2_patch_add_del_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_l2_patch_add_del_reply>>()
{
  return ::vapi_msg_id_l2_patch_add_del_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_l2_patch_add_del_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_l2_patch_add_del_reply>(vapi_msg_id_l2_patch_add_del_reply);
}

template class Msg<vapi_msg_l2_patch_add_del_reply>;

using L2_patch_add_del_reply = Msg<vapi_msg_l2_patch_add_del_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_set_arp_neighbor_limit>(vapi_msg_set_arp_neighbor_limit *msg)
{
  vapi_msg_set_arp_neighbor_limit_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_set_arp_neighbor_limit>(vapi_msg_set_arp_neighbor_limit *msg)
{
  vapi_msg_set_arp_neighbor_limit_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_set_arp_neighbor_limit>()
{
  return ::vapi_msg_id_set_arp_neighbor_limit; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_set_arp_neighbor_limit>>()
{
  return ::vapi_msg_id_set_arp_neighbor_limit; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_set_arp_neighbor_limit()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_set_arp_neighbor_limit>(vapi_msg_id_set_arp_neighbor_limit);
}

template <> inline vapi_msg_set_arp_neighbor_limit* vapi_alloc<vapi_msg_set_arp_neighbor_limit>(Connection &con)
{
  vapi_msg_set_arp_neighbor_limit* result = vapi_alloc_set_arp_neighbor_limit(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_set_arp_neighbor_limit>;

template class Request<vapi_msg_set_arp_neighbor_limit, vapi_msg_set_arp_neighbor_limit_reply>;

using Set_arp_neighbor_limit = Request<vapi_msg_set_arp_neighbor_limit, vapi_msg_set_arp_neighbor_limit_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_add_node_next>(vapi_msg_add_node_next *msg)
{
  vapi_msg_add_node_next_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_add_node_next>(vapi_msg_add_node_next *msg)
{
  vapi_msg_add_node_next_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_add_node_next>()
{
  return ::vapi_msg_id_add_node_next; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_add_node_next>>()
{
  return ::vapi_msg_id_add_node_next; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_add_node_next()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_add_node_next>(vapi_msg_id_add_node_next);
}

template <> inline vapi_msg_add_node_next* vapi_alloc<vapi_msg_add_node_next>(Connection &con)
{
  vapi_msg_add_node_next* result = vapi_alloc_add_node_next(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_add_node_next>;

template class Request<vapi_msg_add_node_next, vapi_msg_add_node_next_reply>;

using Add_node_next = Request<vapi_msg_add_node_next, vapi_msg_add_node_next_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_get_next_index_reply>(vapi_msg_get_next_index_reply *msg)
{
  vapi_msg_get_next_index_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_get_next_index_reply>(vapi_msg_get_next_index_reply *msg)
{
  vapi_msg_get_next_index_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_get_next_index_reply>()
{
  return ::vapi_msg_id_get_next_index_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_get_next_index_reply>>()
{
  return ::vapi_msg_id_get_next_index_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_get_next_index_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_get_next_index_reply>(vapi_msg_id_get_next_index_reply);
}

template class Msg<vapi_msg_get_next_index_reply>;

using Get_next_index_reply = Msg<vapi_msg_get_next_index_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_set_mpls_enable_reply>(vapi_msg_sw_interface_set_mpls_enable_reply *msg)
{
  vapi_msg_sw_interface_set_mpls_enable_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_set_mpls_enable_reply>(vapi_msg_sw_interface_set_mpls_enable_reply *msg)
{
  vapi_msg_sw_interface_set_mpls_enable_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_set_mpls_enable_reply>()
{
  return ::vapi_msg_id_sw_interface_set_mpls_enable_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_set_mpls_enable_reply>>()
{
  return ::vapi_msg_id_sw_interface_set_mpls_enable_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_set_mpls_enable_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_set_mpls_enable_reply>(vapi_msg_id_sw_interface_set_mpls_enable_reply);
}

template class Msg<vapi_msg_sw_interface_set_mpls_enable_reply>;

using Sw_interface_set_mpls_enable_reply = Msg<vapi_msg_sw_interface_set_mpls_enable_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_show_version_reply>(vapi_msg_show_version_reply *msg)
{
  vapi_msg_show_version_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_show_version_reply>(vapi_msg_show_version_reply *msg)
{
  vapi_msg_show_version_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_show_version_reply>()
{
  return ::vapi_msg_id_show_version_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_show_version_reply>>()
{
  return ::vapi_msg_id_show_version_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_show_version_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_show_version_reply>(vapi_msg_id_show_version_reply);
}

template class Msg<vapi_msg_show_version_reply>;

using Show_version_reply = Msg<vapi_msg_show_version_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_want_ip4_arp_events>(vapi_msg_want_ip4_arp_events *msg)
{
  vapi_msg_want_ip4_arp_events_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_want_ip4_arp_events>(vapi_msg_want_ip4_arp_events *msg)
{
  vapi_msg_want_ip4_arp_events_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_want_ip4_arp_events>()
{
  return ::vapi_msg_id_want_ip4_arp_events; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_want_ip4_arp_events>>()
{
  return ::vapi_msg_id_want_ip4_arp_events; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_want_ip4_arp_events()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_want_ip4_arp_events>(vapi_msg_id_want_ip4_arp_events);
}

template <> inline vapi_msg_want_ip4_arp_events* vapi_alloc<vapi_msg_want_ip4_arp_events>(Connection &con)
{
  vapi_msg_want_ip4_arp_events* result = vapi_alloc_want_ip4_arp_events(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_want_ip4_arp_events>;

template class Request<vapi_msg_want_ip4_arp_events, vapi_msg_want_ip4_arp_events_reply>;

using Want_ip4_arp_events = Request<vapi_msg_want_ip4_arp_events, vapi_msg_want_ip4_arp_events_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_ip_source_and_port_range_check_interface_add_del_reply>(vapi_msg_ip_source_and_port_range_check_interface_add_del_reply *msg)
{
  vapi_msg_ip_source_and_port_range_check_interface_add_del_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip_source_and_port_range_check_interface_add_del_reply>(vapi_msg_ip_source_and_port_range_check_interface_add_del_reply *msg)
{
  vapi_msg_ip_source_and_port_range_check_interface_add_del_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip_source_and_port_range_check_interface_add_del_reply>()
{
  return ::vapi_msg_id_ip_source_and_port_range_check_interface_add_del_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip_source_and_port_range_check_interface_add_del_reply>>()
{
  return ::vapi_msg_id_ip_source_and_port_range_check_interface_add_del_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip_source_and_port_range_check_interface_add_del_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip_source_and_port_range_check_interface_add_del_reply>(vapi_msg_id_ip_source_and_port_range_check_interface_add_del_reply);
}

template class Msg<vapi_msg_ip_source_and_port_range_check_interface_add_del_reply>;

using Ip_source_and_port_range_check_interface_add_del_reply = Msg<vapi_msg_ip_source_and_port_range_check_interface_add_del_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_punt_socket_register_reply>(vapi_msg_punt_socket_register_reply *msg)
{
  vapi_msg_punt_socket_register_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_punt_socket_register_reply>(vapi_msg_punt_socket_register_reply *msg)
{
  vapi_msg_punt_socket_register_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_punt_socket_register_reply>()
{
  return ::vapi_msg_id_punt_socket_register_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_punt_socket_register_reply>>()
{
  return ::vapi_msg_id_punt_socket_register_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_punt_socket_register_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_punt_socket_register_reply>(vapi_msg_id_punt_socket_register_reply);
}

template class Msg<vapi_msg_punt_socket_register_reply>;

using Punt_socket_register_reply = Msg<vapi_msg_punt_socket_register_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_create_loopback_instance_reply>(vapi_msg_create_loopback_instance_reply *msg)
{
  vapi_msg_create_loopback_instance_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_create_loopback_instance_reply>(vapi_msg_create_loopback_instance_reply *msg)
{
  vapi_msg_create_loopback_instance_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_create_loopback_instance_reply>()
{
  return ::vapi_msg_id_create_loopback_instance_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_create_loopback_instance_reply>>()
{
  return ::vapi_msg_id_create_loopback_instance_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_create_loopback_instance_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_create_loopback_instance_reply>(vapi_msg_id_create_loopback_instance_reply);
}

template class Msg<vapi_msg_create_loopback_instance_reply>;

using Create_loopback_instance_reply = Msg<vapi_msg_create_loopback_instance_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_delete_loopback_reply>(vapi_msg_delete_loopback_reply *msg)
{
  vapi_msg_delete_loopback_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_delete_loopback_reply>(vapi_msg_delete_loopback_reply *msg)
{
  vapi_msg_delete_loopback_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_delete_loopback_reply>()
{
  return ::vapi_msg_id_delete_loopback_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_delete_loopback_reply>>()
{
  return ::vapi_msg_id_delete_loopback_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_delete_loopback_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_delete_loopback_reply>(vapi_msg_id_delete_loopback_reply);
}

template class Msg<vapi_msg_delete_loopback_reply>;

using Delete_loopback_reply = Msg<vapi_msg_delete_loopback_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_classify_set_interface_l2_tables_reply>(vapi_msg_classify_set_interface_l2_tables_reply *msg)
{
  vapi_msg_classify_set_interface_l2_tables_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_classify_set_interface_l2_tables_reply>(vapi_msg_classify_set_interface_l2_tables_reply *msg)
{
  vapi_msg_classify_set_interface_l2_tables_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_classify_set_interface_l2_tables_reply>()
{
  return ::vapi_msg_id_classify_set_interface_l2_tables_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_classify_set_interface_l2_tables_reply>>()
{
  return ::vapi_msg_id_classify_set_interface_l2_tables_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_classify_set_interface_l2_tables_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_classify_set_interface_l2_tables_reply>(vapi_msg_id_classify_set_interface_l2_tables_reply);
}

template class Msg<vapi_msg_classify_set_interface_l2_tables_reply>;

using Classify_set_interface_l2_tables_reply = Msg<vapi_msg_classify_set_interface_l2_tables_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_pg_capture>(vapi_msg_pg_capture *msg)
{
  vapi_msg_pg_capture_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_pg_capture>(vapi_msg_pg_capture *msg)
{
  vapi_msg_pg_capture_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_pg_capture>()
{
  return ::vapi_msg_id_pg_capture; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_pg_capture>>()
{
  return ::vapi_msg_id_pg_capture; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_pg_capture()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_pg_capture>(vapi_msg_id_pg_capture);
}

template <> inline vapi_msg_pg_capture* vapi_alloc<vapi_msg_pg_capture, size_t>(Connection &con, size_t pcap_file_name_array_size)
{
  vapi_msg_pg_capture* result = vapi_alloc_pg_capture(con.vapi_ctx, pcap_file_name_array_size);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_pg_capture>;

template class Request<vapi_msg_pg_capture, vapi_msg_pg_capture_reply, size_t>;

using Pg_capture = Request<vapi_msg_pg_capture, vapi_msg_pg_capture_reply, size_t>;

template <> inline void vapi_swap_to_be<vapi_msg_create_vlan_subif>(vapi_msg_create_vlan_subif *msg)
{
  vapi_msg_create_vlan_subif_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_create_vlan_subif>(vapi_msg_create_vlan_subif *msg)
{
  vapi_msg_create_vlan_subif_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_create_vlan_subif>()
{
  return ::vapi_msg_id_create_vlan_subif; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_create_vlan_subif>>()
{
  return ::vapi_msg_id_create_vlan_subif; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_create_vlan_subif()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_create_vlan_subif>(vapi_msg_id_create_vlan_subif);
}

template <> inline vapi_msg_create_vlan_subif* vapi_alloc<vapi_msg_create_vlan_subif>(Connection &con)
{
  vapi_msg_create_vlan_subif* result = vapi_alloc_create_vlan_subif(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_create_vlan_subif>;

template class Request<vapi_msg_create_vlan_subif, vapi_msg_create_vlan_subif_reply>;

using Create_vlan_subif = Request<vapi_msg_create_vlan_subif, vapi_msg_create_vlan_subif_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_get_node_graph_reply>(vapi_msg_get_node_graph_reply *msg)
{
  vapi_msg_get_node_graph_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_get_node_graph_reply>(vapi_msg_get_node_graph_reply *msg)
{
  vapi_msg_get_node_graph_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_get_node_graph_reply>()
{
  return ::vapi_msg_id_get_node_graph_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_get_node_graph_reply>>()
{
  return ::vapi_msg_id_get_node_graph_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_get_node_graph_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_get_node_graph_reply>(vapi_msg_id_get_node_graph_reply);
}

template class Msg<vapi_msg_get_node_graph_reply>;

using Get_node_graph_reply = Msg<vapi_msg_get_node_graph_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_set_l2_bridge>(vapi_msg_sw_interface_set_l2_bridge *msg)
{
  vapi_msg_sw_interface_set_l2_bridge_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_set_l2_bridge>(vapi_msg_sw_interface_set_l2_bridge *msg)
{
  vapi_msg_sw_interface_set_l2_bridge_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_set_l2_bridge>()
{
  return ::vapi_msg_id_sw_interface_set_l2_bridge; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_set_l2_bridge>>()
{
  return ::vapi_msg_id_sw_interface_set_l2_bridge; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_set_l2_bridge()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_set_l2_bridge>(vapi_msg_id_sw_interface_set_l2_bridge);
}

template <> inline vapi_msg_sw_interface_set_l2_bridge* vapi_alloc<vapi_msg_sw_interface_set_l2_bridge>(Connection &con)
{
  vapi_msg_sw_interface_set_l2_bridge* result = vapi_alloc_sw_interface_set_l2_bridge(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sw_interface_set_l2_bridge>;

template class Request<vapi_msg_sw_interface_set_l2_bridge, vapi_msg_sw_interface_set_l2_bridge_reply>;

using Sw_interface_set_l2_bridge = Request<vapi_msg_sw_interface_set_l2_bridge, vapi_msg_sw_interface_set_l2_bridge_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_punt>(vapi_msg_punt *msg)
{
  vapi_msg_punt_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_punt>(vapi_msg_punt *msg)
{
  vapi_msg_punt_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_punt>()
{
  return ::vapi_msg_id_punt; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_punt>>()
{
  return ::vapi_msg_id_punt; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_punt()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_punt>(vapi_msg_id_punt);
}

template <> inline vapi_msg_punt* vapi_alloc<vapi_msg_punt>(Connection &con)
{
  vapi_msg_punt* result = vapi_alloc_punt(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_punt>;

template class Request<vapi_msg_punt, vapi_msg_punt_reply>;

using Punt = Request<vapi_msg_punt, vapi_msg_punt_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_delete_loopback>(vapi_msg_delete_loopback *msg)
{
  vapi_msg_delete_loopback_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_delete_loopback>(vapi_msg_delete_loopback *msg)
{
  vapi_msg_delete_loopback_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_delete_loopback>()
{
  return ::vapi_msg_id_delete_loopback; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_delete_loopback>>()
{
  return ::vapi_msg_id_delete_loopback; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_delete_loopback()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_delete_loopback>(vapi_msg_id_delete_loopback);
}

template <> inline vapi_msg_delete_loopback* vapi_alloc<vapi_msg_delete_loopback>(Connection &con)
{
  vapi_msg_delete_loopback* result = vapi_alloc_delete_loopback(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_delete_loopback>;

template class Request<vapi_msg_delete_loopback, vapi_msg_delete_loopback_reply>;

using Delete_loopback = Request<vapi_msg_delete_loopback, vapi_msg_delete_loopback_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_pg_create_interface>(vapi_msg_pg_create_interface *msg)
{
  vapi_msg_pg_create_interface_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_pg_create_interface>(vapi_msg_pg_create_interface *msg)
{
  vapi_msg_pg_create_interface_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_pg_create_interface>()
{
  return ::vapi_msg_id_pg_create_interface; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_pg_create_interface>>()
{
  return ::vapi_msg_id_pg_create_interface; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_pg_create_interface()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_pg_create_interface>(vapi_msg_id_pg_create_interface);
}

template <> inline vapi_msg_pg_create_interface* vapi_alloc<vapi_msg_pg_create_interface>(Connection &con)
{
  vapi_msg_pg_create_interface* result = vapi_alloc_pg_create_interface(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_pg_create_interface>;

template class Request<vapi_msg_pg_create_interface, vapi_msg_pg_create_interface_reply>;

using Pg_create_interface = Request<vapi_msg_pg_create_interface, vapi_msg_pg_create_interface_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_ioam_enable_reply>(vapi_msg_ioam_enable_reply *msg)
{
  vapi_msg_ioam_enable_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ioam_enable_reply>(vapi_msg_ioam_enable_reply *msg)
{
  vapi_msg_ioam_enable_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ioam_enable_reply>()
{
  return ::vapi_msg_id_ioam_enable_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ioam_enable_reply>>()
{
  return ::vapi_msg_id_ioam_enable_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ioam_enable_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ioam_enable_reply>(vapi_msg_id_ioam_enable_reply);
}

template class Msg<vapi_msg_ioam_enable_reply>;

using Ioam_enable_reply = Msg<vapi_msg_ioam_enable_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_create_subif>(vapi_msg_create_subif *msg)
{
  vapi_msg_create_subif_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_create_subif>(vapi_msg_create_subif *msg)
{
  vapi_msg_create_subif_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_create_subif>()
{
  return ::vapi_msg_id_create_subif; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_create_subif>>()
{
  return ::vapi_msg_id_create_subif; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_create_subif()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_create_subif>(vapi_msg_id_create_subif);
}

template <> inline vapi_msg_create_subif* vapi_alloc<vapi_msg_create_subif>(Connection &con)
{
  vapi_msg_create_subif* result = vapi_alloc_create_subif(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_create_subif>;

template class Request<vapi_msg_create_subif, vapi_msg_create_subif_reply>;

using Create_subif = Request<vapi_msg_create_subif, vapi_msg_create_subif_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_cli_inband>(vapi_msg_cli_inband *msg)
{
  vapi_msg_cli_inband_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_cli_inband>(vapi_msg_cli_inband *msg)
{
  vapi_msg_cli_inband_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_cli_inband>()
{
  return ::vapi_msg_id_cli_inband; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_cli_inband>>()
{
  return ::vapi_msg_id_cli_inband; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_cli_inband()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_cli_inband>(vapi_msg_id_cli_inband);
}

template <> inline vapi_msg_cli_inband* vapi_alloc<vapi_msg_cli_inband, size_t>(Connection &con, size_t cmd_array_size)
{
  vapi_msg_cli_inband* result = vapi_alloc_cli_inband(con.vapi_ctx, cmd_array_size);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_cli_inband>;

template class Request<vapi_msg_cli_inband, vapi_msg_cli_inband_reply, size_t>;

using Cli_inband = Request<vapi_msg_cli_inband, vapi_msg_cli_inband_reply, size_t>;

template <> inline void vapi_swap_to_be<vapi_msg_want_ip4_arp_events_reply>(vapi_msg_want_ip4_arp_events_reply *msg)
{
  vapi_msg_want_ip4_arp_events_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_want_ip4_arp_events_reply>(vapi_msg_want_ip4_arp_events_reply *msg)
{
  vapi_msg_want_ip4_arp_events_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_want_ip4_arp_events_reply>()
{
  return ::vapi_msg_id_want_ip4_arp_events_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_want_ip4_arp_events_reply>>()
{
  return ::vapi_msg_id_want_ip4_arp_events_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_want_ip4_arp_events_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_want_ip4_arp_events_reply>(vapi_msg_id_want_ip4_arp_events_reply);
}

template class Msg<vapi_msg_want_ip4_arp_events_reply>;

using Want_ip4_arp_events_reply = Msg<vapi_msg_want_ip4_arp_events_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_delete_subif>(vapi_msg_delete_subif *msg)
{
  vapi_msg_delete_subif_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_delete_subif>(vapi_msg_delete_subif *msg)
{
  vapi_msg_delete_subif_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_delete_subif>()
{
  return ::vapi_msg_id_delete_subif; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_delete_subif>>()
{
  return ::vapi_msg_id_delete_subif; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_delete_subif()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_delete_subif>(vapi_msg_id_delete_subif);
}

template <> inline vapi_msg_delete_subif* vapi_alloc<vapi_msg_delete_subif>(Connection &con)
{
  vapi_msg_delete_subif* result = vapi_alloc_delete_subif(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_delete_subif>;

template class Request<vapi_msg_delete_subif, vapi_msg_delete_subif_reply>;

using Delete_subif = Request<vapi_msg_delete_subif, vapi_msg_delete_subif_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_reset_vrf_reply>(vapi_msg_reset_vrf_reply *msg)
{
  vapi_msg_reset_vrf_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_reset_vrf_reply>(vapi_msg_reset_vrf_reply *msg)
{
  vapi_msg_reset_vrf_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_reset_vrf_reply>()
{
  return ::vapi_msg_id_reset_vrf_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_reset_vrf_reply>>()
{
  return ::vapi_msg_id_reset_vrf_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_reset_vrf_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_reset_vrf_reply>(vapi_msg_id_reset_vrf_reply);
}

template class Msg<vapi_msg_reset_vrf_reply>;

using Reset_vrf_reply = Msg<vapi_msg_reset_vrf_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_feature_enable_disable_reply>(vapi_msg_feature_enable_disable_reply *msg)
{
  vapi_msg_feature_enable_disable_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_feature_enable_disable_reply>(vapi_msg_feature_enable_disable_reply *msg)
{
  vapi_msg_feature_enable_disable_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_feature_enable_disable_reply>()
{
  return ::vapi_msg_id_feature_enable_disable_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_feature_enable_disable_reply>>()
{
  return ::vapi_msg_id_feature_enable_disable_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_feature_enable_disable_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_feature_enable_disable_reply>(vapi_msg_id_feature_enable_disable_reply);
}

template class Msg<vapi_msg_feature_enable_disable_reply>;

using Feature_enable_disable_reply = Msg<vapi_msg_feature_enable_disable_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_create_subif_reply>(vapi_msg_create_subif_reply *msg)
{
  vapi_msg_create_subif_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_create_subif_reply>(vapi_msg_create_subif_reply *msg)
{
  vapi_msg_create_subif_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_create_subif_reply>()
{
  return ::vapi_msg_id_create_subif_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_create_subif_reply>>()
{
  return ::vapi_msg_id_create_subif_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_create_subif_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_create_subif_reply>(vapi_msg_id_create_subif_reply);
}

template class Msg<vapi_msg_create_subif_reply>;

using Create_subif_reply = Msg<vapi_msg_create_subif_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_punt_socket_register>(vapi_msg_punt_socket_register *msg)
{
  vapi_msg_punt_socket_register_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_punt_socket_register>(vapi_msg_punt_socket_register *msg)
{
  vapi_msg_punt_socket_register_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_punt_socket_register>()
{
  return ::vapi_msg_id_punt_socket_register; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_punt_socket_register>>()
{
  return ::vapi_msg_id_punt_socket_register; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_punt_socket_register()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_punt_socket_register>(vapi_msg_id_punt_socket_register);
}

template <> inline vapi_msg_punt_socket_register* vapi_alloc<vapi_msg_punt_socket_register>(Connection &con)
{
  vapi_msg_punt_socket_register* result = vapi_alloc_punt_socket_register(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_punt_socket_register>;

template class Request<vapi_msg_punt_socket_register, vapi_msg_punt_socket_register_reply>;

using Punt_socket_register = Request<vapi_msg_punt_socket_register, vapi_msg_punt_socket_register_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_want_oam_events_reply>(vapi_msg_want_oam_events_reply *msg)
{
  vapi_msg_want_oam_events_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_want_oam_events_reply>(vapi_msg_want_oam_events_reply *msg)
{
  vapi_msg_want_oam_events_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_want_oam_events_reply>()
{
  return ::vapi_msg_id_want_oam_events_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_want_oam_events_reply>>()
{
  return ::vapi_msg_id_want_oam_events_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_want_oam_events_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_want_oam_events_reply>(vapi_msg_id_want_oam_events_reply);
}

template class Msg<vapi_msg_want_oam_events_reply>;

using Want_oam_events_reply = Msg<vapi_msg_want_oam_events_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_want_oam_events>(vapi_msg_want_oam_events *msg)
{
  vapi_msg_want_oam_events_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_want_oam_events>(vapi_msg_want_oam_events *msg)
{
  vapi_msg_want_oam_events_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_want_oam_events>()
{
  return ::vapi_msg_id_want_oam_events; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_want_oam_events>>()
{
  return ::vapi_msg_id_want_oam_events; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_want_oam_events()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_want_oam_events>(vapi_msg_id_want_oam_events);
}

template <> inline vapi_msg_want_oam_events* vapi_alloc<vapi_msg_want_oam_events>(Connection &con)
{
  vapi_msg_want_oam_events* result = vapi_alloc_want_oam_events(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_want_oam_events>;

template class Request<vapi_msg_want_oam_events, vapi_msg_want_oam_events_reply>;

using Want_oam_events = Request<vapi_msg_want_oam_events, vapi_msg_want_oam_events_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_ip_source_and_port_range_check_add_del_reply>(vapi_msg_ip_source_and_port_range_check_add_del_reply *msg)
{
  vapi_msg_ip_source_and_port_range_check_add_del_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip_source_and_port_range_check_add_del_reply>(vapi_msg_ip_source_and_port_range_check_add_del_reply *msg)
{
  vapi_msg_ip_source_and_port_range_check_add_del_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip_source_and_port_range_check_add_del_reply>()
{
  return ::vapi_msg_id_ip_source_and_port_range_check_add_del_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip_source_and_port_range_check_add_del_reply>>()
{
  return ::vapi_msg_id_ip_source_and_port_range_check_add_del_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip_source_and_port_range_check_add_del_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip_source_and_port_range_check_add_del_reply>(vapi_msg_id_ip_source_and_port_range_check_add_del_reply);
}

template class Msg<vapi_msg_ip_source_and_port_range_check_add_del_reply>;

using Ip_source_and_port_range_check_add_del_reply = Msg<vapi_msg_ip_source_and_port_range_check_add_del_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_classify_set_interface_ip_table_reply>(vapi_msg_classify_set_interface_ip_table_reply *msg)
{
  vapi_msg_classify_set_interface_ip_table_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_classify_set_interface_ip_table_reply>(vapi_msg_classify_set_interface_ip_table_reply *msg)
{
  vapi_msg_classify_set_interface_ip_table_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_classify_set_interface_ip_table_reply>()
{
  return ::vapi_msg_id_classify_set_interface_ip_table_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_classify_set_interface_ip_table_reply>>()
{
  return ::vapi_msg_id_classify_set_interface_ip_table_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_classify_set_interface_ip_table_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_classify_set_interface_ip_table_reply>(vapi_msg_id_classify_set_interface_ip_table_reply);
}

template class Msg<vapi_msg_classify_set_interface_ip_table_reply>;

using Classify_set_interface_ip_table_reply = Msg<vapi_msg_classify_set_interface_ip_table_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_create_loopback_instance>(vapi_msg_create_loopback_instance *msg)
{
  vapi_msg_create_loopback_instance_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_create_loopback_instance>(vapi_msg_create_loopback_instance *msg)
{
  vapi_msg_create_loopback_instance_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_create_loopback_instance>()
{
  return ::vapi_msg_id_create_loopback_instance; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_create_loopback_instance>>()
{
  return ::vapi_msg_id_create_loopback_instance; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_create_loopback_instance()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_create_loopback_instance>(vapi_msg_id_create_loopback_instance);
}

template <> inline vapi_msg_create_loopback_instance* vapi_alloc<vapi_msg_create_loopback_instance>(Connection &con)
{
  vapi_msg_create_loopback_instance* result = vapi_alloc_create_loopback_instance(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_create_loopback_instance>;

template class Request<vapi_msg_create_loopback_instance, vapi_msg_create_loopback_instance_reply>;

using Create_loopback_instance = Request<vapi_msg_create_loopback_instance, vapi_msg_create_loopback_instance_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_set_l2_xconnect_reply>(vapi_msg_sw_interface_set_l2_xconnect_reply *msg)
{
  vapi_msg_sw_interface_set_l2_xconnect_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_set_l2_xconnect_reply>(vapi_msg_sw_interface_set_l2_xconnect_reply *msg)
{
  vapi_msg_sw_interface_set_l2_xconnect_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_set_l2_xconnect_reply>()
{
  return ::vapi_msg_id_sw_interface_set_l2_xconnect_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_set_l2_xconnect_reply>>()
{
  return ::vapi_msg_id_sw_interface_set_l2_xconnect_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_set_l2_xconnect_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_set_l2_xconnect_reply>(vapi_msg_id_sw_interface_set_l2_xconnect_reply);
}

template class Msg<vapi_msg_sw_interface_set_l2_xconnect_reply>;

using Sw_interface_set_l2_xconnect_reply = Msg<vapi_msg_sw_interface_set_l2_xconnect_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_cli_inband_reply>(vapi_msg_cli_inband_reply *msg)
{
  vapi_msg_cli_inband_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_cli_inband_reply>(vapi_msg_cli_inband_reply *msg)
{
  vapi_msg_cli_inband_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_cli_inband_reply>()
{
  return ::vapi_msg_id_cli_inband_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_cli_inband_reply>>()
{
  return ::vapi_msg_id_cli_inband_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_cli_inband_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_cli_inband_reply>(vapi_msg_id_cli_inband_reply);
}

template class Msg<vapi_msg_cli_inband_reply>;

using Cli_inband_reply = Msg<vapi_msg_cli_inband_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_input_acl_set_interface>(vapi_msg_input_acl_set_interface *msg)
{
  vapi_msg_input_acl_set_interface_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_input_acl_set_interface>(vapi_msg_input_acl_set_interface *msg)
{
  vapi_msg_input_acl_set_interface_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_input_acl_set_interface>()
{
  return ::vapi_msg_id_input_acl_set_interface; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_input_acl_set_interface>>()
{
  return ::vapi_msg_id_input_acl_set_interface; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_input_acl_set_interface()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_input_acl_set_interface>(vapi_msg_id_input_acl_set_interface);
}

template <> inline vapi_msg_input_acl_set_interface* vapi_alloc<vapi_msg_input_acl_set_interface>(Connection &con)
{
  vapi_msg_input_acl_set_interface* result = vapi_alloc_input_acl_set_interface(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_input_acl_set_interface>;

template class Request<vapi_msg_input_acl_set_interface, vapi_msg_input_acl_set_interface_reply>;

using Input_acl_set_interface = Request<vapi_msg_input_acl_set_interface, vapi_msg_input_acl_set_interface_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_ioam_disable>(vapi_msg_ioam_disable *msg)
{
  vapi_msg_ioam_disable_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ioam_disable>(vapi_msg_ioam_disable *msg)
{
  vapi_msg_ioam_disable_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ioam_disable>()
{
  return ::vapi_msg_id_ioam_disable; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ioam_disable>>()
{
  return ::vapi_msg_id_ioam_disable; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ioam_disable()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ioam_disable>(vapi_msg_id_ioam_disable);
}

template <> inline vapi_msg_ioam_disable* vapi_alloc<vapi_msg_ioam_disable>(Connection &con)
{
  vapi_msg_ioam_disable* result = vapi_alloc_ioam_disable(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_ioam_disable>;

template class Request<vapi_msg_ioam_disable, vapi_msg_ioam_disable_reply>;

using Ioam_disable = Request<vapi_msg_ioam_disable, vapi_msg_ioam_disable_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_proxy_arp_add_del_reply>(vapi_msg_proxy_arp_add_del_reply *msg)
{
  vapi_msg_proxy_arp_add_del_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_proxy_arp_add_del_reply>(vapi_msg_proxy_arp_add_del_reply *msg)
{
  vapi_msg_proxy_arp_add_del_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_proxy_arp_add_del_reply>()
{
  return ::vapi_msg_id_proxy_arp_add_del_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_proxy_arp_add_del_reply>>()
{
  return ::vapi_msg_id_proxy_arp_add_del_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_proxy_arp_add_del_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_proxy_arp_add_del_reply>(vapi_msg_id_proxy_arp_add_del_reply);
}

template class Msg<vapi_msg_proxy_arp_add_del_reply>;

using Proxy_arp_add_del_reply = Msg<vapi_msg_proxy_arp_add_del_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_create_vlan_subif_reply>(vapi_msg_create_vlan_subif_reply *msg)
{
  vapi_msg_create_vlan_subif_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_create_vlan_subif_reply>(vapi_msg_create_vlan_subif_reply *msg)
{
  vapi_msg_create_vlan_subif_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_create_vlan_subif_reply>()
{
  return ::vapi_msg_id_create_vlan_subif_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_create_vlan_subif_reply>>()
{
  return ::vapi_msg_id_create_vlan_subif_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_create_vlan_subif_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_create_vlan_subif_reply>(vapi_msg_id_create_vlan_subif_reply);
}

template class Msg<vapi_msg_create_vlan_subif_reply>;

using Create_vlan_subif_reply = Msg<vapi_msg_create_vlan_subif_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_reset_fib>(vapi_msg_reset_fib *msg)
{
  vapi_msg_reset_fib_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_reset_fib>(vapi_msg_reset_fib *msg)
{
  vapi_msg_reset_fib_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_reset_fib>()
{
  return ::vapi_msg_id_reset_fib; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_reset_fib>>()
{
  return ::vapi_msg_id_reset_fib; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_reset_fib()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_reset_fib>(vapi_msg_id_reset_fib);
}

template <> inline vapi_msg_reset_fib* vapi_alloc<vapi_msg_reset_fib>(Connection &con)
{
  vapi_msg_reset_fib* result = vapi_alloc_reset_fib(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_reset_fib>;

template class Request<vapi_msg_reset_fib, vapi_msg_reset_fib_reply>;

using Reset_fib = Request<vapi_msg_reset_fib, vapi_msg_reset_fib_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_pg_enable_disable>(vapi_msg_pg_enable_disable *msg)
{
  vapi_msg_pg_enable_disable_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_pg_enable_disable>(vapi_msg_pg_enable_disable *msg)
{
  vapi_msg_pg_enable_disable_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_pg_enable_disable>()
{
  return ::vapi_msg_id_pg_enable_disable; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_pg_enable_disable>>()
{
  return ::vapi_msg_id_pg_enable_disable; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_pg_enable_disable()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_pg_enable_disable>(vapi_msg_id_pg_enable_disable);
}

template <> inline vapi_msg_pg_enable_disable* vapi_alloc<vapi_msg_pg_enable_disable, size_t>(Connection &con, size_t stream_name_array_size)
{
  vapi_msg_pg_enable_disable* result = vapi_alloc_pg_enable_disable(con.vapi_ctx, stream_name_array_size);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_pg_enable_disable>;

template class Request<vapi_msg_pg_enable_disable, vapi_msg_pg_enable_disable_reply, size_t>;

using Pg_enable_disable = Request<vapi_msg_pg_enable_disable, vapi_msg_pg_enable_disable_reply, size_t>;

template <> inline void vapi_swap_to_be<vapi_msg_want_ip6_nd_events>(vapi_msg_want_ip6_nd_events *msg)
{
  vapi_msg_want_ip6_nd_events_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_want_ip6_nd_events>(vapi_msg_want_ip6_nd_events *msg)
{
  vapi_msg_want_ip6_nd_events_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_want_ip6_nd_events>()
{
  return ::vapi_msg_id_want_ip6_nd_events; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_want_ip6_nd_events>>()
{
  return ::vapi_msg_id_want_ip6_nd_events; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_want_ip6_nd_events()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_want_ip6_nd_events>(vapi_msg_id_want_ip6_nd_events);
}

template <> inline vapi_msg_want_ip6_nd_events* vapi_alloc<vapi_msg_want_ip6_nd_events>(Connection &con)
{
  vapi_msg_want_ip6_nd_events* result = vapi_alloc_want_ip6_nd_events(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_want_ip6_nd_events>;

template class Request<vapi_msg_want_ip6_nd_events, vapi_msg_want_ip6_nd_events_reply>;

using Want_ip6_nd_events = Request<vapi_msg_want_ip6_nd_events, vapi_msg_want_ip6_nd_events_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_l2_patch_add_del>(vapi_msg_l2_patch_add_del *msg)
{
  vapi_msg_l2_patch_add_del_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_l2_patch_add_del>(vapi_msg_l2_patch_add_del *msg)
{
  vapi_msg_l2_patch_add_del_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_l2_patch_add_del>()
{
  return ::vapi_msg_id_l2_patch_add_del; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_l2_patch_add_del>>()
{
  return ::vapi_msg_id_l2_patch_add_del; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_l2_patch_add_del()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_l2_patch_add_del>(vapi_msg_id_l2_patch_add_del);
}

template <> inline vapi_msg_l2_patch_add_del* vapi_alloc<vapi_msg_l2_patch_add_del>(Connection &con)
{
  vapi_msg_l2_patch_add_del* result = vapi_alloc_l2_patch_add_del(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_l2_patch_add_del>;

template class Request<vapi_msg_l2_patch_add_del, vapi_msg_l2_patch_add_del_reply>;

using L2_patch_add_del = Request<vapi_msg_l2_patch_add_del, vapi_msg_l2_patch_add_del_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_cli_reply>(vapi_msg_cli_reply *msg)
{
  vapi_msg_cli_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_cli_reply>(vapi_msg_cli_reply *msg)
{
  vapi_msg_cli_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_cli_reply>()
{
  return ::vapi_msg_id_cli_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_cli_reply>>()
{
  return ::vapi_msg_id_cli_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_cli_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_cli_reply>(vapi_msg_id_cli_reply);
}

template class Msg<vapi_msg_cli_reply>;

using Cli_reply = Msg<vapi_msg_cli_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_proxy_arp_intfc_enable_disable_reply>(vapi_msg_proxy_arp_intfc_enable_disable_reply *msg)
{
  vapi_msg_proxy_arp_intfc_enable_disable_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_proxy_arp_intfc_enable_disable_reply>(vapi_msg_proxy_arp_intfc_enable_disable_reply *msg)
{
  vapi_msg_proxy_arp_intfc_enable_disable_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_proxy_arp_intfc_enable_disable_reply>()
{
  return ::vapi_msg_id_proxy_arp_intfc_enable_disable_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_proxy_arp_intfc_enable_disable_reply>>()
{
  return ::vapi_msg_id_proxy_arp_intfc_enable_disable_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_proxy_arp_intfc_enable_disable_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_proxy_arp_intfc_enable_disable_reply>(vapi_msg_id_proxy_arp_intfc_enable_disable_reply);
}

template class Msg<vapi_msg_proxy_arp_intfc_enable_disable_reply>;

using Proxy_arp_intfc_enable_disable_reply = Msg<vapi_msg_proxy_arp_intfc_enable_disable_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_control_ping_reply>(vapi_msg_control_ping_reply *msg)
{
  vapi_msg_control_ping_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_control_ping_reply>(vapi_msg_control_ping_reply *msg)
{
  vapi_msg_control_ping_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_control_ping_reply>()
{
  return ::vapi_msg_id_control_ping_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_control_ping_reply>>()
{
  return ::vapi_msg_id_control_ping_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_control_ping_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_control_ping_reply>(vapi_msg_id_control_ping_reply);
}

template class Msg<vapi_msg_control_ping_reply>;

using Control_ping_reply = Msg<vapi_msg_control_ping_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_oam_event>(vapi_msg_oam_event *msg)
{
  vapi_msg_oam_event_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_oam_event>(vapi_msg_oam_event *msg)
{
  vapi_msg_oam_event_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_oam_event>()
{
  return ::vapi_msg_id_oam_event; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_oam_event>>()
{
  return ::vapi_msg_id_oam_event; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_oam_event()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_oam_event>(vapi_msg_id_oam_event);
}

template class Msg<vapi_msg_oam_event>;

using Oam_event = Msg<vapi_msg_oam_event>;
template <> inline void vapi_swap_to_be<vapi_msg_show_version>(vapi_msg_show_version *msg)
{
  vapi_msg_show_version_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_show_version>(vapi_msg_show_version *msg)
{
  vapi_msg_show_version_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_show_version>()
{
  return ::vapi_msg_id_show_version; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_show_version>>()
{
  return ::vapi_msg_id_show_version; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_show_version()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_show_version>(vapi_msg_id_show_version);
}

template <> inline vapi_msg_show_version* vapi_alloc<vapi_msg_show_version>(Connection &con)
{
  vapi_msg_show_version* result = vapi_alloc_show_version(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_show_version>;

template class Request<vapi_msg_show_version, vapi_msg_show_version_reply>;

using Show_version = Request<vapi_msg_show_version, vapi_msg_show_version_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_classify_set_interface_l2_tables>(vapi_msg_classify_set_interface_l2_tables *msg)
{
  vapi_msg_classify_set_interface_l2_tables_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_classify_set_interface_l2_tables>(vapi_msg_classify_set_interface_l2_tables *msg)
{
  vapi_msg_classify_set_interface_l2_tables_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_classify_set_interface_l2_tables>()
{
  return ::vapi_msg_id_classify_set_interface_l2_tables; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_classify_set_interface_l2_tables>>()
{
  return ::vapi_msg_id_classify_set_interface_l2_tables; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_classify_set_interface_l2_tables()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_classify_set_interface_l2_tables>(vapi_msg_id_classify_set_interface_l2_tables);
}

template <> inline vapi_msg_classify_set_interface_l2_tables* vapi_alloc<vapi_msg_classify_set_interface_l2_tables>(Connection &con)
{
  vapi_msg_classify_set_interface_l2_tables* result = vapi_alloc_classify_set_interface_l2_tables(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_classify_set_interface_l2_tables>;

template class Request<vapi_msg_classify_set_interface_l2_tables, vapi_msg_classify_set_interface_l2_tables_reply>;

using Classify_set_interface_l2_tables = Request<vapi_msg_classify_set_interface_l2_tables, vapi_msg_classify_set_interface_l2_tables_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_reset_vrf>(vapi_msg_reset_vrf *msg)
{
  vapi_msg_reset_vrf_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_reset_vrf>(vapi_msg_reset_vrf *msg)
{
  vapi_msg_reset_vrf_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_reset_vrf>()
{
  return ::vapi_msg_id_reset_vrf; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_reset_vrf>>()
{
  return ::vapi_msg_id_reset_vrf; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_reset_vrf()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_reset_vrf>(vapi_msg_id_reset_vrf);
}

template <> inline vapi_msg_reset_vrf* vapi_alloc<vapi_msg_reset_vrf>(Connection &con)
{
  vapi_msg_reset_vrf* result = vapi_alloc_reset_vrf(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_reset_vrf>;

template class Request<vapi_msg_reset_vrf, vapi_msg_reset_vrf_reply>;

using Reset_vrf = Request<vapi_msg_reset_vrf, vapi_msg_reset_vrf_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_input_acl_set_interface_reply>(vapi_msg_input_acl_set_interface_reply *msg)
{
  vapi_msg_input_acl_set_interface_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_input_acl_set_interface_reply>(vapi_msg_input_acl_set_interface_reply *msg)
{
  vapi_msg_input_acl_set_interface_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_input_acl_set_interface_reply>()
{
  return ::vapi_msg_id_input_acl_set_interface_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_input_acl_set_interface_reply>>()
{
  return ::vapi_msg_id_input_acl_set_interface_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_input_acl_set_interface_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_input_acl_set_interface_reply>(vapi_msg_id_input_acl_set_interface_reply);
}

template class Msg<vapi_msg_input_acl_set_interface_reply>;

using Input_acl_set_interface_reply = Msg<vapi_msg_input_acl_set_interface_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_bd_ip_mac_add_del>(vapi_msg_bd_ip_mac_add_del *msg)
{
  vapi_msg_bd_ip_mac_add_del_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_bd_ip_mac_add_del>(vapi_msg_bd_ip_mac_add_del *msg)
{
  vapi_msg_bd_ip_mac_add_del_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_bd_ip_mac_add_del>()
{
  return ::vapi_msg_id_bd_ip_mac_add_del; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_bd_ip_mac_add_del>>()
{
  return ::vapi_msg_id_bd_ip_mac_add_del; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_bd_ip_mac_add_del()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_bd_ip_mac_add_del>(vapi_msg_id_bd_ip_mac_add_del);
}

template <> inline vapi_msg_bd_ip_mac_add_del* vapi_alloc<vapi_msg_bd_ip_mac_add_del>(Connection &con)
{
  vapi_msg_bd_ip_mac_add_del* result = vapi_alloc_bd_ip_mac_add_del(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_bd_ip_mac_add_del>;

template class Request<vapi_msg_bd_ip_mac_add_del, vapi_msg_bd_ip_mac_add_del_reply>;

using Bd_ip_mac_add_del = Request<vapi_msg_bd_ip_mac_add_del, vapi_msg_bd_ip_mac_add_del_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_set_l2_bridge_reply>(vapi_msg_sw_interface_set_l2_bridge_reply *msg)
{
  vapi_msg_sw_interface_set_l2_bridge_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_set_l2_bridge_reply>(vapi_msg_sw_interface_set_l2_bridge_reply *msg)
{
  vapi_msg_sw_interface_set_l2_bridge_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_set_l2_bridge_reply>()
{
  return ::vapi_msg_id_sw_interface_set_l2_bridge_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_set_l2_bridge_reply>>()
{
  return ::vapi_msg_id_sw_interface_set_l2_bridge_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_set_l2_bridge_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_set_l2_bridge_reply>(vapi_msg_id_sw_interface_set_l2_bridge_reply);
}

template class Msg<vapi_msg_sw_interface_set_l2_bridge_reply>;

using Sw_interface_set_l2_bridge_reply = Msg<vapi_msg_sw_interface_set_l2_bridge_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_oam_add_del>(vapi_msg_oam_add_del *msg)
{
  vapi_msg_oam_add_del_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_oam_add_del>(vapi_msg_oam_add_del *msg)
{
  vapi_msg_oam_add_del_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_oam_add_del>()
{
  return ::vapi_msg_id_oam_add_del; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_oam_add_del>>()
{
  return ::vapi_msg_id_oam_add_del; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_oam_add_del()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_oam_add_del>(vapi_msg_id_oam_add_del);
}

template <> inline vapi_msg_oam_add_del* vapi_alloc<vapi_msg_oam_add_del>(Connection &con)
{
  vapi_msg_oam_add_del* result = vapi_alloc_oam_add_del(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_oam_add_del>;

template class Request<vapi_msg_oam_add_del, vapi_msg_oam_add_del_reply>;

using Oam_add_del = Request<vapi_msg_oam_add_del, vapi_msg_oam_add_del_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_get_node_graph>(vapi_msg_get_node_graph *msg)
{
  vapi_msg_get_node_graph_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_get_node_graph>(vapi_msg_get_node_graph *msg)
{
  vapi_msg_get_node_graph_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_get_node_graph>()
{
  return ::vapi_msg_id_get_node_graph; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_get_node_graph>>()
{
  return ::vapi_msg_id_get_node_graph; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_get_node_graph()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_get_node_graph>(vapi_msg_id_get_node_graph);
}

template <> inline vapi_msg_get_node_graph* vapi_alloc<vapi_msg_get_node_graph>(Connection &con)
{
  vapi_msg_get_node_graph* result = vapi_alloc_get_node_graph(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_get_node_graph>;

template class Request<vapi_msg_get_node_graph, vapi_msg_get_node_graph_reply>;

using Get_node_graph = Request<vapi_msg_get_node_graph, vapi_msg_get_node_graph_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_interface_name_renumber>(vapi_msg_interface_name_renumber *msg)
{
  vapi_msg_interface_name_renumber_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_interface_name_renumber>(vapi_msg_interface_name_renumber *msg)
{
  vapi_msg_interface_name_renumber_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_interface_name_renumber>()
{
  return ::vapi_msg_id_interface_name_renumber; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_interface_name_renumber>>()
{
  return ::vapi_msg_id_interface_name_renumber; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_interface_name_renumber()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_interface_name_renumber>(vapi_msg_id_interface_name_renumber);
}

template <> inline vapi_msg_interface_name_renumber* vapi_alloc<vapi_msg_interface_name_renumber>(Connection &con)
{
  vapi_msg_interface_name_renumber* result = vapi_alloc_interface_name_renumber(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_interface_name_renumber>;

template class Request<vapi_msg_interface_name_renumber, vapi_msg_interface_name_renumber_reply>;

using Interface_name_renumber = Request<vapi_msg_interface_name_renumber, vapi_msg_interface_name_renumber_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_pg_enable_disable_reply>(vapi_msg_pg_enable_disable_reply *msg)
{
  vapi_msg_pg_enable_disable_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_pg_enable_disable_reply>(vapi_msg_pg_enable_disable_reply *msg)
{
  vapi_msg_pg_enable_disable_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_pg_enable_disable_reply>()
{
  return ::vapi_msg_id_pg_enable_disable_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_pg_enable_disable_reply>>()
{
  return ::vapi_msg_id_pg_enable_disable_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_pg_enable_disable_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_pg_enable_disable_reply>(vapi_msg_id_pg_enable_disable_reply);
}

template class Msg<vapi_msg_pg_enable_disable_reply>;

using Pg_enable_disable_reply = Msg<vapi_msg_pg_enable_disable_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_create_loopback>(vapi_msg_create_loopback *msg)
{
  vapi_msg_create_loopback_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_create_loopback>(vapi_msg_create_loopback *msg)
{
  vapi_msg_create_loopback_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_create_loopback>()
{
  return ::vapi_msg_id_create_loopback; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_create_loopback>>()
{
  return ::vapi_msg_id_create_loopback; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_create_loopback()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_create_loopback>(vapi_msg_id_create_loopback);
}

template <> inline vapi_msg_create_loopback* vapi_alloc<vapi_msg_create_loopback>(Connection &con)
{
  vapi_msg_create_loopback* result = vapi_alloc_create_loopback(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_create_loopback>;

template class Request<vapi_msg_create_loopback, vapi_msg_create_loopback_reply>;

using Create_loopback = Request<vapi_msg_create_loopback, vapi_msg_create_loopback_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_create_loopback_reply>(vapi_msg_create_loopback_reply *msg)
{
  vapi_msg_create_loopback_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_create_loopback_reply>(vapi_msg_create_loopback_reply *msg)
{
  vapi_msg_create_loopback_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_create_loopback_reply>()
{
  return ::vapi_msg_id_create_loopback_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_create_loopback_reply>>()
{
  return ::vapi_msg_id_create_loopback_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_create_loopback_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_create_loopback_reply>(vapi_msg_id_create_loopback_reply);
}

template class Msg<vapi_msg_create_loopback_reply>;

using Create_loopback_reply = Msg<vapi_msg_create_loopback_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_set_arp_neighbor_limit_reply>(vapi_msg_set_arp_neighbor_limit_reply *msg)
{
  vapi_msg_set_arp_neighbor_limit_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_set_arp_neighbor_limit_reply>(vapi_msg_set_arp_neighbor_limit_reply *msg)
{
  vapi_msg_set_arp_neighbor_limit_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_set_arp_neighbor_limit_reply>()
{
  return ::vapi_msg_id_set_arp_neighbor_limit_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_set_arp_neighbor_limit_reply>>()
{
  return ::vapi_msg_id_set_arp_neighbor_limit_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_set_arp_neighbor_limit_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_set_arp_neighbor_limit_reply>(vapi_msg_id_set_arp_neighbor_limit_reply);
}

template class Msg<vapi_msg_set_arp_neighbor_limit_reply>;

using Set_arp_neighbor_limit_reply = Msg<vapi_msg_set_arp_neighbor_limit_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_add_node_next_reply>(vapi_msg_add_node_next_reply *msg)
{
  vapi_msg_add_node_next_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_add_node_next_reply>(vapi_msg_add_node_next_reply *msg)
{
  vapi_msg_add_node_next_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_add_node_next_reply>()
{
  return ::vapi_msg_id_add_node_next_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_add_node_next_reply>>()
{
  return ::vapi_msg_id_add_node_next_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_add_node_next_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_add_node_next_reply>(vapi_msg_id_add_node_next_reply);
}

template class Msg<vapi_msg_add_node_next_reply>;

using Add_node_next_reply = Msg<vapi_msg_add_node_next_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_set_mpls_enable>(vapi_msg_sw_interface_set_mpls_enable *msg)
{
  vapi_msg_sw_interface_set_mpls_enable_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_set_mpls_enable>(vapi_msg_sw_interface_set_mpls_enable *msg)
{
  vapi_msg_sw_interface_set_mpls_enable_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_set_mpls_enable>()
{
  return ::vapi_msg_id_sw_interface_set_mpls_enable; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_set_mpls_enable>>()
{
  return ::vapi_msg_id_sw_interface_set_mpls_enable; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_set_mpls_enable()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_set_mpls_enable>(vapi_msg_id_sw_interface_set_mpls_enable);
}

template <> inline vapi_msg_sw_interface_set_mpls_enable* vapi_alloc<vapi_msg_sw_interface_set_mpls_enable>(Connection &con)
{
  vapi_msg_sw_interface_set_mpls_enable* result = vapi_alloc_sw_interface_set_mpls_enable(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sw_interface_set_mpls_enable>;

template class Request<vapi_msg_sw_interface_set_mpls_enable, vapi_msg_sw_interface_set_mpls_enable_reply>;

using Sw_interface_set_mpls_enable = Request<vapi_msg_sw_interface_set_mpls_enable, vapi_msg_sw_interface_set_mpls_enable_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_punt_socket_deregister>(vapi_msg_punt_socket_deregister *msg)
{
  vapi_msg_punt_socket_deregister_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_punt_socket_deregister>(vapi_msg_punt_socket_deregister *msg)
{
  vapi_msg_punt_socket_deregister_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_punt_socket_deregister>()
{
  return ::vapi_msg_id_punt_socket_deregister; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_punt_socket_deregister>>()
{
  return ::vapi_msg_id_punt_socket_deregister; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_punt_socket_deregister()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_punt_socket_deregister>(vapi_msg_id_punt_socket_deregister);
}

template <> inline vapi_msg_punt_socket_deregister* vapi_alloc<vapi_msg_punt_socket_deregister>(Connection &con)
{
  vapi_msg_punt_socket_deregister* result = vapi_alloc_punt_socket_deregister(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_punt_socket_deregister>;

template class Request<vapi_msg_punt_socket_deregister, vapi_msg_punt_socket_deregister_reply>;

using Punt_socket_deregister = Request<vapi_msg_punt_socket_deregister, vapi_msg_punt_socket_deregister_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_ip_source_and_port_range_check_interface_add_del>(vapi_msg_ip_source_and_port_range_check_interface_add_del *msg)
{
  vapi_msg_ip_source_and_port_range_check_interface_add_del_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_ip_source_and_port_range_check_interface_add_del>(vapi_msg_ip_source_and_port_range_check_interface_add_del *msg)
{
  vapi_msg_ip_source_and_port_range_check_interface_add_del_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_ip_source_and_port_range_check_interface_add_del>()
{
  return ::vapi_msg_id_ip_source_and_port_range_check_interface_add_del; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_ip_source_and_port_range_check_interface_add_del>>()
{
  return ::vapi_msg_id_ip_source_and_port_range_check_interface_add_del; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_ip_source_and_port_range_check_interface_add_del()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_ip_source_and_port_range_check_interface_add_del>(vapi_msg_id_ip_source_and_port_range_check_interface_add_del);
}

template <> inline vapi_msg_ip_source_and_port_range_check_interface_add_del* vapi_alloc<vapi_msg_ip_source_and_port_range_check_interface_add_del>(Connection &con)
{
  vapi_msg_ip_source_and_port_range_check_interface_add_del* result = vapi_alloc_ip_source_and_port_range_check_interface_add_del(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_ip_source_and_port_range_check_interface_add_del>;

template class Request<vapi_msg_ip_source_and_port_range_check_interface_add_del, vapi_msg_ip_source_and_port_range_check_interface_add_del_reply>;

using Ip_source_and_port_range_check_interface_add_del = Request<vapi_msg_ip_source_and_port_range_check_interface_add_del, vapi_msg_ip_source_and_port_range_check_interface_add_del_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_punt_reply>(vapi_msg_punt_reply *msg)
{
  vapi_msg_punt_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_punt_reply>(vapi_msg_punt_reply *msg)
{
  vapi_msg_punt_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_punt_reply>()
{
  return ::vapi_msg_id_punt_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_punt_reply>>()
{
  return ::vapi_msg_id_punt_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_punt_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_punt_reply>(vapi_msg_id_punt_reply);
}

template class Msg<vapi_msg_punt_reply>;

using Punt_reply = Msg<vapi_msg_punt_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_control_ping>(vapi_msg_control_ping *msg)
{
  vapi_msg_control_ping_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_control_ping>(vapi_msg_control_ping *msg)
{
  vapi_msg_control_ping_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_control_ping>()
{
  return ::vapi_msg_id_control_ping; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_control_ping>>()
{
  return ::vapi_msg_id_control_ping; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_control_ping()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_control_ping>(vapi_msg_id_control_ping);
}

template <> inline vapi_msg_control_ping* vapi_alloc<vapi_msg_control_ping>(Connection &con)
{
  vapi_msg_control_ping* result = vapi_alloc_control_ping(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_control_ping>;

template class Request<vapi_msg_control_ping, vapi_msg_control_ping_reply>;

using Control_ping = Request<vapi_msg_control_ping, vapi_msg_control_ping_reply>;

}
#endif
