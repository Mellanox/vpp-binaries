/*
 * VLIB API definitions Mon Oct 30 07:35:18 2017
 * Input file: vlibmemory/memclnt.api.h
 * Automatically generated: please edit the input file NOT this file!
 */

#if defined(vl_msg_id)||defined(vl_union_id)||defined(vl_printfun) \
 ||defined(vl_endianfun)|| defined(vl_api_version)||defined(vl_typedefs) \
 ||defined(vl_msg_name)||defined(vl_msg_name_crc_list)
/* ok, something was selected */
#else
#warning no content included from vlibmemory/memclnt.api.h
#endif

#define VL_API_PACKED(x) x __attribute__ ((packed))


/****** Message ID / handler enum ******/

#ifdef vl_msg_id
vl_msg_id(VL_API_MEMCLNT_CREATE, vl_api_memclnt_create_t_handler)
vl_msg_id(VL_API_MEMCLNT_CREATE_REPLY, vl_api_memclnt_create_reply_t_handler)
vl_msg_id(VL_API_MEMCLNT_DELETE, vl_api_memclnt_delete_t_handler)
vl_msg_id(VL_API_MEMCLNT_DELETE_REPLY, vl_api_memclnt_delete_reply_t_handler)
vl_msg_id(VL_API_RX_THREAD_EXIT, vl_api_rx_thread_exit_t_handler)
vl_msg_id(VL_API_MEMCLNT_RX_THREAD_SUSPEND, vl_api_memclnt_rx_thread_suspend_t_handler)
vl_msg_id(VL_API_MEMCLNT_READ_TIMEOUT, vl_api_memclnt_read_timeout_t_handler)
vl_msg_id(VL_API_RPC_CALL, vl_api_rpc_call_t_handler)
vl_msg_id(VL_API_RPC_CALL_REPLY, vl_api_rpc_call_reply_t_handler)
vl_msg_id(VL_API_GET_FIRST_MSG_ID, vl_api_get_first_msg_id_t_handler)
vl_msg_id(VL_API_GET_FIRST_MSG_ID_REPLY, vl_api_get_first_msg_id_reply_t_handler)
vl_msg_id(VL_API_TRACE_PLUGIN_MSG_IDS, vl_api_trace_plugin_msg_ids_t_handler)
#endif

/****** Message names ******/

#ifdef vl_msg_name
vl_msg_name(vl_api_memclnt_create_t, 1)
vl_msg_name(vl_api_memclnt_create_reply_t, 1)
vl_msg_name(vl_api_memclnt_delete_t, 1)
vl_msg_name(vl_api_memclnt_delete_reply_t, 1)
vl_msg_name(vl_api_rx_thread_exit_t, 1)
vl_msg_name(vl_api_memclnt_rx_thread_suspend_t, 1)
vl_msg_name(vl_api_memclnt_read_timeout_t, 1)
vl_msg_name(vl_api_rpc_call_t, 1)
vl_msg_name(vl_api_rpc_call_reply_t, 1)
vl_msg_name(vl_api_get_first_msg_id_t, 1)
vl_msg_name(vl_api_get_first_msg_id_reply_t, 1)
vl_msg_name(vl_api_trace_plugin_msg_ids_t, 1)
#endif


/****** Message name, crc list ******/

#ifdef vl_msg_name_crc_list
#define foreach_vl_msg_name_crc_memclnt \
_(VL_API_MEMCLNT_CREATE, memclnt_create, 2671bcfd) \
_(VL_API_MEMCLNT_CREATE_REPLY, memclnt_create_reply, f71a8a1a) \
_(VL_API_MEMCLNT_DELETE, memclnt_delete, 602f4d82) \
_(VL_API_MEMCLNT_DELETE_REPLY, memclnt_delete_reply, 587855a7) \
_(VL_API_RX_THREAD_EXIT, rx_thread_exit, 6110e464) \
_(VL_API_MEMCLNT_RX_THREAD_SUSPEND, memclnt_rx_thread_suspend, 98c139f3) \
_(VL_API_MEMCLNT_READ_TIMEOUT, memclnt_read_timeout, 8161e828) \
_(VL_API_RPC_CALL, rpc_call, e17d6c23) \
_(VL_API_RPC_CALL_REPLY, rpc_call_reply, 45621c6a) \
_(VL_API_GET_FIRST_MSG_ID, get_first_msg_id, 56f7fd40) \
_(VL_API_GET_FIRST_MSG_ID_REPLY, get_first_msg_id_reply, 3c6931c6) \
_(VL_API_TRACE_PLUGIN_MSG_IDS, trace_plugin_msg_ids, 12ce6ba5) 
#endif


/****** Typedefs *****/

#ifdef vl_typedefs

typedef VL_API_PACKED(struct _vl_api_memclnt_create {
    u16 _vl_msg_id;
    i32 ctx_quota;
    u32 context;
    u64 input_queue;
    u8 name[64];
    u32 api_versions[8];
}) vl_api_memclnt_create_t;

typedef VL_API_PACKED(struct _vl_api_memclnt_create_reply {
    u16 _vl_msg_id;
    i32 response;
    u64 handle;
    u32 index;
    u32 context;
    u64 message_table;
}) vl_api_memclnt_create_reply_t;

typedef VL_API_PACKED(struct _vl_api_memclnt_delete {
    u16 _vl_msg_id;
    u32 index;
    u64 handle;
}) vl_api_memclnt_delete_t;

typedef VL_API_PACKED(struct _vl_api_memclnt_delete_reply {
    u16 _vl_msg_id;
    i32 response;
    u64 handle;
}) vl_api_memclnt_delete_reply_t;

typedef VL_API_PACKED(struct _vl_api_rx_thread_exit {
    u16 _vl_msg_id;
    u8 dummy;
}) vl_api_rx_thread_exit_t;

typedef VL_API_PACKED(struct _vl_api_memclnt_rx_thread_suspend {
    u16 _vl_msg_id;
    u8 dummy;
}) vl_api_memclnt_rx_thread_suspend_t;

typedef VL_API_PACKED(struct _vl_api_memclnt_read_timeout {
    u16 _vl_msg_id;
    u8 dummy;
}) vl_api_memclnt_read_timeout_t;

typedef VL_API_PACKED(struct _vl_api_rpc_call {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u64 function;
    u8 multicast;
    u8 need_barrier_sync;
    u8 send_reply;
    u8 data[0];
}) vl_api_rpc_call_t;

typedef VL_API_PACKED(struct _vl_api_rpc_call_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_rpc_call_reply_t;

typedef VL_API_PACKED(struct _vl_api_get_first_msg_id {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 name[64];
}) vl_api_get_first_msg_id_t;

typedef VL_API_PACKED(struct _vl_api_get_first_msg_id_reply {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    i32 retval;
    u16 first_msg_id;
}) vl_api_get_first_msg_id_reply_t;

typedef VL_API_PACKED(struct _vl_api_trace_plugin_msg_ids {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 plugin_name[128];
    u16 first_msg_id;
    u16 last_msg_id;
}) vl_api_trace_plugin_msg_ids_t;

#endif /* vl_typedefs */

/****** Discriminated Union Definitions *****/

#ifdef vl_union_id


#endif /* vl_union_id */

/****** Print functions *****/

#ifdef vl_printfun

#ifdef LP64
#define _uword_fmt "%lld"
#define _uword_cast (long long)
#else
#define _uword_fmt "%ld"
#define _uword_cast long
#endif

/***** manual: vl_api_memclnt_create_t_print  *****/

static inline void *vl_api_memclnt_create_reply_t_print (vl_api_memclnt_create_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_memclnt_create_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "response: %ld\n", (long) a->response);
    vl_print(handle, "handle: %llu\n", (long long) a->handle);
    vl_print(handle, "index: %u\n", (unsigned) a->index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "message_table: %llu\n", (long long) a->message_table);
    return handle;
}

/***** manual: vl_api_memclnt_delete_t_print  *****/

static inline void *vl_api_memclnt_delete_reply_t_print (vl_api_memclnt_delete_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_memclnt_delete_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "response: %ld\n", (long) a->response);
    vl_print(handle, "handle: %llu\n", (long long) a->handle);
    return handle;
}

static inline void *vl_api_rx_thread_exit_t_print (vl_api_rx_thread_exit_t *a,void *handle)
{
    vl_print(handle, "vl_api_rx_thread_exit_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "dummy: %u\n", (unsigned) a->dummy);
    return handle;
}

static inline void *vl_api_memclnt_rx_thread_suspend_t_print (vl_api_memclnt_rx_thread_suspend_t *a,void *handle)
{
    vl_print(handle, "vl_api_memclnt_rx_thread_suspend_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "dummy: %u\n", (unsigned) a->dummy);
    return handle;
}

static inline void *vl_api_memclnt_read_timeout_t_print (vl_api_memclnt_read_timeout_t *a,void *handle)
{
    vl_print(handle, "vl_api_memclnt_read_timeout_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "dummy: %u\n", (unsigned) a->dummy);
    return handle;
}

static inline void *vl_api_rpc_call_t_print (vl_api_rpc_call_t *a,void *handle)
{
    vl_print(handle, "vl_api_rpc_call_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "function: %llu\n", (long long) a->function);
    vl_print(handle, "multicast: %u\n", (unsigned) a->multicast);
    vl_print(handle, "need_barrier_sync: %u\n", (unsigned) a->need_barrier_sync);
    vl_print(handle, "send_reply: %u\n", (unsigned) a->send_reply);
    return handle;
}

static inline void *vl_api_rpc_call_reply_t_print (vl_api_rpc_call_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_rpc_call_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_get_first_msg_id_t_print (vl_api_get_first_msg_id_t *a,void *handle)
{
    vl_print(handle, "vl_api_get_first_msg_id_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "name[%d]: %u\n", _i, a->name[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_get_first_msg_id_reply_t_print (vl_api_get_first_msg_id_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_get_first_msg_id_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "first_msg_id: %u\n", (unsigned) a->first_msg_id);
    return handle;
}

/***** manual: vl_api_trace_plugin_msg_ids_t_print  *****/

#endif /* vl_printfun */


/****** Endian swap functions *****/

#ifdef vl_endianfun

#undef clib_net_to_host_uword
#ifdef LP64
#define clib_net_to_host_uword clib_net_to_host_u64
#else
#define clib_net_to_host_uword clib_net_to_host_u32
#endif

static inline void vl_api_memclnt_create_t_endian (vl_api_memclnt_create_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->ctx_quota = clib_net_to_host_u32(a->ctx_quota);
    a->context = clib_net_to_host_u32(a->context);
    a->input_queue = clib_net_to_host_u64(a->input_queue);
    /* a->name[0..63] = a->name[0..63] (no-op) */
    {
        int _i;
        for (_i = 0; _i < 8; _i++) {
            a->api_versions[_i] = clib_net_to_host_u32(a->api_versions[_i]);
        }
    }
}

static inline void vl_api_memclnt_create_reply_t_endian (vl_api_memclnt_create_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->response = clib_net_to_host_u32(a->response);
    a->handle = clib_net_to_host_u64(a->handle);
    a->index = clib_net_to_host_u32(a->index);
    a->context = clib_net_to_host_u32(a->context);
    a->message_table = clib_net_to_host_u64(a->message_table);
}

static inline void vl_api_memclnt_delete_t_endian (vl_api_memclnt_delete_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->index = clib_net_to_host_u32(a->index);
    a->handle = clib_net_to_host_u64(a->handle);
}

static inline void vl_api_memclnt_delete_reply_t_endian (vl_api_memclnt_delete_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->response = clib_net_to_host_u32(a->response);
    a->handle = clib_net_to_host_u64(a->handle);
}

static inline void vl_api_rx_thread_exit_t_endian (vl_api_rx_thread_exit_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    /* a->dummy = a->dummy (no-op) */
}

static inline void vl_api_memclnt_rx_thread_suspend_t_endian (vl_api_memclnt_rx_thread_suspend_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    /* a->dummy = a->dummy (no-op) */
}

static inline void vl_api_memclnt_read_timeout_t_endian (vl_api_memclnt_read_timeout_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    /* a->dummy = a->dummy (no-op) */
}

static inline void vl_api_rpc_call_t_endian (vl_api_rpc_call_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->function = clib_net_to_host_u64(a->function);
    /* a->multicast = a->multicast (no-op) */
    /* a->need_barrier_sync = a->need_barrier_sync (no-op) */
    /* a->send_reply = a->send_reply (no-op) */
}

static inline void vl_api_rpc_call_reply_t_endian (vl_api_rpc_call_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_get_first_msg_id_t_endian (vl_api_get_first_msg_id_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->name[0..63] = a->name[0..63] (no-op) */
}

static inline void vl_api_get_first_msg_id_reply_t_endian (vl_api_get_first_msg_id_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->first_msg_id = clib_net_to_host_u16(a->first_msg_id);
}

static inline void vl_api_trace_plugin_msg_ids_t_endian (vl_api_trace_plugin_msg_ids_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->plugin_name[0..127] = a->plugin_name[0..127] (no-op) */
    a->first_msg_id = clib_net_to_host_u16(a->first_msg_id);
    a->last_msg_id = clib_net_to_host_u16(a->last_msg_id);
}

#endif /* vl_endianfun */


#ifdef vl_api_version
vl_api_version(memclnt.api, 0x6408124c)

#endif

