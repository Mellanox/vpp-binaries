/*
 * VLIB API definitions Mon Oct 30 07:35:18 2017
 * Input file: vlibsocket/sockclnt.api.h
 * Automatically generated: please edit the input file NOT this file!
 */

#if defined(vl_msg_id)||defined(vl_union_id)||defined(vl_printfun) \
 ||defined(vl_endianfun)|| defined(vl_api_version)||defined(vl_typedefs) \
 ||defined(vl_msg_name)||defined(vl_msg_name_crc_list)
/* ok, something was selected */
#else
#warning no content included from vlibsocket/sockclnt.api.h
#endif

#define VL_API_PACKED(x) x __attribute__ ((packed))


/****** Message ID / handler enum ******/

#ifdef vl_msg_id
vl_msg_id(VL_API_SOCKCLNT_CREATE, vl_api_sockclnt_create_t_handler)
vl_msg_id(VL_API_SOCKCLNT_CREATE_REPLY, vl_api_sockclnt_create_reply_t_handler)
vl_msg_id(VL_API_SOCKCLNT_DELETE, vl_api_sockclnt_delete_t_handler)
vl_msg_id(VL_API_SOCKCLNT_DELETE_REPLY, vl_api_sockclnt_delete_reply_t_handler)
#endif

/****** Message names ******/

#ifdef vl_msg_name
vl_msg_name(vl_api_sockclnt_create_t, 1)
vl_msg_name(vl_api_sockclnt_create_reply_t, 1)
vl_msg_name(vl_api_sockclnt_delete_t, 1)
vl_msg_name(vl_api_sockclnt_delete_reply_t, 1)
#endif


/****** Message name, crc list ******/

#ifdef vl_msg_name_crc_list
#define foreach_vl_msg_name_crc_sockclnt \
_(VL_API_SOCKCLNT_CREATE, sockclnt_create, 37764f5d) \
_(VL_API_SOCKCLNT_CREATE_REPLY, sockclnt_create_reply, 472e733f) \
_(VL_API_SOCKCLNT_DELETE, sockclnt_delete, cbaab4f6) \
_(VL_API_SOCKCLNT_DELETE_REPLY, sockclnt_delete_reply, 91d2c78d) 
#endif


/****** Typedefs *****/

#ifdef vl_typedefs

typedef VL_API_PACKED(struct _vl_api_sockclnt_create {
    u16 _vl_msg_id;
    u8 name[64];
    u32 context;
}) vl_api_sockclnt_create_t;

typedef VL_API_PACKED(struct _vl_api_sockclnt_create_reply {
    u16 _vl_msg_id;
    i32 response;
    u64 handle;
    u32 index;
    u32 context;
}) vl_api_sockclnt_create_reply_t;

typedef VL_API_PACKED(struct _vl_api_sockclnt_delete {
    u16 _vl_msg_id;
    u32 index;
    u64 handle;
}) vl_api_sockclnt_delete_t;

typedef VL_API_PACKED(struct _vl_api_sockclnt_delete_reply {
    u16 _vl_msg_id;
    i32 response;
    u64 handle;
}) vl_api_sockclnt_delete_reply_t;

#endif /* vl_typedefs */

/****** Discriminated Union Definitions *****/

#ifdef vl_union_id


#endif /* vl_union_id */

/****** Print functions *****/

#ifdef vl_printfun

#ifdef LP64
#define _uword_fmt "%lld"
#define _uword_cast (long long)
#else
#define _uword_fmt "%ld"
#define _uword_cast long
#endif

static inline void *vl_api_sockclnt_create_t_print (vl_api_sockclnt_create_t *a,void *handle)
{
    vl_print(handle, "vl_api_sockclnt_create_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "name[%d]: %u\n", _i, a->name[_i]);
        }
    }
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_sockclnt_create_reply_t_print (vl_api_sockclnt_create_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_sockclnt_create_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "response: %ld\n", (long) a->response);
    vl_print(handle, "handle: %llu\n", (long long) a->handle);
    vl_print(handle, "index: %u\n", (unsigned) a->index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_sockclnt_delete_t_print (vl_api_sockclnt_delete_t *a,void *handle)
{
    vl_print(handle, "vl_api_sockclnt_delete_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "index: %u\n", (unsigned) a->index);
    vl_print(handle, "handle: %llu\n", (long long) a->handle);
    return handle;
}

static inline void *vl_api_sockclnt_delete_reply_t_print (vl_api_sockclnt_delete_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_sockclnt_delete_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "response: %ld\n", (long) a->response);
    vl_print(handle, "handle: %llu\n", (long long) a->handle);
    return handle;
}

#endif /* vl_printfun */


/****** Endian swap functions *****/

#ifdef vl_endianfun

#undef clib_net_to_host_uword
#ifdef LP64
#define clib_net_to_host_uword clib_net_to_host_u64
#else
#define clib_net_to_host_uword clib_net_to_host_u32
#endif

static inline void vl_api_sockclnt_create_t_endian (vl_api_sockclnt_create_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    /* a->name[0..63] = a->name[0..63] (no-op) */
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_sockclnt_create_reply_t_endian (vl_api_sockclnt_create_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->response = clib_net_to_host_u32(a->response);
    a->handle = clib_net_to_host_u64(a->handle);
    a->index = clib_net_to_host_u32(a->index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_sockclnt_delete_t_endian (vl_api_sockclnt_delete_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->index = clib_net_to_host_u32(a->index);
    a->handle = clib_net_to_host_u64(a->handle);
}

static inline void vl_api_sockclnt_delete_reply_t_endian (vl_api_sockclnt_delete_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->response = clib_net_to_host_u32(a->response);
    a->handle = clib_net_to_host_u64(a->handle);
}

#endif /* vl_endianfun */


#ifdef vl_api_version
vl_api_version(sockclnt.api, 0x2a926050)

#endif

