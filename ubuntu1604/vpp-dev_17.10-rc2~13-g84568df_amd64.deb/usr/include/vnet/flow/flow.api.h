/*
 * VLIB API definitions Mon Oct 30 07:35:18 2017
 * Input file: vnet/flow/flow.api.h
 * Automatically generated: please edit the input file NOT this file!
 */

#if defined(vl_msg_id)||defined(vl_union_id)||defined(vl_printfun) \
 ||defined(vl_endianfun)|| defined(vl_api_version)||defined(vl_typedefs) \
 ||defined(vl_msg_name)||defined(vl_msg_name_crc_list)
/* ok, something was selected */
#else
#warning no content included from vnet/flow/flow.api.h
#endif

#define VL_API_PACKED(x) x __attribute__ ((packed))


/****** Message ID / handler enum ******/

#ifdef vl_msg_id
vl_msg_id(VL_API_SET_IPFIX_EXPORTER, vl_api_set_ipfix_exporter_t_handler)
vl_msg_id(VL_API_SET_IPFIX_EXPORTER_REPLY, vl_api_set_ipfix_exporter_reply_t_handler)
vl_msg_id(VL_API_IPFIX_EXPORTER_DUMP, vl_api_ipfix_exporter_dump_t_handler)
vl_msg_id(VL_API_IPFIX_EXPORTER_DETAILS, vl_api_ipfix_exporter_details_t_handler)
vl_msg_id(VL_API_SET_IPFIX_CLASSIFY_STREAM, vl_api_set_ipfix_classify_stream_t_handler)
vl_msg_id(VL_API_SET_IPFIX_CLASSIFY_STREAM_REPLY, vl_api_set_ipfix_classify_stream_reply_t_handler)
vl_msg_id(VL_API_IPFIX_CLASSIFY_STREAM_DUMP, vl_api_ipfix_classify_stream_dump_t_handler)
vl_msg_id(VL_API_IPFIX_CLASSIFY_STREAM_DETAILS, vl_api_ipfix_classify_stream_details_t_handler)
vl_msg_id(VL_API_IPFIX_CLASSIFY_TABLE_ADD_DEL, vl_api_ipfix_classify_table_add_del_t_handler)
vl_msg_id(VL_API_IPFIX_CLASSIFY_TABLE_ADD_DEL_REPLY, vl_api_ipfix_classify_table_add_del_reply_t_handler)
vl_msg_id(VL_API_IPFIX_CLASSIFY_TABLE_DUMP, vl_api_ipfix_classify_table_dump_t_handler)
vl_msg_id(VL_API_IPFIX_CLASSIFY_TABLE_DETAILS, vl_api_ipfix_classify_table_details_t_handler)
#endif

/****** Message names ******/

#ifdef vl_msg_name
vl_msg_name(vl_api_set_ipfix_exporter_t, 1)
vl_msg_name(vl_api_set_ipfix_exporter_reply_t, 1)
vl_msg_name(vl_api_ipfix_exporter_dump_t, 1)
vl_msg_name(vl_api_ipfix_exporter_details_t, 1)
vl_msg_name(vl_api_set_ipfix_classify_stream_t, 1)
vl_msg_name(vl_api_set_ipfix_classify_stream_reply_t, 1)
vl_msg_name(vl_api_ipfix_classify_stream_dump_t, 1)
vl_msg_name(vl_api_ipfix_classify_stream_details_t, 1)
vl_msg_name(vl_api_ipfix_classify_table_add_del_t, 1)
vl_msg_name(vl_api_ipfix_classify_table_add_del_reply_t, 1)
vl_msg_name(vl_api_ipfix_classify_table_dump_t, 1)
vl_msg_name(vl_api_ipfix_classify_table_details_t, 1)
#endif


/****** Message name, crc list ******/

#ifdef vl_msg_name_crc_list
#define foreach_vl_msg_name_crc_flow \
_(VL_API_SET_IPFIX_EXPORTER, set_ipfix_exporter, d4c80f5c) \
_(VL_API_SET_IPFIX_EXPORTER_REPLY, set_ipfix_exporter_reply, 40b502e9) \
_(VL_API_IPFIX_EXPORTER_DUMP, ipfix_exporter_dump, 81a51716) \
_(VL_API_IPFIX_EXPORTER_DETAILS, ipfix_exporter_details, e7cc717b) \
_(VL_API_SET_IPFIX_CLASSIFY_STREAM, set_ipfix_classify_stream, 7ee60f3a) \
_(VL_API_SET_IPFIX_CLASSIFY_STREAM_REPLY, set_ipfix_classify_stream_reply, a4d2d102) \
_(VL_API_IPFIX_CLASSIFY_STREAM_DUMP, ipfix_classify_stream_dump, 81842294) \
_(VL_API_IPFIX_CLASSIFY_STREAM_DETAILS, ipfix_classify_stream_details, 6b9383aa) \
_(VL_API_IPFIX_CLASSIFY_TABLE_ADD_DEL, ipfix_classify_table_add_del, 52cc2ed9) \
_(VL_API_IPFIX_CLASSIFY_TABLE_ADD_DEL_REPLY, ipfix_classify_table_add_del_reply, 3116af60) \
_(VL_API_IPFIX_CLASSIFY_TABLE_DUMP, ipfix_classify_table_dump, b2ce9db1) \
_(VL_API_IPFIX_CLASSIFY_TABLE_DETAILS, ipfix_classify_table_details, d0ec861f) 
#endif


/****** Typedefs *****/

#ifdef vl_typedefs

typedef VL_API_PACKED(struct _vl_api_set_ipfix_exporter {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 collector_address[16];
    u16 collector_port;
    u8 src_address[16];
    u32 vrf_id;
    u32 path_mtu;
    u32 template_interval;
    u8 udp_checksum;
}) vl_api_set_ipfix_exporter_t;

typedef VL_API_PACKED(struct _vl_api_set_ipfix_exporter_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_set_ipfix_exporter_reply_t;

typedef VL_API_PACKED(struct _vl_api_ipfix_exporter_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_ipfix_exporter_dump_t;

typedef VL_API_PACKED(struct _vl_api_ipfix_exporter_details {
    u16 _vl_msg_id;
    u32 context;
    u8 collector_address[16];
    u16 collector_port;
    u8 src_address[16];
    u32 vrf_id;
    u32 path_mtu;
    u32 template_interval;
    u8 udp_checksum;
}) vl_api_ipfix_exporter_details_t;

typedef VL_API_PACKED(struct _vl_api_set_ipfix_classify_stream {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 domain_id;
    u16 src_port;
}) vl_api_set_ipfix_classify_stream_t;

typedef VL_API_PACKED(struct _vl_api_set_ipfix_classify_stream_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_set_ipfix_classify_stream_reply_t;

typedef VL_API_PACKED(struct _vl_api_ipfix_classify_stream_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_ipfix_classify_stream_dump_t;

typedef VL_API_PACKED(struct _vl_api_ipfix_classify_stream_details {
    u16 _vl_msg_id;
    u32 context;
    u32 domain_id;
    u16 src_port;
}) vl_api_ipfix_classify_stream_details_t;

typedef VL_API_PACKED(struct _vl_api_ipfix_classify_table_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 table_id;
    u8 ip_version;
    u8 transport_protocol;
    u8 is_add;
}) vl_api_ipfix_classify_table_add_del_t;

typedef VL_API_PACKED(struct _vl_api_ipfix_classify_table_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_ipfix_classify_table_add_del_reply_t;

typedef VL_API_PACKED(struct _vl_api_ipfix_classify_table_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_ipfix_classify_table_dump_t;

typedef VL_API_PACKED(struct _vl_api_ipfix_classify_table_details {
    u16 _vl_msg_id;
    u32 context;
    u32 table_id;
    u8 ip_version;
    u8 transport_protocol;
}) vl_api_ipfix_classify_table_details_t;

#endif /* vl_typedefs */

/****** Discriminated Union Definitions *****/

#ifdef vl_union_id


#endif /* vl_union_id */

/****** Print functions *****/

#ifdef vl_printfun

#ifdef LP64
#define _uword_fmt "%lld"
#define _uword_cast (long long)
#else
#define _uword_fmt "%ld"
#define _uword_cast long
#endif

static inline void *vl_api_set_ipfix_exporter_t_print (vl_api_set_ipfix_exporter_t *a,void *handle)
{
    vl_print(handle, "vl_api_set_ipfix_exporter_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "collector_address[%d]: %u\n", _i, a->collector_address[_i]);
        }
    }
    vl_print(handle, "collector_port: %u\n", (unsigned) a->collector_port);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "src_address[%d]: %u\n", _i, a->src_address[_i]);
        }
    }
    vl_print(handle, "vrf_id: %u\n", (unsigned) a->vrf_id);
    vl_print(handle, "path_mtu: %u\n", (unsigned) a->path_mtu);
    vl_print(handle, "template_interval: %u\n", (unsigned) a->template_interval);
    vl_print(handle, "udp_checksum: %u\n", (unsigned) a->udp_checksum);
    return handle;
}

static inline void *vl_api_set_ipfix_exporter_reply_t_print (vl_api_set_ipfix_exporter_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_set_ipfix_exporter_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_ipfix_exporter_dump_t_print (vl_api_ipfix_exporter_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_ipfix_exporter_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_ipfix_exporter_details_t_print (vl_api_ipfix_exporter_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_ipfix_exporter_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "collector_address[%d]: %u\n", _i, a->collector_address[_i]);
        }
    }
    vl_print(handle, "collector_port: %u\n", (unsigned) a->collector_port);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "src_address[%d]: %u\n", _i, a->src_address[_i]);
        }
    }
    vl_print(handle, "vrf_id: %u\n", (unsigned) a->vrf_id);
    vl_print(handle, "path_mtu: %u\n", (unsigned) a->path_mtu);
    vl_print(handle, "template_interval: %u\n", (unsigned) a->template_interval);
    vl_print(handle, "udp_checksum: %u\n", (unsigned) a->udp_checksum);
    return handle;
}

static inline void *vl_api_set_ipfix_classify_stream_t_print (vl_api_set_ipfix_classify_stream_t *a,void *handle)
{
    vl_print(handle, "vl_api_set_ipfix_classify_stream_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "domain_id: %u\n", (unsigned) a->domain_id);
    vl_print(handle, "src_port: %u\n", (unsigned) a->src_port);
    return handle;
}

static inline void *vl_api_set_ipfix_classify_stream_reply_t_print (vl_api_set_ipfix_classify_stream_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_set_ipfix_classify_stream_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_ipfix_classify_stream_dump_t_print (vl_api_ipfix_classify_stream_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_ipfix_classify_stream_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_ipfix_classify_stream_details_t_print (vl_api_ipfix_classify_stream_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_ipfix_classify_stream_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "domain_id: %u\n", (unsigned) a->domain_id);
    vl_print(handle, "src_port: %u\n", (unsigned) a->src_port);
    return handle;
}

static inline void *vl_api_ipfix_classify_table_add_del_t_print (vl_api_ipfix_classify_table_add_del_t *a,void *handle)
{
    vl_print(handle, "vl_api_ipfix_classify_table_add_del_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "table_id: %u\n", (unsigned) a->table_id);
    vl_print(handle, "ip_version: %u\n", (unsigned) a->ip_version);
    vl_print(handle, "transport_protocol: %u\n", (unsigned) a->transport_protocol);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    return handle;
}

static inline void *vl_api_ipfix_classify_table_add_del_reply_t_print (vl_api_ipfix_classify_table_add_del_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_ipfix_classify_table_add_del_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_ipfix_classify_table_dump_t_print (vl_api_ipfix_classify_table_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_ipfix_classify_table_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_ipfix_classify_table_details_t_print (vl_api_ipfix_classify_table_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_ipfix_classify_table_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "table_id: %u\n", (unsigned) a->table_id);
    vl_print(handle, "ip_version: %u\n", (unsigned) a->ip_version);
    vl_print(handle, "transport_protocol: %u\n", (unsigned) a->transport_protocol);
    return handle;
}

#endif /* vl_printfun */


/****** Endian swap functions *****/

#ifdef vl_endianfun

#undef clib_net_to_host_uword
#ifdef LP64
#define clib_net_to_host_uword clib_net_to_host_u64
#else
#define clib_net_to_host_uword clib_net_to_host_u32
#endif

static inline void vl_api_set_ipfix_exporter_t_endian (vl_api_set_ipfix_exporter_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->collector_address[0..15] = a->collector_address[0..15] (no-op) */
    a->collector_port = clib_net_to_host_u16(a->collector_port);
    /* a->src_address[0..15] = a->src_address[0..15] (no-op) */
    a->vrf_id = clib_net_to_host_u32(a->vrf_id);
    a->path_mtu = clib_net_to_host_u32(a->path_mtu);
    a->template_interval = clib_net_to_host_u32(a->template_interval);
    /* a->udp_checksum = a->udp_checksum (no-op) */
}

static inline void vl_api_set_ipfix_exporter_reply_t_endian (vl_api_set_ipfix_exporter_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_ipfix_exporter_dump_t_endian (vl_api_ipfix_exporter_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_ipfix_exporter_details_t_endian (vl_api_ipfix_exporter_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    /* a->collector_address[0..15] = a->collector_address[0..15] (no-op) */
    a->collector_port = clib_net_to_host_u16(a->collector_port);
    /* a->src_address[0..15] = a->src_address[0..15] (no-op) */
    a->vrf_id = clib_net_to_host_u32(a->vrf_id);
    a->path_mtu = clib_net_to_host_u32(a->path_mtu);
    a->template_interval = clib_net_to_host_u32(a->template_interval);
    /* a->udp_checksum = a->udp_checksum (no-op) */
}

static inline void vl_api_set_ipfix_classify_stream_t_endian (vl_api_set_ipfix_classify_stream_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->domain_id = clib_net_to_host_u32(a->domain_id);
    a->src_port = clib_net_to_host_u16(a->src_port);
}

static inline void vl_api_set_ipfix_classify_stream_reply_t_endian (vl_api_set_ipfix_classify_stream_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_ipfix_classify_stream_dump_t_endian (vl_api_ipfix_classify_stream_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_ipfix_classify_stream_details_t_endian (vl_api_ipfix_classify_stream_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->domain_id = clib_net_to_host_u32(a->domain_id);
    a->src_port = clib_net_to_host_u16(a->src_port);
}

static inline void vl_api_ipfix_classify_table_add_del_t_endian (vl_api_ipfix_classify_table_add_del_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->table_id = clib_net_to_host_u32(a->table_id);
    /* a->ip_version = a->ip_version (no-op) */
    /* a->transport_protocol = a->transport_protocol (no-op) */
    /* a->is_add = a->is_add (no-op) */
}

static inline void vl_api_ipfix_classify_table_add_del_reply_t_endian (vl_api_ipfix_classify_table_add_del_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_ipfix_classify_table_dump_t_endian (vl_api_ipfix_classify_table_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_ipfix_classify_table_details_t_endian (vl_api_ipfix_classify_table_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->table_id = clib_net_to_host_u32(a->table_id);
    /* a->ip_version = a->ip_version (no-op) */
    /* a->transport_protocol = a->transport_protocol (no-op) */
}

#endif /* vl_endianfun */


#ifdef vl_api_version
vl_api_version(flow.api, 0xbc0a0bf1)

#endif

