/*
 * VLIB API definitions Mon Oct 30 07:35:18 2017
 * Input file: vnet/ip/ip.api.h
 * Automatically generated: please edit the input file NOT this file!
 */

#if defined(vl_msg_id)||defined(vl_union_id)||defined(vl_printfun) \
 ||defined(vl_endianfun)|| defined(vl_api_version)||defined(vl_typedefs) \
 ||defined(vl_msg_name)||defined(vl_msg_name_crc_list)
/* ok, something was selected */
#else
#warning no content included from vnet/ip/ip.api.h
#endif

#define VL_API_PACKED(x) x __attribute__ ((packed))


/****** Message ID / handler enum ******/

#ifdef vl_msg_id
vl_msg_id(VL_API_IP_TABLE_ADD_DEL, vl_api_ip_table_add_del_t_handler)
vl_msg_id(VL_API_IP_TABLE_ADD_DEL_REPLY, vl_api_ip_table_add_del_reply_t_handler)
vl_msg_id(VL_API_IP_FIB_DUMP, vl_api_ip_fib_dump_t_handler)
/* typeonly: fib_path */
vl_msg_id(VL_API_IP_FIB_DETAILS, vl_api_ip_fib_details_t_handler)
vl_msg_id(VL_API_IP6_FIB_DUMP, vl_api_ip6_fib_dump_t_handler)
vl_msg_id(VL_API_IP6_FIB_DETAILS, vl_api_ip6_fib_details_t_handler)
vl_msg_id(VL_API_IP_NEIGHBOR_DUMP, vl_api_ip_neighbor_dump_t_handler)
vl_msg_id(VL_API_IP_NEIGHBOR_DETAILS, vl_api_ip_neighbor_details_t_handler)
vl_msg_id(VL_API_IP_NEIGHBOR_ADD_DEL, vl_api_ip_neighbor_add_del_t_handler)
vl_msg_id(VL_API_IP_NEIGHBOR_ADD_DEL_REPLY, vl_api_ip_neighbor_add_del_reply_t_handler)
vl_msg_id(VL_API_SET_IP_FLOW_HASH, vl_api_set_ip_flow_hash_t_handler)
vl_msg_id(VL_API_SET_IP_FLOW_HASH_REPLY, vl_api_set_ip_flow_hash_reply_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_IP6ND_RA_CONFIG, vl_api_sw_interface_ip6nd_ra_config_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_IP6ND_RA_CONFIG_REPLY, vl_api_sw_interface_ip6nd_ra_config_reply_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_IP6ND_RA_PREFIX, vl_api_sw_interface_ip6nd_ra_prefix_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_IP6ND_RA_PREFIX_REPLY, vl_api_sw_interface_ip6nd_ra_prefix_reply_t_handler)
vl_msg_id(VL_API_IP6ND_PROXY_ADD_DEL, vl_api_ip6nd_proxy_add_del_t_handler)
vl_msg_id(VL_API_IP6ND_PROXY_ADD_DEL_REPLY, vl_api_ip6nd_proxy_add_del_reply_t_handler)
vl_msg_id(VL_API_IP6ND_PROXY_DETAILS, vl_api_ip6nd_proxy_details_t_handler)
vl_msg_id(VL_API_IP6ND_PROXY_DUMP, vl_api_ip6nd_proxy_dump_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_IP6_ENABLE_DISABLE, vl_api_sw_interface_ip6_enable_disable_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_IP6_ENABLE_DISABLE_REPLY, vl_api_sw_interface_ip6_enable_disable_reply_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_IP6_SET_LINK_LOCAL_ADDRESS, vl_api_sw_interface_ip6_set_link_local_address_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_IP6_SET_LINK_LOCAL_ADDRESS_REPLY, vl_api_sw_interface_ip6_set_link_local_address_reply_t_handler)
vl_msg_id(VL_API_IP_ADD_DEL_ROUTE, vl_api_ip_add_del_route_t_handler)
vl_msg_id(VL_API_IP_ADD_DEL_ROUTE_REPLY, vl_api_ip_add_del_route_reply_t_handler)
vl_msg_id(VL_API_IP_MROUTE_ADD_DEL, vl_api_ip_mroute_add_del_t_handler)
vl_msg_id(VL_API_IP_MROUTE_ADD_DEL_REPLY, vl_api_ip_mroute_add_del_reply_t_handler)
vl_msg_id(VL_API_IP_MFIB_DUMP, vl_api_ip_mfib_dump_t_handler)
vl_msg_id(VL_API_IP_MFIB_DETAILS, vl_api_ip_mfib_details_t_handler)
vl_msg_id(VL_API_IP6_MFIB_DUMP, vl_api_ip6_mfib_dump_t_handler)
vl_msg_id(VL_API_IP6_MFIB_DETAILS, vl_api_ip6_mfib_details_t_handler)
vl_msg_id(VL_API_IP_ADDRESS_DETAILS, vl_api_ip_address_details_t_handler)
vl_msg_id(VL_API_IP_ADDRESS_DUMP, vl_api_ip_address_dump_t_handler)
vl_msg_id(VL_API_IP_DETAILS, vl_api_ip_details_t_handler)
vl_msg_id(VL_API_IP_DUMP, vl_api_ip_dump_t_handler)
vl_msg_id(VL_API_MFIB_SIGNAL_DUMP, vl_api_mfib_signal_dump_t_handler)
vl_msg_id(VL_API_MFIB_SIGNAL_DETAILS, vl_api_mfib_signal_details_t_handler)
#endif

/****** Message names ******/

#ifdef vl_msg_name
vl_msg_name(vl_api_ip_table_add_del_t, 1)
vl_msg_name(vl_api_ip_table_add_del_reply_t, 1)
vl_msg_name(vl_api_ip_fib_dump_t, 1)
/* typeonly: fib_path */
vl_msg_name(vl_api_ip_fib_details_t, 1)
vl_msg_name(vl_api_ip6_fib_dump_t, 1)
vl_msg_name(vl_api_ip6_fib_details_t, 1)
vl_msg_name(vl_api_ip_neighbor_dump_t, 1)
vl_msg_name(vl_api_ip_neighbor_details_t, 1)
vl_msg_name(vl_api_ip_neighbor_add_del_t, 1)
vl_msg_name(vl_api_ip_neighbor_add_del_reply_t, 1)
vl_msg_name(vl_api_set_ip_flow_hash_t, 1)
vl_msg_name(vl_api_set_ip_flow_hash_reply_t, 1)
vl_msg_name(vl_api_sw_interface_ip6nd_ra_config_t, 1)
vl_msg_name(vl_api_sw_interface_ip6nd_ra_config_reply_t, 1)
vl_msg_name(vl_api_sw_interface_ip6nd_ra_prefix_t, 1)
vl_msg_name(vl_api_sw_interface_ip6nd_ra_prefix_reply_t, 1)
vl_msg_name(vl_api_ip6nd_proxy_add_del_t, 1)
vl_msg_name(vl_api_ip6nd_proxy_add_del_reply_t, 1)
vl_msg_name(vl_api_ip6nd_proxy_details_t, 1)
vl_msg_name(vl_api_ip6nd_proxy_dump_t, 1)
vl_msg_name(vl_api_sw_interface_ip6_enable_disable_t, 1)
vl_msg_name(vl_api_sw_interface_ip6_enable_disable_reply_t, 1)
vl_msg_name(vl_api_sw_interface_ip6_set_link_local_address_t, 1)
vl_msg_name(vl_api_sw_interface_ip6_set_link_local_address_reply_t, 1)
vl_msg_name(vl_api_ip_add_del_route_t, 1)
vl_msg_name(vl_api_ip_add_del_route_reply_t, 1)
vl_msg_name(vl_api_ip_mroute_add_del_t, 1)
vl_msg_name(vl_api_ip_mroute_add_del_reply_t, 1)
vl_msg_name(vl_api_ip_mfib_dump_t, 1)
vl_msg_name(vl_api_ip_mfib_details_t, 1)
vl_msg_name(vl_api_ip6_mfib_dump_t, 1)
vl_msg_name(vl_api_ip6_mfib_details_t, 1)
vl_msg_name(vl_api_ip_address_details_t, 1)
vl_msg_name(vl_api_ip_address_dump_t, 1)
vl_msg_name(vl_api_ip_details_t, 1)
vl_msg_name(vl_api_ip_dump_t, 1)
vl_msg_name(vl_api_mfib_signal_dump_t, 1)
vl_msg_name(vl_api_mfib_signal_details_t, 1)
#endif


/****** Message name, crc list ******/

#ifdef vl_msg_name_crc_list
#define foreach_vl_msg_name_crc_ip \
_(VL_API_IP_TABLE_ADD_DEL, ip_table_add_del, 7192123e) \
_(VL_API_IP_TABLE_ADD_DEL_REPLY, ip_table_add_del_reply, 7da725be) \
_(VL_API_IP_FIB_DUMP, ip_fib_dump, 5fe56ca3) \
_(VL_API_IP_FIB_DETAILS, ip_fib_details, 273e00c4) \
_(VL_API_IP6_FIB_DUMP, ip6_fib_dump, 25c89676) \
_(VL_API_IP6_FIB_DETAILS, ip6_fib_details, f5f9e17e) \
_(VL_API_IP_NEIGHBOR_DUMP, ip_neighbor_dump, 3289e160) \
_(VL_API_IP_NEIGHBOR_DETAILS, ip_neighbor_details, 3a00e32a) \
_(VL_API_IP_NEIGHBOR_ADD_DEL, ip_neighbor_add_del, 5a0d070b) \
_(VL_API_IP_NEIGHBOR_ADD_DEL_REPLY, ip_neighbor_add_del_reply, e5b0f318) \
_(VL_API_SET_IP_FLOW_HASH, set_ip_flow_hash, 92ad3798) \
_(VL_API_SET_IP_FLOW_HASH_REPLY, set_ip_flow_hash_reply, 35a9e5eb) \
_(VL_API_SW_INTERFACE_IP6ND_RA_CONFIG, sw_interface_ip6nd_ra_config, ec4a29f6) \
_(VL_API_SW_INTERFACE_IP6ND_RA_CONFIG_REPLY, sw_interface_ip6nd_ra_config_reply, 16e25c5b) \
_(VL_API_SW_INTERFACE_IP6ND_RA_PREFIX, sw_interface_ip6nd_ra_prefix, 5db6555c) \
_(VL_API_SW_INTERFACE_IP6ND_RA_PREFIX_REPLY, sw_interface_ip6nd_ra_prefix_reply, 8050adb3) \
_(VL_API_IP6ND_PROXY_ADD_DEL, ip6nd_proxy_add_del, c56f802d) \
_(VL_API_IP6ND_PROXY_ADD_DEL_REPLY, ip6nd_proxy_add_del_reply, 00ddc2d5) \
_(VL_API_IP6ND_PROXY_DETAILS, ip6nd_proxy_details, f805ccc1) \
_(VL_API_IP6ND_PROXY_DUMP, ip6nd_proxy_dump, 21597d88) \
_(VL_API_SW_INTERFACE_IP6_ENABLE_DISABLE, sw_interface_ip6_enable_disable, 4a4e5405) \
_(VL_API_SW_INTERFACE_IP6_ENABLE_DISABLE_REPLY, sw_interface_ip6_enable_disable_reply, eb8b4a40) \
_(VL_API_SW_INTERFACE_IP6_SET_LINK_LOCAL_ADDRESS, sw_interface_ip6_set_link_local_address, 3db6d52b) \
_(VL_API_SW_INTERFACE_IP6_SET_LINK_LOCAL_ADDRESS_REPLY, sw_interface_ip6_set_link_local_address_reply, 0a781e17) \
_(VL_API_IP_ADD_DEL_ROUTE, ip_add_del_route, 93e81ee6) \
_(VL_API_IP_ADD_DEL_ROUTE_REPLY, ip_add_del_route_reply, ea57492b) \
_(VL_API_IP_MROUTE_ADD_DEL, ip_mroute_add_del, 8f5f21a8) \
_(VL_API_IP_MROUTE_ADD_DEL_REPLY, ip_mroute_add_del_reply, 8cabe02c) \
_(VL_API_IP_MFIB_DUMP, ip_mfib_dump, ee61390e) \
_(VL_API_IP_MFIB_DETAILS, ip_mfib_details, 395e5699) \
_(VL_API_IP6_MFIB_DUMP, ip6_mfib_dump, 0839e143) \
_(VL_API_IP6_MFIB_DETAILS, ip6_mfib_details, 921b153f) \
_(VL_API_IP_ADDRESS_DETAILS, ip_address_details, 190d4266) \
_(VL_API_IP_ADDRESS_DUMP, ip_address_dump, 632e859a) \
_(VL_API_IP_DETAILS, ip_details, 695c8227) \
_(VL_API_IP_DUMP, ip_dump, 3c1e33e0) \
_(VL_API_MFIB_SIGNAL_DUMP, mfib_signal_dump, bbbbd40d) \
_(VL_API_MFIB_SIGNAL_DETAILS, mfib_signal_details, 6ba92c72) 
#endif


/****** Typedefs *****/

#ifdef vl_typedefs

typedef VL_API_PACKED(struct _vl_api_ip_table_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 table_id;
    u8 is_ipv6;
    u8 is_add;
    u8 name[64];
}) vl_api_ip_table_add_del_t;

typedef VL_API_PACKED(struct _vl_api_ip_table_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_ip_table_add_del_reply_t;

typedef VL_API_PACKED(struct _vl_api_ip_fib_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_ip_fib_dump_t;

typedef VL_API_PACKED(struct _vl_api_fib_path {
    u32 sw_if_index;
    u8 weight;
    u8 preference;
    u8 is_local;
    u8 is_drop;
    u8 is_unreach;
    u8 is_prohibit;
    u8 afi;
    u8 next_hop[16];
}) vl_api_fib_path_t;

typedef VL_API_PACKED(struct _vl_api_ip_fib_details {
    u16 _vl_msg_id;
    u32 context;
    u32 table_id;
    u8 table_name[64];
    u8 address_length;
    u8 address[4];
    u32 count;
    vl_api_fib_path_t path[0];
}) vl_api_ip_fib_details_t;

typedef VL_API_PACKED(struct _vl_api_ip6_fib_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_ip6_fib_dump_t;

typedef VL_API_PACKED(struct _vl_api_ip6_fib_details {
    u16 _vl_msg_id;
    u32 context;
    u32 table_id;
    u8 table_name[64];
    u8 address_length;
    u8 address[16];
    u32 count;
    vl_api_fib_path_t path[0];
}) vl_api_ip6_fib_details_t;

typedef VL_API_PACKED(struct _vl_api_ip_neighbor_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u8 is_ipv6;
}) vl_api_ip_neighbor_dump_t;

typedef VL_API_PACKED(struct _vl_api_ip_neighbor_details {
    u16 _vl_msg_id;
    u32 context;
    u8 is_static;
    u8 is_ipv6;
    u8 mac_address[6];
    u8 ip_address[16];
}) vl_api_ip_neighbor_details_t;

typedef VL_API_PACKED(struct _vl_api_ip_neighbor_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u8 is_add;
    u8 is_ipv6;
    u8 is_static;
    u8 is_no_adj_fib;
    u8 mac_address[6];
    u8 dst_address[16];
}) vl_api_ip_neighbor_add_del_t;

typedef VL_API_PACKED(struct _vl_api_ip_neighbor_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_ip_neighbor_add_del_reply_t;

typedef VL_API_PACKED(struct _vl_api_set_ip_flow_hash {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 vrf_id;
    u8 is_ipv6;
    u8 src;
    u8 dst;
    u8 sport;
    u8 dport;
    u8 proto;
    u8 reverse;
}) vl_api_set_ip_flow_hash_t;

typedef VL_API_PACKED(struct _vl_api_set_ip_flow_hash_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_set_ip_flow_hash_reply_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_ip6nd_ra_config {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u8 suppress;
    u8 managed;
    u8 other;
    u8 ll_option;
    u8 send_unicast;
    u8 cease;
    u8 is_no;
    u8 default_router;
    u32 max_interval;
    u32 min_interval;
    u32 lifetime;
    u32 initial_count;
    u32 initial_interval;
}) vl_api_sw_interface_ip6nd_ra_config_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_ip6nd_ra_config_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_sw_interface_ip6nd_ra_config_reply_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_ip6nd_ra_prefix {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u8 address[16];
    u8 address_length;
    u8 use_default;
    u8 no_advertise;
    u8 off_link;
    u8 no_autoconfig;
    u8 no_onlink;
    u8 is_no;
    u32 val_lifetime;
    u32 pref_lifetime;
}) vl_api_sw_interface_ip6nd_ra_prefix_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_ip6nd_ra_prefix_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_sw_interface_ip6nd_ra_prefix_reply_t;

typedef VL_API_PACKED(struct _vl_api_ip6nd_proxy_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u8 is_del;
    u8 address[16];
}) vl_api_ip6nd_proxy_add_del_t;

typedef VL_API_PACKED(struct _vl_api_ip6nd_proxy_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_ip6nd_proxy_add_del_reply_t;

typedef VL_API_PACKED(struct _vl_api_ip6nd_proxy_details {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u8 address[16];
}) vl_api_ip6nd_proxy_details_t;

typedef VL_API_PACKED(struct _vl_api_ip6nd_proxy_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_ip6nd_proxy_dump_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_ip6_enable_disable {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u8 enable;
}) vl_api_sw_interface_ip6_enable_disable_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_ip6_enable_disable_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_sw_interface_ip6_enable_disable_reply_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_ip6_set_link_local_address {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u8 address[16];
}) vl_api_sw_interface_ip6_set_link_local_address_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_ip6_set_link_local_address_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_sw_interface_ip6_set_link_local_address_reply_t;

typedef VL_API_PACKED(struct _vl_api_ip_add_del_route {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 next_hop_sw_if_index;
    u32 table_id;
    u32 classify_table_index;
    u32 next_hop_table_id;
    u8 create_vrf_if_needed;
    u8 is_add;
    u8 is_drop;
    u8 is_unreach;
    u8 is_prohibit;
    u8 is_ipv6;
    u8 is_local;
    u8 is_classify;
    u8 is_multipath;
    u8 is_resolve_host;
    u8 is_resolve_attached;
    u8 not_last;
    u8 next_hop_weight;
    u8 next_hop_preference;
    u8 dst_address_length;
    u8 dst_address[16];
    u8 next_hop_address[16];
    u8 next_hop_n_out_labels;
    u32 next_hop_via_label;
    u32 next_hop_out_label_stack[0];
}) vl_api_ip_add_del_route_t;

typedef VL_API_PACKED(struct _vl_api_ip_add_del_route_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_ip_add_del_route_reply_t;

typedef VL_API_PACKED(struct _vl_api_ip_mroute_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 next_hop_sw_if_index;
    u32 table_id;
    u32 entry_flags;
    u32 itf_flags;
    u32 rpf_id;
    u16 grp_address_length;
    u8 create_vrf_if_needed;
    u8 is_add;
    u8 is_ipv6;
    u8 is_local;
    u8 grp_address[16];
    u8 src_address[16];
}) vl_api_ip_mroute_add_del_t;

typedef VL_API_PACKED(struct _vl_api_ip_mroute_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_ip_mroute_add_del_reply_t;

typedef VL_API_PACKED(struct _vl_api_ip_mfib_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_ip_mfib_dump_t;

typedef VL_API_PACKED(struct _vl_api_ip_mfib_details {
    u16 _vl_msg_id;
    u32 context;
    u32 table_id;
    u32 entry_flags;
    u32 rpf_id;
    u8 address_length;
    u8 grp_address[4];
    u8 src_address[4];
    u32 count;
    vl_api_fib_path_t path[0];
}) vl_api_ip_mfib_details_t;

typedef VL_API_PACKED(struct _vl_api_ip6_mfib_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_ip6_mfib_dump_t;

typedef VL_API_PACKED(struct _vl_api_ip6_mfib_details {
    u16 _vl_msg_id;
    u32 context;
    u32 table_id;
    u8 address_length;
    u8 grp_address[16];
    u8 src_address[16];
    u32 count;
    vl_api_fib_path_t path[0];
}) vl_api_ip6_mfib_details_t;

typedef VL_API_PACKED(struct _vl_api_ip_address_details {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 ip[16];
    u8 prefix_length;
    u32 sw_if_index;
    u8 is_ipv6;
}) vl_api_ip_address_details_t;

typedef VL_API_PACKED(struct _vl_api_ip_address_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u8 is_ipv6;
}) vl_api_ip_address_dump_t;

typedef VL_API_PACKED(struct _vl_api_ip_details {
    u16 _vl_msg_id;
    u32 sw_if_index;
    u32 context;
    u8 is_ipv6;
}) vl_api_ip_details_t;

typedef VL_API_PACKED(struct _vl_api_ip_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_ipv6;
}) vl_api_ip_dump_t;

typedef VL_API_PACKED(struct _vl_api_mfib_signal_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_mfib_signal_dump_t;

typedef VL_API_PACKED(struct _vl_api_mfib_signal_details {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u32 table_id;
    u16 grp_address_len;
    u8 grp_address[16];
    u8 src_address[16];
    u16 ip_packet_len;
    u8 ip_packet_data[256];
}) vl_api_mfib_signal_details_t;

#endif /* vl_typedefs */

/****** Discriminated Union Definitions *****/

#ifdef vl_union_id


#endif /* vl_union_id */

/****** Print functions *****/

#ifdef vl_printfun

#ifdef LP64
#define _uword_fmt "%lld"
#define _uword_cast (long long)
#else
#define _uword_fmt "%ld"
#define _uword_cast long
#endif

static inline void *vl_api_ip_table_add_del_t_print (vl_api_ip_table_add_del_t *a,void *handle)
{
    vl_print(handle, "vl_api_ip_table_add_del_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "table_id: %u\n", (unsigned) a->table_id);
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "name[%d]: %u\n", _i, a->name[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_ip_table_add_del_reply_t_print (vl_api_ip_table_add_del_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_ip_table_add_del_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_ip_fib_dump_t_print (vl_api_ip_fib_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_ip_fib_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

/***** manual: vl_api_fib_path_t_print  *****/

/***** manual: vl_api_ip_fib_details_t_print  *****/

static inline void *vl_api_ip6_fib_dump_t_print (vl_api_ip6_fib_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_ip6_fib_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

/***** manual: vl_api_ip6_fib_details_t_print  *****/

static inline void *vl_api_ip_neighbor_dump_t_print (vl_api_ip_neighbor_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_ip_neighbor_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    return handle;
}

static inline void *vl_api_ip_neighbor_details_t_print (vl_api_ip_neighbor_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_ip_neighbor_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_static: %u\n", (unsigned) a->is_static);
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    {
        int _i;
        for (_i = 0; _i < 6; _i++) {
            vl_print(handle, "mac_address[%d]: %u\n", _i, a->mac_address[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "ip_address[%d]: %u\n", _i, a->ip_address[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_ip_neighbor_add_del_t_print (vl_api_ip_neighbor_add_del_t *a,void *handle)
{
    vl_print(handle, "vl_api_ip_neighbor_add_del_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    vl_print(handle, "is_static: %u\n", (unsigned) a->is_static);
    vl_print(handle, "is_no_adj_fib: %u\n", (unsigned) a->is_no_adj_fib);
    {
        int _i;
        for (_i = 0; _i < 6; _i++) {
            vl_print(handle, "mac_address[%d]: %u\n", _i, a->mac_address[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "dst_address[%d]: %u\n", _i, a->dst_address[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_ip_neighbor_add_del_reply_t_print (vl_api_ip_neighbor_add_del_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_ip_neighbor_add_del_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_set_ip_flow_hash_t_print (vl_api_set_ip_flow_hash_t *a,void *handle)
{
    vl_print(handle, "vl_api_set_ip_flow_hash_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "vrf_id: %u\n", (unsigned) a->vrf_id);
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    vl_print(handle, "src: %u\n", (unsigned) a->src);
    vl_print(handle, "dst: %u\n", (unsigned) a->dst);
    vl_print(handle, "sport: %u\n", (unsigned) a->sport);
    vl_print(handle, "dport: %u\n", (unsigned) a->dport);
    vl_print(handle, "proto: %u\n", (unsigned) a->proto);
    vl_print(handle, "reverse: %u\n", (unsigned) a->reverse);
    return handle;
}

static inline void *vl_api_set_ip_flow_hash_reply_t_print (vl_api_set_ip_flow_hash_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_set_ip_flow_hash_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_sw_interface_ip6nd_ra_config_t_print (vl_api_sw_interface_ip6nd_ra_config_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_ip6nd_ra_config_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "suppress: %u\n", (unsigned) a->suppress);
    vl_print(handle, "managed: %u\n", (unsigned) a->managed);
    vl_print(handle, "other: %u\n", (unsigned) a->other);
    vl_print(handle, "ll_option: %u\n", (unsigned) a->ll_option);
    vl_print(handle, "send_unicast: %u\n", (unsigned) a->send_unicast);
    vl_print(handle, "cease: %u\n", (unsigned) a->cease);
    vl_print(handle, "is_no: %u\n", (unsigned) a->is_no);
    vl_print(handle, "default_router: %u\n", (unsigned) a->default_router);
    vl_print(handle, "max_interval: %u\n", (unsigned) a->max_interval);
    vl_print(handle, "min_interval: %u\n", (unsigned) a->min_interval);
    vl_print(handle, "lifetime: %u\n", (unsigned) a->lifetime);
    vl_print(handle, "initial_count: %u\n", (unsigned) a->initial_count);
    vl_print(handle, "initial_interval: %u\n", (unsigned) a->initial_interval);
    return handle;
}

static inline void *vl_api_sw_interface_ip6nd_ra_config_reply_t_print (vl_api_sw_interface_ip6nd_ra_config_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_ip6nd_ra_config_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_sw_interface_ip6nd_ra_prefix_t_print (vl_api_sw_interface_ip6nd_ra_prefix_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_ip6nd_ra_prefix_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "address[%d]: %u\n", _i, a->address[_i]);
        }
    }
    vl_print(handle, "address_length: %u\n", (unsigned) a->address_length);
    vl_print(handle, "use_default: %u\n", (unsigned) a->use_default);
    vl_print(handle, "no_advertise: %u\n", (unsigned) a->no_advertise);
    vl_print(handle, "off_link: %u\n", (unsigned) a->off_link);
    vl_print(handle, "no_autoconfig: %u\n", (unsigned) a->no_autoconfig);
    vl_print(handle, "no_onlink: %u\n", (unsigned) a->no_onlink);
    vl_print(handle, "is_no: %u\n", (unsigned) a->is_no);
    vl_print(handle, "val_lifetime: %u\n", (unsigned) a->val_lifetime);
    vl_print(handle, "pref_lifetime: %u\n", (unsigned) a->pref_lifetime);
    return handle;
}

static inline void *vl_api_sw_interface_ip6nd_ra_prefix_reply_t_print (vl_api_sw_interface_ip6nd_ra_prefix_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_ip6nd_ra_prefix_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_ip6nd_proxy_add_del_t_print (vl_api_ip6nd_proxy_add_del_t *a,void *handle)
{
    vl_print(handle, "vl_api_ip6nd_proxy_add_del_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "is_del: %u\n", (unsigned) a->is_del);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "address[%d]: %u\n", _i, a->address[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_ip6nd_proxy_add_del_reply_t_print (vl_api_ip6nd_proxy_add_del_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_ip6nd_proxy_add_del_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_ip6nd_proxy_details_t_print (vl_api_ip6nd_proxy_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_ip6nd_proxy_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "address[%d]: %u\n", _i, a->address[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_ip6nd_proxy_dump_t_print (vl_api_ip6nd_proxy_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_ip6nd_proxy_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_sw_interface_ip6_enable_disable_t_print (vl_api_sw_interface_ip6_enable_disable_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_ip6_enable_disable_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "enable: %u\n", (unsigned) a->enable);
    return handle;
}

static inline void *vl_api_sw_interface_ip6_enable_disable_reply_t_print (vl_api_sw_interface_ip6_enable_disable_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_ip6_enable_disable_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_sw_interface_ip6_set_link_local_address_t_print (vl_api_sw_interface_ip6_set_link_local_address_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_ip6_set_link_local_address_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "address[%d]: %u\n", _i, a->address[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_sw_interface_ip6_set_link_local_address_reply_t_print (vl_api_sw_interface_ip6_set_link_local_address_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_ip6_set_link_local_address_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_ip_add_del_route_t_print (vl_api_ip_add_del_route_t *a,void *handle)
{
    vl_print(handle, "vl_api_ip_add_del_route_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "next_hop_sw_if_index: %u\n", (unsigned) a->next_hop_sw_if_index);
    vl_print(handle, "table_id: %u\n", (unsigned) a->table_id);
    vl_print(handle, "classify_table_index: %u\n", (unsigned) a->classify_table_index);
    vl_print(handle, "next_hop_table_id: %u\n", (unsigned) a->next_hop_table_id);
    vl_print(handle, "create_vrf_if_needed: %u\n", (unsigned) a->create_vrf_if_needed);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "is_drop: %u\n", (unsigned) a->is_drop);
    vl_print(handle, "is_unreach: %u\n", (unsigned) a->is_unreach);
    vl_print(handle, "is_prohibit: %u\n", (unsigned) a->is_prohibit);
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    vl_print(handle, "is_local: %u\n", (unsigned) a->is_local);
    vl_print(handle, "is_classify: %u\n", (unsigned) a->is_classify);
    vl_print(handle, "is_multipath: %u\n", (unsigned) a->is_multipath);
    vl_print(handle, "is_resolve_host: %u\n", (unsigned) a->is_resolve_host);
    vl_print(handle, "is_resolve_attached: %u\n", (unsigned) a->is_resolve_attached);
    vl_print(handle, "not_last: %u\n", (unsigned) a->not_last);
    vl_print(handle, "next_hop_weight: %u\n", (unsigned) a->next_hop_weight);
    vl_print(handle, "next_hop_preference: %u\n", (unsigned) a->next_hop_preference);
    vl_print(handle, "dst_address_length: %u\n", (unsigned) a->dst_address_length);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "dst_address[%d]: %u\n", _i, a->dst_address[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "next_hop_address[%d]: %u\n", _i, a->next_hop_address[_i]);
        }
    }
    vl_print(handle, "next_hop_n_out_labels: %u\n", (unsigned) a->next_hop_n_out_labels);
    vl_print(handle, "next_hop_via_label: %u\n", (unsigned) a->next_hop_via_label);
    return handle;
}

static inline void *vl_api_ip_add_del_route_reply_t_print (vl_api_ip_add_del_route_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_ip_add_del_route_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_ip_mroute_add_del_t_print (vl_api_ip_mroute_add_del_t *a,void *handle)
{
    vl_print(handle, "vl_api_ip_mroute_add_del_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "next_hop_sw_if_index: %u\n", (unsigned) a->next_hop_sw_if_index);
    vl_print(handle, "table_id: %u\n", (unsigned) a->table_id);
    vl_print(handle, "entry_flags: %u\n", (unsigned) a->entry_flags);
    vl_print(handle, "itf_flags: %u\n", (unsigned) a->itf_flags);
    vl_print(handle, "rpf_id: %u\n", (unsigned) a->rpf_id);
    vl_print(handle, "grp_address_length: %u\n", (unsigned) a->grp_address_length);
    vl_print(handle, "create_vrf_if_needed: %u\n", (unsigned) a->create_vrf_if_needed);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    vl_print(handle, "is_local: %u\n", (unsigned) a->is_local);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "grp_address[%d]: %u\n", _i, a->grp_address[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "src_address[%d]: %u\n", _i, a->src_address[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_ip_mroute_add_del_reply_t_print (vl_api_ip_mroute_add_del_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_ip_mroute_add_del_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_ip_mfib_dump_t_print (vl_api_ip_mfib_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_ip_mfib_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

/***** manual: vl_api_ip_mfib_details_t_print  *****/

static inline void *vl_api_ip6_mfib_dump_t_print (vl_api_ip6_mfib_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_ip6_mfib_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

/***** manual: vl_api_ip6_mfib_details_t_print  *****/

static inline void *vl_api_ip_address_details_t_print (vl_api_ip_address_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_ip_address_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "ip[%d]: %u\n", _i, a->ip[_i]);
        }
    }
    vl_print(handle, "prefix_length: %u\n", (unsigned) a->prefix_length);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    return handle;
}

static inline void *vl_api_ip_address_dump_t_print (vl_api_ip_address_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_ip_address_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    return handle;
}

static inline void *vl_api_ip_details_t_print (vl_api_ip_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_ip_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    return handle;
}

static inline void *vl_api_ip_dump_t_print (vl_api_ip_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_ip_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    return handle;
}

static inline void *vl_api_mfib_signal_dump_t_print (vl_api_mfib_signal_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_mfib_signal_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_mfib_signal_details_t_print (vl_api_mfib_signal_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_mfib_signal_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "table_id: %u\n", (unsigned) a->table_id);
    vl_print(handle, "grp_address_len: %u\n", (unsigned) a->grp_address_len);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "grp_address[%d]: %u\n", _i, a->grp_address[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "src_address[%d]: %u\n", _i, a->src_address[_i]);
        }
    }
    vl_print(handle, "ip_packet_len: %u\n", (unsigned) a->ip_packet_len);
    {
        int _i;
        for (_i = 0; _i < 256; _i++) {
            vl_print(handle, "ip_packet_data[%d]: %u\n", _i, a->ip_packet_data[_i]);
        }
    }
    return handle;
}

#endif /* vl_printfun */


/****** Endian swap functions *****/

#ifdef vl_endianfun

#undef clib_net_to_host_uword
#ifdef LP64
#define clib_net_to_host_uword clib_net_to_host_u64
#else
#define clib_net_to_host_uword clib_net_to_host_u32
#endif

static inline void vl_api_ip_table_add_del_t_endian (vl_api_ip_table_add_del_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->table_id = clib_net_to_host_u32(a->table_id);
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    /* a->is_add = a->is_add (no-op) */
    /* a->name[0..63] = a->name[0..63] (no-op) */
}

static inline void vl_api_ip_table_add_del_reply_t_endian (vl_api_ip_table_add_del_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_ip_fib_dump_t_endian (vl_api_ip_fib_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

/***** manual: vl_api_fib_path_t_endian  *****/

/***** manual: vl_api_ip_fib_details_t_endian  *****/

static inline void vl_api_ip6_fib_dump_t_endian (vl_api_ip6_fib_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

/***** manual: vl_api_ip6_fib_details_t_endian  *****/

static inline void vl_api_ip_neighbor_dump_t_endian (vl_api_ip_neighbor_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
}

static inline void vl_api_ip_neighbor_details_t_endian (vl_api_ip_neighbor_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_static = a->is_static (no-op) */
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    /* a->mac_address[0..5] = a->mac_address[0..5] (no-op) */
    /* a->ip_address[0..15] = a->ip_address[0..15] (no-op) */
}

static inline void vl_api_ip_neighbor_add_del_t_endian (vl_api_ip_neighbor_add_del_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->is_add = a->is_add (no-op) */
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    /* a->is_static = a->is_static (no-op) */
    /* a->is_no_adj_fib = a->is_no_adj_fib (no-op) */
    /* a->mac_address[0..5] = a->mac_address[0..5] (no-op) */
    /* a->dst_address[0..15] = a->dst_address[0..15] (no-op) */
}

static inline void vl_api_ip_neighbor_add_del_reply_t_endian (vl_api_ip_neighbor_add_del_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_set_ip_flow_hash_t_endian (vl_api_set_ip_flow_hash_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->vrf_id = clib_net_to_host_u32(a->vrf_id);
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    /* a->src = a->src (no-op) */
    /* a->dst = a->dst (no-op) */
    /* a->sport = a->sport (no-op) */
    /* a->dport = a->dport (no-op) */
    /* a->proto = a->proto (no-op) */
    /* a->reverse = a->reverse (no-op) */
}

static inline void vl_api_set_ip_flow_hash_reply_t_endian (vl_api_set_ip_flow_hash_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_sw_interface_ip6nd_ra_config_t_endian (vl_api_sw_interface_ip6nd_ra_config_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->suppress = a->suppress (no-op) */
    /* a->managed = a->managed (no-op) */
    /* a->other = a->other (no-op) */
    /* a->ll_option = a->ll_option (no-op) */
    /* a->send_unicast = a->send_unicast (no-op) */
    /* a->cease = a->cease (no-op) */
    /* a->is_no = a->is_no (no-op) */
    /* a->default_router = a->default_router (no-op) */
    a->max_interval = clib_net_to_host_u32(a->max_interval);
    a->min_interval = clib_net_to_host_u32(a->min_interval);
    a->lifetime = clib_net_to_host_u32(a->lifetime);
    a->initial_count = clib_net_to_host_u32(a->initial_count);
    a->initial_interval = clib_net_to_host_u32(a->initial_interval);
}

static inline void vl_api_sw_interface_ip6nd_ra_config_reply_t_endian (vl_api_sw_interface_ip6nd_ra_config_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_sw_interface_ip6nd_ra_prefix_t_endian (vl_api_sw_interface_ip6nd_ra_prefix_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->address[0..15] = a->address[0..15] (no-op) */
    /* a->address_length = a->address_length (no-op) */
    /* a->use_default = a->use_default (no-op) */
    /* a->no_advertise = a->no_advertise (no-op) */
    /* a->off_link = a->off_link (no-op) */
    /* a->no_autoconfig = a->no_autoconfig (no-op) */
    /* a->no_onlink = a->no_onlink (no-op) */
    /* a->is_no = a->is_no (no-op) */
    a->val_lifetime = clib_net_to_host_u32(a->val_lifetime);
    a->pref_lifetime = clib_net_to_host_u32(a->pref_lifetime);
}

static inline void vl_api_sw_interface_ip6nd_ra_prefix_reply_t_endian (vl_api_sw_interface_ip6nd_ra_prefix_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_ip6nd_proxy_add_del_t_endian (vl_api_ip6nd_proxy_add_del_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->is_del = a->is_del (no-op) */
    /* a->address[0..15] = a->address[0..15] (no-op) */
}

static inline void vl_api_ip6nd_proxy_add_del_reply_t_endian (vl_api_ip6nd_proxy_add_del_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_ip6nd_proxy_details_t_endian (vl_api_ip6nd_proxy_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->address[0..15] = a->address[0..15] (no-op) */
}

static inline void vl_api_ip6nd_proxy_dump_t_endian (vl_api_ip6nd_proxy_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_sw_interface_ip6_enable_disable_t_endian (vl_api_sw_interface_ip6_enable_disable_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->enable = a->enable (no-op) */
}

static inline void vl_api_sw_interface_ip6_enable_disable_reply_t_endian (vl_api_sw_interface_ip6_enable_disable_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_sw_interface_ip6_set_link_local_address_t_endian (vl_api_sw_interface_ip6_set_link_local_address_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->address[0..15] = a->address[0..15] (no-op) */
}

static inline void vl_api_sw_interface_ip6_set_link_local_address_reply_t_endian (vl_api_sw_interface_ip6_set_link_local_address_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_ip_add_del_route_t_endian (vl_api_ip_add_del_route_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->next_hop_sw_if_index = clib_net_to_host_u32(a->next_hop_sw_if_index);
    a->table_id = clib_net_to_host_u32(a->table_id);
    a->classify_table_index = clib_net_to_host_u32(a->classify_table_index);
    a->next_hop_table_id = clib_net_to_host_u32(a->next_hop_table_id);
    /* a->create_vrf_if_needed = a->create_vrf_if_needed (no-op) */
    /* a->is_add = a->is_add (no-op) */
    /* a->is_drop = a->is_drop (no-op) */
    /* a->is_unreach = a->is_unreach (no-op) */
    /* a->is_prohibit = a->is_prohibit (no-op) */
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    /* a->is_local = a->is_local (no-op) */
    /* a->is_classify = a->is_classify (no-op) */
    /* a->is_multipath = a->is_multipath (no-op) */
    /* a->is_resolve_host = a->is_resolve_host (no-op) */
    /* a->is_resolve_attached = a->is_resolve_attached (no-op) */
    /* a->not_last = a->not_last (no-op) */
    /* a->next_hop_weight = a->next_hop_weight (no-op) */
    /* a->next_hop_preference = a->next_hop_preference (no-op) */
    /* a->dst_address_length = a->dst_address_length (no-op) */
    /* a->dst_address[0..15] = a->dst_address[0..15] (no-op) */
    /* a->next_hop_address[0..15] = a->next_hop_address[0..15] (no-op) */
    /* a->next_hop_n_out_labels = a->next_hop_n_out_labels (no-op) */
    a->next_hop_via_label = clib_net_to_host_u32(a->next_hop_via_label);
}

static inline void vl_api_ip_add_del_route_reply_t_endian (vl_api_ip_add_del_route_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_ip_mroute_add_del_t_endian (vl_api_ip_mroute_add_del_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->next_hop_sw_if_index = clib_net_to_host_u32(a->next_hop_sw_if_index);
    a->table_id = clib_net_to_host_u32(a->table_id);
    a->entry_flags = clib_net_to_host_u32(a->entry_flags);
    a->itf_flags = clib_net_to_host_u32(a->itf_flags);
    a->rpf_id = clib_net_to_host_u32(a->rpf_id);
    a->grp_address_length = clib_net_to_host_u16(a->grp_address_length);
    /* a->create_vrf_if_needed = a->create_vrf_if_needed (no-op) */
    /* a->is_add = a->is_add (no-op) */
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    /* a->is_local = a->is_local (no-op) */
    /* a->grp_address[0..15] = a->grp_address[0..15] (no-op) */
    /* a->src_address[0..15] = a->src_address[0..15] (no-op) */
}

static inline void vl_api_ip_mroute_add_del_reply_t_endian (vl_api_ip_mroute_add_del_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_ip_mfib_dump_t_endian (vl_api_ip_mfib_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

/***** manual: vl_api_ip_mfib_details_t_endian  *****/

static inline void vl_api_ip6_mfib_dump_t_endian (vl_api_ip6_mfib_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

/***** manual: vl_api_ip6_mfib_details_t_endian  *****/

static inline void vl_api_ip_address_details_t_endian (vl_api_ip_address_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->ip[0..15] = a->ip[0..15] (no-op) */
    /* a->prefix_length = a->prefix_length (no-op) */
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
}

static inline void vl_api_ip_address_dump_t_endian (vl_api_ip_address_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
}

static inline void vl_api_ip_details_t_endian (vl_api_ip_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
}

static inline void vl_api_ip_dump_t_endian (vl_api_ip_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
}

static inline void vl_api_mfib_signal_dump_t_endian (vl_api_mfib_signal_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_mfib_signal_details_t_endian (vl_api_mfib_signal_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    a->table_id = clib_net_to_host_u32(a->table_id);
    a->grp_address_len = clib_net_to_host_u16(a->grp_address_len);
    /* a->grp_address[0..15] = a->grp_address[0..15] (no-op) */
    /* a->src_address[0..15] = a->src_address[0..15] (no-op) */
    a->ip_packet_len = clib_net_to_host_u16(a->ip_packet_len);
    /* a->ip_packet_data[0..255] = a->ip_packet_data[0..255] (no-op) */
}

#endif /* vl_endianfun */


#ifdef vl_api_version
vl_api_version(ip.api, 0xaa55f39c)

#endif

