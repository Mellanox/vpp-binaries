/*
 * VLIB API definitions Mon Oct 30 07:35:18 2017
 * Input file: vnet/ipsec/ipsec.api.h
 * Automatically generated: please edit the input file NOT this file!
 */

#if defined(vl_msg_id)||defined(vl_union_id)||defined(vl_printfun) \
 ||defined(vl_endianfun)|| defined(vl_api_version)||defined(vl_typedefs) \
 ||defined(vl_msg_name)||defined(vl_msg_name_crc_list)
/* ok, something was selected */
#else
#warning no content included from vnet/ipsec/ipsec.api.h
#endif

#define VL_API_PACKED(x) x __attribute__ ((packed))


/****** Message ID / handler enum ******/

#ifdef vl_msg_id
vl_msg_id(VL_API_IPSEC_SPD_ADD_DEL, vl_api_ipsec_spd_add_del_t_handler)
vl_msg_id(VL_API_IPSEC_SPD_ADD_DEL_REPLY, vl_api_ipsec_spd_add_del_reply_t_handler)
vl_msg_id(VL_API_IPSEC_INTERFACE_ADD_DEL_SPD, vl_api_ipsec_interface_add_del_spd_t_handler)
vl_msg_id(VL_API_IPSEC_INTERFACE_ADD_DEL_SPD_REPLY, vl_api_ipsec_interface_add_del_spd_reply_t_handler)
vl_msg_id(VL_API_IPSEC_SPD_ADD_DEL_ENTRY, vl_api_ipsec_spd_add_del_entry_t_handler)
vl_msg_id(VL_API_IPSEC_SPD_ADD_DEL_ENTRY_REPLY, vl_api_ipsec_spd_add_del_entry_reply_t_handler)
vl_msg_id(VL_API_IPSEC_SAD_ADD_DEL_ENTRY, vl_api_ipsec_sad_add_del_entry_t_handler)
vl_msg_id(VL_API_IPSEC_SAD_ADD_DEL_ENTRY_REPLY, vl_api_ipsec_sad_add_del_entry_reply_t_handler)
vl_msg_id(VL_API_IPSEC_SA_SET_KEY, vl_api_ipsec_sa_set_key_t_handler)
vl_msg_id(VL_API_IPSEC_SA_SET_KEY_REPLY, vl_api_ipsec_sa_set_key_reply_t_handler)
vl_msg_id(VL_API_IKEV2_PROFILE_ADD_DEL, vl_api_ikev2_profile_add_del_t_handler)
vl_msg_id(VL_API_IKEV2_PROFILE_ADD_DEL_REPLY, vl_api_ikev2_profile_add_del_reply_t_handler)
vl_msg_id(VL_API_IKEV2_PROFILE_SET_AUTH, vl_api_ikev2_profile_set_auth_t_handler)
vl_msg_id(VL_API_IKEV2_PROFILE_SET_AUTH_REPLY, vl_api_ikev2_profile_set_auth_reply_t_handler)
vl_msg_id(VL_API_IKEV2_PROFILE_SET_ID, vl_api_ikev2_profile_set_id_t_handler)
vl_msg_id(VL_API_IKEV2_PROFILE_SET_ID_REPLY, vl_api_ikev2_profile_set_id_reply_t_handler)
vl_msg_id(VL_API_IKEV2_PROFILE_SET_TS, vl_api_ikev2_profile_set_ts_t_handler)
vl_msg_id(VL_API_IKEV2_PROFILE_SET_TS_REPLY, vl_api_ikev2_profile_set_ts_reply_t_handler)
vl_msg_id(VL_API_IKEV2_SET_LOCAL_KEY, vl_api_ikev2_set_local_key_t_handler)
vl_msg_id(VL_API_IKEV2_SET_LOCAL_KEY_REPLY, vl_api_ikev2_set_local_key_reply_t_handler)
vl_msg_id(VL_API_IKEV2_SET_RESPONDER, vl_api_ikev2_set_responder_t_handler)
vl_msg_id(VL_API_IKEV2_SET_RESPONDER_REPLY, vl_api_ikev2_set_responder_reply_t_handler)
vl_msg_id(VL_API_IKEV2_SET_IKE_TRANSFORMS, vl_api_ikev2_set_ike_transforms_t_handler)
vl_msg_id(VL_API_IKEV2_SET_IKE_TRANSFORMS_REPLY, vl_api_ikev2_set_ike_transforms_reply_t_handler)
vl_msg_id(VL_API_IKEV2_SET_ESP_TRANSFORMS, vl_api_ikev2_set_esp_transforms_t_handler)
vl_msg_id(VL_API_IKEV2_SET_ESP_TRANSFORMS_REPLY, vl_api_ikev2_set_esp_transforms_reply_t_handler)
vl_msg_id(VL_API_IKEV2_SET_SA_LIFETIME, vl_api_ikev2_set_sa_lifetime_t_handler)
vl_msg_id(VL_API_IKEV2_SET_SA_LIFETIME_REPLY, vl_api_ikev2_set_sa_lifetime_reply_t_handler)
vl_msg_id(VL_API_IKEV2_INITIATE_SA_INIT, vl_api_ikev2_initiate_sa_init_t_handler)
vl_msg_id(VL_API_IKEV2_INITIATE_SA_INIT_REPLY, vl_api_ikev2_initiate_sa_init_reply_t_handler)
vl_msg_id(VL_API_IKEV2_INITIATE_DEL_IKE_SA, vl_api_ikev2_initiate_del_ike_sa_t_handler)
vl_msg_id(VL_API_IKEV2_INITIATE_DEL_IKE_SA_REPLY, vl_api_ikev2_initiate_del_ike_sa_reply_t_handler)
vl_msg_id(VL_API_IKEV2_INITIATE_DEL_CHILD_SA, vl_api_ikev2_initiate_del_child_sa_t_handler)
vl_msg_id(VL_API_IKEV2_INITIATE_DEL_CHILD_SA_REPLY, vl_api_ikev2_initiate_del_child_sa_reply_t_handler)
vl_msg_id(VL_API_IKEV2_INITIATE_REKEY_CHILD_SA, vl_api_ikev2_initiate_rekey_child_sa_t_handler)
vl_msg_id(VL_API_IKEV2_INITIATE_REKEY_CHILD_SA_REPLY, vl_api_ikev2_initiate_rekey_child_sa_reply_t_handler)
vl_msg_id(VL_API_IPSEC_SPD_DUMP, vl_api_ipsec_spd_dump_t_handler)
vl_msg_id(VL_API_IPSEC_SPD_DETAILS, vl_api_ipsec_spd_details_t_handler)
vl_msg_id(VL_API_IPSEC_TUNNEL_IF_ADD_DEL, vl_api_ipsec_tunnel_if_add_del_t_handler)
vl_msg_id(VL_API_IPSEC_TUNNEL_IF_ADD_DEL_REPLY, vl_api_ipsec_tunnel_if_add_del_reply_t_handler)
#endif

/****** Message names ******/

#ifdef vl_msg_name
vl_msg_name(vl_api_ipsec_spd_add_del_t, 1)
vl_msg_name(vl_api_ipsec_spd_add_del_reply_t, 1)
vl_msg_name(vl_api_ipsec_interface_add_del_spd_t, 1)
vl_msg_name(vl_api_ipsec_interface_add_del_spd_reply_t, 1)
vl_msg_name(vl_api_ipsec_spd_add_del_entry_t, 1)
vl_msg_name(vl_api_ipsec_spd_add_del_entry_reply_t, 1)
vl_msg_name(vl_api_ipsec_sad_add_del_entry_t, 1)
vl_msg_name(vl_api_ipsec_sad_add_del_entry_reply_t, 1)
vl_msg_name(vl_api_ipsec_sa_set_key_t, 1)
vl_msg_name(vl_api_ipsec_sa_set_key_reply_t, 1)
vl_msg_name(vl_api_ikev2_profile_add_del_t, 1)
vl_msg_name(vl_api_ikev2_profile_add_del_reply_t, 1)
vl_msg_name(vl_api_ikev2_profile_set_auth_t, 1)
vl_msg_name(vl_api_ikev2_profile_set_auth_reply_t, 1)
vl_msg_name(vl_api_ikev2_profile_set_id_t, 1)
vl_msg_name(vl_api_ikev2_profile_set_id_reply_t, 1)
vl_msg_name(vl_api_ikev2_profile_set_ts_t, 1)
vl_msg_name(vl_api_ikev2_profile_set_ts_reply_t, 1)
vl_msg_name(vl_api_ikev2_set_local_key_t, 1)
vl_msg_name(vl_api_ikev2_set_local_key_reply_t, 1)
vl_msg_name(vl_api_ikev2_set_responder_t, 1)
vl_msg_name(vl_api_ikev2_set_responder_reply_t, 1)
vl_msg_name(vl_api_ikev2_set_ike_transforms_t, 1)
vl_msg_name(vl_api_ikev2_set_ike_transforms_reply_t, 1)
vl_msg_name(vl_api_ikev2_set_esp_transforms_t, 1)
vl_msg_name(vl_api_ikev2_set_esp_transforms_reply_t, 1)
vl_msg_name(vl_api_ikev2_set_sa_lifetime_t, 1)
vl_msg_name(vl_api_ikev2_set_sa_lifetime_reply_t, 1)
vl_msg_name(vl_api_ikev2_initiate_sa_init_t, 1)
vl_msg_name(vl_api_ikev2_initiate_sa_init_reply_t, 1)
vl_msg_name(vl_api_ikev2_initiate_del_ike_sa_t, 1)
vl_msg_name(vl_api_ikev2_initiate_del_ike_sa_reply_t, 1)
vl_msg_name(vl_api_ikev2_initiate_del_child_sa_t, 1)
vl_msg_name(vl_api_ikev2_initiate_del_child_sa_reply_t, 1)
vl_msg_name(vl_api_ikev2_initiate_rekey_child_sa_t, 1)
vl_msg_name(vl_api_ikev2_initiate_rekey_child_sa_reply_t, 1)
vl_msg_name(vl_api_ipsec_spd_dump_t, 1)
vl_msg_name(vl_api_ipsec_spd_details_t, 1)
vl_msg_name(vl_api_ipsec_tunnel_if_add_del_t, 1)
vl_msg_name(vl_api_ipsec_tunnel_if_add_del_reply_t, 1)
#endif


/****** Message name, crc list ******/

#ifdef vl_msg_name_crc_list
#define foreach_vl_msg_name_crc_ipsec \
_(VL_API_IPSEC_SPD_ADD_DEL, ipsec_spd_add_del, 9b42314b) \
_(VL_API_IPSEC_SPD_ADD_DEL_REPLY, ipsec_spd_add_del_reply, c7439119) \
_(VL_API_IPSEC_INTERFACE_ADD_DEL_SPD, ipsec_interface_add_del_spd, 52de89dc) \
_(VL_API_IPSEC_INTERFACE_ADD_DEL_SPD_REPLY, ipsec_interface_add_del_spd_reply, 977b7be9) \
_(VL_API_IPSEC_SPD_ADD_DEL_ENTRY, ipsec_spd_add_del_entry, d85e0ed5) \
_(VL_API_IPSEC_SPD_ADD_DEL_ENTRY_REPLY, ipsec_spd_add_del_entry_reply, f96c8b2d) \
_(VL_API_IPSEC_SAD_ADD_DEL_ENTRY, ipsec_sad_add_del_entry, 7d6709e1) \
_(VL_API_IPSEC_SAD_ADD_DEL_ENTRY_REPLY, ipsec_sad_add_del_entry_reply, 5cf382d8) \
_(VL_API_IPSEC_SA_SET_KEY, ipsec_sa_set_key, 99a67c60) \
_(VL_API_IPSEC_SA_SET_KEY_REPLY, ipsec_sa_set_key_reply, 5c5b7b46) \
_(VL_API_IKEV2_PROFILE_ADD_DEL, ikev2_profile_add_del, 37b6925c) \
_(VL_API_IKEV2_PROFILE_ADD_DEL_REPLY, ikev2_profile_add_del_reply, 7621f627) \
_(VL_API_IKEV2_PROFILE_SET_AUTH, ikev2_profile_set_auth, a0747739) \
_(VL_API_IKEV2_PROFILE_SET_AUTH_REPLY, ikev2_profile_set_auth_reply, 46083d00) \
_(VL_API_IKEV2_PROFILE_SET_ID, ikev2_profile_set_id, 0c2331dc) \
_(VL_API_IKEV2_PROFILE_SET_ID_REPLY, ikev2_profile_set_id_reply, 66803be5) \
_(VL_API_IKEV2_PROFILE_SET_TS, ikev2_profile_set_ts, 69587e0e) \
_(VL_API_IKEV2_PROFILE_SET_TS_REPLY, ikev2_profile_set_ts_reply, e1c33583) \
_(VL_API_IKEV2_SET_LOCAL_KEY, ikev2_set_local_key, a99b238a) \
_(VL_API_IKEV2_SET_LOCAL_KEY_REPLY, ikev2_set_local_key_reply, 8f7a80e0) \
_(VL_API_IKEV2_SET_RESPONDER, ikev2_set_responder, 519141b4) \
_(VL_API_IKEV2_SET_RESPONDER_REPLY, ikev2_set_responder_reply, 2f1a94d7) \
_(VL_API_IKEV2_SET_IKE_TRANSFORMS, ikev2_set_ike_transforms, f0bf018e) \
_(VL_API_IKEV2_SET_IKE_TRANSFORMS_REPLY, ikev2_set_ike_transforms_reply, 18883302) \
_(VL_API_IKEV2_SET_ESP_TRANSFORMS, ikev2_set_esp_transforms, dadd693a) \
_(VL_API_IKEV2_SET_ESP_TRANSFORMS_REPLY, ikev2_set_esp_transforms_reply, 9f3a1a67) \
_(VL_API_IKEV2_SET_SA_LIFETIME, ikev2_set_sa_lifetime, 61b715bf) \
_(VL_API_IKEV2_SET_SA_LIFETIME_REPLY, ikev2_set_sa_lifetime_reply, 7f73b9e3) \
_(VL_API_IKEV2_INITIATE_SA_INIT, ikev2_initiate_sa_init, 991b95f7) \
_(VL_API_IKEV2_INITIATE_SA_INIT_REPLY, ikev2_initiate_sa_init_reply, 66860cf0) \
_(VL_API_IKEV2_INITIATE_DEL_IKE_SA, ikev2_initiate_del_ike_sa, 2816f367) \
_(VL_API_IKEV2_INITIATE_DEL_IKE_SA_REPLY, ikev2_initiate_del_ike_sa_reply, a5df9a20) \
_(VL_API_IKEV2_INITIATE_DEL_CHILD_SA, ikev2_initiate_del_child_sa, 26eaba1d) \
_(VL_API_IKEV2_INITIATE_DEL_CHILD_SA_REPLY, ikev2_initiate_del_child_sa_reply, b31728ac) \
_(VL_API_IKEV2_INITIATE_REKEY_CHILD_SA, ikev2_initiate_rekey_child_sa, 48a0ad23) \
_(VL_API_IKEV2_INITIATE_REKEY_CHILD_SA_REPLY, ikev2_initiate_rekey_child_sa_reply, 7e5a8a19) \
_(VL_API_IPSEC_SPD_DUMP, ipsec_spd_dump, 5e9ae88e) \
_(VL_API_IPSEC_SPD_DETAILS, ipsec_spd_details, 6f7821b0) \
_(VL_API_IPSEC_TUNNEL_IF_ADD_DEL, ipsec_tunnel_if_add_del, 8218980f) \
_(VL_API_IPSEC_TUNNEL_IF_ADD_DEL_REPLY, ipsec_tunnel_if_add_del_reply, bf5ebd7c) 
#endif


/****** Typedefs *****/

#ifdef vl_typedefs

typedef VL_API_PACKED(struct _vl_api_ipsec_spd_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u32 spd_id;
}) vl_api_ipsec_spd_add_del_t;

typedef VL_API_PACKED(struct _vl_api_ipsec_spd_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_ipsec_spd_add_del_reply_t;

typedef VL_API_PACKED(struct _vl_api_ipsec_interface_add_del_spd {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u32 sw_if_index;
    u32 spd_id;
}) vl_api_ipsec_interface_add_del_spd_t;

typedef VL_API_PACKED(struct _vl_api_ipsec_interface_add_del_spd_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_ipsec_interface_add_del_spd_reply_t;

typedef VL_API_PACKED(struct _vl_api_ipsec_spd_add_del_entry {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u32 spd_id;
    i32 priority;
    u8 is_outbound;
    u8 is_ipv6;
    u8 is_ip_any;
    u8 remote_address_start[16];
    u8 remote_address_stop[16];
    u8 local_address_start[16];
    u8 local_address_stop[16];
    u8 protocol;
    u16 remote_port_start;
    u16 remote_port_stop;
    u16 local_port_start;
    u16 local_port_stop;
    u8 policy;
    u32 sa_id;
}) vl_api_ipsec_spd_add_del_entry_t;

typedef VL_API_PACKED(struct _vl_api_ipsec_spd_add_del_entry_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_ipsec_spd_add_del_entry_reply_t;

typedef VL_API_PACKED(struct _vl_api_ipsec_sad_add_del_entry {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u32 sad_id;
    u32 spi;
    u8 protocol;
    u8 crypto_algorithm;
    u8 crypto_key_length;
    u8 crypto_key[128];
    u8 integrity_algorithm;
    u8 integrity_key_length;
    u8 integrity_key[128];
    u8 use_extended_sequence_number;
    u8 is_tunnel;
    u8 is_tunnel_ipv6;
    u8 tunnel_src_address[16];
    u8 tunnel_dst_address[16];
}) vl_api_ipsec_sad_add_del_entry_t;

typedef VL_API_PACKED(struct _vl_api_ipsec_sad_add_del_entry_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_ipsec_sad_add_del_entry_reply_t;

typedef VL_API_PACKED(struct _vl_api_ipsec_sa_set_key {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sa_id;
    u8 crypto_key_length;
    u8 crypto_key[128];
    u8 integrity_key_length;
    u8 integrity_key[128];
}) vl_api_ipsec_sa_set_key_t;

typedef VL_API_PACKED(struct _vl_api_ipsec_sa_set_key_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_ipsec_sa_set_key_reply_t;

typedef VL_API_PACKED(struct _vl_api_ikev2_profile_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 name[64];
    u8 is_add;
}) vl_api_ikev2_profile_add_del_t;

typedef VL_API_PACKED(struct _vl_api_ikev2_profile_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_ikev2_profile_add_del_reply_t;

typedef VL_API_PACKED(struct _vl_api_ikev2_profile_set_auth {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 name[64];
    u8 auth_method;
    u8 is_hex;
    u32 data_len;
    u8 data[0];
}) vl_api_ikev2_profile_set_auth_t;

typedef VL_API_PACKED(struct _vl_api_ikev2_profile_set_auth_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_ikev2_profile_set_auth_reply_t;

typedef VL_API_PACKED(struct _vl_api_ikev2_profile_set_id {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 name[64];
    u8 is_local;
    u8 id_type;
    u32 data_len;
    u8 data[0];
}) vl_api_ikev2_profile_set_id_t;

typedef VL_API_PACKED(struct _vl_api_ikev2_profile_set_id_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_ikev2_profile_set_id_reply_t;

typedef VL_API_PACKED(struct _vl_api_ikev2_profile_set_ts {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 name[64];
    u8 is_local;
    u8 proto;
    u16 start_port;
    u16 end_port;
    u32 start_addr;
    u32 end_addr;
}) vl_api_ikev2_profile_set_ts_t;

typedef VL_API_PACKED(struct _vl_api_ikev2_profile_set_ts_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_ikev2_profile_set_ts_reply_t;

typedef VL_API_PACKED(struct _vl_api_ikev2_set_local_key {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 key_file[256];
}) vl_api_ikev2_set_local_key_t;

typedef VL_API_PACKED(struct _vl_api_ikev2_set_local_key_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_ikev2_set_local_key_reply_t;

typedef VL_API_PACKED(struct _vl_api_ikev2_set_responder {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 name[64];
    u32 sw_if_index;
    u8 address[4];
}) vl_api_ikev2_set_responder_t;

typedef VL_API_PACKED(struct _vl_api_ikev2_set_responder_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_ikev2_set_responder_reply_t;

typedef VL_API_PACKED(struct _vl_api_ikev2_set_ike_transforms {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 name[64];
    u32 crypto_alg;
    u32 crypto_key_size;
    u32 integ_alg;
    u32 dh_group;
}) vl_api_ikev2_set_ike_transforms_t;

typedef VL_API_PACKED(struct _vl_api_ikev2_set_ike_transforms_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_ikev2_set_ike_transforms_reply_t;

typedef VL_API_PACKED(struct _vl_api_ikev2_set_esp_transforms {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 name[64];
    u32 crypto_alg;
    u32 crypto_key_size;
    u32 integ_alg;
    u32 dh_group;
}) vl_api_ikev2_set_esp_transforms_t;

typedef VL_API_PACKED(struct _vl_api_ikev2_set_esp_transforms_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_ikev2_set_esp_transforms_reply_t;

typedef VL_API_PACKED(struct _vl_api_ikev2_set_sa_lifetime {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 name[64];
    u64 lifetime;
    u32 lifetime_jitter;
    u32 handover;
    u64 lifetime_maxdata;
}) vl_api_ikev2_set_sa_lifetime_t;

typedef VL_API_PACKED(struct _vl_api_ikev2_set_sa_lifetime_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_ikev2_set_sa_lifetime_reply_t;

typedef VL_API_PACKED(struct _vl_api_ikev2_initiate_sa_init {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 name[64];
}) vl_api_ikev2_initiate_sa_init_t;

typedef VL_API_PACKED(struct _vl_api_ikev2_initiate_sa_init_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_ikev2_initiate_sa_init_reply_t;

typedef VL_API_PACKED(struct _vl_api_ikev2_initiate_del_ike_sa {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u64 ispi;
}) vl_api_ikev2_initiate_del_ike_sa_t;

typedef VL_API_PACKED(struct _vl_api_ikev2_initiate_del_ike_sa_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_ikev2_initiate_del_ike_sa_reply_t;

typedef VL_API_PACKED(struct _vl_api_ikev2_initiate_del_child_sa {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 ispi;
}) vl_api_ikev2_initiate_del_child_sa_t;

typedef VL_API_PACKED(struct _vl_api_ikev2_initiate_del_child_sa_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_ikev2_initiate_del_child_sa_reply_t;

typedef VL_API_PACKED(struct _vl_api_ikev2_initiate_rekey_child_sa {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 ispi;
}) vl_api_ikev2_initiate_rekey_child_sa_t;

typedef VL_API_PACKED(struct _vl_api_ikev2_initiate_rekey_child_sa_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_ikev2_initiate_rekey_child_sa_reply_t;

typedef VL_API_PACKED(struct _vl_api_ipsec_spd_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 spd_id;
    u32 sa_id;
}) vl_api_ipsec_spd_dump_t;

typedef VL_API_PACKED(struct _vl_api_ipsec_spd_details {
    u16 _vl_msg_id;
    u32 context;
    u32 spd_id;
    i32 priority;
    u8 is_outbound;
    u8 is_ipv6;
    u8 local_start_addr[16];
    u8 local_stop_addr[16];
    u16 local_start_port;
    u16 local_stop_port;
    u8 remote_start_addr[16];
    u8 remote_stop_addr[16];
    u16 remote_start_port;
    u16 remote_stop_port;
    u8 protocol;
    u8 policy;
    u32 sa_id;
    u64 bytes;
    u64 packets;
}) vl_api_ipsec_spd_details_t;

typedef VL_API_PACKED(struct _vl_api_ipsec_tunnel_if_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 esn;
    u8 anti_replay;
    u8 local_ip[4];
    u8 remote_ip[4];
    u32 local_spi;
    u32 remote_spi;
    u8 crypto_alg;
    u8 local_crypto_key_len;
    u8 local_crypto_key[128];
    u8 remote_crypto_key_len;
    u8 remote_crypto_key[128];
    u8 integ_alg;
    u8 local_integ_key_len;
    u8 local_integ_key[128];
    u8 remote_integ_key_len;
    u8 remote_integ_key[128];
}) vl_api_ipsec_tunnel_if_add_del_t;

typedef VL_API_PACKED(struct _vl_api_ipsec_tunnel_if_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 sw_if_index;
}) vl_api_ipsec_tunnel_if_add_del_reply_t;

#endif /* vl_typedefs */

/****** Discriminated Union Definitions *****/

#ifdef vl_union_id


#endif /* vl_union_id */

/****** Print functions *****/

#ifdef vl_printfun

#ifdef LP64
#define _uword_fmt "%lld"
#define _uword_cast (long long)
#else
#define _uword_fmt "%ld"
#define _uword_cast long
#endif

static inline void *vl_api_ipsec_spd_add_del_t_print (vl_api_ipsec_spd_add_del_t *a,void *handle)
{
    vl_print(handle, "vl_api_ipsec_spd_add_del_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "spd_id: %u\n", (unsigned) a->spd_id);
    return handle;
}

static inline void *vl_api_ipsec_spd_add_del_reply_t_print (vl_api_ipsec_spd_add_del_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_ipsec_spd_add_del_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_ipsec_interface_add_del_spd_t_print (vl_api_ipsec_interface_add_del_spd_t *a,void *handle)
{
    vl_print(handle, "vl_api_ipsec_interface_add_del_spd_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "spd_id: %u\n", (unsigned) a->spd_id);
    return handle;
}

static inline void *vl_api_ipsec_interface_add_del_spd_reply_t_print (vl_api_ipsec_interface_add_del_spd_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_ipsec_interface_add_del_spd_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_ipsec_spd_add_del_entry_t_print (vl_api_ipsec_spd_add_del_entry_t *a,void *handle)
{
    vl_print(handle, "vl_api_ipsec_spd_add_del_entry_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "spd_id: %u\n", (unsigned) a->spd_id);
    vl_print(handle, "priority: %ld\n", (long) a->priority);
    vl_print(handle, "is_outbound: %u\n", (unsigned) a->is_outbound);
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    vl_print(handle, "is_ip_any: %u\n", (unsigned) a->is_ip_any);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "remote_address_start[%d]: %u\n", _i, a->remote_address_start[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "remote_address_stop[%d]: %u\n", _i, a->remote_address_stop[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "local_address_start[%d]: %u\n", _i, a->local_address_start[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "local_address_stop[%d]: %u\n", _i, a->local_address_stop[_i]);
        }
    }
    vl_print(handle, "protocol: %u\n", (unsigned) a->protocol);
    vl_print(handle, "remote_port_start: %u\n", (unsigned) a->remote_port_start);
    vl_print(handle, "remote_port_stop: %u\n", (unsigned) a->remote_port_stop);
    vl_print(handle, "local_port_start: %u\n", (unsigned) a->local_port_start);
    vl_print(handle, "local_port_stop: %u\n", (unsigned) a->local_port_stop);
    vl_print(handle, "policy: %u\n", (unsigned) a->policy);
    vl_print(handle, "sa_id: %u\n", (unsigned) a->sa_id);
    return handle;
}

static inline void *vl_api_ipsec_spd_add_del_entry_reply_t_print (vl_api_ipsec_spd_add_del_entry_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_ipsec_spd_add_del_entry_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_ipsec_sad_add_del_entry_t_print (vl_api_ipsec_sad_add_del_entry_t *a,void *handle)
{
    vl_print(handle, "vl_api_ipsec_sad_add_del_entry_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "sad_id: %u\n", (unsigned) a->sad_id);
    vl_print(handle, "spi: %u\n", (unsigned) a->spi);
    vl_print(handle, "protocol: %u\n", (unsigned) a->protocol);
    vl_print(handle, "crypto_algorithm: %u\n", (unsigned) a->crypto_algorithm);
    vl_print(handle, "crypto_key_length: %u\n", (unsigned) a->crypto_key_length);
    {
        int _i;
        for (_i = 0; _i < 128; _i++) {
            vl_print(handle, "crypto_key[%d]: %u\n", _i, a->crypto_key[_i]);
        }
    }
    vl_print(handle, "integrity_algorithm: %u\n", (unsigned) a->integrity_algorithm);
    vl_print(handle, "integrity_key_length: %u\n", (unsigned) a->integrity_key_length);
    {
        int _i;
        for (_i = 0; _i < 128; _i++) {
            vl_print(handle, "integrity_key[%d]: %u\n", _i, a->integrity_key[_i]);
        }
    }
    vl_print(handle, "use_extended_sequence_number: %u\n", (unsigned) a->use_extended_sequence_number);
    vl_print(handle, "is_tunnel: %u\n", (unsigned) a->is_tunnel);
    vl_print(handle, "is_tunnel_ipv6: %u\n", (unsigned) a->is_tunnel_ipv6);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "tunnel_src_address[%d]: %u\n", _i, a->tunnel_src_address[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "tunnel_dst_address[%d]: %u\n", _i, a->tunnel_dst_address[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_ipsec_sad_add_del_entry_reply_t_print (vl_api_ipsec_sad_add_del_entry_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_ipsec_sad_add_del_entry_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_ipsec_sa_set_key_t_print (vl_api_ipsec_sa_set_key_t *a,void *handle)
{
    vl_print(handle, "vl_api_ipsec_sa_set_key_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sa_id: %u\n", (unsigned) a->sa_id);
    vl_print(handle, "crypto_key_length: %u\n", (unsigned) a->crypto_key_length);
    {
        int _i;
        for (_i = 0; _i < 128; _i++) {
            vl_print(handle, "crypto_key[%d]: %u\n", _i, a->crypto_key[_i]);
        }
    }
    vl_print(handle, "integrity_key_length: %u\n", (unsigned) a->integrity_key_length);
    {
        int _i;
        for (_i = 0; _i < 128; _i++) {
            vl_print(handle, "integrity_key[%d]: %u\n", _i, a->integrity_key[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_ipsec_sa_set_key_reply_t_print (vl_api_ipsec_sa_set_key_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_ipsec_sa_set_key_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_ikev2_profile_add_del_t_print (vl_api_ikev2_profile_add_del_t *a,void *handle)
{
    vl_print(handle, "vl_api_ikev2_profile_add_del_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "name[%d]: %u\n", _i, a->name[_i]);
        }
    }
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    return handle;
}

static inline void *vl_api_ikev2_profile_add_del_reply_t_print (vl_api_ikev2_profile_add_del_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_ikev2_profile_add_del_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_ikev2_profile_set_auth_t_print (vl_api_ikev2_profile_set_auth_t *a,void *handle)
{
    vl_print(handle, "vl_api_ikev2_profile_set_auth_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "name[%d]: %u\n", _i, a->name[_i]);
        }
    }
    vl_print(handle, "auth_method: %u\n", (unsigned) a->auth_method);
    vl_print(handle, "is_hex: %u\n", (unsigned) a->is_hex);
    vl_print(handle, "data_len: %u\n", (unsigned) a->data_len);
    return handle;
}

static inline void *vl_api_ikev2_profile_set_auth_reply_t_print (vl_api_ikev2_profile_set_auth_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_ikev2_profile_set_auth_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_ikev2_profile_set_id_t_print (vl_api_ikev2_profile_set_id_t *a,void *handle)
{
    vl_print(handle, "vl_api_ikev2_profile_set_id_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "name[%d]: %u\n", _i, a->name[_i]);
        }
    }
    vl_print(handle, "is_local: %u\n", (unsigned) a->is_local);
    vl_print(handle, "id_type: %u\n", (unsigned) a->id_type);
    vl_print(handle, "data_len: %u\n", (unsigned) a->data_len);
    return handle;
}

static inline void *vl_api_ikev2_profile_set_id_reply_t_print (vl_api_ikev2_profile_set_id_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_ikev2_profile_set_id_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_ikev2_profile_set_ts_t_print (vl_api_ikev2_profile_set_ts_t *a,void *handle)
{
    vl_print(handle, "vl_api_ikev2_profile_set_ts_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "name[%d]: %u\n", _i, a->name[_i]);
        }
    }
    vl_print(handle, "is_local: %u\n", (unsigned) a->is_local);
    vl_print(handle, "proto: %u\n", (unsigned) a->proto);
    vl_print(handle, "start_port: %u\n", (unsigned) a->start_port);
    vl_print(handle, "end_port: %u\n", (unsigned) a->end_port);
    vl_print(handle, "start_addr: %u\n", (unsigned) a->start_addr);
    vl_print(handle, "end_addr: %u\n", (unsigned) a->end_addr);
    return handle;
}

static inline void *vl_api_ikev2_profile_set_ts_reply_t_print (vl_api_ikev2_profile_set_ts_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_ikev2_profile_set_ts_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_ikev2_set_local_key_t_print (vl_api_ikev2_set_local_key_t *a,void *handle)
{
    vl_print(handle, "vl_api_ikev2_set_local_key_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 256; _i++) {
            vl_print(handle, "key_file[%d]: %u\n", _i, a->key_file[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_ikev2_set_local_key_reply_t_print (vl_api_ikev2_set_local_key_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_ikev2_set_local_key_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_ikev2_set_responder_t_print (vl_api_ikev2_set_responder_t *a,void *handle)
{
    vl_print(handle, "vl_api_ikev2_set_responder_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "name[%d]: %u\n", _i, a->name[_i]);
        }
    }
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "address[%d]: %u\n", _i, a->address[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_ikev2_set_responder_reply_t_print (vl_api_ikev2_set_responder_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_ikev2_set_responder_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_ikev2_set_ike_transforms_t_print (vl_api_ikev2_set_ike_transforms_t *a,void *handle)
{
    vl_print(handle, "vl_api_ikev2_set_ike_transforms_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "name[%d]: %u\n", _i, a->name[_i]);
        }
    }
    vl_print(handle, "crypto_alg: %u\n", (unsigned) a->crypto_alg);
    vl_print(handle, "crypto_key_size: %u\n", (unsigned) a->crypto_key_size);
    vl_print(handle, "integ_alg: %u\n", (unsigned) a->integ_alg);
    vl_print(handle, "dh_group: %u\n", (unsigned) a->dh_group);
    return handle;
}

static inline void *vl_api_ikev2_set_ike_transforms_reply_t_print (vl_api_ikev2_set_ike_transforms_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_ikev2_set_ike_transforms_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_ikev2_set_esp_transforms_t_print (vl_api_ikev2_set_esp_transforms_t *a,void *handle)
{
    vl_print(handle, "vl_api_ikev2_set_esp_transforms_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "name[%d]: %u\n", _i, a->name[_i]);
        }
    }
    vl_print(handle, "crypto_alg: %u\n", (unsigned) a->crypto_alg);
    vl_print(handle, "crypto_key_size: %u\n", (unsigned) a->crypto_key_size);
    vl_print(handle, "integ_alg: %u\n", (unsigned) a->integ_alg);
    vl_print(handle, "dh_group: %u\n", (unsigned) a->dh_group);
    return handle;
}

static inline void *vl_api_ikev2_set_esp_transforms_reply_t_print (vl_api_ikev2_set_esp_transforms_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_ikev2_set_esp_transforms_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_ikev2_set_sa_lifetime_t_print (vl_api_ikev2_set_sa_lifetime_t *a,void *handle)
{
    vl_print(handle, "vl_api_ikev2_set_sa_lifetime_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "name[%d]: %u\n", _i, a->name[_i]);
        }
    }
    vl_print(handle, "lifetime: %llu\n", (long long) a->lifetime);
    vl_print(handle, "lifetime_jitter: %u\n", (unsigned) a->lifetime_jitter);
    vl_print(handle, "handover: %u\n", (unsigned) a->handover);
    vl_print(handle, "lifetime_maxdata: %llu\n", (long long) a->lifetime_maxdata);
    return handle;
}

static inline void *vl_api_ikev2_set_sa_lifetime_reply_t_print (vl_api_ikev2_set_sa_lifetime_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_ikev2_set_sa_lifetime_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_ikev2_initiate_sa_init_t_print (vl_api_ikev2_initiate_sa_init_t *a,void *handle)
{
    vl_print(handle, "vl_api_ikev2_initiate_sa_init_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "name[%d]: %u\n", _i, a->name[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_ikev2_initiate_sa_init_reply_t_print (vl_api_ikev2_initiate_sa_init_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_ikev2_initiate_sa_init_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_ikev2_initiate_del_ike_sa_t_print (vl_api_ikev2_initiate_del_ike_sa_t *a,void *handle)
{
    vl_print(handle, "vl_api_ikev2_initiate_del_ike_sa_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "ispi: %llu\n", (long long) a->ispi);
    return handle;
}

static inline void *vl_api_ikev2_initiate_del_ike_sa_reply_t_print (vl_api_ikev2_initiate_del_ike_sa_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_ikev2_initiate_del_ike_sa_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_ikev2_initiate_del_child_sa_t_print (vl_api_ikev2_initiate_del_child_sa_t *a,void *handle)
{
    vl_print(handle, "vl_api_ikev2_initiate_del_child_sa_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "ispi: %u\n", (unsigned) a->ispi);
    return handle;
}

static inline void *vl_api_ikev2_initiate_del_child_sa_reply_t_print (vl_api_ikev2_initiate_del_child_sa_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_ikev2_initiate_del_child_sa_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_ikev2_initiate_rekey_child_sa_t_print (vl_api_ikev2_initiate_rekey_child_sa_t *a,void *handle)
{
    vl_print(handle, "vl_api_ikev2_initiate_rekey_child_sa_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "ispi: %u\n", (unsigned) a->ispi);
    return handle;
}

static inline void *vl_api_ikev2_initiate_rekey_child_sa_reply_t_print (vl_api_ikev2_initiate_rekey_child_sa_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_ikev2_initiate_rekey_child_sa_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_ipsec_spd_dump_t_print (vl_api_ipsec_spd_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_ipsec_spd_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "spd_id: %u\n", (unsigned) a->spd_id);
    vl_print(handle, "sa_id: %u\n", (unsigned) a->sa_id);
    return handle;
}

static inline void *vl_api_ipsec_spd_details_t_print (vl_api_ipsec_spd_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_ipsec_spd_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "spd_id: %u\n", (unsigned) a->spd_id);
    vl_print(handle, "priority: %ld\n", (long) a->priority);
    vl_print(handle, "is_outbound: %u\n", (unsigned) a->is_outbound);
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "local_start_addr[%d]: %u\n", _i, a->local_start_addr[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "local_stop_addr[%d]: %u\n", _i, a->local_stop_addr[_i]);
        }
    }
    vl_print(handle, "local_start_port: %u\n", (unsigned) a->local_start_port);
    vl_print(handle, "local_stop_port: %u\n", (unsigned) a->local_stop_port);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "remote_start_addr[%d]: %u\n", _i, a->remote_start_addr[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "remote_stop_addr[%d]: %u\n", _i, a->remote_stop_addr[_i]);
        }
    }
    vl_print(handle, "remote_start_port: %u\n", (unsigned) a->remote_start_port);
    vl_print(handle, "remote_stop_port: %u\n", (unsigned) a->remote_stop_port);
    vl_print(handle, "protocol: %u\n", (unsigned) a->protocol);
    vl_print(handle, "policy: %u\n", (unsigned) a->policy);
    vl_print(handle, "sa_id: %u\n", (unsigned) a->sa_id);
    vl_print(handle, "bytes: %llu\n", (long long) a->bytes);
    vl_print(handle, "packets: %llu\n", (long long) a->packets);
    return handle;
}

static inline void *vl_api_ipsec_tunnel_if_add_del_t_print (vl_api_ipsec_tunnel_if_add_del_t *a,void *handle)
{
    vl_print(handle, "vl_api_ipsec_tunnel_if_add_del_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "esn: %u\n", (unsigned) a->esn);
    vl_print(handle, "anti_replay: %u\n", (unsigned) a->anti_replay);
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "local_ip[%d]: %u\n", _i, a->local_ip[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "remote_ip[%d]: %u\n", _i, a->remote_ip[_i]);
        }
    }
    vl_print(handle, "local_spi: %u\n", (unsigned) a->local_spi);
    vl_print(handle, "remote_spi: %u\n", (unsigned) a->remote_spi);
    vl_print(handle, "crypto_alg: %u\n", (unsigned) a->crypto_alg);
    vl_print(handle, "local_crypto_key_len: %u\n", (unsigned) a->local_crypto_key_len);
    {
        int _i;
        for (_i = 0; _i < 128; _i++) {
            vl_print(handle, "local_crypto_key[%d]: %u\n", _i, a->local_crypto_key[_i]);
        }
    }
    vl_print(handle, "remote_crypto_key_len: %u\n", (unsigned) a->remote_crypto_key_len);
    {
        int _i;
        for (_i = 0; _i < 128; _i++) {
            vl_print(handle, "remote_crypto_key[%d]: %u\n", _i, a->remote_crypto_key[_i]);
        }
    }
    vl_print(handle, "integ_alg: %u\n", (unsigned) a->integ_alg);
    vl_print(handle, "local_integ_key_len: %u\n", (unsigned) a->local_integ_key_len);
    {
        int _i;
        for (_i = 0; _i < 128; _i++) {
            vl_print(handle, "local_integ_key[%d]: %u\n", _i, a->local_integ_key[_i]);
        }
    }
    vl_print(handle, "remote_integ_key_len: %u\n", (unsigned) a->remote_integ_key_len);
    {
        int _i;
        for (_i = 0; _i < 128; _i++) {
            vl_print(handle, "remote_integ_key[%d]: %u\n", _i, a->remote_integ_key[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_ipsec_tunnel_if_add_del_reply_t_print (vl_api_ipsec_tunnel_if_add_del_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_ipsec_tunnel_if_add_del_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    return handle;
}

#endif /* vl_printfun */


/****** Endian swap functions *****/

#ifdef vl_endianfun

#undef clib_net_to_host_uword
#ifdef LP64
#define clib_net_to_host_uword clib_net_to_host_u64
#else
#define clib_net_to_host_uword clib_net_to_host_u32
#endif

static inline void vl_api_ipsec_spd_add_del_t_endian (vl_api_ipsec_spd_add_del_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    a->spd_id = clib_net_to_host_u32(a->spd_id);
}

static inline void vl_api_ipsec_spd_add_del_reply_t_endian (vl_api_ipsec_spd_add_del_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_ipsec_interface_add_del_spd_t_endian (vl_api_ipsec_interface_add_del_spd_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    a->spd_id = clib_net_to_host_u32(a->spd_id);
}

static inline void vl_api_ipsec_interface_add_del_spd_reply_t_endian (vl_api_ipsec_interface_add_del_spd_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_ipsec_spd_add_del_entry_t_endian (vl_api_ipsec_spd_add_del_entry_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    a->spd_id = clib_net_to_host_u32(a->spd_id);
    a->priority = clib_net_to_host_u32(a->priority);
    /* a->is_outbound = a->is_outbound (no-op) */
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    /* a->is_ip_any = a->is_ip_any (no-op) */
    /* a->remote_address_start[0..15] = a->remote_address_start[0..15] (no-op) */
    /* a->remote_address_stop[0..15] = a->remote_address_stop[0..15] (no-op) */
    /* a->local_address_start[0..15] = a->local_address_start[0..15] (no-op) */
    /* a->local_address_stop[0..15] = a->local_address_stop[0..15] (no-op) */
    /* a->protocol = a->protocol (no-op) */
    a->remote_port_start = clib_net_to_host_u16(a->remote_port_start);
    a->remote_port_stop = clib_net_to_host_u16(a->remote_port_stop);
    a->local_port_start = clib_net_to_host_u16(a->local_port_start);
    a->local_port_stop = clib_net_to_host_u16(a->local_port_stop);
    /* a->policy = a->policy (no-op) */
    a->sa_id = clib_net_to_host_u32(a->sa_id);
}

static inline void vl_api_ipsec_spd_add_del_entry_reply_t_endian (vl_api_ipsec_spd_add_del_entry_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_ipsec_sad_add_del_entry_t_endian (vl_api_ipsec_sad_add_del_entry_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    a->sad_id = clib_net_to_host_u32(a->sad_id);
    a->spi = clib_net_to_host_u32(a->spi);
    /* a->protocol = a->protocol (no-op) */
    /* a->crypto_algorithm = a->crypto_algorithm (no-op) */
    /* a->crypto_key_length = a->crypto_key_length (no-op) */
    /* a->crypto_key[0..127] = a->crypto_key[0..127] (no-op) */
    /* a->integrity_algorithm = a->integrity_algorithm (no-op) */
    /* a->integrity_key_length = a->integrity_key_length (no-op) */
    /* a->integrity_key[0..127] = a->integrity_key[0..127] (no-op) */
    /* a->use_extended_sequence_number = a->use_extended_sequence_number (no-op) */
    /* a->is_tunnel = a->is_tunnel (no-op) */
    /* a->is_tunnel_ipv6 = a->is_tunnel_ipv6 (no-op) */
    /* a->tunnel_src_address[0..15] = a->tunnel_src_address[0..15] (no-op) */
    /* a->tunnel_dst_address[0..15] = a->tunnel_dst_address[0..15] (no-op) */
}

static inline void vl_api_ipsec_sad_add_del_entry_reply_t_endian (vl_api_ipsec_sad_add_del_entry_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_ipsec_sa_set_key_t_endian (vl_api_ipsec_sa_set_key_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sa_id = clib_net_to_host_u32(a->sa_id);
    /* a->crypto_key_length = a->crypto_key_length (no-op) */
    /* a->crypto_key[0..127] = a->crypto_key[0..127] (no-op) */
    /* a->integrity_key_length = a->integrity_key_length (no-op) */
    /* a->integrity_key[0..127] = a->integrity_key[0..127] (no-op) */
}

static inline void vl_api_ipsec_sa_set_key_reply_t_endian (vl_api_ipsec_sa_set_key_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_ikev2_profile_add_del_t_endian (vl_api_ikev2_profile_add_del_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->name[0..63] = a->name[0..63] (no-op) */
    /* a->is_add = a->is_add (no-op) */
}

static inline void vl_api_ikev2_profile_add_del_reply_t_endian (vl_api_ikev2_profile_add_del_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_ikev2_profile_set_auth_t_endian (vl_api_ikev2_profile_set_auth_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->name[0..63] = a->name[0..63] (no-op) */
    /* a->auth_method = a->auth_method (no-op) */
    /* a->is_hex = a->is_hex (no-op) */
    a->data_len = clib_net_to_host_u32(a->data_len);
}

static inline void vl_api_ikev2_profile_set_auth_reply_t_endian (vl_api_ikev2_profile_set_auth_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_ikev2_profile_set_id_t_endian (vl_api_ikev2_profile_set_id_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->name[0..63] = a->name[0..63] (no-op) */
    /* a->is_local = a->is_local (no-op) */
    /* a->id_type = a->id_type (no-op) */
    a->data_len = clib_net_to_host_u32(a->data_len);
}

static inline void vl_api_ikev2_profile_set_id_reply_t_endian (vl_api_ikev2_profile_set_id_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_ikev2_profile_set_ts_t_endian (vl_api_ikev2_profile_set_ts_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->name[0..63] = a->name[0..63] (no-op) */
    /* a->is_local = a->is_local (no-op) */
    /* a->proto = a->proto (no-op) */
    a->start_port = clib_net_to_host_u16(a->start_port);
    a->end_port = clib_net_to_host_u16(a->end_port);
    a->start_addr = clib_net_to_host_u32(a->start_addr);
    a->end_addr = clib_net_to_host_u32(a->end_addr);
}

static inline void vl_api_ikev2_profile_set_ts_reply_t_endian (vl_api_ikev2_profile_set_ts_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_ikev2_set_local_key_t_endian (vl_api_ikev2_set_local_key_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->key_file[0..255] = a->key_file[0..255] (no-op) */
}

static inline void vl_api_ikev2_set_local_key_reply_t_endian (vl_api_ikev2_set_local_key_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_ikev2_set_responder_t_endian (vl_api_ikev2_set_responder_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->name[0..63] = a->name[0..63] (no-op) */
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->address[0..3] = a->address[0..3] (no-op) */
}

static inline void vl_api_ikev2_set_responder_reply_t_endian (vl_api_ikev2_set_responder_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_ikev2_set_ike_transforms_t_endian (vl_api_ikev2_set_ike_transforms_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->name[0..63] = a->name[0..63] (no-op) */
    a->crypto_alg = clib_net_to_host_u32(a->crypto_alg);
    a->crypto_key_size = clib_net_to_host_u32(a->crypto_key_size);
    a->integ_alg = clib_net_to_host_u32(a->integ_alg);
    a->dh_group = clib_net_to_host_u32(a->dh_group);
}

static inline void vl_api_ikev2_set_ike_transforms_reply_t_endian (vl_api_ikev2_set_ike_transforms_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_ikev2_set_esp_transforms_t_endian (vl_api_ikev2_set_esp_transforms_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->name[0..63] = a->name[0..63] (no-op) */
    a->crypto_alg = clib_net_to_host_u32(a->crypto_alg);
    a->crypto_key_size = clib_net_to_host_u32(a->crypto_key_size);
    a->integ_alg = clib_net_to_host_u32(a->integ_alg);
    a->dh_group = clib_net_to_host_u32(a->dh_group);
}

static inline void vl_api_ikev2_set_esp_transforms_reply_t_endian (vl_api_ikev2_set_esp_transforms_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_ikev2_set_sa_lifetime_t_endian (vl_api_ikev2_set_sa_lifetime_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->name[0..63] = a->name[0..63] (no-op) */
    a->lifetime = clib_net_to_host_u64(a->lifetime);
    a->lifetime_jitter = clib_net_to_host_u32(a->lifetime_jitter);
    a->handover = clib_net_to_host_u32(a->handover);
    a->lifetime_maxdata = clib_net_to_host_u64(a->lifetime_maxdata);
}

static inline void vl_api_ikev2_set_sa_lifetime_reply_t_endian (vl_api_ikev2_set_sa_lifetime_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_ikev2_initiate_sa_init_t_endian (vl_api_ikev2_initiate_sa_init_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->name[0..63] = a->name[0..63] (no-op) */
}

static inline void vl_api_ikev2_initiate_sa_init_reply_t_endian (vl_api_ikev2_initiate_sa_init_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_ikev2_initiate_del_ike_sa_t_endian (vl_api_ikev2_initiate_del_ike_sa_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->ispi = clib_net_to_host_u64(a->ispi);
}

static inline void vl_api_ikev2_initiate_del_ike_sa_reply_t_endian (vl_api_ikev2_initiate_del_ike_sa_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_ikev2_initiate_del_child_sa_t_endian (vl_api_ikev2_initiate_del_child_sa_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->ispi = clib_net_to_host_u32(a->ispi);
}

static inline void vl_api_ikev2_initiate_del_child_sa_reply_t_endian (vl_api_ikev2_initiate_del_child_sa_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_ikev2_initiate_rekey_child_sa_t_endian (vl_api_ikev2_initiate_rekey_child_sa_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->ispi = clib_net_to_host_u32(a->ispi);
}

static inline void vl_api_ikev2_initiate_rekey_child_sa_reply_t_endian (vl_api_ikev2_initiate_rekey_child_sa_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_ipsec_spd_dump_t_endian (vl_api_ipsec_spd_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->spd_id = clib_net_to_host_u32(a->spd_id);
    a->sa_id = clib_net_to_host_u32(a->sa_id);
}

static inline void vl_api_ipsec_spd_details_t_endian (vl_api_ipsec_spd_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->spd_id = clib_net_to_host_u32(a->spd_id);
    a->priority = clib_net_to_host_u32(a->priority);
    /* a->is_outbound = a->is_outbound (no-op) */
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    /* a->local_start_addr[0..15] = a->local_start_addr[0..15] (no-op) */
    /* a->local_stop_addr[0..15] = a->local_stop_addr[0..15] (no-op) */
    a->local_start_port = clib_net_to_host_u16(a->local_start_port);
    a->local_stop_port = clib_net_to_host_u16(a->local_stop_port);
    /* a->remote_start_addr[0..15] = a->remote_start_addr[0..15] (no-op) */
    /* a->remote_stop_addr[0..15] = a->remote_stop_addr[0..15] (no-op) */
    a->remote_start_port = clib_net_to_host_u16(a->remote_start_port);
    a->remote_stop_port = clib_net_to_host_u16(a->remote_stop_port);
    /* a->protocol = a->protocol (no-op) */
    /* a->policy = a->policy (no-op) */
    a->sa_id = clib_net_to_host_u32(a->sa_id);
    a->bytes = clib_net_to_host_u64(a->bytes);
    a->packets = clib_net_to_host_u64(a->packets);
}

static inline void vl_api_ipsec_tunnel_if_add_del_t_endian (vl_api_ipsec_tunnel_if_add_del_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    /* a->esn = a->esn (no-op) */
    /* a->anti_replay = a->anti_replay (no-op) */
    /* a->local_ip[0..3] = a->local_ip[0..3] (no-op) */
    /* a->remote_ip[0..3] = a->remote_ip[0..3] (no-op) */
    a->local_spi = clib_net_to_host_u32(a->local_spi);
    a->remote_spi = clib_net_to_host_u32(a->remote_spi);
    /* a->crypto_alg = a->crypto_alg (no-op) */
    /* a->local_crypto_key_len = a->local_crypto_key_len (no-op) */
    /* a->local_crypto_key[0..127] = a->local_crypto_key[0..127] (no-op) */
    /* a->remote_crypto_key_len = a->remote_crypto_key_len (no-op) */
    /* a->remote_crypto_key[0..127] = a->remote_crypto_key[0..127] (no-op) */
    /* a->integ_alg = a->integ_alg (no-op) */
    /* a->local_integ_key_len = a->local_integ_key_len (no-op) */
    /* a->local_integ_key[0..127] = a->local_integ_key[0..127] (no-op) */
    /* a->remote_integ_key_len = a->remote_integ_key_len (no-op) */
    /* a->remote_integ_key[0..127] = a->remote_integ_key[0..127] (no-op) */
}

static inline void vl_api_ipsec_tunnel_if_add_del_reply_t_endian (vl_api_ipsec_tunnel_if_add_del_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
}

#endif /* vl_endianfun */


#ifdef vl_api_version
vl_api_version(ipsec.api, 0x27171243)

#endif

