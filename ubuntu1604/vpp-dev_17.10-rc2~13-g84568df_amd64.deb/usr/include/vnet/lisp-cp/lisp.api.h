/*
 * VLIB API definitions Mon Oct 30 07:35:18 2017
 * Input file: vnet/lisp-cp/lisp.api.h
 * Automatically generated: please edit the input file NOT this file!
 */

#if defined(vl_msg_id)||defined(vl_union_id)||defined(vl_printfun) \
 ||defined(vl_endianfun)|| defined(vl_api_version)||defined(vl_typedefs) \
 ||defined(vl_msg_name)||defined(vl_msg_name_crc_list)
/* ok, something was selected */
#else
#warning no content included from vnet/lisp-cp/lisp.api.h
#endif

#define VL_API_PACKED(x) x __attribute__ ((packed))


/****** Message ID / handler enum ******/

#ifdef vl_msg_id
/* typeonly: local_locator */
vl_msg_id(VL_API_LISP_ADD_DEL_LOCATOR_SET, vl_api_lisp_add_del_locator_set_t_handler)
vl_msg_id(VL_API_LISP_ADD_DEL_LOCATOR_SET_REPLY, vl_api_lisp_add_del_locator_set_reply_t_handler)
vl_msg_id(VL_API_LISP_ADD_DEL_LOCATOR, vl_api_lisp_add_del_locator_t_handler)
vl_msg_id(VL_API_LISP_ADD_DEL_LOCATOR_REPLY, vl_api_lisp_add_del_locator_reply_t_handler)
vl_msg_id(VL_API_LISP_ADD_DEL_LOCAL_EID, vl_api_lisp_add_del_local_eid_t_handler)
vl_msg_id(VL_API_LISP_ADD_DEL_LOCAL_EID_REPLY, vl_api_lisp_add_del_local_eid_reply_t_handler)
vl_msg_id(VL_API_LISP_ADD_DEL_MAP_SERVER, vl_api_lisp_add_del_map_server_t_handler)
vl_msg_id(VL_API_LISP_ADD_DEL_MAP_SERVER_REPLY, vl_api_lisp_add_del_map_server_reply_t_handler)
vl_msg_id(VL_API_LISP_ADD_DEL_MAP_RESOLVER, vl_api_lisp_add_del_map_resolver_t_handler)
vl_msg_id(VL_API_LISP_ADD_DEL_MAP_RESOLVER_REPLY, vl_api_lisp_add_del_map_resolver_reply_t_handler)
vl_msg_id(VL_API_LISP_ENABLE_DISABLE, vl_api_lisp_enable_disable_t_handler)
vl_msg_id(VL_API_LISP_ENABLE_DISABLE_REPLY, vl_api_lisp_enable_disable_reply_t_handler)
vl_msg_id(VL_API_LISP_PITR_SET_LOCATOR_SET, vl_api_lisp_pitr_set_locator_set_t_handler)
vl_msg_id(VL_API_LISP_PITR_SET_LOCATOR_SET_REPLY, vl_api_lisp_pitr_set_locator_set_reply_t_handler)
vl_msg_id(VL_API_LISP_USE_PETR, vl_api_lisp_use_petr_t_handler)
vl_msg_id(VL_API_LISP_USE_PETR_REPLY, vl_api_lisp_use_petr_reply_t_handler)
vl_msg_id(VL_API_SHOW_LISP_USE_PETR, vl_api_show_lisp_use_petr_t_handler)
vl_msg_id(VL_API_SHOW_LISP_USE_PETR_REPLY, vl_api_show_lisp_use_petr_reply_t_handler)
vl_msg_id(VL_API_SHOW_LISP_RLOC_PROBE_STATE, vl_api_show_lisp_rloc_probe_state_t_handler)
vl_msg_id(VL_API_SHOW_LISP_RLOC_PROBE_STATE_REPLY, vl_api_show_lisp_rloc_probe_state_reply_t_handler)
vl_msg_id(VL_API_LISP_RLOC_PROBE_ENABLE_DISABLE, vl_api_lisp_rloc_probe_enable_disable_t_handler)
vl_msg_id(VL_API_LISP_RLOC_PROBE_ENABLE_DISABLE_REPLY, vl_api_lisp_rloc_probe_enable_disable_reply_t_handler)
vl_msg_id(VL_API_LISP_MAP_REGISTER_ENABLE_DISABLE, vl_api_lisp_map_register_enable_disable_t_handler)
vl_msg_id(VL_API_LISP_MAP_REGISTER_ENABLE_DISABLE_REPLY, vl_api_lisp_map_register_enable_disable_reply_t_handler)
vl_msg_id(VL_API_SHOW_LISP_MAP_REGISTER_STATE, vl_api_show_lisp_map_register_state_t_handler)
vl_msg_id(VL_API_SHOW_LISP_MAP_REGISTER_STATE_REPLY, vl_api_show_lisp_map_register_state_reply_t_handler)
vl_msg_id(VL_API_LISP_MAP_REQUEST_MODE, vl_api_lisp_map_request_mode_t_handler)
vl_msg_id(VL_API_LISP_MAP_REQUEST_MODE_REPLY, vl_api_lisp_map_request_mode_reply_t_handler)
vl_msg_id(VL_API_SHOW_LISP_MAP_REQUEST_MODE, vl_api_show_lisp_map_request_mode_t_handler)
vl_msg_id(VL_API_SHOW_LISP_MAP_REQUEST_MODE_REPLY, vl_api_show_lisp_map_request_mode_reply_t_handler)
/* typeonly: remote_locator */
vl_msg_id(VL_API_LISP_ADD_DEL_REMOTE_MAPPING, vl_api_lisp_add_del_remote_mapping_t_handler)
vl_msg_id(VL_API_LISP_ADD_DEL_REMOTE_MAPPING_REPLY, vl_api_lisp_add_del_remote_mapping_reply_t_handler)
vl_msg_id(VL_API_LISP_ADD_DEL_ADJACENCY, vl_api_lisp_add_del_adjacency_t_handler)
vl_msg_id(VL_API_LISP_ADD_DEL_ADJACENCY_REPLY, vl_api_lisp_add_del_adjacency_reply_t_handler)
vl_msg_id(VL_API_LISP_ADD_DEL_MAP_REQUEST_ITR_RLOCS, vl_api_lisp_add_del_map_request_itr_rlocs_t_handler)
vl_msg_id(VL_API_LISP_ADD_DEL_MAP_REQUEST_ITR_RLOCS_REPLY, vl_api_lisp_add_del_map_request_itr_rlocs_reply_t_handler)
vl_msg_id(VL_API_LISP_EID_TABLE_ADD_DEL_MAP, vl_api_lisp_eid_table_add_del_map_t_handler)
vl_msg_id(VL_API_LISP_EID_TABLE_ADD_DEL_MAP_REPLY, vl_api_lisp_eid_table_add_del_map_reply_t_handler)
vl_msg_id(VL_API_LISP_LOCATOR_DUMP, vl_api_lisp_locator_dump_t_handler)
vl_msg_id(VL_API_LISP_LOCATOR_DETAILS, vl_api_lisp_locator_details_t_handler)
vl_msg_id(VL_API_LISP_LOCATOR_SET_DETAILS, vl_api_lisp_locator_set_details_t_handler)
vl_msg_id(VL_API_LISP_LOCATOR_SET_DUMP, vl_api_lisp_locator_set_dump_t_handler)
vl_msg_id(VL_API_LISP_EID_TABLE_DETAILS, vl_api_lisp_eid_table_details_t_handler)
vl_msg_id(VL_API_LISP_EID_TABLE_DUMP, vl_api_lisp_eid_table_dump_t_handler)
/* typeonly: lisp_adjacency */
vl_msg_id(VL_API_LISP_ADJACENCIES_GET_REPLY, vl_api_lisp_adjacencies_get_reply_t_handler)
vl_msg_id(VL_API_LISP_ADJACENCIES_GET, vl_api_lisp_adjacencies_get_t_handler)
vl_msg_id(VL_API_LISP_EID_TABLE_MAP_DETAILS, vl_api_lisp_eid_table_map_details_t_handler)
vl_msg_id(VL_API_LISP_EID_TABLE_MAP_DUMP, vl_api_lisp_eid_table_map_dump_t_handler)
vl_msg_id(VL_API_LISP_EID_TABLE_VNI_DUMP, vl_api_lisp_eid_table_vni_dump_t_handler)
vl_msg_id(VL_API_LISP_EID_TABLE_VNI_DETAILS, vl_api_lisp_eid_table_vni_details_t_handler)
vl_msg_id(VL_API_LISP_MAP_RESOLVER_DETAILS, vl_api_lisp_map_resolver_details_t_handler)
vl_msg_id(VL_API_LISP_MAP_RESOLVER_DUMP, vl_api_lisp_map_resolver_dump_t_handler)
vl_msg_id(VL_API_LISP_MAP_SERVER_DETAILS, vl_api_lisp_map_server_details_t_handler)
vl_msg_id(VL_API_LISP_MAP_SERVER_DUMP, vl_api_lisp_map_server_dump_t_handler)
vl_msg_id(VL_API_SHOW_LISP_STATUS, vl_api_show_lisp_status_t_handler)
vl_msg_id(VL_API_SHOW_LISP_STATUS_REPLY, vl_api_show_lisp_status_reply_t_handler)
vl_msg_id(VL_API_LISP_GET_MAP_REQUEST_ITR_RLOCS, vl_api_lisp_get_map_request_itr_rlocs_t_handler)
vl_msg_id(VL_API_LISP_GET_MAP_REQUEST_ITR_RLOCS_REPLY, vl_api_lisp_get_map_request_itr_rlocs_reply_t_handler)
vl_msg_id(VL_API_SHOW_LISP_PITR, vl_api_show_lisp_pitr_t_handler)
vl_msg_id(VL_API_SHOW_LISP_PITR_REPLY, vl_api_show_lisp_pitr_reply_t_handler)
#endif

/****** Message names ******/

#ifdef vl_msg_name
/* typeonly: local_locator */
vl_msg_name(vl_api_lisp_add_del_locator_set_t, 1)
vl_msg_name(vl_api_lisp_add_del_locator_set_reply_t, 1)
vl_msg_name(vl_api_lisp_add_del_locator_t, 1)
vl_msg_name(vl_api_lisp_add_del_locator_reply_t, 1)
vl_msg_name(vl_api_lisp_add_del_local_eid_t, 1)
vl_msg_name(vl_api_lisp_add_del_local_eid_reply_t, 1)
vl_msg_name(vl_api_lisp_add_del_map_server_t, 1)
vl_msg_name(vl_api_lisp_add_del_map_server_reply_t, 1)
vl_msg_name(vl_api_lisp_add_del_map_resolver_t, 1)
vl_msg_name(vl_api_lisp_add_del_map_resolver_reply_t, 1)
vl_msg_name(vl_api_lisp_enable_disable_t, 1)
vl_msg_name(vl_api_lisp_enable_disable_reply_t, 1)
vl_msg_name(vl_api_lisp_pitr_set_locator_set_t, 1)
vl_msg_name(vl_api_lisp_pitr_set_locator_set_reply_t, 1)
vl_msg_name(vl_api_lisp_use_petr_t, 1)
vl_msg_name(vl_api_lisp_use_petr_reply_t, 1)
vl_msg_name(vl_api_show_lisp_use_petr_t, 1)
vl_msg_name(vl_api_show_lisp_use_petr_reply_t, 1)
vl_msg_name(vl_api_show_lisp_rloc_probe_state_t, 1)
vl_msg_name(vl_api_show_lisp_rloc_probe_state_reply_t, 1)
vl_msg_name(vl_api_lisp_rloc_probe_enable_disable_t, 1)
vl_msg_name(vl_api_lisp_rloc_probe_enable_disable_reply_t, 1)
vl_msg_name(vl_api_lisp_map_register_enable_disable_t, 1)
vl_msg_name(vl_api_lisp_map_register_enable_disable_reply_t, 1)
vl_msg_name(vl_api_show_lisp_map_register_state_t, 1)
vl_msg_name(vl_api_show_lisp_map_register_state_reply_t, 1)
vl_msg_name(vl_api_lisp_map_request_mode_t, 1)
vl_msg_name(vl_api_lisp_map_request_mode_reply_t, 1)
vl_msg_name(vl_api_show_lisp_map_request_mode_t, 1)
vl_msg_name(vl_api_show_lisp_map_request_mode_reply_t, 1)
/* typeonly: remote_locator */
vl_msg_name(vl_api_lisp_add_del_remote_mapping_t, 1)
vl_msg_name(vl_api_lisp_add_del_remote_mapping_reply_t, 1)
vl_msg_name(vl_api_lisp_add_del_adjacency_t, 1)
vl_msg_name(vl_api_lisp_add_del_adjacency_reply_t, 1)
vl_msg_name(vl_api_lisp_add_del_map_request_itr_rlocs_t, 1)
vl_msg_name(vl_api_lisp_add_del_map_request_itr_rlocs_reply_t, 1)
vl_msg_name(vl_api_lisp_eid_table_add_del_map_t, 1)
vl_msg_name(vl_api_lisp_eid_table_add_del_map_reply_t, 1)
vl_msg_name(vl_api_lisp_locator_dump_t, 1)
vl_msg_name(vl_api_lisp_locator_details_t, 1)
vl_msg_name(vl_api_lisp_locator_set_details_t, 1)
vl_msg_name(vl_api_lisp_locator_set_dump_t, 1)
vl_msg_name(vl_api_lisp_eid_table_details_t, 1)
vl_msg_name(vl_api_lisp_eid_table_dump_t, 1)
/* typeonly: lisp_adjacency */
vl_msg_name(vl_api_lisp_adjacencies_get_reply_t, 1)
vl_msg_name(vl_api_lisp_adjacencies_get_t, 1)
vl_msg_name(vl_api_lisp_eid_table_map_details_t, 1)
vl_msg_name(vl_api_lisp_eid_table_map_dump_t, 1)
vl_msg_name(vl_api_lisp_eid_table_vni_dump_t, 1)
vl_msg_name(vl_api_lisp_eid_table_vni_details_t, 1)
vl_msg_name(vl_api_lisp_map_resolver_details_t, 1)
vl_msg_name(vl_api_lisp_map_resolver_dump_t, 1)
vl_msg_name(vl_api_lisp_map_server_details_t, 1)
vl_msg_name(vl_api_lisp_map_server_dump_t, 1)
vl_msg_name(vl_api_show_lisp_status_t, 1)
vl_msg_name(vl_api_show_lisp_status_reply_t, 1)
vl_msg_name(vl_api_lisp_get_map_request_itr_rlocs_t, 1)
vl_msg_name(vl_api_lisp_get_map_request_itr_rlocs_reply_t, 1)
vl_msg_name(vl_api_show_lisp_pitr_t, 1)
vl_msg_name(vl_api_show_lisp_pitr_reply_t, 1)
#endif


/****** Message name, crc list ******/

#ifdef vl_msg_name_crc_list
#define foreach_vl_msg_name_crc_lisp \
_(VL_API_LISP_ADD_DEL_LOCATOR_SET, lisp_add_del_locator_set, 25774ef4) \
_(VL_API_LISP_ADD_DEL_LOCATOR_SET_REPLY, lisp_add_del_locator_set_reply, c167cab1) \
_(VL_API_LISP_ADD_DEL_LOCATOR, lisp_add_del_locator, 442b7292) \
_(VL_API_LISP_ADD_DEL_LOCATOR_REPLY, lisp_add_del_locator_reply, 89ce7940) \
_(VL_API_LISP_ADD_DEL_LOCAL_EID, lisp_add_del_local_eid, c0af8d48) \
_(VL_API_LISP_ADD_DEL_LOCAL_EID_REPLY, lisp_add_del_local_eid_reply, d4860470) \
_(VL_API_LISP_ADD_DEL_MAP_SERVER, lisp_add_del_map_server, 592b70b3) \
_(VL_API_LISP_ADD_DEL_MAP_SERVER_REPLY, lisp_add_del_map_server_reply, 26f8f732) \
_(VL_API_LISP_ADD_DEL_MAP_RESOLVER, lisp_add_del_map_resolver, 1d0303ff) \
_(VL_API_LISP_ADD_DEL_MAP_RESOLVER_REPLY, lisp_add_del_map_resolver_reply, da4d72e0) \
_(VL_API_LISP_ENABLE_DISABLE, lisp_enable_disable, 6c27720f) \
_(VL_API_LISP_ENABLE_DISABLE_REPLY, lisp_enable_disable_reply, 36406c38) \
_(VL_API_LISP_PITR_SET_LOCATOR_SET, lisp_pitr_set_locator_set, 59fbff25) \
_(VL_API_LISP_PITR_SET_LOCATOR_SET_REPLY, lisp_pitr_set_locator_set_reply, 46d996c2) \
_(VL_API_LISP_USE_PETR, lisp_use_petr, 5b3f74b8) \
_(VL_API_LISP_USE_PETR_REPLY, lisp_use_petr_reply, 752b0f68) \
_(VL_API_SHOW_LISP_USE_PETR, show_lisp_use_petr, 69cf8a34) \
_(VL_API_SHOW_LISP_USE_PETR_REPLY, show_lisp_use_petr_reply, 8e9360a8) \
_(VL_API_SHOW_LISP_RLOC_PROBE_STATE, show_lisp_rloc_probe_state, c0b0f08b) \
_(VL_API_SHOW_LISP_RLOC_PROBE_STATE_REPLY, show_lisp_rloc_probe_state_reply, 23a1e712) \
_(VL_API_LISP_RLOC_PROBE_ENABLE_DISABLE, lisp_rloc_probe_enable_disable, 32c270ac) \
_(VL_API_LISP_RLOC_PROBE_ENABLE_DISABLE_REPLY, lisp_rloc_probe_enable_disable_reply, 97d05bc4) \
_(VL_API_LISP_MAP_REGISTER_ENABLE_DISABLE, lisp_map_register_enable_disable, 8d0a81ca) \
_(VL_API_LISP_MAP_REGISTER_ENABLE_DISABLE_REPLY, lisp_map_register_enable_disable_reply, 99e7a700) \
_(VL_API_SHOW_LISP_MAP_REGISTER_STATE, show_lisp_map_register_state, 55fc9581) \
_(VL_API_SHOW_LISP_MAP_REGISTER_STATE_REPLY, show_lisp_map_register_state_reply, 8d04052e) \
_(VL_API_LISP_MAP_REQUEST_MODE, lisp_map_request_mode, d204de7c) \
_(VL_API_LISP_MAP_REQUEST_MODE_REPLY, lisp_map_request_mode_reply, 930edf9f) \
_(VL_API_SHOW_LISP_MAP_REQUEST_MODE, show_lisp_map_request_mode, da78d18a) \
_(VL_API_SHOW_LISP_MAP_REQUEST_MODE_REPLY, show_lisp_map_request_mode_reply, ed3aadef) \
_(VL_API_LISP_ADD_DEL_REMOTE_MAPPING, lisp_add_del_remote_mapping, 833c53f9) \
_(VL_API_LISP_ADD_DEL_REMOTE_MAPPING_REPLY, lisp_add_del_remote_mapping_reply, 4cae72c9) \
_(VL_API_LISP_ADD_DEL_ADJACENCY, lisp_add_del_adjacency, 2bbefa02) \
_(VL_API_LISP_ADD_DEL_ADJACENCY_REPLY, lisp_add_del_adjacency_reply, 4628e1a8) \
_(VL_API_LISP_ADD_DEL_MAP_REQUEST_ITR_RLOCS, lisp_add_del_map_request_itr_rlocs, 3376a927) \
_(VL_API_LISP_ADD_DEL_MAP_REQUEST_ITR_RLOCS_REPLY, lisp_add_del_map_request_itr_rlocs_reply, 712498b4) \
_(VL_API_LISP_EID_TABLE_ADD_DEL_MAP, lisp_eid_table_add_del_map, 598a91ce) \
_(VL_API_LISP_EID_TABLE_ADD_DEL_MAP_REPLY, lisp_eid_table_add_del_map_reply, 9c948155) \
_(VL_API_LISP_LOCATOR_DUMP, lisp_locator_dump, 35176bc8) \
_(VL_API_LISP_LOCATOR_DETAILS, lisp_locator_details, cb282c00) \
_(VL_API_LISP_LOCATOR_SET_DETAILS, lisp_locator_set_details, 4ab2d4cf) \
_(VL_API_LISP_LOCATOR_SET_DUMP, lisp_locator_set_dump, 0f3d315b) \
_(VL_API_LISP_EID_TABLE_DETAILS, lisp_eid_table_details, b93cde6b) \
_(VL_API_LISP_EID_TABLE_DUMP, lisp_eid_table_dump, 354e0c1a) \
_(VL_API_LISP_ADJACENCIES_GET_REPLY, lisp_adjacencies_get_reply, 00dcfe1d) \
_(VL_API_LISP_ADJACENCIES_GET, lisp_adjacencies_get, f0252c92) \
_(VL_API_LISP_EID_TABLE_MAP_DETAILS, lisp_eid_table_map_details, c5f081e9) \
_(VL_API_LISP_EID_TABLE_MAP_DUMP, lisp_eid_table_map_dump, b0704823) \
_(VL_API_LISP_EID_TABLE_VNI_DUMP, lisp_eid_table_vni_dump, 3456e06a) \
_(VL_API_LISP_EID_TABLE_VNI_DETAILS, lisp_eid_table_vni_details, e2f8a8b9) \
_(VL_API_LISP_MAP_RESOLVER_DETAILS, lisp_map_resolver_details, e8c68ebd) \
_(VL_API_LISP_MAP_RESOLVER_DUMP, lisp_map_resolver_dump, 4e5e2003) \
_(VL_API_LISP_MAP_SERVER_DETAILS, lisp_map_server_details, 4ef38e5a) \
_(VL_API_LISP_MAP_SERVER_DUMP, lisp_map_server_dump, 2b2998e2) \
_(VL_API_SHOW_LISP_STATUS, show_lisp_status, 8092ab77) \
_(VL_API_SHOW_LISP_STATUS_REPLY, show_lisp_status_reply, 6aa3f21d) \
_(VL_API_LISP_GET_MAP_REQUEST_ITR_RLOCS, lisp_get_map_request_itr_rlocs, 1e2d23a4) \
_(VL_API_LISP_GET_MAP_REQUEST_ITR_RLOCS_REPLY, lisp_get_map_request_itr_rlocs_reply, 39bfca79) \
_(VL_API_SHOW_LISP_PITR, show_lisp_pitr, d4a061e6) \
_(VL_API_SHOW_LISP_PITR_REPLY, show_lisp_pitr_reply, e730f16e) 
#endif


/****** Typedefs *****/

#ifdef vl_typedefs

typedef VL_API_PACKED(struct _vl_api_local_locator {
    u32 sw_if_index;
    u8 priority;
    u8 weight;
}) vl_api_local_locator_t;

typedef VL_API_PACKED(struct _vl_api_lisp_add_del_locator_set {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 locator_set_name[64];
    u32 locator_num;
    vl_api_local_locator_t locators[0];
}) vl_api_lisp_add_del_locator_set_t;

typedef VL_API_PACKED(struct _vl_api_lisp_add_del_locator_set_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 ls_index;
}) vl_api_lisp_add_del_locator_set_reply_t;

typedef VL_API_PACKED(struct _vl_api_lisp_add_del_locator {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 locator_set_name[64];
    u32 sw_if_index;
    u8 priority;
    u8 weight;
}) vl_api_lisp_add_del_locator_t;

typedef VL_API_PACKED(struct _vl_api_lisp_add_del_locator_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_lisp_add_del_locator_reply_t;

typedef VL_API_PACKED(struct _vl_api_lisp_add_del_local_eid {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 eid_type;
    u8 eid[16];
    u8 prefix_len;
    u8 locator_set_name[64];
    u32 vni;
    u16 key_id;
    u8 key[64];
}) vl_api_lisp_add_del_local_eid_t;

typedef VL_API_PACKED(struct _vl_api_lisp_add_del_local_eid_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_lisp_add_del_local_eid_reply_t;

typedef VL_API_PACKED(struct _vl_api_lisp_add_del_map_server {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 is_ipv6;
    u8 ip_address[16];
}) vl_api_lisp_add_del_map_server_t;

typedef VL_API_PACKED(struct _vl_api_lisp_add_del_map_server_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_lisp_add_del_map_server_reply_t;

typedef VL_API_PACKED(struct _vl_api_lisp_add_del_map_resolver {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 is_ipv6;
    u8 ip_address[16];
}) vl_api_lisp_add_del_map_resolver_t;

typedef VL_API_PACKED(struct _vl_api_lisp_add_del_map_resolver_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_lisp_add_del_map_resolver_reply_t;

typedef VL_API_PACKED(struct _vl_api_lisp_enable_disable {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_en;
}) vl_api_lisp_enable_disable_t;

typedef VL_API_PACKED(struct _vl_api_lisp_enable_disable_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_lisp_enable_disable_reply_t;

typedef VL_API_PACKED(struct _vl_api_lisp_pitr_set_locator_set {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 ls_name[64];
}) vl_api_lisp_pitr_set_locator_set_t;

typedef VL_API_PACKED(struct _vl_api_lisp_pitr_set_locator_set_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_lisp_pitr_set_locator_set_reply_t;

typedef VL_API_PACKED(struct _vl_api_lisp_use_petr {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_ip4;
    u8 address[16];
    u8 is_add;
}) vl_api_lisp_use_petr_t;

typedef VL_API_PACKED(struct _vl_api_lisp_use_petr_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_lisp_use_petr_reply_t;

typedef VL_API_PACKED(struct _vl_api_show_lisp_use_petr {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_show_lisp_use_petr_t;

typedef VL_API_PACKED(struct _vl_api_show_lisp_use_petr_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 status;
    u8 is_ip4;
    u8 address[16];
}) vl_api_show_lisp_use_petr_reply_t;

typedef VL_API_PACKED(struct _vl_api_show_lisp_rloc_probe_state {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_show_lisp_rloc_probe_state_t;

typedef VL_API_PACKED(struct _vl_api_show_lisp_rloc_probe_state_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 is_enabled;
}) vl_api_show_lisp_rloc_probe_state_reply_t;

typedef VL_API_PACKED(struct _vl_api_lisp_rloc_probe_enable_disable {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_enabled;
}) vl_api_lisp_rloc_probe_enable_disable_t;

typedef VL_API_PACKED(struct _vl_api_lisp_rloc_probe_enable_disable_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_lisp_rloc_probe_enable_disable_reply_t;

typedef VL_API_PACKED(struct _vl_api_lisp_map_register_enable_disable {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_enabled;
}) vl_api_lisp_map_register_enable_disable_t;

typedef VL_API_PACKED(struct _vl_api_lisp_map_register_enable_disable_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_lisp_map_register_enable_disable_reply_t;

typedef VL_API_PACKED(struct _vl_api_show_lisp_map_register_state {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_show_lisp_map_register_state_t;

typedef VL_API_PACKED(struct _vl_api_show_lisp_map_register_state_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 is_enabled;
}) vl_api_show_lisp_map_register_state_reply_t;

typedef VL_API_PACKED(struct _vl_api_lisp_map_request_mode {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 mode;
}) vl_api_lisp_map_request_mode_t;

typedef VL_API_PACKED(struct _vl_api_lisp_map_request_mode_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_lisp_map_request_mode_reply_t;

typedef VL_API_PACKED(struct _vl_api_show_lisp_map_request_mode {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_show_lisp_map_request_mode_t;

typedef VL_API_PACKED(struct _vl_api_show_lisp_map_request_mode_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 mode;
}) vl_api_show_lisp_map_request_mode_reply_t;

typedef VL_API_PACKED(struct _vl_api_remote_locator {
    u8 is_ip4;
    u8 priority;
    u8 weight;
    u8 addr[16];
}) vl_api_remote_locator_t;

typedef VL_API_PACKED(struct _vl_api_lisp_add_del_remote_mapping {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 is_src_dst;
    u8 del_all;
    u32 vni;
    u8 action;
    u8 eid_type;
    u8 eid[16];
    u8 eid_len;
    u8 seid[16];
    u8 seid_len;
    u32 rloc_num;
    vl_api_remote_locator_t rlocs[0];
}) vl_api_lisp_add_del_remote_mapping_t;

typedef VL_API_PACKED(struct _vl_api_lisp_add_del_remote_mapping_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_lisp_add_del_remote_mapping_reply_t;

typedef VL_API_PACKED(struct _vl_api_lisp_add_del_adjacency {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u32 vni;
    u8 eid_type;
    u8 reid[16];
    u8 leid[16];
    u8 reid_len;
    u8 leid_len;
}) vl_api_lisp_add_del_adjacency_t;

typedef VL_API_PACKED(struct _vl_api_lisp_add_del_adjacency_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_lisp_add_del_adjacency_reply_t;

typedef VL_API_PACKED(struct _vl_api_lisp_add_del_map_request_itr_rlocs {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 locator_set_name[64];
}) vl_api_lisp_add_del_map_request_itr_rlocs_t;

typedef VL_API_PACKED(struct _vl_api_lisp_add_del_map_request_itr_rlocs_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_lisp_add_del_map_request_itr_rlocs_reply_t;

typedef VL_API_PACKED(struct _vl_api_lisp_eid_table_add_del_map {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u32 vni;
    u32 dp_table;
    u8 is_l2;
}) vl_api_lisp_eid_table_add_del_map_t;

typedef VL_API_PACKED(struct _vl_api_lisp_eid_table_add_del_map_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_lisp_eid_table_add_del_map_reply_t;

typedef VL_API_PACKED(struct _vl_api_lisp_locator_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 ls_index;
    u8 ls_name[64];
    u8 is_index_set;
}) vl_api_lisp_locator_dump_t;

typedef VL_API_PACKED(struct _vl_api_lisp_locator_details {
    u16 _vl_msg_id;
    u32 context;
    u8 local;
    u32 sw_if_index;
    u8 is_ipv6;
    u8 ip_address[16];
    u8 priority;
    u8 weight;
}) vl_api_lisp_locator_details_t;

typedef VL_API_PACKED(struct _vl_api_lisp_locator_set_details {
    u16 _vl_msg_id;
    u32 context;
    u32 ls_index;
    u8 ls_name[64];
}) vl_api_lisp_locator_set_details_t;

typedef VL_API_PACKED(struct _vl_api_lisp_locator_set_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 filter;
}) vl_api_lisp_locator_set_dump_t;

typedef VL_API_PACKED(struct _vl_api_lisp_eid_table_details {
    u16 _vl_msg_id;
    u32 context;
    u32 locator_set_index;
    u8 action;
    u8 is_local;
    u8 eid_type;
    u8 is_src_dst;
    u32 vni;
    u8 eid[16];
    u8 eid_prefix_len;
    u8 seid[16];
    u8 seid_prefix_len;
    u32 ttl;
    u8 authoritative;
    u16 key_id;
    u8 key[64];
}) vl_api_lisp_eid_table_details_t;

typedef VL_API_PACKED(struct _vl_api_lisp_eid_table_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 eid_set;
    u8 prefix_length;
    u32 vni;
    u8 eid_type;
    u8 eid[16];
    u8 filter;
}) vl_api_lisp_eid_table_dump_t;

typedef VL_API_PACKED(struct _vl_api_lisp_adjacency {
    u8 eid_type;
    u8 reid[16];
    u8 leid[16];
    u8 reid_prefix_len;
    u8 leid_prefix_len;
}) vl_api_lisp_adjacency_t;

typedef VL_API_PACKED(struct _vl_api_lisp_adjacencies_get_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 count;
    vl_api_lisp_adjacency_t adjacencies[0];
}) vl_api_lisp_adjacencies_get_reply_t;

typedef VL_API_PACKED(struct _vl_api_lisp_adjacencies_get {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 vni;
}) vl_api_lisp_adjacencies_get_t;

typedef VL_API_PACKED(struct _vl_api_lisp_eid_table_map_details {
    u16 _vl_msg_id;
    u32 context;
    u32 vni;
    u32 dp_table;
}) vl_api_lisp_eid_table_map_details_t;

typedef VL_API_PACKED(struct _vl_api_lisp_eid_table_map_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_l2;
}) vl_api_lisp_eid_table_map_dump_t;

typedef VL_API_PACKED(struct _vl_api_lisp_eid_table_vni_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_lisp_eid_table_vni_dump_t;

typedef VL_API_PACKED(struct _vl_api_lisp_eid_table_vni_details {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 vni;
}) vl_api_lisp_eid_table_vni_details_t;

typedef VL_API_PACKED(struct _vl_api_lisp_map_resolver_details {
    u16 _vl_msg_id;
    u32 context;
    u8 is_ipv6;
    u8 ip_address[16];
}) vl_api_lisp_map_resolver_details_t;

typedef VL_API_PACKED(struct _vl_api_lisp_map_resolver_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_lisp_map_resolver_dump_t;

typedef VL_API_PACKED(struct _vl_api_lisp_map_server_details {
    u16 _vl_msg_id;
    u32 context;
    u8 is_ipv6;
    u8 ip_address[16];
}) vl_api_lisp_map_server_details_t;

typedef VL_API_PACKED(struct _vl_api_lisp_map_server_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_lisp_map_server_dump_t;

typedef VL_API_PACKED(struct _vl_api_show_lisp_status {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_show_lisp_status_t;

typedef VL_API_PACKED(struct _vl_api_show_lisp_status_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 feature_status;
    u8 gpe_status;
}) vl_api_show_lisp_status_reply_t;

typedef VL_API_PACKED(struct _vl_api_lisp_get_map_request_itr_rlocs {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_lisp_get_map_request_itr_rlocs_t;

typedef VL_API_PACKED(struct _vl_api_lisp_get_map_request_itr_rlocs_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 locator_set_name[64];
}) vl_api_lisp_get_map_request_itr_rlocs_reply_t;

typedef VL_API_PACKED(struct _vl_api_show_lisp_pitr {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_show_lisp_pitr_t;

typedef VL_API_PACKED(struct _vl_api_show_lisp_pitr_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 status;
    u8 locator_set_name[64];
}) vl_api_show_lisp_pitr_reply_t;

#endif /* vl_typedefs */

/****** Discriminated Union Definitions *****/

#ifdef vl_union_id


#endif /* vl_union_id */

/****** Print functions *****/

#ifdef vl_printfun

#ifdef LP64
#define _uword_fmt "%lld"
#define _uword_cast (long long)
#else
#define _uword_fmt "%ld"
#define _uword_cast long
#endif

/***** manual: vl_api_local_locator_t_print  *****/

/***** manual: vl_api_lisp_add_del_locator_set_t_print  *****/

static inline void *vl_api_lisp_add_del_locator_set_reply_t_print (vl_api_lisp_add_del_locator_set_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_add_del_locator_set_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "ls_index: %u\n", (unsigned) a->ls_index);
    return handle;
}

static inline void *vl_api_lisp_add_del_locator_t_print (vl_api_lisp_add_del_locator_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_add_del_locator_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "locator_set_name[%d]: %u\n", _i, a->locator_set_name[_i]);
        }
    }
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "priority: %u\n", (unsigned) a->priority);
    vl_print(handle, "weight: %u\n", (unsigned) a->weight);
    return handle;
}

static inline void *vl_api_lisp_add_del_locator_reply_t_print (vl_api_lisp_add_del_locator_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_add_del_locator_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_lisp_add_del_local_eid_t_print (vl_api_lisp_add_del_local_eid_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_add_del_local_eid_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "eid_type: %u\n", (unsigned) a->eid_type);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "eid[%d]: %u\n", _i, a->eid[_i]);
        }
    }
    vl_print(handle, "prefix_len: %u\n", (unsigned) a->prefix_len);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "locator_set_name[%d]: %u\n", _i, a->locator_set_name[_i]);
        }
    }
    vl_print(handle, "vni: %u\n", (unsigned) a->vni);
    vl_print(handle, "key_id: %u\n", (unsigned) a->key_id);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "key[%d]: %u\n", _i, a->key[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_lisp_add_del_local_eid_reply_t_print (vl_api_lisp_add_del_local_eid_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_add_del_local_eid_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_lisp_add_del_map_server_t_print (vl_api_lisp_add_del_map_server_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_add_del_map_server_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "ip_address[%d]: %u\n", _i, a->ip_address[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_lisp_add_del_map_server_reply_t_print (vl_api_lisp_add_del_map_server_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_add_del_map_server_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_lisp_add_del_map_resolver_t_print (vl_api_lisp_add_del_map_resolver_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_add_del_map_resolver_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "ip_address[%d]: %u\n", _i, a->ip_address[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_lisp_add_del_map_resolver_reply_t_print (vl_api_lisp_add_del_map_resolver_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_add_del_map_resolver_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_lisp_enable_disable_t_print (vl_api_lisp_enable_disable_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_enable_disable_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_en: %u\n", (unsigned) a->is_en);
    return handle;
}

static inline void *vl_api_lisp_enable_disable_reply_t_print (vl_api_lisp_enable_disable_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_enable_disable_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_lisp_pitr_set_locator_set_t_print (vl_api_lisp_pitr_set_locator_set_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_pitr_set_locator_set_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "ls_name[%d]: %u\n", _i, a->ls_name[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_lisp_pitr_set_locator_set_reply_t_print (vl_api_lisp_pitr_set_locator_set_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_pitr_set_locator_set_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_lisp_use_petr_t_print (vl_api_lisp_use_petr_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_use_petr_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_ip4: %u\n", (unsigned) a->is_ip4);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "address[%d]: %u\n", _i, a->address[_i]);
        }
    }
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    return handle;
}

static inline void *vl_api_lisp_use_petr_reply_t_print (vl_api_lisp_use_petr_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_use_petr_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_show_lisp_use_petr_t_print (vl_api_show_lisp_use_petr_t *a,void *handle)
{
    vl_print(handle, "vl_api_show_lisp_use_petr_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_show_lisp_use_petr_reply_t_print (vl_api_show_lisp_use_petr_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_show_lisp_use_petr_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "status: %u\n", (unsigned) a->status);
    vl_print(handle, "is_ip4: %u\n", (unsigned) a->is_ip4);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "address[%d]: %u\n", _i, a->address[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_show_lisp_rloc_probe_state_t_print (vl_api_show_lisp_rloc_probe_state_t *a,void *handle)
{
    vl_print(handle, "vl_api_show_lisp_rloc_probe_state_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_show_lisp_rloc_probe_state_reply_t_print (vl_api_show_lisp_rloc_probe_state_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_show_lisp_rloc_probe_state_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "is_enabled: %u\n", (unsigned) a->is_enabled);
    return handle;
}

static inline void *vl_api_lisp_rloc_probe_enable_disable_t_print (vl_api_lisp_rloc_probe_enable_disable_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_rloc_probe_enable_disable_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_enabled: %u\n", (unsigned) a->is_enabled);
    return handle;
}

static inline void *vl_api_lisp_rloc_probe_enable_disable_reply_t_print (vl_api_lisp_rloc_probe_enable_disable_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_rloc_probe_enable_disable_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_lisp_map_register_enable_disable_t_print (vl_api_lisp_map_register_enable_disable_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_map_register_enable_disable_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_enabled: %u\n", (unsigned) a->is_enabled);
    return handle;
}

static inline void *vl_api_lisp_map_register_enable_disable_reply_t_print (vl_api_lisp_map_register_enable_disable_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_map_register_enable_disable_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_show_lisp_map_register_state_t_print (vl_api_show_lisp_map_register_state_t *a,void *handle)
{
    vl_print(handle, "vl_api_show_lisp_map_register_state_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_show_lisp_map_register_state_reply_t_print (vl_api_show_lisp_map_register_state_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_show_lisp_map_register_state_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "is_enabled: %u\n", (unsigned) a->is_enabled);
    return handle;
}

static inline void *vl_api_lisp_map_request_mode_t_print (vl_api_lisp_map_request_mode_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_map_request_mode_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "mode: %u\n", (unsigned) a->mode);
    return handle;
}

static inline void *vl_api_lisp_map_request_mode_reply_t_print (vl_api_lisp_map_request_mode_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_map_request_mode_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_show_lisp_map_request_mode_t_print (vl_api_show_lisp_map_request_mode_t *a,void *handle)
{
    vl_print(handle, "vl_api_show_lisp_map_request_mode_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_show_lisp_map_request_mode_reply_t_print (vl_api_show_lisp_map_request_mode_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_show_lisp_map_request_mode_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "mode: %u\n", (unsigned) a->mode);
    return handle;
}

/***** manual: vl_api_remote_locator_t_print  *****/

/***** manual: vl_api_lisp_add_del_remote_mapping_t_print  *****/

static inline void *vl_api_lisp_add_del_remote_mapping_reply_t_print (vl_api_lisp_add_del_remote_mapping_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_add_del_remote_mapping_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_lisp_add_del_adjacency_t_print (vl_api_lisp_add_del_adjacency_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_add_del_adjacency_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "vni: %u\n", (unsigned) a->vni);
    vl_print(handle, "eid_type: %u\n", (unsigned) a->eid_type);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "reid[%d]: %u\n", _i, a->reid[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "leid[%d]: %u\n", _i, a->leid[_i]);
        }
    }
    vl_print(handle, "reid_len: %u\n", (unsigned) a->reid_len);
    vl_print(handle, "leid_len: %u\n", (unsigned) a->leid_len);
    return handle;
}

static inline void *vl_api_lisp_add_del_adjacency_reply_t_print (vl_api_lisp_add_del_adjacency_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_add_del_adjacency_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_lisp_add_del_map_request_itr_rlocs_t_print (vl_api_lisp_add_del_map_request_itr_rlocs_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_add_del_map_request_itr_rlocs_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "locator_set_name[%d]: %u\n", _i, a->locator_set_name[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_lisp_add_del_map_request_itr_rlocs_reply_t_print (vl_api_lisp_add_del_map_request_itr_rlocs_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_add_del_map_request_itr_rlocs_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_lisp_eid_table_add_del_map_t_print (vl_api_lisp_eid_table_add_del_map_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_eid_table_add_del_map_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "vni: %u\n", (unsigned) a->vni);
    vl_print(handle, "dp_table: %u\n", (unsigned) a->dp_table);
    vl_print(handle, "is_l2: %u\n", (unsigned) a->is_l2);
    return handle;
}

static inline void *vl_api_lisp_eid_table_add_del_map_reply_t_print (vl_api_lisp_eid_table_add_del_map_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_eid_table_add_del_map_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_lisp_locator_dump_t_print (vl_api_lisp_locator_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_locator_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "ls_index: %u\n", (unsigned) a->ls_index);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "ls_name[%d]: %u\n", _i, a->ls_name[_i]);
        }
    }
    vl_print(handle, "is_index_set: %u\n", (unsigned) a->is_index_set);
    return handle;
}

static inline void *vl_api_lisp_locator_details_t_print (vl_api_lisp_locator_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_locator_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "local: %u\n", (unsigned) a->local);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "ip_address[%d]: %u\n", _i, a->ip_address[_i]);
        }
    }
    vl_print(handle, "priority: %u\n", (unsigned) a->priority);
    vl_print(handle, "weight: %u\n", (unsigned) a->weight);
    return handle;
}

static inline void *vl_api_lisp_locator_set_details_t_print (vl_api_lisp_locator_set_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_locator_set_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "ls_index: %u\n", (unsigned) a->ls_index);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "ls_name[%d]: %u\n", _i, a->ls_name[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_lisp_locator_set_dump_t_print (vl_api_lisp_locator_set_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_locator_set_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "filter: %u\n", (unsigned) a->filter);
    return handle;
}

static inline void *vl_api_lisp_eid_table_details_t_print (vl_api_lisp_eid_table_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_eid_table_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "locator_set_index: %u\n", (unsigned) a->locator_set_index);
    vl_print(handle, "action: %u\n", (unsigned) a->action);
    vl_print(handle, "is_local: %u\n", (unsigned) a->is_local);
    vl_print(handle, "eid_type: %u\n", (unsigned) a->eid_type);
    vl_print(handle, "is_src_dst: %u\n", (unsigned) a->is_src_dst);
    vl_print(handle, "vni: %u\n", (unsigned) a->vni);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "eid[%d]: %u\n", _i, a->eid[_i]);
        }
    }
    vl_print(handle, "eid_prefix_len: %u\n", (unsigned) a->eid_prefix_len);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "seid[%d]: %u\n", _i, a->seid[_i]);
        }
    }
    vl_print(handle, "seid_prefix_len: %u\n", (unsigned) a->seid_prefix_len);
    vl_print(handle, "ttl: %u\n", (unsigned) a->ttl);
    vl_print(handle, "authoritative: %u\n", (unsigned) a->authoritative);
    vl_print(handle, "key_id: %u\n", (unsigned) a->key_id);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "key[%d]: %u\n", _i, a->key[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_lisp_eid_table_dump_t_print (vl_api_lisp_eid_table_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_eid_table_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "eid_set: %u\n", (unsigned) a->eid_set);
    vl_print(handle, "prefix_length: %u\n", (unsigned) a->prefix_length);
    vl_print(handle, "vni: %u\n", (unsigned) a->vni);
    vl_print(handle, "eid_type: %u\n", (unsigned) a->eid_type);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "eid[%d]: %u\n", _i, a->eid[_i]);
        }
    }
    vl_print(handle, "filter: %u\n", (unsigned) a->filter);
    return handle;
}

/***** manual: vl_api_lisp_adjacency_t_print  *****/

/***** manual: vl_api_lisp_adjacencies_get_reply_t_print  *****/

static inline void *vl_api_lisp_adjacencies_get_t_print (vl_api_lisp_adjacencies_get_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_adjacencies_get_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "vni: %u\n", (unsigned) a->vni);
    return handle;
}

static inline void *vl_api_lisp_eid_table_map_details_t_print (vl_api_lisp_eid_table_map_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_eid_table_map_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "vni: %u\n", (unsigned) a->vni);
    vl_print(handle, "dp_table: %u\n", (unsigned) a->dp_table);
    return handle;
}

static inline void *vl_api_lisp_eid_table_map_dump_t_print (vl_api_lisp_eid_table_map_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_eid_table_map_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_l2: %u\n", (unsigned) a->is_l2);
    return handle;
}

static inline void *vl_api_lisp_eid_table_vni_dump_t_print (vl_api_lisp_eid_table_vni_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_eid_table_vni_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_lisp_eid_table_vni_details_t_print (vl_api_lisp_eid_table_vni_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_eid_table_vni_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "vni: %u\n", (unsigned) a->vni);
    return handle;
}

static inline void *vl_api_lisp_map_resolver_details_t_print (vl_api_lisp_map_resolver_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_map_resolver_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "ip_address[%d]: %u\n", _i, a->ip_address[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_lisp_map_resolver_dump_t_print (vl_api_lisp_map_resolver_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_map_resolver_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_lisp_map_server_details_t_print (vl_api_lisp_map_server_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_map_server_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "ip_address[%d]: %u\n", _i, a->ip_address[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_lisp_map_server_dump_t_print (vl_api_lisp_map_server_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_map_server_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_show_lisp_status_t_print (vl_api_show_lisp_status_t *a,void *handle)
{
    vl_print(handle, "vl_api_show_lisp_status_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_show_lisp_status_reply_t_print (vl_api_show_lisp_status_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_show_lisp_status_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "feature_status: %u\n", (unsigned) a->feature_status);
    vl_print(handle, "gpe_status: %u\n", (unsigned) a->gpe_status);
    return handle;
}

static inline void *vl_api_lisp_get_map_request_itr_rlocs_t_print (vl_api_lisp_get_map_request_itr_rlocs_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_get_map_request_itr_rlocs_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_lisp_get_map_request_itr_rlocs_reply_t_print (vl_api_lisp_get_map_request_itr_rlocs_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_lisp_get_map_request_itr_rlocs_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "locator_set_name[%d]: %u\n", _i, a->locator_set_name[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_show_lisp_pitr_t_print (vl_api_show_lisp_pitr_t *a,void *handle)
{
    vl_print(handle, "vl_api_show_lisp_pitr_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_show_lisp_pitr_reply_t_print (vl_api_show_lisp_pitr_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_show_lisp_pitr_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "status: %u\n", (unsigned) a->status);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "locator_set_name[%d]: %u\n", _i, a->locator_set_name[_i]);
        }
    }
    return handle;
}

#endif /* vl_printfun */


/****** Endian swap functions *****/

#ifdef vl_endianfun

#undef clib_net_to_host_uword
#ifdef LP64
#define clib_net_to_host_uword clib_net_to_host_u64
#else
#define clib_net_to_host_uword clib_net_to_host_u32
#endif

/***** manual: vl_api_local_locator_t_endian  *****/

/***** manual: vl_api_lisp_add_del_locator_set_t_endian  *****/

static inline void vl_api_lisp_add_del_locator_set_reply_t_endian (vl_api_lisp_add_del_locator_set_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->ls_index = clib_net_to_host_u32(a->ls_index);
}

static inline void vl_api_lisp_add_del_locator_t_endian (vl_api_lisp_add_del_locator_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    /* a->locator_set_name[0..63] = a->locator_set_name[0..63] (no-op) */
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->priority = a->priority (no-op) */
    /* a->weight = a->weight (no-op) */
}

static inline void vl_api_lisp_add_del_locator_reply_t_endian (vl_api_lisp_add_del_locator_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_lisp_add_del_local_eid_t_endian (vl_api_lisp_add_del_local_eid_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    /* a->eid_type = a->eid_type (no-op) */
    /* a->eid[0..15] = a->eid[0..15] (no-op) */
    /* a->prefix_len = a->prefix_len (no-op) */
    /* a->locator_set_name[0..63] = a->locator_set_name[0..63] (no-op) */
    a->vni = clib_net_to_host_u32(a->vni);
    a->key_id = clib_net_to_host_u16(a->key_id);
    /* a->key[0..63] = a->key[0..63] (no-op) */
}

static inline void vl_api_lisp_add_del_local_eid_reply_t_endian (vl_api_lisp_add_del_local_eid_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_lisp_add_del_map_server_t_endian (vl_api_lisp_add_del_map_server_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    /* a->ip_address[0..15] = a->ip_address[0..15] (no-op) */
}

static inline void vl_api_lisp_add_del_map_server_reply_t_endian (vl_api_lisp_add_del_map_server_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_lisp_add_del_map_resolver_t_endian (vl_api_lisp_add_del_map_resolver_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    /* a->ip_address[0..15] = a->ip_address[0..15] (no-op) */
}

static inline void vl_api_lisp_add_del_map_resolver_reply_t_endian (vl_api_lisp_add_del_map_resolver_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_lisp_enable_disable_t_endian (vl_api_lisp_enable_disable_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_en = a->is_en (no-op) */
}

static inline void vl_api_lisp_enable_disable_reply_t_endian (vl_api_lisp_enable_disable_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_lisp_pitr_set_locator_set_t_endian (vl_api_lisp_pitr_set_locator_set_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    /* a->ls_name[0..63] = a->ls_name[0..63] (no-op) */
}

static inline void vl_api_lisp_pitr_set_locator_set_reply_t_endian (vl_api_lisp_pitr_set_locator_set_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_lisp_use_petr_t_endian (vl_api_lisp_use_petr_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_ip4 = a->is_ip4 (no-op) */
    /* a->address[0..15] = a->address[0..15] (no-op) */
    /* a->is_add = a->is_add (no-op) */
}

static inline void vl_api_lisp_use_petr_reply_t_endian (vl_api_lisp_use_petr_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_show_lisp_use_petr_t_endian (vl_api_show_lisp_use_petr_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_show_lisp_use_petr_reply_t_endian (vl_api_show_lisp_use_petr_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    /* a->status = a->status (no-op) */
    /* a->is_ip4 = a->is_ip4 (no-op) */
    /* a->address[0..15] = a->address[0..15] (no-op) */
}

static inline void vl_api_show_lisp_rloc_probe_state_t_endian (vl_api_show_lisp_rloc_probe_state_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_show_lisp_rloc_probe_state_reply_t_endian (vl_api_show_lisp_rloc_probe_state_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    /* a->is_enabled = a->is_enabled (no-op) */
}

static inline void vl_api_lisp_rloc_probe_enable_disable_t_endian (vl_api_lisp_rloc_probe_enable_disable_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_enabled = a->is_enabled (no-op) */
}

static inline void vl_api_lisp_rloc_probe_enable_disable_reply_t_endian (vl_api_lisp_rloc_probe_enable_disable_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_lisp_map_register_enable_disable_t_endian (vl_api_lisp_map_register_enable_disable_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_enabled = a->is_enabled (no-op) */
}

static inline void vl_api_lisp_map_register_enable_disable_reply_t_endian (vl_api_lisp_map_register_enable_disable_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_show_lisp_map_register_state_t_endian (vl_api_show_lisp_map_register_state_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_show_lisp_map_register_state_reply_t_endian (vl_api_show_lisp_map_register_state_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    /* a->is_enabled = a->is_enabled (no-op) */
}

static inline void vl_api_lisp_map_request_mode_t_endian (vl_api_lisp_map_request_mode_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->mode = a->mode (no-op) */
}

static inline void vl_api_lisp_map_request_mode_reply_t_endian (vl_api_lisp_map_request_mode_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_show_lisp_map_request_mode_t_endian (vl_api_show_lisp_map_request_mode_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_show_lisp_map_request_mode_reply_t_endian (vl_api_show_lisp_map_request_mode_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    /* a->mode = a->mode (no-op) */
}

/***** manual: vl_api_remote_locator_t_endian  *****/

/***** manual: vl_api_lisp_add_del_remote_mapping_t_endian  *****/

static inline void vl_api_lisp_add_del_remote_mapping_reply_t_endian (vl_api_lisp_add_del_remote_mapping_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_lisp_add_del_adjacency_t_endian (vl_api_lisp_add_del_adjacency_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    a->vni = clib_net_to_host_u32(a->vni);
    /* a->eid_type = a->eid_type (no-op) */
    /* a->reid[0..15] = a->reid[0..15] (no-op) */
    /* a->leid[0..15] = a->leid[0..15] (no-op) */
    /* a->reid_len = a->reid_len (no-op) */
    /* a->leid_len = a->leid_len (no-op) */
}

static inline void vl_api_lisp_add_del_adjacency_reply_t_endian (vl_api_lisp_add_del_adjacency_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_lisp_add_del_map_request_itr_rlocs_t_endian (vl_api_lisp_add_del_map_request_itr_rlocs_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    /* a->locator_set_name[0..63] = a->locator_set_name[0..63] (no-op) */
}

static inline void vl_api_lisp_add_del_map_request_itr_rlocs_reply_t_endian (vl_api_lisp_add_del_map_request_itr_rlocs_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_lisp_eid_table_add_del_map_t_endian (vl_api_lisp_eid_table_add_del_map_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    a->vni = clib_net_to_host_u32(a->vni);
    a->dp_table = clib_net_to_host_u32(a->dp_table);
    /* a->is_l2 = a->is_l2 (no-op) */
}

static inline void vl_api_lisp_eid_table_add_del_map_reply_t_endian (vl_api_lisp_eid_table_add_del_map_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_lisp_locator_dump_t_endian (vl_api_lisp_locator_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->ls_index = clib_net_to_host_u32(a->ls_index);
    /* a->ls_name[0..63] = a->ls_name[0..63] (no-op) */
    /* a->is_index_set = a->is_index_set (no-op) */
}

static inline void vl_api_lisp_locator_details_t_endian (vl_api_lisp_locator_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    /* a->local = a->local (no-op) */
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    /* a->ip_address[0..15] = a->ip_address[0..15] (no-op) */
    /* a->priority = a->priority (no-op) */
    /* a->weight = a->weight (no-op) */
}

static inline void vl_api_lisp_locator_set_details_t_endian (vl_api_lisp_locator_set_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->ls_index = clib_net_to_host_u32(a->ls_index);
    /* a->ls_name[0..63] = a->ls_name[0..63] (no-op) */
}

static inline void vl_api_lisp_locator_set_dump_t_endian (vl_api_lisp_locator_set_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->filter = a->filter (no-op) */
}

static inline void vl_api_lisp_eid_table_details_t_endian (vl_api_lisp_eid_table_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->locator_set_index = clib_net_to_host_u32(a->locator_set_index);
    /* a->action = a->action (no-op) */
    /* a->is_local = a->is_local (no-op) */
    /* a->eid_type = a->eid_type (no-op) */
    /* a->is_src_dst = a->is_src_dst (no-op) */
    a->vni = clib_net_to_host_u32(a->vni);
    /* a->eid[0..15] = a->eid[0..15] (no-op) */
    /* a->eid_prefix_len = a->eid_prefix_len (no-op) */
    /* a->seid[0..15] = a->seid[0..15] (no-op) */
    /* a->seid_prefix_len = a->seid_prefix_len (no-op) */
    a->ttl = clib_net_to_host_u32(a->ttl);
    /* a->authoritative = a->authoritative (no-op) */
    a->key_id = clib_net_to_host_u16(a->key_id);
    /* a->key[0..63] = a->key[0..63] (no-op) */
}

static inline void vl_api_lisp_eid_table_dump_t_endian (vl_api_lisp_eid_table_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->eid_set = a->eid_set (no-op) */
    /* a->prefix_length = a->prefix_length (no-op) */
    a->vni = clib_net_to_host_u32(a->vni);
    /* a->eid_type = a->eid_type (no-op) */
    /* a->eid[0..15] = a->eid[0..15] (no-op) */
    /* a->filter = a->filter (no-op) */
}

/***** manual: vl_api_lisp_adjacency_t_endian  *****/

/***** manual: vl_api_lisp_adjacencies_get_reply_t_endian  *****/

static inline void vl_api_lisp_adjacencies_get_t_endian (vl_api_lisp_adjacencies_get_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->vni = clib_net_to_host_u32(a->vni);
}

static inline void vl_api_lisp_eid_table_map_details_t_endian (vl_api_lisp_eid_table_map_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->vni = clib_net_to_host_u32(a->vni);
    a->dp_table = clib_net_to_host_u32(a->dp_table);
}

static inline void vl_api_lisp_eid_table_map_dump_t_endian (vl_api_lisp_eid_table_map_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_l2 = a->is_l2 (no-op) */
}

static inline void vl_api_lisp_eid_table_vni_dump_t_endian (vl_api_lisp_eid_table_vni_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_lisp_eid_table_vni_details_t_endian (vl_api_lisp_eid_table_vni_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->vni = clib_net_to_host_u32(a->vni);
}

static inline void vl_api_lisp_map_resolver_details_t_endian (vl_api_lisp_map_resolver_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    /* a->ip_address[0..15] = a->ip_address[0..15] (no-op) */
}

static inline void vl_api_lisp_map_resolver_dump_t_endian (vl_api_lisp_map_resolver_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_lisp_map_server_details_t_endian (vl_api_lisp_map_server_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    /* a->ip_address[0..15] = a->ip_address[0..15] (no-op) */
}

static inline void vl_api_lisp_map_server_dump_t_endian (vl_api_lisp_map_server_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_show_lisp_status_t_endian (vl_api_show_lisp_status_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_show_lisp_status_reply_t_endian (vl_api_show_lisp_status_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    /* a->feature_status = a->feature_status (no-op) */
    /* a->gpe_status = a->gpe_status (no-op) */
}

static inline void vl_api_lisp_get_map_request_itr_rlocs_t_endian (vl_api_lisp_get_map_request_itr_rlocs_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_lisp_get_map_request_itr_rlocs_reply_t_endian (vl_api_lisp_get_map_request_itr_rlocs_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    /* a->locator_set_name[0..63] = a->locator_set_name[0..63] (no-op) */
}

static inline void vl_api_show_lisp_pitr_t_endian (vl_api_show_lisp_pitr_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_show_lisp_pitr_reply_t_endian (vl_api_show_lisp_pitr_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    /* a->status = a->status (no-op) */
    /* a->locator_set_name[0..63] = a->locator_set_name[0..63] (no-op) */
}

#endif /* vl_endianfun */


#ifdef vl_api_version
vl_api_version(lisp.api, 0x4da3ff1c)

#endif

