/*
 * VLIB API definitions Mon Oct 30 07:35:18 2017
 * Input file: vnet/lisp-gpe/lisp_gpe.api.h
 * Automatically generated: please edit the input file NOT this file!
 */

#if defined(vl_msg_id)||defined(vl_union_id)||defined(vl_printfun) \
 ||defined(vl_endianfun)|| defined(vl_api_version)||defined(vl_typedefs) \
 ||defined(vl_msg_name)||defined(vl_msg_name_crc_list)
/* ok, something was selected */
#else
#warning no content included from vnet/lisp-gpe/lisp_gpe.api.h
#endif

#define VL_API_PACKED(x) x __attribute__ ((packed))


/****** Message ID / handler enum ******/

#ifdef vl_msg_id
/* typeonly: gpe_locator */
vl_msg_id(VL_API_GPE_ADD_DEL_FWD_ENTRY, vl_api_gpe_add_del_fwd_entry_t_handler)
vl_msg_id(VL_API_GPE_ADD_DEL_FWD_ENTRY_REPLY, vl_api_gpe_add_del_fwd_entry_reply_t_handler)
vl_msg_id(VL_API_GPE_ENABLE_DISABLE, vl_api_gpe_enable_disable_t_handler)
vl_msg_id(VL_API_GPE_ENABLE_DISABLE_REPLY, vl_api_gpe_enable_disable_reply_t_handler)
vl_msg_id(VL_API_GPE_ADD_DEL_IFACE, vl_api_gpe_add_del_iface_t_handler)
vl_msg_id(VL_API_GPE_ADD_DEL_IFACE_REPLY, vl_api_gpe_add_del_iface_reply_t_handler)
vl_msg_id(VL_API_GPE_FWD_ENTRY_VNIS_GET, vl_api_gpe_fwd_entry_vnis_get_t_handler)
vl_msg_id(VL_API_GPE_FWD_ENTRY_VNIS_GET_REPLY, vl_api_gpe_fwd_entry_vnis_get_reply_t_handler)
vl_msg_id(VL_API_GPE_FWD_ENTRIES_GET, vl_api_gpe_fwd_entries_get_t_handler)
/* typeonly: gpe_fwd_entry */
vl_msg_id(VL_API_GPE_FWD_ENTRIES_GET_REPLY, vl_api_gpe_fwd_entries_get_reply_t_handler)
vl_msg_id(VL_API_GPE_FWD_ENTRY_PATH_DUMP, vl_api_gpe_fwd_entry_path_dump_t_handler)
vl_msg_id(VL_API_GPE_FWD_ENTRY_PATH_DETAILS, vl_api_gpe_fwd_entry_path_details_t_handler)
vl_msg_id(VL_API_GPE_SET_ENCAP_MODE, vl_api_gpe_set_encap_mode_t_handler)
vl_msg_id(VL_API_GPE_SET_ENCAP_MODE_REPLY, vl_api_gpe_set_encap_mode_reply_t_handler)
vl_msg_id(VL_API_GPE_GET_ENCAP_MODE, vl_api_gpe_get_encap_mode_t_handler)
vl_msg_id(VL_API_GPE_GET_ENCAP_MODE_REPLY, vl_api_gpe_get_encap_mode_reply_t_handler)
vl_msg_id(VL_API_GPE_ADD_DEL_NATIVE_FWD_RPATH, vl_api_gpe_add_del_native_fwd_rpath_t_handler)
vl_msg_id(VL_API_GPE_ADD_DEL_NATIVE_FWD_RPATH_REPLY, vl_api_gpe_add_del_native_fwd_rpath_reply_t_handler)
vl_msg_id(VL_API_GPE_NATIVE_FWD_RPATHS_GET, vl_api_gpe_native_fwd_rpaths_get_t_handler)
/* typeonly: gpe_native_fwd_rpath */
vl_msg_id(VL_API_GPE_NATIVE_FWD_RPATHS_GET_REPLY, vl_api_gpe_native_fwd_rpaths_get_reply_t_handler)
#endif

/****** Message names ******/

#ifdef vl_msg_name
/* typeonly: gpe_locator */
vl_msg_name(vl_api_gpe_add_del_fwd_entry_t, 1)
vl_msg_name(vl_api_gpe_add_del_fwd_entry_reply_t, 1)
vl_msg_name(vl_api_gpe_enable_disable_t, 1)
vl_msg_name(vl_api_gpe_enable_disable_reply_t, 1)
vl_msg_name(vl_api_gpe_add_del_iface_t, 1)
vl_msg_name(vl_api_gpe_add_del_iface_reply_t, 1)
vl_msg_name(vl_api_gpe_fwd_entry_vnis_get_t, 1)
vl_msg_name(vl_api_gpe_fwd_entry_vnis_get_reply_t, 1)
vl_msg_name(vl_api_gpe_fwd_entries_get_t, 1)
/* typeonly: gpe_fwd_entry */
vl_msg_name(vl_api_gpe_fwd_entries_get_reply_t, 1)
vl_msg_name(vl_api_gpe_fwd_entry_path_dump_t, 1)
vl_msg_name(vl_api_gpe_fwd_entry_path_details_t, 1)
vl_msg_name(vl_api_gpe_set_encap_mode_t, 1)
vl_msg_name(vl_api_gpe_set_encap_mode_reply_t, 1)
vl_msg_name(vl_api_gpe_get_encap_mode_t, 1)
vl_msg_name(vl_api_gpe_get_encap_mode_reply_t, 1)
vl_msg_name(vl_api_gpe_add_del_native_fwd_rpath_t, 1)
vl_msg_name(vl_api_gpe_add_del_native_fwd_rpath_reply_t, 1)
vl_msg_name(vl_api_gpe_native_fwd_rpaths_get_t, 1)
/* typeonly: gpe_native_fwd_rpath */
vl_msg_name(vl_api_gpe_native_fwd_rpaths_get_reply_t, 1)
#endif


/****** Message name, crc list ******/

#ifdef vl_msg_name_crc_list
#define foreach_vl_msg_name_crc_lisp_gpe \
_(VL_API_GPE_ADD_DEL_FWD_ENTRY, gpe_add_del_fwd_entry, bcb43b69) \
_(VL_API_GPE_ADD_DEL_FWD_ENTRY_REPLY, gpe_add_del_fwd_entry_reply, a8d7fb73) \
_(VL_API_GPE_ENABLE_DISABLE, gpe_enable_disable, 05e310d8) \
_(VL_API_GPE_ENABLE_DISABLE_REPLY, gpe_enable_disable_reply, d021cf76) \
_(VL_API_GPE_ADD_DEL_IFACE, gpe_add_del_iface, e4870f5a) \
_(VL_API_GPE_ADD_DEL_IFACE_REPLY, gpe_add_del_iface_reply, 92a5cddb) \
_(VL_API_GPE_FWD_ENTRY_VNIS_GET, gpe_fwd_entry_vnis_get, ddc3a779) \
_(VL_API_GPE_FWD_ENTRY_VNIS_GET_REPLY, gpe_fwd_entry_vnis_get_reply, ba9d59e6) \
_(VL_API_GPE_FWD_ENTRIES_GET, gpe_fwd_entries_get, 113b9a39) \
_(VL_API_GPE_FWD_ENTRIES_GET_REPLY, gpe_fwd_entries_get_reply, 484da49c) \
_(VL_API_GPE_FWD_ENTRY_PATH_DUMP, gpe_fwd_entry_path_dump, 30b320f6) \
_(VL_API_GPE_FWD_ENTRY_PATH_DETAILS, gpe_fwd_entry_path_details, a9187578) \
_(VL_API_GPE_SET_ENCAP_MODE, gpe_set_encap_mode, 6b0767d1) \
_(VL_API_GPE_SET_ENCAP_MODE_REPLY, gpe_set_encap_mode_reply, dcadb033) \
_(VL_API_GPE_GET_ENCAP_MODE, gpe_get_encap_mode, c8c38e9f) \
_(VL_API_GPE_GET_ENCAP_MODE_REPLY, gpe_get_encap_mode_reply, 90637a31) \
_(VL_API_GPE_ADD_DEL_NATIVE_FWD_RPATH, gpe_add_del_native_fwd_rpath, da1517fb) \
_(VL_API_GPE_ADD_DEL_NATIVE_FWD_RPATH_REPLY, gpe_add_del_native_fwd_rpath_reply, 403f1258) \
_(VL_API_GPE_NATIVE_FWD_RPATHS_GET, gpe_native_fwd_rpaths_get, 2eeecb39) \
_(VL_API_GPE_NATIVE_FWD_RPATHS_GET_REPLY, gpe_native_fwd_rpaths_get_reply, cb9f7e1c) 
#endif


/****** Typedefs *****/

#ifdef vl_typedefs

typedef VL_API_PACKED(struct _vl_api_gpe_locator {
    u8 is_ip4;
    u8 weight;
    u8 addr[16];
}) vl_api_gpe_locator_t;

typedef VL_API_PACKED(struct _vl_api_gpe_add_del_fwd_entry {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 eid_type;
    u8 rmt_eid[16];
    u8 lcl_eid[16];
    u8 rmt_len;
    u8 lcl_len;
    u32 vni;
    u32 dp_table;
    u8 action;
    u32 loc_num;
    vl_api_gpe_locator_t locs[0];
}) vl_api_gpe_add_del_fwd_entry_t;

typedef VL_API_PACKED(struct _vl_api_gpe_add_del_fwd_entry_reply {
    u16 _vl_msg_id;
    i32 retval;
    u32 context;
    u32 fwd_entry_index;
}) vl_api_gpe_add_del_fwd_entry_reply_t;

typedef VL_API_PACKED(struct _vl_api_gpe_enable_disable {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_en;
}) vl_api_gpe_enable_disable_t;

typedef VL_API_PACKED(struct _vl_api_gpe_enable_disable_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_gpe_enable_disable_reply_t;

typedef VL_API_PACKED(struct _vl_api_gpe_add_del_iface {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 is_l2;
    u32 dp_table;
    u32 vni;
}) vl_api_gpe_add_del_iface_t;

typedef VL_API_PACKED(struct _vl_api_gpe_add_del_iface_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_gpe_add_del_iface_reply_t;

typedef VL_API_PACKED(struct _vl_api_gpe_fwd_entry_vnis_get {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_gpe_fwd_entry_vnis_get_t;

typedef VL_API_PACKED(struct _vl_api_gpe_fwd_entry_vnis_get_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 count;
    u32 vnis[0];
}) vl_api_gpe_fwd_entry_vnis_get_reply_t;

typedef VL_API_PACKED(struct _vl_api_gpe_fwd_entries_get {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 vni;
}) vl_api_gpe_fwd_entries_get_t;

typedef VL_API_PACKED(struct _vl_api_gpe_fwd_entry {
    u32 fwd_entry_index;
    u32 dp_table;
    u8 eid_type;
    u8 leid_prefix_len;
    u8 reid_prefix_len;
    u8 leid[16];
    u8 reid[16];
    u32 vni;
    u8 action;
}) vl_api_gpe_fwd_entry_t;

typedef VL_API_PACKED(struct _vl_api_gpe_fwd_entries_get_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 count;
    vl_api_gpe_fwd_entry_t entries[0];
}) vl_api_gpe_fwd_entries_get_reply_t;

typedef VL_API_PACKED(struct _vl_api_gpe_fwd_entry_path_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 fwd_entry_index;
}) vl_api_gpe_fwd_entry_path_dump_t;

typedef VL_API_PACKED(struct _vl_api_gpe_fwd_entry_path_details {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    vl_api_gpe_locator_t lcl_loc;
    vl_api_gpe_locator_t rmt_loc;
}) vl_api_gpe_fwd_entry_path_details_t;

typedef VL_API_PACKED(struct _vl_api_gpe_set_encap_mode {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 mode;
}) vl_api_gpe_set_encap_mode_t;

typedef VL_API_PACKED(struct _vl_api_gpe_set_encap_mode_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_gpe_set_encap_mode_reply_t;

typedef VL_API_PACKED(struct _vl_api_gpe_get_encap_mode {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_gpe_get_encap_mode_t;

typedef VL_API_PACKED(struct _vl_api_gpe_get_encap_mode_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 encap_mode;
}) vl_api_gpe_get_encap_mode_reply_t;

typedef VL_API_PACKED(struct _vl_api_gpe_add_del_native_fwd_rpath {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u32 table_id;
    u32 nh_sw_if_index;
    u8 is_ip4;
    u8 nh_addr[16];
}) vl_api_gpe_add_del_native_fwd_rpath_t;

typedef VL_API_PACKED(struct _vl_api_gpe_add_del_native_fwd_rpath_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_gpe_add_del_native_fwd_rpath_reply_t;

typedef VL_API_PACKED(struct _vl_api_gpe_native_fwd_rpaths_get {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_ip4;
}) vl_api_gpe_native_fwd_rpaths_get_t;

typedef VL_API_PACKED(struct _vl_api_gpe_native_fwd_rpath {
    u32 fib_index;
    u32 nh_sw_if_index;
    u8 is_ip4;
    u8 nh_addr[16];
}) vl_api_gpe_native_fwd_rpath_t;

typedef VL_API_PACKED(struct _vl_api_gpe_native_fwd_rpaths_get_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 count;
    vl_api_gpe_native_fwd_rpath_t entries[0];
}) vl_api_gpe_native_fwd_rpaths_get_reply_t;

#endif /* vl_typedefs */

/****** Discriminated Union Definitions *****/

#ifdef vl_union_id


#endif /* vl_union_id */

/****** Print functions *****/

#ifdef vl_printfun

#ifdef LP64
#define _uword_fmt "%lld"
#define _uword_cast (long long)
#else
#define _uword_fmt "%ld"
#define _uword_cast long
#endif

/***** manual: vl_api_gpe_locator_t_print  *****/

/***** manual: vl_api_gpe_add_del_fwd_entry_t_print  *****/

static inline void *vl_api_gpe_add_del_fwd_entry_reply_t_print (vl_api_gpe_add_del_fwd_entry_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_gpe_add_del_fwd_entry_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "fwd_entry_index: %u\n", (unsigned) a->fwd_entry_index);
    return handle;
}

static inline void *vl_api_gpe_enable_disable_t_print (vl_api_gpe_enable_disable_t *a,void *handle)
{
    vl_print(handle, "vl_api_gpe_enable_disable_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_en: %u\n", (unsigned) a->is_en);
    return handle;
}

static inline void *vl_api_gpe_enable_disable_reply_t_print (vl_api_gpe_enable_disable_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_gpe_enable_disable_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_gpe_add_del_iface_t_print (vl_api_gpe_add_del_iface_t *a,void *handle)
{
    vl_print(handle, "vl_api_gpe_add_del_iface_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "is_l2: %u\n", (unsigned) a->is_l2);
    vl_print(handle, "dp_table: %u\n", (unsigned) a->dp_table);
    vl_print(handle, "vni: %u\n", (unsigned) a->vni);
    return handle;
}

static inline void *vl_api_gpe_add_del_iface_reply_t_print (vl_api_gpe_add_del_iface_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_gpe_add_del_iface_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_gpe_fwd_entry_vnis_get_t_print (vl_api_gpe_fwd_entry_vnis_get_t *a,void *handle)
{
    vl_print(handle, "vl_api_gpe_fwd_entry_vnis_get_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

/***** manual: vl_api_gpe_fwd_entry_vnis_get_reply_t_print  *****/

static inline void *vl_api_gpe_fwd_entries_get_t_print (vl_api_gpe_fwd_entries_get_t *a,void *handle)
{
    vl_print(handle, "vl_api_gpe_fwd_entries_get_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "vni: %u\n", (unsigned) a->vni);
    return handle;
}

/***** manual: vl_api_gpe_fwd_entry_t_print  *****/

/***** manual: vl_api_gpe_fwd_entries_get_reply_t_print  *****/

static inline void *vl_api_gpe_fwd_entry_path_dump_t_print (vl_api_gpe_fwd_entry_path_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_gpe_fwd_entry_path_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "fwd_entry_index: %u\n", (unsigned) a->fwd_entry_index);
    return handle;
}

/***** manual: vl_api_gpe_fwd_entry_path_details_t_print  *****/

static inline void *vl_api_gpe_set_encap_mode_t_print (vl_api_gpe_set_encap_mode_t *a,void *handle)
{
    vl_print(handle, "vl_api_gpe_set_encap_mode_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "mode: %u\n", (unsigned) a->mode);
    return handle;
}

static inline void *vl_api_gpe_set_encap_mode_reply_t_print (vl_api_gpe_set_encap_mode_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_gpe_set_encap_mode_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_gpe_get_encap_mode_t_print (vl_api_gpe_get_encap_mode_t *a,void *handle)
{
    vl_print(handle, "vl_api_gpe_get_encap_mode_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_gpe_get_encap_mode_reply_t_print (vl_api_gpe_get_encap_mode_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_gpe_get_encap_mode_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "encap_mode: %u\n", (unsigned) a->encap_mode);
    return handle;
}

static inline void *vl_api_gpe_add_del_native_fwd_rpath_t_print (vl_api_gpe_add_del_native_fwd_rpath_t *a,void *handle)
{
    vl_print(handle, "vl_api_gpe_add_del_native_fwd_rpath_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "table_id: %u\n", (unsigned) a->table_id);
    vl_print(handle, "nh_sw_if_index: %u\n", (unsigned) a->nh_sw_if_index);
    vl_print(handle, "is_ip4: %u\n", (unsigned) a->is_ip4);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "nh_addr[%d]: %u\n", _i, a->nh_addr[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_gpe_add_del_native_fwd_rpath_reply_t_print (vl_api_gpe_add_del_native_fwd_rpath_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_gpe_add_del_native_fwd_rpath_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_gpe_native_fwd_rpaths_get_t_print (vl_api_gpe_native_fwd_rpaths_get_t *a,void *handle)
{
    vl_print(handle, "vl_api_gpe_native_fwd_rpaths_get_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_ip4: %u\n", (unsigned) a->is_ip4);
    return handle;
}

/***** manual: vl_api_gpe_native_fwd_rpath_t_print  *****/

/***** manual: vl_api_gpe_native_fwd_rpaths_get_reply_t_print  *****/

#endif /* vl_printfun */


/****** Endian swap functions *****/

#ifdef vl_endianfun

#undef clib_net_to_host_uword
#ifdef LP64
#define clib_net_to_host_uword clib_net_to_host_u64
#else
#define clib_net_to_host_uword clib_net_to_host_u32
#endif

/***** manual: vl_api_gpe_locator_t_endian  *****/

/***** manual: vl_api_gpe_add_del_fwd_entry_t_endian  *****/

static inline void vl_api_gpe_add_del_fwd_entry_reply_t_endian (vl_api_gpe_add_del_fwd_entry_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->retval = clib_net_to_host_u32(a->retval);
    a->context = clib_net_to_host_u32(a->context);
    a->fwd_entry_index = clib_net_to_host_u32(a->fwd_entry_index);
}

static inline void vl_api_gpe_enable_disable_t_endian (vl_api_gpe_enable_disable_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_en = a->is_en (no-op) */
}

static inline void vl_api_gpe_enable_disable_reply_t_endian (vl_api_gpe_enable_disable_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_gpe_add_del_iface_t_endian (vl_api_gpe_add_del_iface_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    /* a->is_l2 = a->is_l2 (no-op) */
    a->dp_table = clib_net_to_host_u32(a->dp_table);
    a->vni = clib_net_to_host_u32(a->vni);
}

static inline void vl_api_gpe_add_del_iface_reply_t_endian (vl_api_gpe_add_del_iface_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_gpe_fwd_entry_vnis_get_t_endian (vl_api_gpe_fwd_entry_vnis_get_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

/***** manual: vl_api_gpe_fwd_entry_vnis_get_reply_t_endian  *****/

static inline void vl_api_gpe_fwd_entries_get_t_endian (vl_api_gpe_fwd_entries_get_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->vni = clib_net_to_host_u32(a->vni);
}

/***** manual: vl_api_gpe_fwd_entry_t_endian  *****/

/***** manual: vl_api_gpe_fwd_entries_get_reply_t_endian  *****/

static inline void vl_api_gpe_fwd_entry_path_dump_t_endian (vl_api_gpe_fwd_entry_path_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->fwd_entry_index = clib_net_to_host_u32(a->fwd_entry_index);
}

/***** manual: vl_api_gpe_fwd_entry_path_details_t_endian  *****/

static inline void vl_api_gpe_set_encap_mode_t_endian (vl_api_gpe_set_encap_mode_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->mode = a->mode (no-op) */
}

static inline void vl_api_gpe_set_encap_mode_reply_t_endian (vl_api_gpe_set_encap_mode_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_gpe_get_encap_mode_t_endian (vl_api_gpe_get_encap_mode_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_gpe_get_encap_mode_reply_t_endian (vl_api_gpe_get_encap_mode_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    /* a->encap_mode = a->encap_mode (no-op) */
}

static inline void vl_api_gpe_add_del_native_fwd_rpath_t_endian (vl_api_gpe_add_del_native_fwd_rpath_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    a->table_id = clib_net_to_host_u32(a->table_id);
    a->nh_sw_if_index = clib_net_to_host_u32(a->nh_sw_if_index);
    /* a->is_ip4 = a->is_ip4 (no-op) */
    /* a->nh_addr[0..15] = a->nh_addr[0..15] (no-op) */
}

static inline void vl_api_gpe_add_del_native_fwd_rpath_reply_t_endian (vl_api_gpe_add_del_native_fwd_rpath_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_gpe_native_fwd_rpaths_get_t_endian (vl_api_gpe_native_fwd_rpaths_get_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_ip4 = a->is_ip4 (no-op) */
}

/***** manual: vl_api_gpe_native_fwd_rpath_t_endian  *****/

/***** manual: vl_api_gpe_native_fwd_rpaths_get_reply_t_endian  *****/

#endif /* vl_endianfun */


#ifdef vl_api_version
vl_api_version(lisp_gpe.api, 0xa073ab69)

#endif

