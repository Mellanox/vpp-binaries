/*
 * VLIB API definitions Mon Oct 30 07:35:18 2017
 * Input file: vnet/map/map.api.h
 * Automatically generated: please edit the input file NOT this file!
 */

#if defined(vl_msg_id)||defined(vl_union_id)||defined(vl_printfun) \
 ||defined(vl_endianfun)|| defined(vl_api_version)||defined(vl_typedefs) \
 ||defined(vl_msg_name)||defined(vl_msg_name_crc_list)
/* ok, something was selected */
#else
#warning no content included from vnet/map/map.api.h
#endif

#define VL_API_PACKED(x) x __attribute__ ((packed))


/****** Message ID / handler enum ******/

#ifdef vl_msg_id
vl_msg_id(VL_API_MAP_ADD_DOMAIN, vl_api_map_add_domain_t_handler)
vl_msg_id(VL_API_MAP_ADD_DOMAIN_REPLY, vl_api_map_add_domain_reply_t_handler)
vl_msg_id(VL_API_MAP_DEL_DOMAIN, vl_api_map_del_domain_t_handler)
vl_msg_id(VL_API_MAP_DEL_DOMAIN_REPLY, vl_api_map_del_domain_reply_t_handler)
vl_msg_id(VL_API_MAP_ADD_DEL_RULE, vl_api_map_add_del_rule_t_handler)
vl_msg_id(VL_API_MAP_ADD_DEL_RULE_REPLY, vl_api_map_add_del_rule_reply_t_handler)
vl_msg_id(VL_API_MAP_DOMAIN_DUMP, vl_api_map_domain_dump_t_handler)
vl_msg_id(VL_API_MAP_DOMAIN_DETAILS, vl_api_map_domain_details_t_handler)
vl_msg_id(VL_API_MAP_RULE_DUMP, vl_api_map_rule_dump_t_handler)
vl_msg_id(VL_API_MAP_RULE_DETAILS, vl_api_map_rule_details_t_handler)
vl_msg_id(VL_API_MAP_SUMMARY_STATS, vl_api_map_summary_stats_t_handler)
vl_msg_id(VL_API_MAP_SUMMARY_STATS_REPLY, vl_api_map_summary_stats_reply_t_handler)
#endif

/****** Message names ******/

#ifdef vl_msg_name
vl_msg_name(vl_api_map_add_domain_t, 1)
vl_msg_name(vl_api_map_add_domain_reply_t, 1)
vl_msg_name(vl_api_map_del_domain_t, 1)
vl_msg_name(vl_api_map_del_domain_reply_t, 1)
vl_msg_name(vl_api_map_add_del_rule_t, 1)
vl_msg_name(vl_api_map_add_del_rule_reply_t, 1)
vl_msg_name(vl_api_map_domain_dump_t, 1)
vl_msg_name(vl_api_map_domain_details_t, 1)
vl_msg_name(vl_api_map_rule_dump_t, 1)
vl_msg_name(vl_api_map_rule_details_t, 1)
vl_msg_name(vl_api_map_summary_stats_t, 1)
vl_msg_name(vl_api_map_summary_stats_reply_t, 1)
#endif


/****** Message name, crc list ******/

#ifdef vl_msg_name_crc_list
#define foreach_vl_msg_name_crc_map \
_(VL_API_MAP_ADD_DOMAIN, map_add_domain, e83fafb7) \
_(VL_API_MAP_ADD_DOMAIN_REPLY, map_add_domain_reply, f6c61861) \
_(VL_API_MAP_DEL_DOMAIN, map_del_domain, 4c06875c) \
_(VL_API_MAP_DEL_DOMAIN_REPLY, map_del_domain_reply, 7c61a925) \
_(VL_API_MAP_ADD_DEL_RULE, map_add_del_rule, 3e3644ad) \
_(VL_API_MAP_ADD_DEL_RULE_REPLY, map_add_del_rule_reply, 02c9e765) \
_(VL_API_MAP_DOMAIN_DUMP, map_domain_dump, b64dff5d) \
_(VL_API_MAP_DOMAIN_DETAILS, map_domain_details, caa121eb) \
_(VL_API_MAP_RULE_DUMP, map_rule_dump, 11d0e36b) \
_(VL_API_MAP_RULE_DETAILS, map_rule_details, 7ef2b612) \
_(VL_API_MAP_SUMMARY_STATS, map_summary_stats, f6a12980) \
_(VL_API_MAP_SUMMARY_STATS_REPLY, map_summary_stats_reply, 700b3e21) 
#endif


/****** Typedefs *****/

#ifdef vl_typedefs

typedef VL_API_PACKED(struct _vl_api_map_add_domain {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 ip6_prefix[16];
    u8 ip4_prefix[4];
    u8 ip6_src[16];
    u8 ip6_prefix_len;
    u8 ip4_prefix_len;
    u8 ip6_src_prefix_len;
    u8 ea_bits_len;
    u8 psid_offset;
    u8 psid_length;
    u8 is_translation;
    u16 mtu;
}) vl_api_map_add_domain_t;

typedef VL_API_PACKED(struct _vl_api_map_add_domain_reply {
    u16 _vl_msg_id;
    u32 context;
    u32 index;
    i32 retval;
}) vl_api_map_add_domain_reply_t;

typedef VL_API_PACKED(struct _vl_api_map_del_domain {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 index;
}) vl_api_map_del_domain_t;

typedef VL_API_PACKED(struct _vl_api_map_del_domain_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_map_del_domain_reply_t;

typedef VL_API_PACKED(struct _vl_api_map_add_del_rule {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 index;
    u8 is_add;
    u8 ip6_dst[16];
    u16 psid;
}) vl_api_map_add_del_rule_t;

typedef VL_API_PACKED(struct _vl_api_map_add_del_rule_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_map_add_del_rule_reply_t;

typedef VL_API_PACKED(struct _vl_api_map_domain_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_map_domain_dump_t;

typedef VL_API_PACKED(struct _vl_api_map_domain_details {
    u16 _vl_msg_id;
    u32 context;
    u32 domain_index;
    u8 ip6_prefix[16];
    u8 ip4_prefix[4];
    u8 ip6_src[16];
    u8 ip6_prefix_len;
    u8 ip4_prefix_len;
    u8 ip6_src_len;
    u8 ea_bits_len;
    u8 psid_offset;
    u8 psid_length;
    u8 flags;
    u16 mtu;
    u8 is_translation;
}) vl_api_map_domain_details_t;

typedef VL_API_PACKED(struct _vl_api_map_rule_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 domain_index;
}) vl_api_map_rule_dump_t;

typedef VL_API_PACKED(struct _vl_api_map_rule_details {
    u16 _vl_msg_id;
    u32 context;
    u8 ip6_dst[16];
    u16 psid;
}) vl_api_map_rule_details_t;

typedef VL_API_PACKED(struct _vl_api_map_summary_stats {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_map_summary_stats_t;

typedef VL_API_PACKED(struct _vl_api_map_summary_stats_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u64 total_bindings;
    u64 total_pkts[2];
    u64 total_bytes[2];
    u64 total_ip4_fragments;
    u64 total_security_check[2];
}) vl_api_map_summary_stats_reply_t;

#endif /* vl_typedefs */

/****** Discriminated Union Definitions *****/

#ifdef vl_union_id


#endif /* vl_union_id */

/****** Print functions *****/

#ifdef vl_printfun

#ifdef LP64
#define _uword_fmt "%lld"
#define _uword_cast (long long)
#else
#define _uword_fmt "%ld"
#define _uword_cast long
#endif

static inline void *vl_api_map_add_domain_t_print (vl_api_map_add_domain_t *a,void *handle)
{
    vl_print(handle, "vl_api_map_add_domain_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "ip6_prefix[%d]: %u\n", _i, a->ip6_prefix[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "ip4_prefix[%d]: %u\n", _i, a->ip4_prefix[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "ip6_src[%d]: %u\n", _i, a->ip6_src[_i]);
        }
    }
    vl_print(handle, "ip6_prefix_len: %u\n", (unsigned) a->ip6_prefix_len);
    vl_print(handle, "ip4_prefix_len: %u\n", (unsigned) a->ip4_prefix_len);
    vl_print(handle, "ip6_src_prefix_len: %u\n", (unsigned) a->ip6_src_prefix_len);
    vl_print(handle, "ea_bits_len: %u\n", (unsigned) a->ea_bits_len);
    vl_print(handle, "psid_offset: %u\n", (unsigned) a->psid_offset);
    vl_print(handle, "psid_length: %u\n", (unsigned) a->psid_length);
    vl_print(handle, "is_translation: %u\n", (unsigned) a->is_translation);
    vl_print(handle, "mtu: %u\n", (unsigned) a->mtu);
    return handle;
}

static inline void *vl_api_map_add_domain_reply_t_print (vl_api_map_add_domain_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_map_add_domain_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "index: %u\n", (unsigned) a->index);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_map_del_domain_t_print (vl_api_map_del_domain_t *a,void *handle)
{
    vl_print(handle, "vl_api_map_del_domain_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "index: %u\n", (unsigned) a->index);
    return handle;
}

static inline void *vl_api_map_del_domain_reply_t_print (vl_api_map_del_domain_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_map_del_domain_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_map_add_del_rule_t_print (vl_api_map_add_del_rule_t *a,void *handle)
{
    vl_print(handle, "vl_api_map_add_del_rule_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "index: %u\n", (unsigned) a->index);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "ip6_dst[%d]: %u\n", _i, a->ip6_dst[_i]);
        }
    }
    vl_print(handle, "psid: %u\n", (unsigned) a->psid);
    return handle;
}

static inline void *vl_api_map_add_del_rule_reply_t_print (vl_api_map_add_del_rule_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_map_add_del_rule_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_map_domain_dump_t_print (vl_api_map_domain_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_map_domain_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_map_domain_details_t_print (vl_api_map_domain_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_map_domain_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "domain_index: %u\n", (unsigned) a->domain_index);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "ip6_prefix[%d]: %u\n", _i, a->ip6_prefix[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "ip4_prefix[%d]: %u\n", _i, a->ip4_prefix[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "ip6_src[%d]: %u\n", _i, a->ip6_src[_i]);
        }
    }
    vl_print(handle, "ip6_prefix_len: %u\n", (unsigned) a->ip6_prefix_len);
    vl_print(handle, "ip4_prefix_len: %u\n", (unsigned) a->ip4_prefix_len);
    vl_print(handle, "ip6_src_len: %u\n", (unsigned) a->ip6_src_len);
    vl_print(handle, "ea_bits_len: %u\n", (unsigned) a->ea_bits_len);
    vl_print(handle, "psid_offset: %u\n", (unsigned) a->psid_offset);
    vl_print(handle, "psid_length: %u\n", (unsigned) a->psid_length);
    vl_print(handle, "flags: %u\n", (unsigned) a->flags);
    vl_print(handle, "mtu: %u\n", (unsigned) a->mtu);
    vl_print(handle, "is_translation: %u\n", (unsigned) a->is_translation);
    return handle;
}

static inline void *vl_api_map_rule_dump_t_print (vl_api_map_rule_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_map_rule_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "domain_index: %u\n", (unsigned) a->domain_index);
    return handle;
}

static inline void *vl_api_map_rule_details_t_print (vl_api_map_rule_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_map_rule_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "ip6_dst[%d]: %u\n", _i, a->ip6_dst[_i]);
        }
    }
    vl_print(handle, "psid: %u\n", (unsigned) a->psid);
    return handle;
}

static inline void *vl_api_map_summary_stats_t_print (vl_api_map_summary_stats_t *a,void *handle)
{
    vl_print(handle, "vl_api_map_summary_stats_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_map_summary_stats_reply_t_print (vl_api_map_summary_stats_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_map_summary_stats_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "total_bindings: %llu\n", (long long) a->total_bindings);
    {
        int _i;
        for (_i = 0; _i < 2; _i++) {
            vl_print(handle, "total_pkts[%d]: %llu\n", _i, a->total_pkts[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 2; _i++) {
            vl_print(handle, "total_bytes[%d]: %llu\n", _i, a->total_bytes[_i]);
        }
    }
    vl_print(handle, "total_ip4_fragments: %llu\n", (long long) a->total_ip4_fragments);
    {
        int _i;
        for (_i = 0; _i < 2; _i++) {
            vl_print(handle, "total_security_check[%d]: %llu\n", _i, a->total_security_check[_i]);
        }
    }
    return handle;
}

#endif /* vl_printfun */


/****** Endian swap functions *****/

#ifdef vl_endianfun

#undef clib_net_to_host_uword
#ifdef LP64
#define clib_net_to_host_uword clib_net_to_host_u64
#else
#define clib_net_to_host_uword clib_net_to_host_u32
#endif

static inline void vl_api_map_add_domain_t_endian (vl_api_map_add_domain_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->ip6_prefix[0..15] = a->ip6_prefix[0..15] (no-op) */
    /* a->ip4_prefix[0..3] = a->ip4_prefix[0..3] (no-op) */
    /* a->ip6_src[0..15] = a->ip6_src[0..15] (no-op) */
    /* a->ip6_prefix_len = a->ip6_prefix_len (no-op) */
    /* a->ip4_prefix_len = a->ip4_prefix_len (no-op) */
    /* a->ip6_src_prefix_len = a->ip6_src_prefix_len (no-op) */
    /* a->ea_bits_len = a->ea_bits_len (no-op) */
    /* a->psid_offset = a->psid_offset (no-op) */
    /* a->psid_length = a->psid_length (no-op) */
    /* a->is_translation = a->is_translation (no-op) */
    a->mtu = clib_net_to_host_u16(a->mtu);
}

static inline void vl_api_map_add_domain_reply_t_endian (vl_api_map_add_domain_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->index = clib_net_to_host_u32(a->index);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_map_del_domain_t_endian (vl_api_map_del_domain_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->index = clib_net_to_host_u32(a->index);
}

static inline void vl_api_map_del_domain_reply_t_endian (vl_api_map_del_domain_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_map_add_del_rule_t_endian (vl_api_map_add_del_rule_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->index = clib_net_to_host_u32(a->index);
    /* a->is_add = a->is_add (no-op) */
    /* a->ip6_dst[0..15] = a->ip6_dst[0..15] (no-op) */
    a->psid = clib_net_to_host_u16(a->psid);
}

static inline void vl_api_map_add_del_rule_reply_t_endian (vl_api_map_add_del_rule_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_map_domain_dump_t_endian (vl_api_map_domain_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_map_domain_details_t_endian (vl_api_map_domain_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->domain_index = clib_net_to_host_u32(a->domain_index);
    /* a->ip6_prefix[0..15] = a->ip6_prefix[0..15] (no-op) */
    /* a->ip4_prefix[0..3] = a->ip4_prefix[0..3] (no-op) */
    /* a->ip6_src[0..15] = a->ip6_src[0..15] (no-op) */
    /* a->ip6_prefix_len = a->ip6_prefix_len (no-op) */
    /* a->ip4_prefix_len = a->ip4_prefix_len (no-op) */
    /* a->ip6_src_len = a->ip6_src_len (no-op) */
    /* a->ea_bits_len = a->ea_bits_len (no-op) */
    /* a->psid_offset = a->psid_offset (no-op) */
    /* a->psid_length = a->psid_length (no-op) */
    /* a->flags = a->flags (no-op) */
    a->mtu = clib_net_to_host_u16(a->mtu);
    /* a->is_translation = a->is_translation (no-op) */
}

static inline void vl_api_map_rule_dump_t_endian (vl_api_map_rule_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->domain_index = clib_net_to_host_u32(a->domain_index);
}

static inline void vl_api_map_rule_details_t_endian (vl_api_map_rule_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    /* a->ip6_dst[0..15] = a->ip6_dst[0..15] (no-op) */
    a->psid = clib_net_to_host_u16(a->psid);
}

static inline void vl_api_map_summary_stats_t_endian (vl_api_map_summary_stats_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_map_summary_stats_reply_t_endian (vl_api_map_summary_stats_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->total_bindings = clib_net_to_host_u64(a->total_bindings);
    {
        int _i;
        for (_i = 0; _i < 2; _i++) {
            a->total_pkts[_i] = clib_net_to_host_u64(a->total_pkts[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 2; _i++) {
            a->total_bytes[_i] = clib_net_to_host_u64(a->total_bytes[_i]);
        }
    }
    a->total_ip4_fragments = clib_net_to_host_u64(a->total_ip4_fragments);
    {
        int _i;
        for (_i = 0; _i < 2; _i++) {
            a->total_security_check[_i] = clib_net_to_host_u64(a->total_security_check[_i]);
        }
    }
}

#endif /* vl_endianfun */


#ifdef vl_api_version
vl_api_version(map.api, 0xa09b8624)

#endif

