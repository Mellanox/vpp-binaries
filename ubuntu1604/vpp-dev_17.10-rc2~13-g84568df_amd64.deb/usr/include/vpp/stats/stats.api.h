/*
 * VLIB API definitions Mon Oct 30 07:35:18 2017
 * Input file: vpp/stats/stats.api.h
 * Automatically generated: please edit the input file NOT this file!
 */

#if defined(vl_msg_id)||defined(vl_union_id)||defined(vl_printfun) \
 ||defined(vl_endianfun)|| defined(vl_api_version)||defined(vl_typedefs) \
 ||defined(vl_msg_name)||defined(vl_msg_name_crc_list)
/* ok, something was selected */
#else
#warning no content included from vpp/stats/stats.api.h
#endif

#define VL_API_PACKED(x) x __attribute__ ((packed))


/****** Message ID / handler enum ******/

#ifdef vl_msg_id
vl_msg_id(VL_API_WANT_STATS, vl_api_want_stats_t_handler)
vl_msg_id(VL_API_WANT_STATS_REPLY, vl_api_want_stats_reply_t_handler)
vl_msg_id(VL_API_WANT_INTERFACE_SIMPLE_STATS, vl_api_want_interface_simple_stats_t_handler)
vl_msg_id(VL_API_WANT_INTERFACE_SIMPLE_STATS_REPLY, vl_api_want_interface_simple_stats_reply_t_handler)
vl_msg_id(VL_API_WANT_PER_INTERFACE_SIMPLE_STATS, vl_api_want_per_interface_simple_stats_t_handler)
vl_msg_id(VL_API_WANT_PER_INTERFACE_SIMPLE_STATS_REPLY, vl_api_want_per_interface_simple_stats_reply_t_handler)
vl_msg_id(VL_API_WANT_INTERFACE_COMBINED_STATS, vl_api_want_interface_combined_stats_t_handler)
vl_msg_id(VL_API_WANT_INTERFACE_COMBINED_STATS_REPLY, vl_api_want_interface_combined_stats_reply_t_handler)
vl_msg_id(VL_API_WANT_PER_INTERFACE_COMBINED_STATS, vl_api_want_per_interface_combined_stats_t_handler)
vl_msg_id(VL_API_WANT_PER_INTERFACE_COMBINED_STATS_REPLY, vl_api_want_per_interface_combined_stats_reply_t_handler)
vl_msg_id(VL_API_WANT_IP4_FIB_STATS, vl_api_want_ip4_fib_stats_t_handler)
vl_msg_id(VL_API_WANT_IP4_FIB_STATS_REPLY, vl_api_want_ip4_fib_stats_reply_t_handler)
vl_msg_id(VL_API_WANT_IP6_FIB_STATS, vl_api_want_ip6_fib_stats_t_handler)
vl_msg_id(VL_API_WANT_IP6_FIB_STATS_REPLY, vl_api_want_ip6_fib_stats_reply_t_handler)
vl_msg_id(VL_API_WANT_IP4_NBR_STATS, vl_api_want_ip4_nbr_stats_t_handler)
vl_msg_id(VL_API_WANT_IP4_NBR_STATS_REPLY, vl_api_want_ip4_nbr_stats_reply_t_handler)
vl_msg_id(VL_API_WANT_IP6_NBR_STATS, vl_api_want_ip6_nbr_stats_t_handler)
vl_msg_id(VL_API_WANT_IP6_NBR_STATS_REPLY, vl_api_want_ip6_nbr_stats_reply_t_handler)
/* typeonly: ip4_fib_counter */
vl_msg_id(VL_API_VNET_IP4_FIB_COUNTERS, vl_api_vnet_ip4_fib_counters_t_handler)
/* typeonly: ip4_nbr_counter */
vl_msg_id(VL_API_VNET_IP4_NBR_COUNTERS, vl_api_vnet_ip4_nbr_counters_t_handler)
/* typeonly: ip6_fib_counter */
vl_msg_id(VL_API_VNET_IP6_FIB_COUNTERS, vl_api_vnet_ip6_fib_counters_t_handler)
/* typeonly: ip6_nbr_counter */
vl_msg_id(VL_API_VNET_IP6_NBR_COUNTERS, vl_api_vnet_ip6_nbr_counters_t_handler)
vl_msg_id(VL_API_VNET_GET_SUMMARY_STATS, vl_api_vnet_get_summary_stats_t_handler)
vl_msg_id(VL_API_VNET_GET_SUMMARY_STATS_REPLY, vl_api_vnet_get_summary_stats_reply_t_handler)
#endif

/****** Message names ******/

#ifdef vl_msg_name
vl_msg_name(vl_api_want_stats_t, 1)
vl_msg_name(vl_api_want_stats_reply_t, 1)
vl_msg_name(vl_api_want_interface_simple_stats_t, 1)
vl_msg_name(vl_api_want_interface_simple_stats_reply_t, 1)
vl_msg_name(vl_api_want_per_interface_simple_stats_t, 1)
vl_msg_name(vl_api_want_per_interface_simple_stats_reply_t, 1)
vl_msg_name(vl_api_want_interface_combined_stats_t, 1)
vl_msg_name(vl_api_want_interface_combined_stats_reply_t, 1)
vl_msg_name(vl_api_want_per_interface_combined_stats_t, 1)
vl_msg_name(vl_api_want_per_interface_combined_stats_reply_t, 1)
vl_msg_name(vl_api_want_ip4_fib_stats_t, 1)
vl_msg_name(vl_api_want_ip4_fib_stats_reply_t, 1)
vl_msg_name(vl_api_want_ip6_fib_stats_t, 1)
vl_msg_name(vl_api_want_ip6_fib_stats_reply_t, 1)
vl_msg_name(vl_api_want_ip4_nbr_stats_t, 1)
vl_msg_name(vl_api_want_ip4_nbr_stats_reply_t, 1)
vl_msg_name(vl_api_want_ip6_nbr_stats_t, 1)
vl_msg_name(vl_api_want_ip6_nbr_stats_reply_t, 1)
/* typeonly: ip4_fib_counter */
vl_msg_name(vl_api_vnet_ip4_fib_counters_t, 1)
/* typeonly: ip4_nbr_counter */
vl_msg_name(vl_api_vnet_ip4_nbr_counters_t, 1)
/* typeonly: ip6_fib_counter */
vl_msg_name(vl_api_vnet_ip6_fib_counters_t, 1)
/* typeonly: ip6_nbr_counter */
vl_msg_name(vl_api_vnet_ip6_nbr_counters_t, 1)
vl_msg_name(vl_api_vnet_get_summary_stats_t, 1)
vl_msg_name(vl_api_vnet_get_summary_stats_reply_t, 1)
#endif


/****** Message name, crc list ******/

#ifdef vl_msg_name_crc_list
#define foreach_vl_msg_name_crc_stats \
_(VL_API_WANT_STATS, want_stats, 4f2effb4) \
_(VL_API_WANT_STATS_REPLY, want_stats_reply, b36abf5f) \
_(VL_API_WANT_INTERFACE_SIMPLE_STATS, want_interface_simple_stats, bb4739ed) \
_(VL_API_WANT_INTERFACE_SIMPLE_STATS_REPLY, want_interface_simple_stats_reply, 5163615b) \
_(VL_API_WANT_PER_INTERFACE_SIMPLE_STATS, want_per_interface_simple_stats, 0165e6f2) \
_(VL_API_WANT_PER_INTERFACE_SIMPLE_STATS_REPLY, want_per_interface_simple_stats_reply, 720ee096) \
_(VL_API_WANT_INTERFACE_COMBINED_STATS, want_interface_combined_stats, a98830b6) \
_(VL_API_WANT_INTERFACE_COMBINED_STATS_REPLY, want_interface_combined_stats_reply, b260196d) \
_(VL_API_WANT_PER_INTERFACE_COMBINED_STATS, want_per_interface_combined_stats, d914890f) \
_(VL_API_WANT_PER_INTERFACE_COMBINED_STATS_REPLY, want_per_interface_combined_stats_reply, 06158495) \
_(VL_API_WANT_IP4_FIB_STATS, want_ip4_fib_stats, 6ce4937d) \
_(VL_API_WANT_IP4_FIB_STATS_REPLY, want_ip4_fib_stats_reply, d337cb77) \
_(VL_API_WANT_IP6_FIB_STATS, want_ip6_fib_stats, 01697516) \
_(VL_API_WANT_IP6_FIB_STATS_REPLY, want_ip6_fib_stats_reply, 531708ab) \
_(VL_API_WANT_IP4_NBR_STATS, want_ip4_nbr_stats, 6bea26e1) \
_(VL_API_WANT_IP4_NBR_STATS_REPLY, want_ip4_nbr_stats_reply, e27d62cd) \
_(VL_API_WANT_IP6_NBR_STATS, want_ip6_nbr_stats, 0667c08a) \
_(VL_API_WANT_IP6_NBR_STATS_REPLY, want_ip6_nbr_stats_reply, 625da111) \
_(VL_API_VNET_IP4_FIB_COUNTERS, vnet_ip4_fib_counters, 1ab9d6c5) \
_(VL_API_VNET_IP4_NBR_COUNTERS, vnet_ip4_nbr_counters, fc2b5092) \
_(VL_API_VNET_IP6_FIB_COUNTERS, vnet_ip6_fib_counters, 9ab453ae) \
_(VL_API_VNET_IP6_NBR_COUNTERS, vnet_ip6_nbr_counters, 181b673f) \
_(VL_API_VNET_GET_SUMMARY_STATS, vnet_get_summary_stats, 16435c20) \
_(VL_API_VNET_GET_SUMMARY_STATS_REPLY, vnet_get_summary_stats_reply, 675ce280) 
#endif


/****** Typedefs *****/

#ifdef vl_typedefs

typedef VL_API_PACKED(struct _vl_api_want_stats {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 enable_disable;
    u32 pid;
}) vl_api_want_stats_t;

typedef VL_API_PACKED(struct _vl_api_want_stats_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_want_stats_reply_t;

typedef VL_API_PACKED(struct _vl_api_want_interface_simple_stats {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 enable_disable;
    u32 pid;
}) vl_api_want_interface_simple_stats_t;

typedef VL_API_PACKED(struct _vl_api_want_interface_simple_stats_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_want_interface_simple_stats_reply_t;

typedef VL_API_PACKED(struct _vl_api_want_per_interface_simple_stats {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 enable_disable;
    u32 pid;
    u32 num;
    u32 sw_ifs[0];
}) vl_api_want_per_interface_simple_stats_t;

typedef VL_API_PACKED(struct _vl_api_want_per_interface_simple_stats_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_want_per_interface_simple_stats_reply_t;

typedef VL_API_PACKED(struct _vl_api_want_interface_combined_stats {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 enable_disable;
    u32 pid;
}) vl_api_want_interface_combined_stats_t;

typedef VL_API_PACKED(struct _vl_api_want_interface_combined_stats_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_want_interface_combined_stats_reply_t;

typedef VL_API_PACKED(struct _vl_api_want_per_interface_combined_stats {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 enable_disable;
    u32 pid;
    u32 num;
    u32 sw_ifs[0];
}) vl_api_want_per_interface_combined_stats_t;

typedef VL_API_PACKED(struct _vl_api_want_per_interface_combined_stats_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_want_per_interface_combined_stats_reply_t;

typedef VL_API_PACKED(struct _vl_api_want_ip4_fib_stats {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 enable_disable;
    u32 pid;
}) vl_api_want_ip4_fib_stats_t;

typedef VL_API_PACKED(struct _vl_api_want_ip4_fib_stats_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_want_ip4_fib_stats_reply_t;

typedef VL_API_PACKED(struct _vl_api_want_ip6_fib_stats {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 enable_disable;
    u32 pid;
}) vl_api_want_ip6_fib_stats_t;

typedef VL_API_PACKED(struct _vl_api_want_ip6_fib_stats_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_want_ip6_fib_stats_reply_t;

typedef VL_API_PACKED(struct _vl_api_want_ip4_nbr_stats {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 enable_disable;
    u32 pid;
}) vl_api_want_ip4_nbr_stats_t;

typedef VL_API_PACKED(struct _vl_api_want_ip4_nbr_stats_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_want_ip4_nbr_stats_reply_t;

typedef VL_API_PACKED(struct _vl_api_want_ip6_nbr_stats {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 enable_disable;
    u32 pid;
}) vl_api_want_ip6_nbr_stats_t;

typedef VL_API_PACKED(struct _vl_api_want_ip6_nbr_stats_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_want_ip6_nbr_stats_reply_t;

typedef VL_API_PACKED(struct _vl_api_ip4_fib_counter {
    u32 address;
    u8 address_length;
    u64 packets;
    u64 bytes;
}) vl_api_ip4_fib_counter_t;

typedef VL_API_PACKED(struct _vl_api_vnet_ip4_fib_counters {
    u16 _vl_msg_id;
    u32 vrf_id;
    u32 count;
    vl_api_ip4_fib_counter_t c[0];
}) vl_api_vnet_ip4_fib_counters_t;

typedef VL_API_PACKED(struct _vl_api_ip4_nbr_counter {
    u32 address;
    u8 link_type;
    u64 packets;
    u64 bytes;
}) vl_api_ip4_nbr_counter_t;

typedef VL_API_PACKED(struct _vl_api_vnet_ip4_nbr_counters {
    u16 _vl_msg_id;
    u32 count;
    u32 sw_if_index;
    u8 begin;
    vl_api_ip4_nbr_counter_t c[0];
}) vl_api_vnet_ip4_nbr_counters_t;

typedef VL_API_PACKED(struct _vl_api_ip6_fib_counter {
    u64 address[2];
    u8 address_length;
    u64 packets;
    u64 bytes;
}) vl_api_ip6_fib_counter_t;

typedef VL_API_PACKED(struct _vl_api_vnet_ip6_fib_counters {
    u16 _vl_msg_id;
    u32 vrf_id;
    u32 count;
    vl_api_ip6_fib_counter_t c[0];
}) vl_api_vnet_ip6_fib_counters_t;

typedef VL_API_PACKED(struct _vl_api_ip6_nbr_counter {
    u64 address[2];
    u8 link_type;
    u64 packets;
    u64 bytes;
}) vl_api_ip6_nbr_counter_t;

typedef VL_API_PACKED(struct _vl_api_vnet_ip6_nbr_counters {
    u16 _vl_msg_id;
    u32 count;
    u32 sw_if_index;
    u8 begin;
    vl_api_ip6_nbr_counter_t c[0];
}) vl_api_vnet_ip6_nbr_counters_t;

typedef VL_API_PACKED(struct _vl_api_vnet_get_summary_stats {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_vnet_get_summary_stats_t;

typedef VL_API_PACKED(struct _vl_api_vnet_get_summary_stats_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u64 total_pkts[2];
    u64 total_bytes[2];
    f64 vector_rate;
}) vl_api_vnet_get_summary_stats_reply_t;

#endif /* vl_typedefs */

/****** Discriminated Union Definitions *****/

#ifdef vl_union_id


#endif /* vl_union_id */

/****** Print functions *****/

#ifdef vl_printfun

#ifdef LP64
#define _uword_fmt "%lld"
#define _uword_cast (long long)
#else
#define _uword_fmt "%ld"
#define _uword_cast long
#endif

static inline void *vl_api_want_stats_t_print (vl_api_want_stats_t *a,void *handle)
{
    vl_print(handle, "vl_api_want_stats_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "enable_disable: %u\n", (unsigned) a->enable_disable);
    vl_print(handle, "pid: %u\n", (unsigned) a->pid);
    return handle;
}

static inline void *vl_api_want_stats_reply_t_print (vl_api_want_stats_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_want_stats_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_want_interface_simple_stats_t_print (vl_api_want_interface_simple_stats_t *a,void *handle)
{
    vl_print(handle, "vl_api_want_interface_simple_stats_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "enable_disable: %u\n", (unsigned) a->enable_disable);
    vl_print(handle, "pid: %u\n", (unsigned) a->pid);
    return handle;
}

static inline void *vl_api_want_interface_simple_stats_reply_t_print (vl_api_want_interface_simple_stats_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_want_interface_simple_stats_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_want_per_interface_simple_stats_t_print (vl_api_want_per_interface_simple_stats_t *a,void *handle)
{
    vl_print(handle, "vl_api_want_per_interface_simple_stats_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "enable_disable: %u\n", (unsigned) a->enable_disable);
    vl_print(handle, "pid: %u\n", (unsigned) a->pid);
    vl_print(handle, "num: %u\n", (unsigned) a->num);
    return handle;
}

static inline void *vl_api_want_per_interface_simple_stats_reply_t_print (vl_api_want_per_interface_simple_stats_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_want_per_interface_simple_stats_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_want_interface_combined_stats_t_print (vl_api_want_interface_combined_stats_t *a,void *handle)
{
    vl_print(handle, "vl_api_want_interface_combined_stats_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "enable_disable: %u\n", (unsigned) a->enable_disable);
    vl_print(handle, "pid: %u\n", (unsigned) a->pid);
    return handle;
}

static inline void *vl_api_want_interface_combined_stats_reply_t_print (vl_api_want_interface_combined_stats_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_want_interface_combined_stats_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_want_per_interface_combined_stats_t_print (vl_api_want_per_interface_combined_stats_t *a,void *handle)
{
    vl_print(handle, "vl_api_want_per_interface_combined_stats_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "enable_disable: %u\n", (unsigned) a->enable_disable);
    vl_print(handle, "pid: %u\n", (unsigned) a->pid);
    vl_print(handle, "num: %u\n", (unsigned) a->num);
    return handle;
}

static inline void *vl_api_want_per_interface_combined_stats_reply_t_print (vl_api_want_per_interface_combined_stats_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_want_per_interface_combined_stats_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_want_ip4_fib_stats_t_print (vl_api_want_ip4_fib_stats_t *a,void *handle)
{
    vl_print(handle, "vl_api_want_ip4_fib_stats_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "enable_disable: %u\n", (unsigned) a->enable_disable);
    vl_print(handle, "pid: %u\n", (unsigned) a->pid);
    return handle;
}

static inline void *vl_api_want_ip4_fib_stats_reply_t_print (vl_api_want_ip4_fib_stats_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_want_ip4_fib_stats_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_want_ip6_fib_stats_t_print (vl_api_want_ip6_fib_stats_t *a,void *handle)
{
    vl_print(handle, "vl_api_want_ip6_fib_stats_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "enable_disable: %u\n", (unsigned) a->enable_disable);
    vl_print(handle, "pid: %u\n", (unsigned) a->pid);
    return handle;
}

static inline void *vl_api_want_ip6_fib_stats_reply_t_print (vl_api_want_ip6_fib_stats_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_want_ip6_fib_stats_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_want_ip4_nbr_stats_t_print (vl_api_want_ip4_nbr_stats_t *a,void *handle)
{
    vl_print(handle, "vl_api_want_ip4_nbr_stats_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "enable_disable: %u\n", (unsigned) a->enable_disable);
    vl_print(handle, "pid: %u\n", (unsigned) a->pid);
    return handle;
}

static inline void *vl_api_want_ip4_nbr_stats_reply_t_print (vl_api_want_ip4_nbr_stats_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_want_ip4_nbr_stats_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_want_ip6_nbr_stats_t_print (vl_api_want_ip6_nbr_stats_t *a,void *handle)
{
    vl_print(handle, "vl_api_want_ip6_nbr_stats_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "enable_disable: %u\n", (unsigned) a->enable_disable);
    vl_print(handle, "pid: %u\n", (unsigned) a->pid);
    return handle;
}

static inline void *vl_api_want_ip6_nbr_stats_reply_t_print (vl_api_want_ip6_nbr_stats_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_want_ip6_nbr_stats_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

/***** manual: vl_api_ip4_fib_counter_t_print  *****/

/***** manual: vl_api_vnet_ip4_fib_counters_t_print  *****/

/***** manual: vl_api_ip4_nbr_counter_t_print  *****/

/***** manual: vl_api_vnet_ip4_nbr_counters_t_print  *****/

/***** manual: vl_api_ip6_fib_counter_t_print  *****/

/***** manual: vl_api_vnet_ip6_fib_counters_t_print  *****/

/***** manual: vl_api_ip6_nbr_counter_t_print  *****/

/***** manual: vl_api_vnet_ip6_nbr_counters_t_print  *****/

static inline void *vl_api_vnet_get_summary_stats_t_print (vl_api_vnet_get_summary_stats_t *a,void *handle)
{
    vl_print(handle, "vl_api_vnet_get_summary_stats_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_vnet_get_summary_stats_reply_t_print (vl_api_vnet_get_summary_stats_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_vnet_get_summary_stats_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    {
        int _i;
        for (_i = 0; _i < 2; _i++) {
            vl_print(handle, "total_pkts[%d]: %llu\n", _i, a->total_pkts[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 2; _i++) {
            vl_print(handle, "total_bytes[%d]: %llu\n", _i, a->total_bytes[_i]);
        }
    }
    vl_print(handle, "vector_rate: %.2f\n", (double) a->vector_rate);
    return handle;
}

#endif /* vl_printfun */


/****** Endian swap functions *****/

#ifdef vl_endianfun

#undef clib_net_to_host_uword
#ifdef LP64
#define clib_net_to_host_uword clib_net_to_host_u64
#else
#define clib_net_to_host_uword clib_net_to_host_u32
#endif

static inline void vl_api_want_stats_t_endian (vl_api_want_stats_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->enable_disable = clib_net_to_host_u32(a->enable_disable);
    a->pid = clib_net_to_host_u32(a->pid);
}

static inline void vl_api_want_stats_reply_t_endian (vl_api_want_stats_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_want_interface_simple_stats_t_endian (vl_api_want_interface_simple_stats_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->enable_disable = clib_net_to_host_u32(a->enable_disable);
    a->pid = clib_net_to_host_u32(a->pid);
}

static inline void vl_api_want_interface_simple_stats_reply_t_endian (vl_api_want_interface_simple_stats_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_want_per_interface_simple_stats_t_endian (vl_api_want_per_interface_simple_stats_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->enable_disable = clib_net_to_host_u32(a->enable_disable);
    a->pid = clib_net_to_host_u32(a->pid);
    a->num = clib_net_to_host_u32(a->num);
}

static inline void vl_api_want_per_interface_simple_stats_reply_t_endian (vl_api_want_per_interface_simple_stats_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_want_interface_combined_stats_t_endian (vl_api_want_interface_combined_stats_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->enable_disable = clib_net_to_host_u32(a->enable_disable);
    a->pid = clib_net_to_host_u32(a->pid);
}

static inline void vl_api_want_interface_combined_stats_reply_t_endian (vl_api_want_interface_combined_stats_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_want_per_interface_combined_stats_t_endian (vl_api_want_per_interface_combined_stats_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->enable_disable = clib_net_to_host_u32(a->enable_disable);
    a->pid = clib_net_to_host_u32(a->pid);
    a->num = clib_net_to_host_u32(a->num);
}

static inline void vl_api_want_per_interface_combined_stats_reply_t_endian (vl_api_want_per_interface_combined_stats_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_want_ip4_fib_stats_t_endian (vl_api_want_ip4_fib_stats_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->enable_disable = clib_net_to_host_u32(a->enable_disable);
    a->pid = clib_net_to_host_u32(a->pid);
}

static inline void vl_api_want_ip4_fib_stats_reply_t_endian (vl_api_want_ip4_fib_stats_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_want_ip6_fib_stats_t_endian (vl_api_want_ip6_fib_stats_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->enable_disable = clib_net_to_host_u32(a->enable_disable);
    a->pid = clib_net_to_host_u32(a->pid);
}

static inline void vl_api_want_ip6_fib_stats_reply_t_endian (vl_api_want_ip6_fib_stats_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_want_ip4_nbr_stats_t_endian (vl_api_want_ip4_nbr_stats_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->enable_disable = clib_net_to_host_u32(a->enable_disable);
    a->pid = clib_net_to_host_u32(a->pid);
}

static inline void vl_api_want_ip4_nbr_stats_reply_t_endian (vl_api_want_ip4_nbr_stats_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_want_ip6_nbr_stats_t_endian (vl_api_want_ip6_nbr_stats_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->enable_disable = clib_net_to_host_u32(a->enable_disable);
    a->pid = clib_net_to_host_u32(a->pid);
}

static inline void vl_api_want_ip6_nbr_stats_reply_t_endian (vl_api_want_ip6_nbr_stats_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

/***** manual: vl_api_ip4_fib_counter_t_endian  *****/

/***** manual: vl_api_vnet_ip4_fib_counters_t_endian  *****/

/***** manual: vl_api_ip4_nbr_counter_t_endian  *****/

/***** manual: vl_api_vnet_ip4_nbr_counters_t_endian  *****/

/***** manual: vl_api_ip6_fib_counter_t_endian  *****/

/***** manual: vl_api_vnet_ip6_fib_counters_t_endian  *****/

/***** manual: vl_api_ip6_nbr_counter_t_endian  *****/

/***** manual: vl_api_vnet_ip6_nbr_counters_t_endian  *****/

static inline void vl_api_vnet_get_summary_stats_t_endian (vl_api_vnet_get_summary_stats_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_vnet_get_summary_stats_reply_t_endian (vl_api_vnet_get_summary_stats_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    {
        int _i;
        for (_i = 0; _i < 2; _i++) {
            a->total_pkts[_i] = clib_net_to_host_u64(a->total_pkts[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 2; _i++) {
            a->total_bytes[_i] = clib_net_to_host_u64(a->total_bytes[_i]);
        }
    }
    a->vector_rate =  (a->vector_rate);
}

#endif /* vl_endianfun */


#ifdef vl_api_version
vl_api_version(stats.api, 0xe8ea8b53)

#endif

