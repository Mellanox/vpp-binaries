/*
 * VLIB API definitions Mon Oct 30 07:41:50 2017
 * Input file: acl/acl.api.h
 * Automatically generated: please edit the input file NOT this file!
 */

#if defined(vl_msg_id)||defined(vl_union_id)||defined(vl_printfun) \
 ||defined(vl_endianfun)|| defined(vl_api_version)||defined(vl_typedefs) \
 ||defined(vl_msg_name)||defined(vl_msg_name_crc_list)
/* ok, something was selected */
#else
#warning no content included from acl/acl.api.h
#endif

#define VL_API_PACKED(x) x __attribute__ ((packed))


/****** Message ID / handler enum ******/

#ifdef vl_msg_id
vl_msg_id(VL_API_ACL_PLUGIN_GET_VERSION, vl_api_acl_plugin_get_version_t_handler)
vl_msg_id(VL_API_ACL_PLUGIN_GET_VERSION_REPLY, vl_api_acl_plugin_get_version_reply_t_handler)
vl_msg_id(VL_API_ACL_PLUGIN_CONTROL_PING, vl_api_acl_plugin_control_ping_t_handler)
vl_msg_id(VL_API_ACL_PLUGIN_CONTROL_PING_REPLY, vl_api_acl_plugin_control_ping_reply_t_handler)
/* typeonly: acl_rule */
/* typeonly: macip_acl_rule */
vl_msg_id(VL_API_ACL_ADD_REPLACE, vl_api_acl_add_replace_t_handler)
vl_msg_id(VL_API_ACL_ADD_REPLACE_REPLY, vl_api_acl_add_replace_reply_t_handler)
vl_msg_id(VL_API_ACL_DEL, vl_api_acl_del_t_handler)
vl_msg_id(VL_API_ACL_DEL_REPLY, vl_api_acl_del_reply_t_handler)
vl_msg_id(VL_API_ACL_INTERFACE_ADD_DEL, vl_api_acl_interface_add_del_t_handler)
vl_msg_id(VL_API_ACL_INTERFACE_ADD_DEL_REPLY, vl_api_acl_interface_add_del_reply_t_handler)
vl_msg_id(VL_API_ACL_INTERFACE_SET_ACL_LIST, vl_api_acl_interface_set_acl_list_t_handler)
vl_msg_id(VL_API_ACL_INTERFACE_SET_ACL_LIST_REPLY, vl_api_acl_interface_set_acl_list_reply_t_handler)
vl_msg_id(VL_API_ACL_DUMP, vl_api_acl_dump_t_handler)
vl_msg_id(VL_API_ACL_DETAILS, vl_api_acl_details_t_handler)
vl_msg_id(VL_API_ACL_INTERFACE_LIST_DUMP, vl_api_acl_interface_list_dump_t_handler)
vl_msg_id(VL_API_ACL_INTERFACE_LIST_DETAILS, vl_api_acl_interface_list_details_t_handler)
vl_msg_id(VL_API_MACIP_ACL_ADD, vl_api_macip_acl_add_t_handler)
vl_msg_id(VL_API_MACIP_ACL_ADD_REPLY, vl_api_macip_acl_add_reply_t_handler)
vl_msg_id(VL_API_MACIP_ACL_ADD_REPLACE, vl_api_macip_acl_add_replace_t_handler)
vl_msg_id(VL_API_MACIP_ACL_ADD_REPLACE_REPLY, vl_api_macip_acl_add_replace_reply_t_handler)
vl_msg_id(VL_API_MACIP_ACL_DEL, vl_api_macip_acl_del_t_handler)
vl_msg_id(VL_API_MACIP_ACL_DEL_REPLY, vl_api_macip_acl_del_reply_t_handler)
vl_msg_id(VL_API_MACIP_ACL_INTERFACE_ADD_DEL, vl_api_macip_acl_interface_add_del_t_handler)
vl_msg_id(VL_API_MACIP_ACL_INTERFACE_ADD_DEL_REPLY, vl_api_macip_acl_interface_add_del_reply_t_handler)
vl_msg_id(VL_API_MACIP_ACL_DUMP, vl_api_macip_acl_dump_t_handler)
vl_msg_id(VL_API_MACIP_ACL_DETAILS, vl_api_macip_acl_details_t_handler)
vl_msg_id(VL_API_MACIP_ACL_INTERFACE_GET, vl_api_macip_acl_interface_get_t_handler)
vl_msg_id(VL_API_MACIP_ACL_INTERFACE_GET_REPLY, vl_api_macip_acl_interface_get_reply_t_handler)
vl_msg_id(VL_API_MACIP_ACL_INTERFACE_LIST_DUMP, vl_api_macip_acl_interface_list_dump_t_handler)
vl_msg_id(VL_API_MACIP_ACL_INTERFACE_LIST_DETAILS, vl_api_macip_acl_interface_list_details_t_handler)
#endif

/****** Message names ******/

#ifdef vl_msg_name
vl_msg_name(vl_api_acl_plugin_get_version_t, 1)
vl_msg_name(vl_api_acl_plugin_get_version_reply_t, 1)
vl_msg_name(vl_api_acl_plugin_control_ping_t, 1)
vl_msg_name(vl_api_acl_plugin_control_ping_reply_t, 1)
/* typeonly: acl_rule */
/* typeonly: macip_acl_rule */
vl_msg_name(vl_api_acl_add_replace_t, 1)
vl_msg_name(vl_api_acl_add_replace_reply_t, 1)
vl_msg_name(vl_api_acl_del_t, 1)
vl_msg_name(vl_api_acl_del_reply_t, 1)
vl_msg_name(vl_api_acl_interface_add_del_t, 1)
vl_msg_name(vl_api_acl_interface_add_del_reply_t, 1)
vl_msg_name(vl_api_acl_interface_set_acl_list_t, 1)
vl_msg_name(vl_api_acl_interface_set_acl_list_reply_t, 1)
vl_msg_name(vl_api_acl_dump_t, 1)
vl_msg_name(vl_api_acl_details_t, 1)
vl_msg_name(vl_api_acl_interface_list_dump_t, 1)
vl_msg_name(vl_api_acl_interface_list_details_t, 1)
vl_msg_name(vl_api_macip_acl_add_t, 1)
vl_msg_name(vl_api_macip_acl_add_reply_t, 1)
vl_msg_name(vl_api_macip_acl_add_replace_t, 1)
vl_msg_name(vl_api_macip_acl_add_replace_reply_t, 1)
vl_msg_name(vl_api_macip_acl_del_t, 1)
vl_msg_name(vl_api_macip_acl_del_reply_t, 1)
vl_msg_name(vl_api_macip_acl_interface_add_del_t, 1)
vl_msg_name(vl_api_macip_acl_interface_add_del_reply_t, 1)
vl_msg_name(vl_api_macip_acl_dump_t, 1)
vl_msg_name(vl_api_macip_acl_details_t, 1)
vl_msg_name(vl_api_macip_acl_interface_get_t, 1)
vl_msg_name(vl_api_macip_acl_interface_get_reply_t, 1)
vl_msg_name(vl_api_macip_acl_interface_list_dump_t, 1)
vl_msg_name(vl_api_macip_acl_interface_list_details_t, 1)
#endif


/****** Message name, crc list ******/

#ifdef vl_msg_name_crc_list
#define foreach_vl_msg_name_crc_acl \
_(VL_API_ACL_PLUGIN_GET_VERSION, acl_plugin_get_version, d7c07748) \
_(VL_API_ACL_PLUGIN_GET_VERSION_REPLY, acl_plugin_get_version_reply, 43eb59a5) \
_(VL_API_ACL_PLUGIN_CONTROL_PING, acl_plugin_control_ping, fc22c86e) \
_(VL_API_ACL_PLUGIN_CONTROL_PING_REPLY, acl_plugin_control_ping_reply, e07e9231) \
_(VL_API_ACL_ADD_REPLACE, acl_add_replace, 3c317936) \
_(VL_API_ACL_ADD_REPLACE_REPLY, acl_add_replace_reply, a5e6d0cf) \
_(VL_API_ACL_DEL, acl_del, 82cc30ed) \
_(VL_API_ACL_DEL_REPLY, acl_del_reply, bbb83d84) \
_(VL_API_ACL_INTERFACE_ADD_DEL, acl_interface_add_del, 98b53725) \
_(VL_API_ACL_INTERFACE_ADD_DEL_REPLY, acl_interface_add_del_reply, c1b3c077) \
_(VL_API_ACL_INTERFACE_SET_ACL_LIST, acl_interface_set_acl_list, 7562419c) \
_(VL_API_ACL_INTERFACE_SET_ACL_LIST_REPLY, acl_interface_set_acl_list_reply, 435ddc2b) \
_(VL_API_ACL_DUMP, acl_dump, c188156d) \
_(VL_API_ACL_DETAILS, acl_details, 1c8916b7) \
_(VL_API_ACL_INTERFACE_LIST_DUMP, acl_interface_list_dump, adfe84b8) \
_(VL_API_ACL_INTERFACE_LIST_DETAILS, acl_interface_list_details, c8150656) \
_(VL_API_MACIP_ACL_ADD, macip_acl_add, 33356284) \
_(VL_API_MACIP_ACL_ADD_REPLY, macip_acl_add_reply, 472edb4c) \
_(VL_API_MACIP_ACL_ADD_REPLACE, macip_acl_add_replace, d6f92681) \
_(VL_API_MACIP_ACL_ADD_REPLACE_REPLY, macip_acl_add_replace_reply, 650701c2) \
_(VL_API_MACIP_ACL_DEL, macip_acl_del, dde1141f) \
_(VL_API_MACIP_ACL_DEL_REPLY, macip_acl_del_reply, eeb60e0f) \
_(VL_API_MACIP_ACL_INTERFACE_ADD_DEL, macip_acl_interface_add_del, 03a4fab2) \
_(VL_API_MACIP_ACL_INTERFACE_ADD_DEL_REPLY, macip_acl_interface_add_del_reply, 9e9ee485) \
_(VL_API_MACIP_ACL_DUMP, macip_acl_dump, d38227cb) \
_(VL_API_MACIP_ACL_DETAILS, macip_acl_details, ee1c50db) \
_(VL_API_MACIP_ACL_INTERFACE_GET, macip_acl_interface_get, 317ce31c) \
_(VL_API_MACIP_ACL_INTERFACE_GET_REPLY, macip_acl_interface_get_reply, 6c86a56c) \
_(VL_API_MACIP_ACL_INTERFACE_LIST_DUMP, macip_acl_interface_list_dump, 10645403) \
_(VL_API_MACIP_ACL_INTERFACE_LIST_DETAILS, macip_acl_interface_list_details, d38dc074) 
#endif


/****** Typedefs *****/

#ifdef vl_typedefs

typedef VL_API_PACKED(struct _vl_api_acl_plugin_get_version {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_acl_plugin_get_version_t;

typedef VL_API_PACKED(struct _vl_api_acl_plugin_get_version_reply {
    u16 _vl_msg_id;
    u32 context;
    u32 major;
    u32 minor;
}) vl_api_acl_plugin_get_version_reply_t;

typedef VL_API_PACKED(struct _vl_api_acl_plugin_control_ping {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_acl_plugin_control_ping_t;

typedef VL_API_PACKED(struct _vl_api_acl_plugin_control_ping_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 client_index;
    u32 vpe_pid;
}) vl_api_acl_plugin_control_ping_reply_t;

typedef VL_API_PACKED(struct _vl_api_acl_rule {
    u8 is_permit;
    u8 is_ipv6;
    u8 src_ip_addr[16];
    u8 src_ip_prefix_len;
    u8 dst_ip_addr[16];
    u8 dst_ip_prefix_len;
    u8 proto;
    u16 srcport_or_icmptype_first;
    u16 srcport_or_icmptype_last;
    u16 dstport_or_icmpcode_first;
    u16 dstport_or_icmpcode_last;
    u8 tcp_flags_mask;
    u8 tcp_flags_value;
}) vl_api_acl_rule_t;

typedef VL_API_PACKED(struct _vl_api_macip_acl_rule {
    u8 is_permit;
    u8 is_ipv6;
    u8 src_mac[6];
    u8 src_mac_mask[6];
    u8 src_ip_addr[16];
    u8 src_ip_prefix_len;
}) vl_api_macip_acl_rule_t;

typedef VL_API_PACKED(struct _vl_api_acl_add_replace {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 acl_index;
    u8 tag[64];
    u32 count;
    vl_api_acl_rule_t r[0];
}) vl_api_acl_add_replace_t;

typedef VL_API_PACKED(struct _vl_api_acl_add_replace_reply {
    u16 _vl_msg_id;
    u32 context;
    u32 acl_index;
    i32 retval;
}) vl_api_acl_add_replace_reply_t;

typedef VL_API_PACKED(struct _vl_api_acl_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 acl_index;
}) vl_api_acl_del_t;

typedef VL_API_PACKED(struct _vl_api_acl_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_acl_del_reply_t;

typedef VL_API_PACKED(struct _vl_api_acl_interface_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 is_input;
    u32 sw_if_index;
    u32 acl_index;
}) vl_api_acl_interface_add_del_t;

typedef VL_API_PACKED(struct _vl_api_acl_interface_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_acl_interface_add_del_reply_t;

typedef VL_API_PACKED(struct _vl_api_acl_interface_set_acl_list {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u8 count;
    u8 n_input;
    u32 acls[0];
}) vl_api_acl_interface_set_acl_list_t;

typedef VL_API_PACKED(struct _vl_api_acl_interface_set_acl_list_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_acl_interface_set_acl_list_reply_t;

typedef VL_API_PACKED(struct _vl_api_acl_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 acl_index;
}) vl_api_acl_dump_t;

typedef VL_API_PACKED(struct _vl_api_acl_details {
    u16 _vl_msg_id;
    u32 context;
    u32 acl_index;
    u8 tag[64];
    u32 count;
    vl_api_acl_rule_t r[0];
}) vl_api_acl_details_t;

typedef VL_API_PACKED(struct _vl_api_acl_interface_list_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
}) vl_api_acl_interface_list_dump_t;

typedef VL_API_PACKED(struct _vl_api_acl_interface_list_details {
    u16 _vl_msg_id;
    u32 context;
    u32 sw_if_index;
    u8 count;
    u8 n_input;
    u32 acls[0];
}) vl_api_acl_interface_list_details_t;

typedef VL_API_PACKED(struct _vl_api_macip_acl_add {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 tag[64];
    u32 count;
    vl_api_macip_acl_rule_t r[0];
}) vl_api_macip_acl_add_t;

typedef VL_API_PACKED(struct _vl_api_macip_acl_add_reply {
    u16 _vl_msg_id;
    u32 context;
    u32 acl_index;
    i32 retval;
}) vl_api_macip_acl_add_reply_t;

typedef VL_API_PACKED(struct _vl_api_macip_acl_add_replace {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 acl_index;
    u8 tag[64];
    u32 count;
    vl_api_macip_acl_rule_t r[0];
}) vl_api_macip_acl_add_replace_t;

typedef VL_API_PACKED(struct _vl_api_macip_acl_add_replace_reply {
    u16 _vl_msg_id;
    u32 context;
    u32 acl_index;
    i32 retval;
}) vl_api_macip_acl_add_replace_reply_t;

typedef VL_API_PACKED(struct _vl_api_macip_acl_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 acl_index;
}) vl_api_macip_acl_del_t;

typedef VL_API_PACKED(struct _vl_api_macip_acl_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_macip_acl_del_reply_t;

typedef VL_API_PACKED(struct _vl_api_macip_acl_interface_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u32 sw_if_index;
    u32 acl_index;
}) vl_api_macip_acl_interface_add_del_t;

typedef VL_API_PACKED(struct _vl_api_macip_acl_interface_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_macip_acl_interface_add_del_reply_t;

typedef VL_API_PACKED(struct _vl_api_macip_acl_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 acl_index;
}) vl_api_macip_acl_dump_t;

typedef VL_API_PACKED(struct _vl_api_macip_acl_details {
    u16 _vl_msg_id;
    u32 context;
    u32 acl_index;
    u8 tag[64];
    u32 count;
    vl_api_macip_acl_rule_t r[0];
}) vl_api_macip_acl_details_t;

typedef VL_API_PACKED(struct _vl_api_macip_acl_interface_get {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_macip_acl_interface_get_t;

typedef VL_API_PACKED(struct _vl_api_macip_acl_interface_get_reply {
    u16 _vl_msg_id;
    u32 context;
    u32 count;
    u32 acls[0];
}) vl_api_macip_acl_interface_get_reply_t;

typedef VL_API_PACKED(struct _vl_api_macip_acl_interface_list_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
}) vl_api_macip_acl_interface_list_dump_t;

typedef VL_API_PACKED(struct _vl_api_macip_acl_interface_list_details {
    u16 _vl_msg_id;
    u32 context;
    u32 sw_if_index;
    u8 count;
    u32 acls[0];
}) vl_api_macip_acl_interface_list_details_t;

#endif /* vl_typedefs */

/****** Discriminated Union Definitions *****/

#ifdef vl_union_id


#endif /* vl_union_id */

/****** Print functions *****/

#ifdef vl_printfun

#ifdef LP64
#define _uword_fmt "%lld"
#define _uword_cast (long long)
#else
#define _uword_fmt "%ld"
#define _uword_cast long
#endif

static inline void *vl_api_acl_plugin_get_version_t_print (vl_api_acl_plugin_get_version_t *a,void *handle)
{
    vl_print(handle, "vl_api_acl_plugin_get_version_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_acl_plugin_get_version_reply_t_print (vl_api_acl_plugin_get_version_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_acl_plugin_get_version_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "major: %u\n", (unsigned) a->major);
    vl_print(handle, "minor: %u\n", (unsigned) a->minor);
    return handle;
}

static inline void *vl_api_acl_plugin_control_ping_t_print (vl_api_acl_plugin_control_ping_t *a,void *handle)
{
    vl_print(handle, "vl_api_acl_plugin_control_ping_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_acl_plugin_control_ping_reply_t_print (vl_api_acl_plugin_control_ping_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_acl_plugin_control_ping_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "vpe_pid: %u\n", (unsigned) a->vpe_pid);
    return handle;
}

/***** manual: vl_api_acl_rule_t_print  *****/

/***** manual: vl_api_macip_acl_rule_t_print  *****/

/***** manual: vl_api_acl_add_replace_t_print  *****/

static inline void *vl_api_acl_add_replace_reply_t_print (vl_api_acl_add_replace_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_acl_add_replace_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "acl_index: %u\n", (unsigned) a->acl_index);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

/***** manual: vl_api_acl_del_t_print  *****/

static inline void *vl_api_acl_del_reply_t_print (vl_api_acl_del_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_acl_del_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

/***** manual: vl_api_acl_interface_add_del_t_print  *****/

static inline void *vl_api_acl_interface_add_del_reply_t_print (vl_api_acl_interface_add_del_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_acl_interface_add_del_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

/***** manual: vl_api_acl_interface_set_acl_list_t_print  *****/

static inline void *vl_api_acl_interface_set_acl_list_reply_t_print (vl_api_acl_interface_set_acl_list_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_acl_interface_set_acl_list_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_acl_dump_t_print (vl_api_acl_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_acl_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "acl_index: %u\n", (unsigned) a->acl_index);
    return handle;
}

/***** manual: vl_api_acl_details_t_print  *****/

static inline void *vl_api_acl_interface_list_dump_t_print (vl_api_acl_interface_list_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_acl_interface_list_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    return handle;
}

static inline void *vl_api_acl_interface_list_details_t_print (vl_api_acl_interface_list_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_acl_interface_list_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "count: %u\n", (unsigned) a->count);
    vl_print(handle, "n_input: %u\n", (unsigned) a->n_input);
    return handle;
}

/***** manual: vl_api_macip_acl_add_t_print  *****/

static inline void *vl_api_macip_acl_add_reply_t_print (vl_api_macip_acl_add_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_macip_acl_add_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "acl_index: %u\n", (unsigned) a->acl_index);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

/***** manual: vl_api_macip_acl_add_replace_t_print  *****/

static inline void *vl_api_macip_acl_add_replace_reply_t_print (vl_api_macip_acl_add_replace_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_macip_acl_add_replace_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "acl_index: %u\n", (unsigned) a->acl_index);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

/***** manual: vl_api_macip_acl_del_t_print  *****/

static inline void *vl_api_macip_acl_del_reply_t_print (vl_api_macip_acl_del_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_macip_acl_del_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

/***** manual: vl_api_macip_acl_interface_add_del_t_print  *****/

static inline void *vl_api_macip_acl_interface_add_del_reply_t_print (vl_api_macip_acl_interface_add_del_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_macip_acl_interface_add_del_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_macip_acl_dump_t_print (vl_api_macip_acl_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_macip_acl_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "acl_index: %u\n", (unsigned) a->acl_index);
    return handle;
}

/***** manual: vl_api_macip_acl_details_t_print  *****/

static inline void *vl_api_macip_acl_interface_get_t_print (vl_api_macip_acl_interface_get_t *a,void *handle)
{
    vl_print(handle, "vl_api_macip_acl_interface_get_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_macip_acl_interface_get_reply_t_print (vl_api_macip_acl_interface_get_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_macip_acl_interface_get_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "count: %u\n", (unsigned) a->count);
    return handle;
}

static inline void *vl_api_macip_acl_interface_list_dump_t_print (vl_api_macip_acl_interface_list_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_macip_acl_interface_list_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    return handle;
}

static inline void *vl_api_macip_acl_interface_list_details_t_print (vl_api_macip_acl_interface_list_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_macip_acl_interface_list_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "count: %u\n", (unsigned) a->count);
    return handle;
}

#endif /* vl_printfun */


/****** Endian swap functions *****/

#ifdef vl_endianfun

#undef clib_net_to_host_uword
#ifdef LP64
#define clib_net_to_host_uword clib_net_to_host_u64
#else
#define clib_net_to_host_uword clib_net_to_host_u32
#endif

static inline void vl_api_acl_plugin_get_version_t_endian (vl_api_acl_plugin_get_version_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_acl_plugin_get_version_reply_t_endian (vl_api_acl_plugin_get_version_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->major = clib_net_to_host_u32(a->major);
    a->minor = clib_net_to_host_u32(a->minor);
}

static inline void vl_api_acl_plugin_control_ping_t_endian (vl_api_acl_plugin_control_ping_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_acl_plugin_control_ping_reply_t_endian (vl_api_acl_plugin_control_ping_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->vpe_pid = clib_net_to_host_u32(a->vpe_pid);
}

static inline void vl_api_acl_rule_t_endian (vl_api_acl_rule_t *a)
{
    /* a->is_permit = a->is_permit (no-op) */
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    /* a->src_ip_addr[0..15] = a->src_ip_addr[0..15] (no-op) */
    /* a->src_ip_prefix_len = a->src_ip_prefix_len (no-op) */
    /* a->dst_ip_addr[0..15] = a->dst_ip_addr[0..15] (no-op) */
    /* a->dst_ip_prefix_len = a->dst_ip_prefix_len (no-op) */
    /* a->proto = a->proto (no-op) */
    a->srcport_or_icmptype_first = clib_net_to_host_u16(a->srcport_or_icmptype_first);
    a->srcport_or_icmptype_last = clib_net_to_host_u16(a->srcport_or_icmptype_last);
    a->dstport_or_icmpcode_first = clib_net_to_host_u16(a->dstport_or_icmpcode_first);
    a->dstport_or_icmpcode_last = clib_net_to_host_u16(a->dstport_or_icmpcode_last);
    /* a->tcp_flags_mask = a->tcp_flags_mask (no-op) */
    /* a->tcp_flags_value = a->tcp_flags_value (no-op) */
}

static inline void vl_api_macip_acl_rule_t_endian (vl_api_macip_acl_rule_t *a)
{
    /* a->is_permit = a->is_permit (no-op) */
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    /* a->src_mac[0..5] = a->src_mac[0..5] (no-op) */
    /* a->src_mac_mask[0..5] = a->src_mac_mask[0..5] (no-op) */
    /* a->src_ip_addr[0..15] = a->src_ip_addr[0..15] (no-op) */
    /* a->src_ip_prefix_len = a->src_ip_prefix_len (no-op) */
}

/***** manual: vl_api_acl_add_replace_t_endian  *****/

static inline void vl_api_acl_add_replace_reply_t_endian (vl_api_acl_add_replace_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->acl_index = clib_net_to_host_u32(a->acl_index);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_acl_del_t_endian (vl_api_acl_del_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->acl_index = clib_net_to_host_u32(a->acl_index);
}

static inline void vl_api_acl_del_reply_t_endian (vl_api_acl_del_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_acl_interface_add_del_t_endian (vl_api_acl_interface_add_del_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    /* a->is_input = a->is_input (no-op) */
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    a->acl_index = clib_net_to_host_u32(a->acl_index);
}

static inline void vl_api_acl_interface_add_del_reply_t_endian (vl_api_acl_interface_add_del_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_acl_interface_set_acl_list_t_endian (vl_api_acl_interface_set_acl_list_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->count = a->count (no-op) */
    /* a->n_input = a->n_input (no-op) */
}

static inline void vl_api_acl_interface_set_acl_list_reply_t_endian (vl_api_acl_interface_set_acl_list_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_acl_dump_t_endian (vl_api_acl_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->acl_index = clib_net_to_host_u32(a->acl_index);
}

/***** manual: vl_api_acl_details_t_endian  *****/

static inline void vl_api_acl_interface_list_dump_t_endian (vl_api_acl_interface_list_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
}

static inline void vl_api_acl_interface_list_details_t_endian (vl_api_acl_interface_list_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->count = a->count (no-op) */
    /* a->n_input = a->n_input (no-op) */
}

/***** manual: vl_api_macip_acl_add_t_endian  *****/

static inline void vl_api_macip_acl_add_reply_t_endian (vl_api_macip_acl_add_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->acl_index = clib_net_to_host_u32(a->acl_index);
    a->retval = clib_net_to_host_u32(a->retval);
}

/***** manual: vl_api_macip_acl_add_replace_t_endian  *****/

static inline void vl_api_macip_acl_add_replace_reply_t_endian (vl_api_macip_acl_add_replace_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->acl_index = clib_net_to_host_u32(a->acl_index);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_macip_acl_del_t_endian (vl_api_macip_acl_del_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->acl_index = clib_net_to_host_u32(a->acl_index);
}

static inline void vl_api_macip_acl_del_reply_t_endian (vl_api_macip_acl_del_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_macip_acl_interface_add_del_t_endian (vl_api_macip_acl_interface_add_del_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    a->acl_index = clib_net_to_host_u32(a->acl_index);
}

static inline void vl_api_macip_acl_interface_add_del_reply_t_endian (vl_api_macip_acl_interface_add_del_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_macip_acl_dump_t_endian (vl_api_macip_acl_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->acl_index = clib_net_to_host_u32(a->acl_index);
}

/***** manual: vl_api_macip_acl_details_t_endian  *****/

static inline void vl_api_macip_acl_interface_get_t_endian (vl_api_macip_acl_interface_get_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_macip_acl_interface_get_reply_t_endian (vl_api_macip_acl_interface_get_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->count = clib_net_to_host_u32(a->count);
}

static inline void vl_api_macip_acl_interface_list_dump_t_endian (vl_api_macip_acl_interface_list_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
}

static inline void vl_api_macip_acl_interface_list_details_t_endian (vl_api_macip_acl_interface_list_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->count = a->count (no-op) */
}

#endif /* vl_endianfun */


#ifdef vl_api_version
vl_api_version(acl.api, 0xd7a26377)

#endif

